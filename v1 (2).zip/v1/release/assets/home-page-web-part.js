(()=>{ var __RUSHSTACK_CURRENT_SCRIPT__ = document.currentScript; define("ebc404b0-c2df-41b6-ac41-fd90a265f239_0.0.1", ["react","react-dom","@microsoft/sp-core-library","@microsoft/sp-property-pane","@microsoft/sp-webpart-base","HomePageWebPartStrings","@microsoft/sp-http"], (__WEBPACK_EXTERNAL_MODULE__959__, __WEBPACK_EXTERNAL_MODULE__398__, __WEBPACK_EXTERNAL_MODULE__676__, __WEBPACK_EXTERNAL_MODULE__877__, __WEBPACK_EXTERNAL_MODULE__642__, __WEBPACK_EXTERNAL_MODULE__299__, __WEBPACK_EXTERNAL_MODULE__909__) => { return /******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 591:
/*!**************************************************************!*\
  !*** ./lib/webparts/homePage/components/HomePage.module.css ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_microsoft_sp_css_loader_node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/@microsoft/sp-css-loader/node_modules/@microsoft/load-themed-styles/lib-es6/index.js */ 323);
// Imports


_node_modules_microsoft_sp_css_loader_node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__.loadStyles(".homePage_2a396803{--hub-bg:#17171d;--hub-panel:#202027;--hub-text:#f7f7f5;--hub-muted:#b7b7bd;--hub-yellow:#ffe600;--hub-pink:#e8288f;--hub-cyan:#29c3e0;background:var(--hub-bg);color:var(--hub-text);height:100vh;left:0;line-height:1.5;overflow:hidden;overflow:auto;position:fixed;scroll-behavior:smooth;top:0;width:100%;z-index:999999}.homePage_2a396803,.homePage_2a396803 button{font-family:Arial,sans-serif}.hero_2a396803{isolation:isolate;min-height:100svh;overflow:hidden;position:relative}.heroGrid_2a396803,.heroImage_2a396803,.heroShade_2a396803{inset:0;pointer-events:none;position:absolute}.heroImage_2a396803{background:url(https://images.unsplash.com/photo-1541746972996-4e0b0f43e02a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=2000) center 42%/cover no-repeat;transform:scale(1.06);z-index:-3}.heroShade_2a396803{background:linear-gradient(180deg,rgba(23,23,29,.76),rgba(23,23,29,.82) 52%,#17171d),linear-gradient(90deg,rgba(23,23,29,.94),rgba(23,23,29,.44) 64%,transparent);z-index:-2}.heroGrid_2a396803{background-image:linear-gradient(90deg,#fff 1px,transparent 0),linear-gradient(#fff 1px,transparent 0);background-size:64px 64px;mask-image:radial-gradient(at 30% 40%,#000 20%,transparent 70%);opacity:.06;z-index:-1}.heroInner_2a396803,.sectionInner_2a396803{margin-inline:auto;width:min(100% - 40px,1280px)}.heroInner_2a396803{display:flex;flex-direction:column;min-height:100svh}.header_2a396803{align-items:center;display:flex;gap:24px;justify-content:space-between;padding-block:24px}.brandLink_2a396803{color:inherit;text-decoration:none}.brand_2a396803{align-items:flex-end;display:flex;gap:10px}.brandMark_2a396803{font-size:30px;font-weight:750;letter-spacing:0;line-height:.95;position:relative}.brandMark_2a396803:before{background:var(--hub-yellow);content:\"\";height:7px;left:0;position:absolute;top:-9px;transform:skewY(-12deg);transform-origin:left;width:36px}.brandTagline_2a396803{color:hsla(0,0%,100%,.82);font-size:11px;font-weight:550;line-height:1.15}.navigation_2a396803{align-items:center;backdrop-filter:blur(12px);background:hsla(0,0%,100%,.05);border:1px solid hsla(0,0%,100%,.12);border-radius:999px;display:flex;gap:3px;padding:4px}.navigation_2a396803 a{border-radius:999px;color:hsla(0,0%,100%,.82);font-size:14px;padding:9px 16px;text-decoration:none;transition:background-color .18s,color .18s}.navigation_2a396803 a:focus-visible,.navigation_2a396803 a:hover{background:var(--hub-yellow);color:#17171d;outline:0}.heroCopy_2a396803{animation:riseIn_2a396803 .7s ease-out both;display:flex;flex:1;flex-direction:column;justify-content:center;max-width:700px;padding:36px 0 0}.heroCopy_2a396803 h1{font-size:clamp(48px,7vw,88px);font-weight:650;line-height:.98;margin:0}.heroCopy_2a396803 h1 span{background:linear-gradient(90deg,var(--hub-yellow),#ffb800);background-clip:text;color:transparent}.heroCopy_2a396803>p{color:hsla(0,0%,100%,.78);font-size:18px;margin:20px 0 0;max-width:590px}.portalArea_2a396803{padding-bottom:24px}.portalGrid_2a396803{display:grid;gap:16px;grid-template-columns:repeat(6,minmax(0,1fr))}.portalCard_2a396803{animation:riseIn_2a396803 .65s ease-out both;backdrop-filter:blur(20px);background:hsla(0,0%,100%,.055);border:1px solid hsla(0,0%,100%,.12);border-radius:12px;color:inherit;display:flex;flex-direction:column;min-width:0;overflow:hidden;position:relative;text-align:left;text-decoration:none;transition:border-color .2s,background-color .2s,transform .2s}.portalCard_2a396803:nth-child(2){animation-delay:60ms}.portalCard_2a396803:nth-child(3){animation-delay:.12s}.portalCard_2a396803:nth-child(4){animation-delay:.18s}.portalCard_2a396803:nth-child(5){animation-delay:.24s}.portalCard_2a396803:nth-child(6){animation-delay:.3s}.portalCard_2a396803:focus-visible,.portalCard_2a396803:hover{background:hsla(0,0%,100%,.11);border-color:rgba(255,230,0,.65);outline:0;transform:translateY(-3px)}.portalGlow_2a396803{background:0 0;border-radius:50%;filter:blur(35px);height:128px;position:absolute;right:-40px;top:-40px;transition:background-color .3s;width:128px}.portalCard_2a396803:hover .portalGlow_2a396803{background:rgba(255,230,0,.24)}.portalContent_2a396803{display:flex;flex:1;flex-direction:column;gap:8px;padding:16px;position:relative}.portalTop_2a396803{align-items:flex-start;display:flex;justify-content:space-between}.portalIcon_2a396803{background:hsla(0,0%,100%,.1);border-radius:9px;display:grid;height:40px;place-items:center;transition:transform .2s,background-color .2s,color .2s;width:40px}.portalIcon_2a396803 svg{height:20px;width:20px}.portalCard_2a396803:hover .portalIcon_2a396803{background:var(--hub-yellow);color:#17171d;transform:rotate(-8deg)}.portalArrow_2a396803{color:var(--hub-muted);height:20px;opacity:0;transform:translate(-4px,4px);transition:opacity .2s,transform .2s,color .2s;width:20px}.portalCard_2a396803:hover .portalArrow_2a396803{color:var(--hub-yellow);opacity:1;transform:none}.portalEyebrow_2a396803,.portalTitle_2a396803{display:block}.portalEyebrow_2a396803{color:var(--hub-yellow);font-size:12px;font-weight:650}.portalTitle_2a396803{font-size:18px;font-weight:650;margin-top:2px}.colorBar_2a396803,.footerColorBar_2a396803{background:linear-gradient(90deg,var(--hub-yellow),var(--hub-pink),var(--hub-cyan));display:block;height:4px;width:100%}.portalCard_2a396803 .colorBar_2a396803{transform:scaleX(.5);transform-origin:left;transition:transform .35s}.portalCard_2a396803:hover .colorBar_2a396803{transform:scaleX(1)}.exploreLink_2a396803{align-items:center;color:var(--hub-muted);display:flex;font-size:11px;gap:8px;justify-content:center;letter-spacing:.14em;margin:16px auto 0;text-decoration:none;text-transform:uppercase;width:fit-content}.exploreLink_2a396803:hover{color:var(--hub-yellow)}.exploreLink_2a396803 svg{height:16px;width:16px}.featuredSection_2a396803{background:var(--hub-bg);padding-block:104px}.sectionHeader_2a396803{align-items:flex-end;display:flex;gap:24px;justify-content:space-between}.sectionTitleBlock_2a396803{align-items:flex-start;display:flex;flex-direction:column;gap:12px}.eyebrow_2a396803{color:var(--hub-yellow);font-size:12px;font-weight:700;letter-spacing:.2em;margin:0;text-transform:uppercase}.contactIntro_2a396803 h2,.sectionTitleBlock_2a396803 h2{font-size:clamp(30px,4vw,50px);font-weight:650;line-height:1.08;margin:0}.sectionTitleBlock_2a396803>.colorBar_2a396803{width:96px}.carouselControls_2a396803{align-items:center;display:flex;gap:12px}.pageDots_2a396803{align-items:center;display:flex;gap:6px}.pageDots_2a396803 button{background:hsla(0,0%,100%,.24);border:0;border-radius:999px;cursor:pointer;height:6px;padding:0;transition:width .2s,background-color .2s;width:12px}.pageDots_2a396803 button:hover{background:hsla(0,0%,100%,.48)}.pageDots_2a396803 button.activeDot_2a396803{background:var(--hub-yellow);width:32px}.carouselArrow_2a396803{background:0 0;border:1px solid hsla(0,0%,100%,.2);border-radius:50%;color:var(--hub-text);cursor:pointer;display:grid;height:44px;place-items:center;transition:.2s;width:44px}.carouselArrow_2a396803 svg{height:20px;width:20px}.carouselArrow_2a396803:focus-visible,.carouselArrow_2a396803:hover{background:var(--hub-yellow);border-color:var(--hub-yellow);color:#17171d;outline:0}.featuredGrid_2a396803{display:grid;gap:16px;grid-template-columns:repeat(4,minmax(0,1fr));margin-top:48px}.featuredCard_2a396803{animation:riseIn_2a396803 .4s ease-out both;background:var(--hub-panel);border:1px solid hsla(0,0%,100%,.12);border-radius:14px;display:flex;flex-direction:column;min-height:250px;overflow:hidden;padding:18px;position:relative}.featuredCard_2a396803:before{background:linear-gradient(135deg,rgba(255,230,0,0),rgba(232,40,143,0));content:\"\";inset:0;pointer-events:none;position:absolute;transition:background .3s}.featuredCard_2a396803:hover:before{background:linear-gradient(135deg,rgba(255,230,0,.08),rgba(232,40,143,.08))}.featuredCard_2a396803 h3,.featuredMeta_2a396803,.location_2a396803,.registerLine_2a396803{position:relative}.featuredMeta_2a396803{align-items:flex-start;display:flex;gap:8px;justify-content:space-between}.dateBadge_2a396803{align-items:center;background:hsla(0,0%,100%,.07);border-radius:9px;display:flex;flex-direction:column;min-width:54px;padding:7px 10px;transition:.2s}.featuredCard_2a396803:hover .dateBadge_2a396803{background:var(--hub-yellow);color:#17171d}.dateBadge_2a396803 span{font-size:10px;font-weight:700;letter-spacing:.1em;text-transform:uppercase}.dateBadge_2a396803 strong{font-size:24px;line-height:1.15}.category_2a396803{border:1px solid hsla(0,0%,100%,.12);border-radius:999px;color:var(--hub-muted);font-size:11px;padding:5px 10px}.featuredCard_2a396803 h3{font-size:20px;font-weight:650;line-height:1.25;margin:20px 0 0}.location_2a396803{align-items:center;color:var(--hub-muted);display:flex;font-size:12px;gap:6px;margin:9px 0 0}.location_2a396803 svg{height:14px;width:14px}.registerLine_2a396803{align-items:center;border-top:1px solid hsla(0,0%,100%,.12);color:var(--hub-yellow);display:flex;font-size:14px;justify-content:space-between;margin-top:auto;padding-top:14px}.registerLine_2a396803 a{color:inherit;text-decoration:none}.registerLine_2a396803 a:hover{text-decoration:underline}.registerArrow_2a396803{background:rgba(255,230,0,.1);border-radius:50%;display:grid;height:36px;place-items:center;transition:.2s;width:36px}.registerArrow_2a396803 svg{height:16px;width:16px}.featuredCard_2a396803:hover .registerArrow_2a396803{background:var(--hub-yellow);color:#17171d;transform:rotate(-45deg)}.dataMessage_2a396803{color:var(--hub-muted);margin:28px 0 0}.stagesSection_2a396803{background:#f4f4f6;color:#1f1f28;overflow:hidden;padding-block:104px;position:relative}.stagePattern_2a396803{background-image:radial-gradient(#c9c9d4 1px,transparent 0);background-size:22px 22px;inset:0;mask-image:linear-gradient(270deg,#000,transparent 70%);opacity:.5;pointer-events:none;position:absolute}.stagesSection_2a396803 .sectionInner_2a396803{position:relative}.stagesSection_2a396803 .eyebrow_2a396803{color:#806f00}.stageTabs_2a396803{background:#fff;border-radius:999px;box-shadow:0 1px 3px rgba(0,0,0,.1);display:flex;gap:4px;margin-top:42px;max-width:100%;overflow-x:auto;padding:6px;width:max-content}.stageTabs_2a396803 button{align-items:center;background:0 0;border:0;border-radius:999px;color:rgba(31,31,40,.68);cursor:pointer;display:flex;flex:0 0 auto;font-size:14px;font-weight:600;gap:8px;padding:9px 16px;transition:color .2s,background-color .2s}.stageTabs_2a396803 button[aria-pressed=true]{background:#1f1f28;color:#fff}.stageTabs_2a396803 button:focus-visible{outline:2px solid #806f00;outline-offset:2px}.stageNumber_2a396803{background:rgba(0,0,0,.08);border-radius:50%;color:#1f1f28;display:grid;font-size:10px;font-weight:750;height:21px;place-items:center;width:21px}.stageTabs_2a396803 button[aria-pressed=true] .stageNumber_2a396803{background:var(--hub-yellow)}.stageDescription_2a396803{color:rgba(31,31,40,.74);font-size:18px;margin:30px 0 0}.courseGrid_2a396803{display:grid;gap:24px;grid-template-columns:repeat(3,minmax(0,1fr));margin-top:28px}.courseCard_2a396803{background:#fff;border-radius:14px;box-shadow:0 1px 4px rgba(0,0,0,.1);overflow:hidden;transition:box-shadow .25s,transform .25s}.courseCard_2a396803:hover{box-shadow:0 16px 35px rgba(0,0,0,.16);transform:translateY(-3px)}.courseLink_2a396803{color:inherit;display:block;text-decoration:none}.courseImageWrap_2a396803{height:208px;overflow:hidden;position:relative}.courseImageWrap_2a396803:after{background:linear-gradient(0deg,rgba(0,0,0,.5),transparent 55%);content:\"\";inset:0;pointer-events:none;position:absolute}.courseImageWrap_2a396803 img{height:100%;object-fit:cover;transition:transform .5s;width:100%}.courseCard_2a396803:hover img{transform:scale(1.06)}.courseImageFallback_2a396803{background:linear-gradient(135deg,#2a2a31,#45454d);color:var(--hub-yellow);display:grid;height:100%;place-items:center;width:100%}.courseImageFallback_2a396803 svg{height:40px;width:40px}.courseIcon_2a396803{background:var(--hub-yellow);border-radius:50%;bottom:12px;box-shadow:0 6px 15px rgba(0,0,0,.18);color:#1f1f28;display:grid;height:44px;place-items:center;position:absolute;right:18px;transition:transform .2s;width:44px;z-index:1}.courseIcon_2a396803 svg{height:20px;width:20px}.courseCard_2a396803:hover .courseIcon_2a396803{transform:rotate(12deg) scale(1.06)}.courseContent_2a396803{padding:24px}.courseContent_2a396803 h3{font-size:18px;font-weight:650;margin:0}.courseContent_2a396803 p{color:rgba(31,31,40,.68);font-size:14px;line-height:1.55;margin:6px 0 0}.footer_2a396803{background:var(--hub-bg);overflow:hidden;position:relative}.footerColorBar_2a396803{height:4px}.footer_2a396803 .sectionInner_2a396803{padding-block:80px 28px}.contactGrid_2a396803{align-items:center;display:grid;gap:48px;grid-template-columns:1fr 1.3fr}.contactIntro_2a396803 h2{margin-top:12px}.contactIntro_2a396803>p:last-child{color:var(--hub-muted);margin:16px 0 0;max-width:400px}.contactCards_2a396803{display:grid;gap:12px;grid-template-columns:repeat(3,minmax(0,1fr))}.contactCard_2a396803{background:var(--hub-panel);border:1px solid hsla(0,0%,100%,.12);border-radius:14px;color:inherit;display:flex;flex-direction:column;gap:16px;justify-content:space-between;min-height:130px;padding:16px;text-decoration:none;transition:border-color .2s}.contactCard_2a396803:focus-visible,.contactCard_2a396803:hover{border-color:rgba(255,230,0,.65);outline:0}.contactIcon_2a396803{color:var(--hub-yellow);height:24px;width:24px}.contactCard_2a396803 strong{align-items:center;display:flex;font-size:14px;gap:8px}.contactCard_2a396803 small{color:var(--hub-muted);display:block;font-size:11px;margin-top:5px}.contactArrow_2a396803{height:16px;opacity:0;transform:translateX(-6px);transition:.2s;width:16px}.contactCard_2a396803:hover .contactArrow_2a396803{opacity:1;transform:none}.footerBottom_2a396803{align-items:center;border-top:1px solid hsla(0,0%,100%,.12);display:flex;gap:24px;justify-content:space-between;margin-top:64px;padding-top:28px}.footerBottom_2a396803>p{color:var(--hub-muted);font-size:12px;margin:0}.talentSection_2a396803{background:linear-gradient(180deg,#1d1d25,#17171d);padding-block:96px}.talentSubhead_2a396803{align-items:center;color:var(--hub-muted);display:flex;gap:12px;margin-top:24px;max-width:700px}.talentSubhead_2a396803 svg{color:var(--hub-yellow);flex:none;height:24px;width:24px}.talentSubhead_2a396803 p{margin:0}.talentGroupTitle_2a396803{font-size:21px;font-weight:650;margin:38px 0 0}.talentServiceGrid_2a396803{display:grid;gap:14px;grid-template-columns:repeat(6,minmax(0,1fr));margin-top:20px}.talentServiceCard_2a396803{align-items:center;background:var(--hub-panel);border:1px solid hsla(0,0%,100%,.14);border-radius:12px;color:var(--hub-text);cursor:pointer;display:flex;flex-direction:column;min-width:0;overflow:hidden;padding:18px 12px 0;transition:transform .2s,border-color .2s,background-color .2s}.talentServiceCard_2a396803:focus-visible,.talentServiceCard_2a396803:hover{background:#282830;border-color:var(--hub-yellow);outline:0;transform:translateY(-4px)}.talentServiceIcon_2a396803{color:var(--hub-yellow);height:30px;margin-bottom:12px;width:30px}.talentServiceName_2a396803{font-size:13px;font-weight:700;min-height:40px;text-align:center}.talentAvatar_2a396803,.talentFilterAvatar_2a396803,.talentLocationAvatar_2a396803,.talentModalAvatar_2a396803{background:var(--hub-yellow);border-radius:50%;color:#17171d;display:grid;flex:none;font-weight:800;place-items:center}.talentAvatar_2a396803{border:2px solid #fff;font-size:17px;height:58px;margin:4px 0 -19px;transition:transform .2s;width:58px;z-index:1}.talentServiceCard_2a396803:hover .talentAvatar_2a396803{transform:scale(1.06)}.talentPersonName_2a396803{background:var(--hub-yellow);color:#17171d;font-size:12px;font-weight:750;line-height:1.25;min-height:58px;padding:26px 8px 10px;text-align:center;width:calc(100% + 24px)}.talentLocationHeading_2a396803{align-items:center;display:flex;gap:20px;justify-content:space-between;margin-top:54px}.talentLocationHeading_2a396803 .talentGroupTitle_2a396803{margin:0}.talentLocationHeading_2a396803 p{color:var(--hub-muted);font-size:14px;margin:7px 0 0}.talentLocationHeading_2a396803>svg{color:var(--hub-yellow);flex:none;height:28px;width:28px}.talentFilters_2a396803{display:flex;flex-wrap:wrap;gap:9px;margin-top:22px}.talentFilter_2a396803{align-items:center;background:var(--hub-panel);border:1px solid hsla(0,0%,100%,.2);border-radius:999px;color:var(--hub-text);cursor:pointer;display:inline-flex;font-size:13px;font-weight:600;gap:8px;padding:8px 14px;transition:transform .18s,border-color .18s,background-color .18s,color .18s}.talentFilter_2a396803:focus-visible,.talentFilter_2a396803:hover{border-color:var(--hub-yellow);outline:0;transform:translateY(-2px)}.talentFilterActive_2a396803{background:var(--hub-yellow);border-color:var(--hub-yellow);color:#17171d}.talentFilterAvatar_2a396803{background:hsla(0,0%,100%,.2);font-size:9px;height:21px;width:21px}.talentFilterActive_2a396803 .talentFilterAvatar_2a396803{background:rgba(0,0,0,.12)}.talentLocationGrid_2a396803{display:grid;gap:12px;grid-template-columns:repeat(3,minmax(0,1fr));margin-top:18px}.talentLocationCard_2a396803{align-items:center;animation:riseIn_2a396803 .4s both;background:var(--hub-panel);border:1px solid hsla(0,0%,100%,.14);border-radius:11px;color:var(--hub-text);cursor:pointer;display:grid;gap:12px;grid-template-columns:42px minmax(0,1fr) 130px;min-width:0;padding:12px;position:relative;text-align:left;transition:transform .2s,border-color .2s}.talentLocationCard_2a396803:focus-visible,.talentLocationCard_2a396803:hover{border-color:var(--hub-yellow);outline:0;transform:translateY(-3px)}.talentFlag_2a396803{background:hsla(0,0%,100%,.08);border:1px solid hsla(0,0%,100%,.18);border-radius:50%;display:grid;font-size:21px;height:42px;place-items:center;width:42px}.talentLocationInfo_2a396803{display:flex;flex-direction:column;gap:3px;min-width:0}.talentLocationName_2a396803{font-size:14px;font-weight:700;line-height:1.25}.talentLocationName_2a396803 small{color:var(--hub-yellow);display:block;font-size:10px;font-weight:700;letter-spacing:.04em;margin-top:3px;text-transform:uppercase}.talentCities_2a396803{color:var(--hub-muted);font-size:11px;line-height:1.35}.talentLocationPerson_2a396803{align-items:center;display:flex;font-size:11px;font-weight:650;gap:8px;min-width:0}.talentLocationAvatar_2a396803{border:2px solid hsla(0,0%,100%,.8);font-size:10px;height:34px;width:34px}.talentLocationArrow_2a396803{color:var(--hub-yellow);font-size:21px;opacity:0;position:absolute;right:7px;top:50%;transform:translate(-4px,-50%);transition:opacity .2s,transform .2s}.talentLocationCard_2a396803:focus-visible .talentLocationArrow_2a396803,.talentLocationCard_2a396803:hover .talentLocationArrow_2a396803{opacity:1;transform:translateY(-50%)}.talentNote_2a396803{align-items:center;background:var(--hub-yellow);border-radius:12px;color:#17171d;display:flex;gap:14px;margin-top:36px;padding:16px 20px}.talentNoteIcon_2a396803{background:#17171d;border-radius:50%;color:var(--hub-yellow);display:grid;flex:none;font-family:Georgia,serif;font-size:18px;font-weight:800;height:34px;place-items:center;width:34px}.talentNote_2a396803 p{font-size:14px;font-weight:600;margin:0}.talentModalBackdrop_2a396803{animation:fadeIn_2a396803 .18s ease-out both;backdrop-filter:blur(7px);background:rgba(8,8,12,.82);display:grid;inset:0;padding:20px;place-items:center;position:fixed;z-index:1000001}.talentModal_2a396803{animation:riseIn_2a396803 .22s ease-out both;background:#292932;border:1px solid hsla(0,0%,100%,.2);border-radius:20px;box-shadow:0 24px 80px rgba(0,0,0,.45);max-height:min(80vh,700px);overflow-y:auto;padding:32px 26px 26px;position:relative;text-align:center;width:min(460px,100%)}.talentModalClose_2a396803{background:#17171d;border:1px solid hsla(0,0%,100%,.22);border-radius:50%;color:var(--hub-text);cursor:pointer;display:grid;font-size:22px;height:36px;place-items:center;position:absolute;right:12px;top:12px;transition:background-color .2s,color .2s;width:36px}.talentModalClose_2a396803:focus-visible,.talentModalClose_2a396803:hover{background:var(--hub-yellow);border-color:var(--hub-yellow);color:#17171d;outline:0}.talentModalAvatar_2a396803{border:3px solid #fff;font-size:23px;height:76px;margin:0 auto 12px;width:76px}.talentModal_2a396803 h2{font-size:24px;margin:0}.talentModalRole_2a396803{color:var(--hub-yellow);font-size:12px;font-weight:700;letter-spacing:.06em;margin:5px 0 0;text-transform:uppercase}.talentModalTags_2a396803{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin-top:20px}.talentModalTags_2a396803 span{align-items:center;background:#17171d;border:1px solid hsla(0,0%,100%,.14);border-radius:999px;color:var(--hub-text);display:inline-flex;font-size:11px;gap:6px;padding:7px 10px;text-align:left}.talentModalTags_2a396803 svg{color:var(--hub-yellow);flex:none;height:13px;width:13px}@keyframes fadeIn_2a396803{0%{opacity:0}to{opacity:1}}.auditPage_2a396803{--audit-bg:#1a1a24;--audit-card:#2e2e38;--audit-yellow:#ffe600;--audit-white:#fff;--audit-gray:hsla(0,0%,100%,.78);--audit-gray-2:hsla(0,0%,100%,.62);--audit-border:hsla(0,0%,100%,.1);background:var(--audit-bg);color:var(--audit-white);font-family:Segoe UI,Inter,system-ui,-apple-system,Helvetica,Arial,sans-serif;inset:0;line-height:1.55;overflow:auto;position:fixed;scroll-behavior:smooth;z-index:999999}.auditPage_2a396803 *,.auditPage_2a396803 :after,.auditPage_2a396803 :before{box-sizing:border-box}.auditHero_2a396803{align-items:flex-end;background:linear-gradient(115deg,rgba(26,26,36,.92),rgba(26,26,36,.58) 52%,rgba(26,26,36,.08)),linear-gradient(160deg,#2e2e38,#1a1a24);display:flex;min-height:340px;overflow:hidden;padding:0 48px 42px;position:relative}.auditHeroContent_2a396803{animation:auditRiseIn_2a396803 .8s cubic-bezier(.22,1,.36,1) .1s both;position:relative;z-index:1}.auditHero_2a396803 h1{font-size:44px;font-weight:800;letter-spacing:.3px;line-height:1.12;margin:0;text-shadow:0 2px 18px rgba(26,26,36,.5)}.auditUnderline_2a396803{animation:auditRiseIn_2a396803 .8s cubic-bezier(.22,1,.36,1) .25s both;background:var(--audit-yellow);border-radius:3px;display:block;height:5px;margin-top:14px;width:120px}.auditSkyline_2a396803{height:62%;inset:auto 0 -6px;opacity:.85;pointer-events:none;position:absolute;width:100%}.auditGlow_2a396803{background:radial-gradient(ellipse at center,rgba(255,230,0,.22),transparent 70%);filter:blur(10px);height:320px;pointer-events:none;position:absolute;right:8%;top:-40%;width:520px}.auditCornerSecondary_2a396803,.auditCorner_2a396803{animation:auditSlideIn_2a396803 1s cubic-bezier(.22,1,.36,1) both;background:var(--audit-yellow);position:absolute;right:0;top:0;z-index:1}.auditCorner_2a396803{clip-path:polygon(100% 0,100% 100%,calc(100% - 190px) 0);height:150px;width:230px}.auditCornerSecondary_2a396803{animation-delay:.12s;clip-path:polygon(100% 0,100% 100%,45% 0);height:210px;opacity:.95;width:120px}.auditIntro_2a396803{max-width:1100px;padding:52px 48px 40px}.auditSection_2a396803{padding:0 48px 40px}.auditSectionHead_2a396803{align-items:center;display:flex;gap:14px;margin-bottom:20px}.auditSectionBar_2a396803{background:var(--audit-yellow);border-radius:3px;flex:none;height:40px;width:6px}.auditSectionHead_2a396803 h2{font-size:26px;font-weight:800;margin:0}.auditLead_2a396803{color:var(--audit-white);font-size:15px;font-weight:600;margin-bottom:8px}.auditIntro_2a396803 p:not(.auditLead_2a396803){color:var(--audit-gray);font-size:13.5px;margin-bottom:14px;max-width:960px}.auditIntro_2a396803 a{color:var(--audit-yellow);font-weight:700;text-decoration:underline;text-underline-offset:2px}.auditIntro_2a396803 a:hover{color:var(--audit-white)}.auditSubhead_2a396803{color:var(--audit-gray);font-size:13.5px;margin:-8px 0 26px 20px}.teamGrid_2a396803{display:grid;gap:22px;grid-template-columns:repeat(5,minmax(0,1fr))}.teamCard_2a396803{animation:auditCardIn_2a396803 .6s cubic-bezier(.22,1,.36,1) both;background:var(--audit-card);border:1px solid var(--audit-border);border-radius:10px;overflow:hidden;transition:transform .3s cubic-bezier(.22,1,.36,1),box-shadow .3s}.teamCard_2a396803:hover{box-shadow:0 18px 40px rgba(26,26,36,.5);transform:translateY(-8px)}.teamPhoto_2a396803{background:radial-gradient(circle at 50% 30%,rgba(255,230,0,.24),transparent 45%),linear-gradient(145deg,#41414a,#202027 72%);display:grid;height:190px;overflow:hidden;place-items:center;position:relative}.teamPhotoImage_2a396803{display:block;height:100%;object-fit:cover;object-position:center;width:100%}.teamPhoto_2a396803:after{background:var(--audit-yellow);clip-path:polygon(0 0,100% 0,100% 100%);content:\"\";height:44px;position:absolute;right:0;top:0;width:44px}.teamBody_2a396803{padding:16px 16px 18px;text-align:left}.teamBody_2a396803 h3{font-size:15px;font-weight:700;margin:0}.teamBody_2a396803 p{color:var(--audit-gray-2);font-size:12px;margin:3px 0 0}.teamIcons_2a396803{display:flex;gap:10px;justify-content:center;margin-top:14px}.teamIconButton_2a396803{align-items:center;background:0 0;border:1.5px solid hsla(0,0%,100%,.35);border-radius:50%;color:var(--audit-white);cursor:pointer;display:flex;height:34px;justify-content:center;transition:all .25s;width:34px}.teamIconButton_2a396803 svg{fill:currentColor;height:15px;width:15px}.teamIconButton_2a396803:focus-visible,.teamIconButton_2a396803:hover{background:var(--audit-yellow);border-color:var(--audit-yellow);color:var(--audit-bg);outline:0;transform:scale(1.12)}.teamIconButton_2a396803:disabled{cursor:not-allowed}.postcardGrid_2a396803{display:grid;gap:20px;grid-template-columns:repeat(5,minmax(0,1fr))}.postcardButton_2a396803{animation:auditPostcardIn_2a396803 .6s cubic-bezier(.22,1,.36,1) both;background:var(--audit-card);border:1px solid var(--audit-border);border-radius:12px;cursor:pointer;min-width:0;overflow:hidden;padding:0;position:relative;transition:transform .3s cubic-bezier(.22,1,.36,1),box-shadow .3s}.postcardButton_2a396803:hover{box-shadow:0 18px 40px rgba(26,26,36,.55),0 0 0 2px rgba(255,230,0,.35);transform:translateY(-8px)}.postcardButton_2a396803:focus-visible{outline:2px solid var(--audit-yellow);outline-offset:3px}.postcardImage_2a396803{display:block;height:auto;width:100%}.postcardImageLarge_2a396803{max-height:72vh;max-width:min(74vw,620px);object-fit:contain;width:auto}.auditFooter_2a396803{border-top:1px solid var(--audit-border);color:hsla(0,0%,100%,.75);font-size:12.5px;margin-top:30px;overflow:hidden;padding:26px 48px 34px;position:relative}.galleryModal_2a396803{align-items:center;animation:auditFadeIn_2a396803 .2s ease both;backdrop-filter:blur(8px);background:rgba(26,26,36,.88);display:flex;inset:0;justify-content:center;overflow:auto;padding:74px 100px;position:fixed;z-index:1000001}.galleryInner_2a396803{margin:auto;max-width:100%;position:relative;width:max-content}.galleryCard_2a396803{animation:auditGalleryIn_2a396803 .3s cubic-bezier(.22,1,.36,1) both;background:var(--audit-card);border:1px solid hsla(0,0%,100%,.14);border-radius:16px;box-shadow:0 30px 80px rgba(26,26,36,.7);overflow:hidden;touch-action:pan-y}.galleryFadeOutNext_2a396803{animation:galleryFadeOutNext_2a396803 .18s ease-in both}.galleryFadeOutPrevious_2a396803{animation:galleryFadeOutPrevious_2a396803 .18s ease-in both}.galleryFadeInNext_2a396803{animation:galleryFadeInNext_2a396803 .24s ease-out both}.galleryFadeInPrevious_2a396803{animation:galleryFadeInPrevious_2a396803 .24s ease-out both}.galleryClose_2a396803{align-items:center;background:rgba(26,26,36,.6);border:1.5px solid hsla(0,0%,100%,.5);border-radius:50%;color:var(--audit-white);cursor:pointer;display:flex;font-size:22px;height:40px;justify-content:center;position:absolute;right:0;top:-52px;transition:all .25s;width:40px;z-index:5}.galleryClose_2a396803:focus-visible,.galleryClose_2a396803:hover{background:var(--audit-yellow);border-color:var(--audit-yellow);color:var(--audit-bg);outline:0;transform:rotate(90deg)}.galleryNav_2a396803{align-items:center;background:rgba(26,26,36,.75);border:1.5px solid hsla(0,0%,100%,.5);border-radius:50%;color:var(--audit-white);cursor:pointer;display:flex;font-size:28px;height:46px;justify-content:center;position:absolute;top:50%;transform:translateY(-50%);transition:all .25s;width:46px;z-index:5}.galleryNav_2a396803:focus-visible,.galleryNav_2a396803:hover{background:var(--audit-yellow);border-color:var(--audit-yellow);color:var(--audit-bg);outline:0;transform:translateY(-50%) scale(1.1)}.galleryPrevious_2a396803{left:-64px}.galleryNext_2a396803{right:-64px}.galleryDots_2a396803{align-items:center;bottom:-42px;display:flex;gap:8px;left:50%;position:absolute;transform:translateX(-50%)}.galleryDot_2a396803{background:hsla(0,0%,100%,.3);border:0;border-radius:50%;cursor:pointer;height:8px;padding:0;transition:all .2s;width:8px}.galleryDot_2a396803:focus-visible,.galleryDot_2a396803:hover{background:hsla(0,0%,100%,.7);outline:1px solid var(--audit-yellow);outline-offset:2px}.galleryDotActive_2a396803{background:var(--audit-yellow);border-radius:4px;width:22px}.galleryHint_2a396803{align-items:center;color:hsla(0,0%,100%,.65);display:flex;font-size:11px;gap:6px;left:0}.galleryHint_2a396803,.galleryPosition_2a396803{bottom:-46px;margin:0;position:absolute;white-space:nowrap}.galleryPosition_2a396803{color:hsla(0,0%,100%,.75);font-size:12px;font-variant-numeric:tabular-nums;right:0}.galleryHint_2a396803 kbd{border:1px solid hsla(0,0%,100%,.35);border-radius:4px;display:inline-block;font:inherit;line-height:16px;padding:0 5px}@keyframes auditSlideIn_2a396803{0%{transform:translateX(120%)}to{transform:translateX(0)}}@keyframes auditRiseIn_2a396803{0%{opacity:0;transform:translateY(22px)}to{opacity:1;transform:translateY(0)}}@keyframes auditCardIn_2a396803{0%{opacity:0;transform:translateY(26px) scale(.96)}to{opacity:1;transform:translateY(0) scale(1)}}@keyframes auditPostcardIn_2a396803{0%{opacity:0;transform:translateY(26px)}to{opacity:1;transform:translateY(0)}}@keyframes auditGalleryIn_2a396803{0%{opacity:0;transform:translateY(24px)}to{opacity:1;transform:translateY(0)}}@keyframes auditFadeIn_2a396803{0%{opacity:0}to{opacity:1}}@keyframes galleryFadeOutNext_2a396803{0%{opacity:1;transform:translateX(0)}to{opacity:0;transform:translateX(-24px)}}@keyframes galleryFadeOutPrevious_2a396803{0%{opacity:1;transform:translateX(0)}to{opacity:0;transform:translateX(24px)}}@keyframes galleryFadeInNext_2a396803{0%{opacity:0;transform:translateX(24px)}to{opacity:1;transform:translateX(0)}}@keyframes galleryFadeInPrevious_2a396803{0%{opacity:0;transform:translateX(-24px)}to{opacity:1;transform:translateX(0)}}@media (max-width:1100px){.teamGrid_2a396803{grid-template-columns:repeat(3,minmax(0,1fr))}.postcardGrid_2a396803{grid-template-columns:repeat(4,minmax(0,1fr))}}@media (max-width:760px){.auditHero_2a396803{min-height:300px;padding:0 24px 32px}.auditHero_2a396803 h1{font-size:34px}.auditIntro_2a396803{padding:40px 24px 32px}.auditSection_2a396803{padding:0 24px 32px}.auditFooter_2a396803{padding:24px 24px 30px}.teamGrid_2a396803{gap:14px;grid-template-columns:repeat(2,minmax(0,1fr))}.teamPhoto_2a396803{height:150px}.postcardGrid_2a396803{gap:12px;grid-template-columns:repeat(3,minmax(0,1fr))}.galleryModal_2a396803{padding:72px 18px}.postcardImageLarge_2a396803{max-height:72vh;max-width:82vw}.galleryPrevious_2a396803{left:8px}.galleryNext_2a396803{right:8px}.galleryHint_2a396803{display:none}}@media (max-width:480px){.teamGrid_2a396803{grid-template-columns:1fr}.teamPhoto_2a396803{height:190px}.postcardGrid_2a396803{grid-template-columns:repeat(2,minmax(0,1fr))}.galleryNav_2a396803{height:40px;width:40px}.galleryPrevious_2a396803{left:8px}.galleryNext_2a396803{right:8px}}@media (prefers-reduced-motion:reduce){.auditPage_2a396803 *,.auditPage_2a396803 :after,.auditPage_2a396803 :before{animation-duration:0s!important;animation-iteration-count:1!important;transition-duration:0s!important}.auditPage_2a396803{scroll-behavior:auto}}@keyframes riseIn_2a396803{0%{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}@media (min-width:1024px) and (max-width:1599px){.heroCopy_2a396803 h1{font-size:65px}}@media (min-width:768px){.heroInner_2a396803,.sectionInner_2a396803{width:min(100% - 64px,1280px)}.heroCopy_2a396803{padding-top:32px}}@media (max-width:1023px){.portalGrid_2a396803{grid-template-columns:repeat(3,minmax(0,1fr))}.featuredGrid_2a396803{grid-template-columns:repeat(2,minmax(0,1fr))}.contactGrid_2a396803{grid-template-columns:1fr}}@media (max-width:1100px){.talentServiceGrid_2a396803{grid-template-columns:repeat(3,minmax(0,1fr))}.talentLocationGrid_2a396803{grid-template-columns:repeat(2,minmax(0,1fr))}}@media (max-width:767px){.heroInner_2a396803,.hero_2a396803{min-height:auto}.heroInner_2a396803,.sectionInner_2a396803{width:min(100% - 36px,1280px)}.header_2a396803{padding-block:20px}.navigation_2a396803{display:none}.heroCopy_2a396803{min-height:340px;padding:34px 0 0}.heroCopy_2a396803 h1{font-size:clamp(46px,13vw,66px)}.heroCopy_2a396803>p{font-size:16px}.portalGrid_2a396803{gap:10px;grid-template-columns:repeat(2,minmax(0,1fr))}.portalContent_2a396803{gap:10px;padding:12px}.portalIcon_2a396803{height:34px;width:34px}.portalIcon_2a396803 svg{height:18px;width:18px}.portalTitle_2a396803{font-size:15px}.portalArrow_2a396803{opacity:.75;transform:none}.exploreLink_2a396803{display:none}.featuredSection_2a396803,.stagesSection_2a396803{padding-block:72px}.sectionHeader_2a396803{align-items:flex-start;flex-direction:column}.carouselControls_2a396803{align-self:flex-end}.featuredGrid_2a396803{gap:12px;margin-top:28px}.featuredCard_2a396803{min-height:220px;padding:14px}.category_2a396803{font-size:10px}.featuredCard_2a396803 h3{font-size:17px;margin-top:16px}.stageTabs_2a396803{border-radius:14px;width:100%}.courseGrid_2a396803{gap:16px;grid-template-columns:1fr}.courseImageWrap_2a396803{height:220px}.footer_2a396803 .sectionInner_2a396803{padding-top:64px}.contactCards_2a396803{grid-template-columns:1fr}.contactCard_2a396803{min-height:108px;padding:14px}.footerBottom_2a396803{align-items:flex-start;flex-direction:column;margin-top:44px}.talentSection_2a396803{padding-block:72px}.talentServiceGrid_2a396803{gap:10px;grid-template-columns:repeat(2,minmax(0,1fr))}.talentGroupTitle_2a396803{font-size:19px;margin-top:30px}.talentLocationHeading_2a396803{margin-top:42px}.talentLocationGrid_2a396803{grid-template-columns:1fr}.talentLocationCard_2a396803{grid-template-columns:42px minmax(0,1fr) 120px}.talentNote_2a396803{align-items:flex-start;padding:14px}.talentNote_2a396803 p{font-size:13px}}@media (prefers-reduced-motion:reduce){*,:after,:before{animation-duration:0s!important;animation-iteration-count:1!important;scroll-behavior:auto!important;transition-duration:0s!important}}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovTUVOQUxlYXJuaW5nL3NyYy93ZWJwYXJ0cy9ob21lUGFnZS9jb21wb25lbnRzL0hvbWVQYWdlLm1vZHVsZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVBLG1CQUNFLGdCQUFBLENBQ0EsbUJBQUEsQ0FDQSxrQkFBQSxDQUNBLG1CQUFBLENBQ0Esb0JBQUEsQ0FDQSxrQkFBQSxDQUNBLGtCQUFBLENBR0Esd0JBQUEsQ0FDQSxxQkFBQSxDQUlFLFlBQUEsQ0FFQSxNQUFBLENBSkYsZUFBQSxDQUxBLGVBQUEsQ0FRRSxhQUFBLENBSG1CLGNBQUEsQ0FKckIsc0JBQUEsQ0FTRSxLQUFBLENBSkEsVUFBQSxDQUtBLGNBQUEsQ0FHSiw2Q0FWRSw0QkFVaUIsQ0FFbkIsZUFBNEIsaUJBQUEsQ0FBc0MsaUJBQUEsQ0FBbEIsZUFBQSxDQUF4QyxpQkFBMEQsQ0FDbEUsMkRBQXdELE9BQUEsQ0FBVSxtQkFBQSxDQUE5QixpQkFBOEIsQ0FDbEUsb0JBQTBCLDJKQUFBLENBQWtLLHFCQUFBLENBQS9LLFVBQStLLENBQzVMLG9CQUEwQixpS0FBQSxDQUFiLFVBQWEsQ0FDMUIsbUJBQXVDLHNHQUFBLENBQW9ILHlCQUFBLENBQTRCLCtEQUFBLENBQTlKLFdBQUEsQ0FBYixVQUEySyxDQUN2TCwyQ0FBNkQsa0JBQUEsQ0FBakMsNkJBQWlDLENBQzdELG9CQUFpQyxZQUFBLENBQWUscUJBQUEsQ0FBbkMsaUJBQW1DLENBQ2hELGlCQUF5QixrQkFBQSxDQUFmLFlBQUEsQ0FBb0UsUUFBQSxDQUFoQyw2QkFBQSxDQUEyQyxrQkFBQSxDQUN6RixvQkFBYSxhQUFBLENBQWdCLG9CQUFBLENBQzdCLGdCQUF3QixvQkFBQSxDQUFmLFlBQUEsQ0FBc0MsUUFBQSxDQUMvQyxvQkFBaUMsY0FBQSxDQUFpQixlQUFBLENBQW9DLGdCQUFBLENBQWxCLGVBQUEsQ0FBdkQsaUJBQXlFLENBQ3RGLDJCQUFvRyw0QkFBQSxDQUEvRSxVQUFBLENBQWtFLFVBQUEsQ0FBakMsTUFBQSxDQUFwQixpQkFBQSxDQUE2QixRQUFBLENBQW9FLHVCQUFBLENBQTBCLHFCQUFBLENBQW5GLFVBQW1GLENBQzdKLHVCQUFnQix5QkFBQSxDQUE4QixjQUFBLENBQWlCLGVBQUEsQ0FBa0IsZ0JBQUEsQ0FDakYscUJBQTZCLGtCQUFBLENBQStJLDBCQUFBLENBQW5DLDhCQUFBLENBQS9ELG9DQUFBLENBQXlDLG1CQUFBLENBQXJHLFlBQUEsQ0FBb0MsT0FBQSxDQUFVLFdBQWdILENBQzVLLHVCQUFtQyxtQkFBQSxDQUFzQix5QkFBQSxDQUE4QixjQUFBLENBQXZFLGdCQUFBLENBQXdGLG9CQUFBLENBQXVCLDJDQUFBLENBQy9ILGtFQUFtRCw0QkFBQSxDQUErQixhQUFBLENBQWdCLFNBQUEsQ0FDbEcsbUJBQTBILDJDQUFBLENBQW5GLFlBQUEsQ0FBVCxNQUFBLENBQXdCLHFCQUFBLENBQXdCLHNCQUFBLENBQWxFLGVBQUEsQ0FBMkYsZ0JBQW1CLENBQzFILHNCQUEwQiw4QkFBQSxDQUFtQyxlQUFBLENBQWtCLGVBQUEsQ0FBaEUsUUFBZ0UsQ0FDL0UsMkJBQW9CLDJEQUFBLENBQWdFLG9CQUFBLENBQXVCLGlCQUFBLENBQzNHLHFCQUFvRCx5QkFBQSxDQUE4QixjQUFBLENBQWhELGVBQUEsQ0FBbEIsZUFBa0UsQ0FDbEYscUJBQWMsbUJBQUEsQ0FDZCxxQkFBYyxZQUFBLENBQWlFLFFBQUEsQ0FBbEQsNkNBQWtELENBQy9FLHFCQUFvVyw0Q0FBQSxDQUFoRywwQkFBQSxDQUE3RiwrQkFBQSxDQUE5RCxvQ0FBQSxDQUF5QyxrQkFBQSxDQUF5RCxhQUFBLENBQXpLLFlBQUEsQ0FBZSxxQkFBQSxDQUF3QixXQUFBLENBQWMsZUFBQSxDQUF6RSxpQkFBQSxDQUE2TSxlQUFBLENBQWtCLG9CQUFBLENBQW9ELDhEQUFtRSxDQUNwVyxrQ0FBMkIsb0JBQUEsQ0FBd0Isa0NBQTJCLG9CQUFBLENBQXdCLGtDQUEyQixvQkFBQSxDQUF3QixrQ0FBMkIsb0JBQUEsQ0FBd0Isa0NBQTJCLG1CQUFBLENBQ3ZPLDhEQUFrRiw4QkFBQSxDQUFuQyxnQ0FBQSxDQUFtRyxTQUFBLENBQTdCLDBCQUE2QixDQUNsSixxQkFBNkcsY0FBQSxDQUFwQixpQkFBQSxDQUE2QyxpQkFBQSxDQUE1RCxZQUFBLENBQTVELGlCQUFBLENBQWdDLFdBQUEsQ0FBWixTQUFBLENBQXdILCtCQUFBLENBQTlGLFdBQThGLENBQzFKLGdEQUFnQyw4QkFBQSxDQUNoQyx3QkFBcUMsWUFBQSxDQUFlLE1BQUEsQ0FBUyxxQkFBQSxDQUF3QixPQUFBLENBQVUsWUFBQSxDQUE5RSxpQkFBOEUsQ0FDL0Ysb0JBQTRCLHNCQUFBLENBQWYsWUFBQSxDQUF3Qyw2QkFBQSxDQUNyRCxxQkFBaUcsNkJBQUEsQ0FBcEIsaUJBQUEsQ0FBL0QsWUFBQSxDQUE0QixXQUFBLENBQWMsa0JBQUEsQ0FBMkUsdURBQUEsQ0FBdEcsVUFBc0csQ0FDbkkseUJBQStCLFdBQUEsQ0FBYixVQUFhLENBQy9CLGdEQUEwRCw0QkFBQSxDQUErQixhQUFBLENBQXpELHVCQUF5RCxDQUN6RixzQkFBMEMsc0JBQUEsQ0FBZCxXQUFBLENBQXVDLFNBQUEsQ0FBWSw2QkFBQSxDQUFpQyw4Q0FBQSxDQUFqRyxVQUFpRyxDQUNoSCxpREFBNkMsdUJBQUEsQ0FBWixTQUFBLENBQXNDLGNBQUEsQ0FDdkUsOENBQStCLGFBQUEsQ0FDL0Isd0JBQWlCLHVCQUFBLENBQTBCLGNBQUEsQ0FBaUIsZUFBQSxDQUM1RCxzQkFBZ0MsY0FBQSxDQUFpQixlQUFBLENBQWxDLGNBQWtDLENBQ2pELDRDQUF1RSxtRkFBQSxDQUExQyxhQUFBLENBQWdCLFVBQUEsQ0FBYSxVQUFhLENBQ3ZFLHdDQUF3QixvQkFBQSxDQUF1QixxQkFBQSxDQUF3Qix5QkFBQSxDQUN2RSw4Q0FBOEIsbUJBQUEsQ0FDOUIsc0JBQThCLGtCQUFBLENBQWlHLHNCQUFBLENBQWhILFlBQUEsQ0FBeUksY0FBQSxDQUE1RSxPQUFBLENBQXpCLHNCQUFBLENBQXNILG9CQUFBLENBQS9ELGtCQUFBLENBQWlILG9CQUFBLENBQTNCLHdCQUFBLENBQTFHLGlCQUFxSSxDQUMzTiw0QkFBcUIsdUJBQUEsQ0FBMkIsMEJBQWdDLFdBQUEsQ0FBYixVQUFhLENBRWhGLDBCQUF5Qyx3QkFBQSxDQUF0QixtQkFBc0IsQ0FDekMsd0JBQWdDLG9CQUFBLENBQWYsWUFBQSxDQUFzRSxRQUFBLENBQWhDLDZCQUFnQyxDQUN2Riw0QkFBNEQsc0JBQUEsQ0FBdkMsWUFBQSxDQUFlLHFCQUFBLENBQWlELFFBQUEsQ0FDckYsa0JBQXNCLHVCQUFBLENBQTBCLGNBQUEsQ0FBaUIsZUFBQSxDQUFrQixtQkFBQSxDQUF4RSxRQUFBLENBQThGLHdCQUFBLENBQ3pHLHlEQUFxRCw4QkFBQSxDQUFtQyxlQUFBLENBQWtCLGdCQUFBLENBQWhFLFFBQWdFLENBQzFHLCtDQUFpQyxVQUFBLENBQ2pDLDJCQUFtQyxrQkFBQSxDQUFmLFlBQUEsQ0FBb0MsUUFBQSxDQUN4RCxtQkFBMkIsa0JBQUEsQ0FBZixZQUFBLENBQW9DLE9BQUEsQ0FDaEQsMEJBQTBGLDhCQUFBLENBQWpDLFFBQUEsQ0FBVyxtQkFBQSxDQUF5RCxjQUFBLENBQTdGLFVBQUEsQ0FBYSxTQUFBLENBQWlHLHlDQUFBLENBQTNILFVBQTJILENBQzlJLGdDQUF5Qiw4QkFBQSxDQUFvQyw2Q0FBMEMsNEJBQUEsQ0FBYixVQUFhLENBQ3ZHLHdCQUE0SSxjQUFBLENBQTVELG1DQUFBLENBQXdDLGlCQUFBLENBQTZDLHFCQUFBLENBQXdCLGNBQUEsQ0FBNUssWUFBQSxDQUE0QixXQUFBLENBQWMsa0JBQUEsQ0FBbUosY0FBQSxDQUE5SyxVQUE4SyxDQUM5TSw0QkFBa0MsV0FBQSxDQUFiLFVBQWEsQ0FBZSxvRUFBc0YsNEJBQUEsQ0FBakMsOEJBQUEsQ0FBZ0UsYUFBQSxDQUFnQixTQUFBLENBQ3RMLHVCQUFnQixZQUFBLENBQWlFLFFBQUEsQ0FBbEQsNkNBQUEsQ0FBNkQsZUFBQSxDQUM1Rix1QkFBMk4sMkNBQUEsQ0FBOUIsMkJBQUEsQ0FBOUQsb0NBQUEsQ0FBeUMsa0JBQUEsQ0FBcEksWUFBQSxDQUFrQyxxQkFBQSxDQUFuQixnQkFBQSxDQUEyQyxlQUFBLENBQWtCLFlBQUEsQ0FBaEcsaUJBQTJNLENBQzNOLDhCQUFtRSx1RUFBQSxDQUEzQyxVQUFBLENBQWlDLE9BQUEsQ0FBa0gsbUJBQUEsQ0FBdEksaUJBQUEsQ0FBMEcseUJBQTRCLENBQXVCLG9DQUE4QiwyRUFBQSxDQUNoTywyRkFBNEQsaUJBQUEsQ0FBcUIsdUJBQStCLHNCQUFBLENBQWYsWUFBQSxDQUF3RSxPQUFBLENBQWhDLDZCQUFnQyxDQUN6SyxvQkFBcUUsa0JBQUEsQ0FBNEQsOEJBQUEsQ0FBcEIsaUJBQUEsQ0FBaEcsWUFBQSxDQUFnQyxxQkFBQSxDQUFqQixjQUFBLENBQThELGdCQUFBLENBQTBFLGNBQUEsQ0FBa0IsaURBQWlDLDRCQUFBLENBQStCLGFBQUEsQ0FDdFAseUJBQWtCLGNBQUEsQ0FBaUIsZUFBQSxDQUFrQixtQkFBQSxDQUFzQix3QkFBQSxDQUE0QiwyQkFBb0IsY0FBQSxDQUFpQixnQkFBQSxDQUM1SSxtQkFBK0Isb0NBQUEsQ0FBeUMsbUJBQUEsQ0FBc0Isc0JBQUEsQ0FBeUIsY0FBQSxDQUEzRyxnQkFBMkcsQ0FDdkgsMEJBQXFDLGNBQUEsQ0FBaUIsZUFBQSxDQUFrQixnQkFBQSxDQUFyRCxlQUFxRCxDQUFvQixtQkFBMkIsa0JBQUEsQ0FBZ0Qsc0JBQUEsQ0FBL0QsWUFBQSxDQUF3RixjQUFBLENBQXBELE9BQUEsQ0FBVSxjQUEwQyxDQUFrQix1QkFBNkIsV0FBQSxDQUFiLFVBQWEsQ0FDL08sdUJBQStCLGtCQUFBLENBQTBGLHdDQUFBLENBQTZDLHVCQUFBLENBQXRKLFlBQUEsQ0FBZ0wsY0FBQSxDQUE1SSw2QkFBQSxDQUFnQyxlQUFBLENBQWtCLGdCQUEwRixDQUNoTSx5QkFBa0IsYUFBQSxDQUFnQixvQkFBQSxDQUF3QiwrQkFBd0IseUJBQUEsQ0FDbEYsd0JBQW9HLDZCQUFBLENBQXBCLGlCQUFBLENBQS9ELFlBQUEsQ0FBNEIsV0FBQSxDQUFjLGtCQUFBLENBQXlFLGNBQUEsQ0FBcEcsVUFBb0csQ0FBa0IsNEJBQWtDLFdBQUEsQ0FBYixVQUFhLENBQWUscURBQWdFLDRCQUFBLENBQStCLGFBQUEsQ0FBMUQsd0JBQTBELENBQ3RTLHNCQUFpQyxzQkFBQSxDQUFsQixlQUFrQixDQUVqQyx3QkFBNkUsa0JBQUEsQ0FBcUIsYUFBQSxDQUE3RCxlQUFBLENBQWtCLG1CQUFBLENBQXRDLGlCQUFpRixDQUNsRyx1QkFBMkQsMkRBQUEsQ0FBaUUseUJBQUEsQ0FBeEYsT0FBQSxDQUFvSCx1REFBQSxDQUExRyxVQUFBLENBQXVLLG1CQUFBLENBQXJNLGlCQUFxTSxDQUF1QiwrQ0FBK0IsaUJBQUEsQ0FBcUIsMENBQTBCLGFBQUEsQ0FDMVQsb0JBQW1KLGVBQUEsQ0FBdEIsbUJBQUEsQ0FBd0MsbUNBQUEsQ0FBeEosWUFBQSxDQUFvRCxPQUFBLENBQTRCLGVBQUEsQ0FBN0MsY0FBQSxDQUEyQixlQUFBLENBQW9DLFdBQUEsQ0FBbkYsaUJBQXlJLENBQ3JLLDJCQUFtRCxrQkFBQSxDQUFtRixjQUFBLENBQWpDLFFBQUEsQ0FBVyxtQkFBQSxDQUErQyx3QkFBQSxDQUE4RCxjQUFBLENBQXpNLFlBQUEsQ0FBZSxhQUFBLENBQXVKLGNBQUEsQ0FBaUIsZUFBQSxDQUFuSSxPQUFBLENBQVUsZ0JBQUEsQ0FBNEoseUNBQUEsQ0FDOU8sOENBQXlDLGtCQUFBLENBQXFCLFVBQUEsQ0FBYyx5Q0FBa0MseUJBQUEsQ0FBNEIsa0JBQUEsQ0FDMUksc0JBQWtHLDBCQUFBLENBQXBCLGlCQUFBLENBQWlELGFBQUEsQ0FBaEgsWUFBQSxDQUFnSSxjQUFBLENBQWlCLGVBQUEsQ0FBckgsV0FBQSxDQUFjLGtCQUFBLENBQTNCLFVBQWtJLENBQW1CLG9FQUFzRCw0QkFBQSxDQUN6TywyQkFBc0Msd0JBQUEsQ0FBMkIsY0FBQSxDQUE3QyxlQUE2QyxDQUNqRSxxQkFBYyxZQUFBLENBQWlFLFFBQUEsQ0FBbEQsNkNBQUEsQ0FBNkQsZUFBQSxDQUFtQixxQkFBcUQsZUFBQSxDQUFyQixrQkFBQSxDQUF1QyxtQ0FBQSxDQUF6RCxlQUFBLENBQStGLHlDQUFBLENBQThDLDJCQUFpRCxzQ0FBQSxDQUE3QiwwQkFBNkIsQ0FBMEMscUJBQThCLGFBQUEsQ0FBaEIsYUFBQSxDQUFnQyxvQkFBQSxDQUNqWiwwQkFBdUMsWUFBQSxDQUFlLGVBQUEsQ0FBbkMsaUJBQW1DLENBQW1CLGdDQUFxRSwrREFBQSxDQUEzQyxVQUFBLENBQWlDLE9BQUEsQ0FBZ0YsbUJBQUEsQ0FBcEcsaUJBQW9HLENBQXVCLDhCQUFvQyxXQUFBLENBQWMsZ0JBQUEsQ0FBbUIsd0JBQUEsQ0FBOUMsVUFBOEMsQ0FBNEIsK0JBQXdCLHFCQUFBLENBQ3BXLDhCQUFzRixrREFBQSxDQUF1RCx1QkFBQSxDQUF0SCxZQUFBLENBQTRCLFdBQUEsQ0FBYyxrQkFBQSxDQUEzQixVQUF1RyxDQUEyQixrQ0FBd0MsV0FBQSxDQUFiLFVBQWEsQ0FDaE4scUJBQTRKLDRCQUFBLENBQXBCLGlCQUFBLENBQTdFLFdBQUEsQ0FBZ0oscUNBQUEsQ0FBaEIsYUFBQSxDQUFsSCxZQUFBLENBQTRCLFdBQUEsQ0FBYyxrQkFBQSxDQUFyRyxpQkFBQSxDQUFnQyxVQUFBLENBQXFNLHdCQUFBLENBQTNKLFVBQUEsQ0FBdEQsU0FBaU4sQ0FBNEIseUJBQStCLFdBQUEsQ0FBYixVQUFhLENBQWUsZ0RBQWdDLG1DQUFBLENBQzdWLHdCQUFpQixZQUFBLENBQWdCLDJCQUErQixjQUFBLENBQWlCLGVBQUEsQ0FBNUIsUUFBNEIsQ0FBbUIsMEJBQW9DLHdCQUFBLENBQTJCLGNBQUEsQ0FBaUIsZ0JBQUEsQ0FBN0QsY0FBNkQsQ0FFcEwsaUJBQWdELHdCQUFBLENBQWxCLGVBQUEsQ0FBcEIsaUJBQXNDLENBQTRCLHlCQUFrQixVQUFBLENBQWMsd0NBQXdCLHVCQUFBLENBQ3BJLHNCQUFnRSxrQkFBQSxDQUFqRCxZQUFBLENBQXNFLFFBQUEsQ0FBdkQsK0JBQXVELENBQVksMEJBQW1CLGVBQUEsQ0FBbUIsb0NBQW1FLHNCQUFBLENBQWxCLGVBQUEsQ0FBbEIsZUFBb0MsQ0FDMU0sdUJBQWdCLFlBQUEsQ0FBaUUsUUFBQSxDQUFsRCw2Q0FBa0QsQ0FBWSxzQkFBaU0sMkJBQUEsQ0FBOUQsb0NBQUEsQ0FBeUMsa0JBQUEsQ0FBbUQsYUFBQSxDQUFoTixZQUFBLENBQWtDLHFCQUFBLENBQXdELFFBQUEsQ0FBaEMsNkJBQUEsQ0FBM0MsZ0JBQUEsQ0FBc0YsWUFBQSxDQUEySCxvQkFBQSxDQUF1QiwyQkFBQSxDQUErQixnRUFBaUQsZ0NBQUEsQ0FBbUMsU0FBQSxDQUN0ZCxzQkFBMEMsdUJBQUEsQ0FBZCxXQUFBLENBQWIsVUFBMkIsQ0FBMkIsNkJBQXFDLGtCQUFBLENBQWYsWUFBQSxDQUE4QyxjQUFBLENBQVYsT0FBVSxDQUFrQiw0QkFBc0Qsc0JBQUEsQ0FBakMsYUFBQSxDQUEwRCxjQUFBLENBQTFDLGNBQTBDLENBQWtCLHVCQUE2QixXQUFBLENBQWMsU0FBQSxDQUFZLDBCQUFBLENBQTZCLGNBQUEsQ0FBcEUsVUFBb0UsQ0FBa0IsbURBQW1DLFNBQUEsQ0FBWSxjQUFBLENBQ2paLHVCQUErQixrQkFBQSxDQUFxRyx3Q0FBQSxDQUFwSCxZQUFBLENBQW9FLFFBQUEsQ0FBaEMsNkJBQUEsQ0FBMkMsZUFBQSxDQUFrQixnQkFBbUIsQ0FBOEMseUJBQStCLHNCQUFBLENBQXlCLGNBQUEsQ0FBcEMsUUFBb0MsQ0FFMU8sd0JBQXNDLGtEQUFBLENBQXJCLGtCQUFxQixDQUN0Qyx3QkFBZ0Msa0JBQUEsQ0FBb0Usc0JBQUEsQ0FBbkYsWUFBQSxDQUFvQyxRQUFBLENBQTZCLGVBQUEsQ0FBbEIsZUFBb0MsQ0FBMEIsNEJBQTRELHVCQUFBLENBQVosU0FBQSxDQUFkLFdBQUEsQ0FBYixVQUF1QyxDQUEyQiwwQkFBbUIsUUFBQSxDQUN4TywyQkFBc0MsY0FBQSxDQUFpQixlQUFBLENBQW5DLGVBQW1DLENBQ3ZELDRCQUFxQixZQUFBLENBQWlFLFFBQUEsQ0FBbEQsNkNBQUEsQ0FBNkQsZUFBQSxDQUNqRyw0QkFBMEUsa0JBQUEsQ0FBMkgsMkJBQUEsQ0FBOUQsb0NBQUEsQ0FBeUMsa0JBQUEsQ0FBbUQscUJBQUEsQ0FBd0IsY0FBQSxDQUF0TyxZQUFBLENBQTZCLHFCQUFBLENBQWQsV0FBQSxDQUFpRixlQUFBLENBQXRCLG1CQUFBLENBQTZLLDhEQUFBLENBQzVRLDRFQUEySCxrQkFBQSxDQUFqQyw4QkFBQSxDQUFzRCxTQUFBLENBQW5GLDBCQUFtRixDQUNoSiw0QkFBcUUsdUJBQUEsQ0FBbkMsV0FBQSxDQUFjLGtCQUFBLENBQTNCLFVBQWdELENBQ3JFLDRCQUF1QyxjQUFBLENBQWlCLGVBQUEsQ0FBbkMsZUFBQSxDQUFxRCxpQkFBQSxDQUMxRSwrR0FBb0osNEJBQUEsQ0FBcEIsaUJBQUEsQ0FBbUQsYUFBQSxDQUFuRyxZQUFBLENBQWUsU0FBQSxDQUFvRyxlQUFBLENBQXhGLGtCQUF3RixDQUNuTSx1QkFBNEUscUJBQUEsQ0FBd0IsY0FBQSxDQUEzRCxXQUFBLENBQWMsa0JBQUEsQ0FBOEQsd0JBQUEsQ0FBekYsVUFBQSxDQUFaLFNBQXFHLENBQTRCLHlEQUF5QyxxQkFBQSxDQUMxTCwyQkFBd0YsNEJBQUEsQ0FBK0IsYUFBQSxDQUFnQixjQUFBLENBQWlCLGVBQUEsQ0FBa0IsZ0JBQUEsQ0FBNUgsZUFBQSxDQUFrQixxQkFBQSxDQUE2SCxpQkFBQSxDQUF6Syx1QkFBeUssQ0FDN0wsZ0NBQXdDLGtCQUFBLENBQWYsWUFBQSxDQUFvRSxRQUFBLENBQWhDLDZCQUFBLENBQTJDLGVBQUEsQ0FBbUIsMkRBQTJDLFFBQUEsQ0FBWSxrQ0FBNEMsc0JBQUEsQ0FBeUIsY0FBQSxDQUExQyxjQUEwQyxDQUFrQixvQ0FBc0UsdUJBQUEsQ0FBWixTQUFBLENBQWQsV0FBQSxDQUFiLFVBQXVDLENBQy9VLHdCQUFpQixZQUFBLENBQWUsY0FBQSxDQUFpQixPQUFBLENBQVUsZUFBQSxDQUMzRCx1QkFBc0Msa0JBQUEsQ0FBZ0gsMkJBQUEsQ0FBOUQsbUNBQUEsQ0FBd0MsbUJBQUEsQ0FBb0QscUJBQUEsQ0FBMkQsY0FBQSxDQUEvTixtQkFBQSxDQUE0TCxjQUFBLENBQWlCLGVBQUEsQ0FBbEssT0FBQSxDQUFVLGdCQUFBLENBQTJMLDRFQUFBLENBQ2hRLGtFQUFnRiw4QkFBQSxDQUFpQyxTQUFBLENBQTlELDBCQUE4RCxDQUFnQiw2QkFBdUQsNEJBQUEsQ0FBakMsOEJBQUEsQ0FBZ0UsYUFBQSxDQUN2Tiw2QkFBaUQsNkJBQUEsQ0FBa0MsYUFBQSxDQUFoRCxXQUFBLENBQWIsVUFBNkQsQ0FBaUIsMERBQTBDLDBCQUFBLENBQzlJLDZCQUFzQixZQUFBLENBQWlFLFFBQUEsQ0FBbEQsNkNBQUEsQ0FBNkQsZUFBQSxDQUNsRyw2QkFBMkcsa0JBQUEsQ0FBb04sa0NBQUEsQ0FBekYsMkJBQUEsQ0FBOUQsb0NBQUEsQ0FBeUMsa0JBQUEsQ0FBbUQscUJBQUEsQ0FBMEMsY0FBQSxDQUFwUSxZQUFBLENBQXNGLFFBQUEsQ0FBdkUsOENBQUEsQ0FBa0YsV0FBQSxDQUFjLFlBQUEsQ0FBbkksaUJBQUEsQ0FBc1EsZUFBQSxDQUErRCx5Q0FBQSxDQUMzViw4RUFBNEYsOEJBQUEsQ0FBaUMsU0FBQSxDQUE5RCwwQkFBOEQsQ0FDN0gscUJBQTBJLDhCQUFBLENBQTdELG9DQUFBLENBQXlDLGlCQUFBLENBQXhHLFlBQUEsQ0FBK0osY0FBQSxDQUFuSSxXQUFBLENBQWMsa0JBQUEsQ0FBM0IsVUFBZ0osQ0FDN0ssNkJBQXNCLFlBQUEsQ0FBNkIscUJBQUEsQ0FBd0IsT0FBQSxDQUF0QyxXQUFzQyxDQUFXLDZCQUFzQixjQUFBLENBQWlCLGVBQUEsQ0FBa0IsZ0JBQUEsQ0FBb0IsbUNBQTZELHVCQUFBLENBQWpDLGFBQUEsQ0FBMkQsY0FBQSxDQUFpQixlQUFBLENBQWtCLG9CQUFBLENBQTlFLGNBQUEsQ0FBcUcsd0JBQUEsQ0FBNEIsdUJBQWdCLHNCQUFBLENBQXlCLGNBQUEsQ0FBaUIsZ0JBQUEsQ0FDMVksK0JBQXFELGtCQUFBLENBQTdCLFlBQUEsQ0FBNEQsY0FBQSxDQUFpQixlQUFBLENBQTNCLE9BQUEsQ0FBbkMsV0FBOEQsQ0FBbUIsK0JBQW1ELG1DQUFBLENBQXdDLGNBQUEsQ0FBdEQsV0FBQSxDQUFiLFVBQW1FLENBQWtCLDhCQUFpRSx1QkFBQSxDQUEwQixjQUFBLENBQWlCLFNBQUEsQ0FBckYsaUJBQUEsQ0FBOEIsU0FBQSxDQUFWLE9BQUEsQ0FBNkUsOEJBQUEsQ0FBa0Msb0NBQUEsQ0FBeUMsMElBQXlHLFNBQUEsQ0FBWSwwQkFBQSxDQUM3aEIscUJBQTZCLGtCQUFBLENBQTJGLDRCQUFBLENBQXJCLGtCQUFBLENBQW9ELGFBQUEsQ0FBekksWUFBQSxDQUFvQyxRQUFBLENBQVcsZUFBQSxDQUFrQixpQkFBd0UsQ0FBaUIseUJBQWlILGtCQUFBLENBQXBCLGlCQUFBLENBQXlDLHVCQUFBLENBQXBILFlBQUEsQ0FBMEMsU0FBQSxDQUFvRyx5QkFBQSxDQUE2QixjQUFBLENBQWlCLGVBQUEsQ0FBaEssV0FBQSxDQUEwQixrQkFBQSxDQUF2QyxVQUE2SyxDQUFtQix1QkFBMkIsY0FBQSxDQUFpQixlQUFBLENBQTVCLFFBQTRCLENBQ3JiLDhCQUFpTCw0Q0FBQSxDQUE1Qix5QkFBQSxDQUE5QiwyQkFBQSxDQUFuRCxZQUFBLENBQVYsT0FBQSxDQUE4QyxZQUFBLENBQXJCLGtCQUFBLENBQTVELGNBQUEsQ0FBaUIsZUFBeUksQ0FDakwsc0JBQW9SLDRDQUFBLENBQWxGLGtCQUFBLENBQTdELG1DQUFBLENBQXdDLGtCQUFBLENBQTBDLHNDQUFBLENBQTNKLDBCQUFBLENBQThCLGVBQUEsQ0FBa0Isc0JBQUEsQ0FBN0YsaUJBQUEsQ0FBaVAsaUJBQUEsQ0FBN04scUJBQWlQLENBQ3BSLDJCQUE0TCxrQkFBQSxDQUE3RCxvQ0FBQSxDQUF5QyxpQkFBQSxDQUF5QyxxQkFBQSxDQUF5QyxjQUFBLENBQTFMLFlBQUEsQ0FBeUssY0FBQSxDQUE3SSxXQUFBLENBQWMsa0JBQUEsQ0FBdEYsaUJBQUEsQ0FBK0IsVUFBQSxDQUFYLFFBQUEsQ0FBbU8seUNBQUEsQ0FBNUwsVUFBNEwsQ0FBOEMsMEVBQTRGLDRCQUFBLENBQWpDLDhCQUFBLENBQWdFLGFBQUEsQ0FBZ0IsU0FBQSxDQUNwYyw0QkFBcUUscUJBQUEsQ0FBd0IsY0FBQSxDQUEzRCxXQUFBLENBQWMsa0JBQUEsQ0FBM0IsVUFBd0UsQ0FBa0IseUJBQTZCLGNBQUEsQ0FBWCxRQUFXLENBQWtCLDBCQUFvQyx1QkFBQSxDQUEwQixjQUFBLENBQWlCLGVBQUEsQ0FBa0Isb0JBQUEsQ0FBOUUsY0FBQSxDQUFxRyx3QkFBQSxDQUN0UiwwQkFBbUIsWUFBQSxDQUFlLGNBQUEsQ0FBMEMsT0FBQSxDQUF6QixzQkFBQSxDQUFtQyxlQUFBLENBQW1CLCtCQUE4QyxrQkFBQSxDQUFpSCxrQkFBQSxDQUEvRCxvQ0FBQSxDQUF5QyxtQkFBQSxDQUEyQyxxQkFBQSxDQUE1SixtQkFBQSxDQUFvTCxjQUFBLENBQXpJLE9BQUEsQ0FBVSxnQkFBQSxDQUFnSixlQUFBLENBQW1CLDhCQUE4RCx1QkFBQSxDQUFaLFNBQUEsQ0FBZCxXQUFBLENBQWIsVUFBdUMsQ0FDdlosMkJBQW9CLEdBQU8sU0FBQSxDQUFjLEdBQUssU0FBQSxDQUFBLENBRTlDLG9CQUNFLGtCQUFBLENBQ0Esb0JBQUEsQ0FDQSxzQkFBQSxDQUNBLGtCQUFBLENBQ0EsZ0NBQUEsQ0FDQSxrQ0FBQSxDQUNBLGlDQUFBLENBS0EsMEJBQUEsQ0FDQSx3QkFBQSxDQUNBLDZFQUFBLENBSkEsT0FBQSxDQUtBLGdCQUFBLENBSkEsYUFBQSxDQUhBLGNBQUEsQ0FRQSxzQkFBQSxDQVBBLGNBT0EsQ0FFRiw2RUFBMEQscUJBQUEsQ0FDMUQsb0JBQW1FLG9CQUFBLENBQStELHVJQUFBLENBQWpHLFlBQUEsQ0FBZSxnQkFBQSxDQUEwQyxlQUFBLENBQWtCLG1CQUFBLENBQS9GLGlCQUFxSCxDQUNsSSwyQkFBb0QscUVBQUEsQ0FBaEMsaUJBQUEsQ0FBb0IsU0FBWSxDQUNwRCx1QkFBMkIsY0FBQSxDQUFpQixlQUFBLENBQXFDLG1CQUFBLENBQW5CLGdCQUFBLENBQTlDLFFBQUEsQ0FBdUYsd0NBQUEsQ0FDdkcseUJBQW9JLHNFQUFBLENBQWpDLDhCQUFBLENBQXBCLGlCQUFBLENBQTdELGFBQUEsQ0FBOEIsVUFBQSxDQUFhLGVBQUEsQ0FBM0IsV0FBa0csQ0FDcEksdUJBQXFFLFVBQUEsQ0FBakMsaUJBQUEsQ0FBOEMsV0FBQSxDQUFjLG1CQUFBLENBQWhGLGlCQUFBLENBQXdDLFVBQXdDLENBQ2hHLG9CQUFvRixpRkFBQSxDQUFzRixpQkFBQSxDQUFyRyxZQUFBLENBQXlILG1CQUFBLENBQWpMLGlCQUFBLENBQStCLFFBQUEsQ0FBWCxRQUFBLENBQXNCLFdBQXVJLENBQzlMLHFEQUF5SCxpRUFBQSxDQUFqQyw4QkFBQSxDQUFsRCxpQkFBQSxDQUF3QyxPQUFBLENBQVIsS0FBQSxDQUFaLFNBQStELENBQ3pILHNCQUE0Qyx3REFBQSxDQUFmLFlBQUEsQ0FBZCxXQUE2QixDQUM1QywrQkFBK0csb0JBQUEsQ0FBNUMseUNBQUEsQ0FBN0IsWUFBQSxDQUFlLFdBQUEsQ0FBN0IsV0FBdUYsQ0FDL0cscUJBQWMsZ0JBQUEsQ0FBbUIsc0JBQUEsQ0FDakMsdUJBQWdCLG1CQUFBLENBQ2hCLDJCQUFtQyxrQkFBQSxDQUFmLFlBQUEsQ0FBb0MsUUFBQSxDQUFXLGtCQUFBLENBQ25FLDBCQUE2RSw4QkFBQSxDQUFwQixpQkFBQSxDQUFaLFNBQUEsQ0FBZCxXQUFBLENBQVosU0FBMEQsQ0FDN0UsOEJBQWtDLGNBQUEsQ0FBaUIsZUFBQSxDQUE1QixRQUE0QixDQUNuRCxvQkFBaUMsd0JBQUEsQ0FBMkIsY0FBQSxDQUFpQixlQUFBLENBQWhFLGlCQUFnRSxDQUM3RSxnREFBdUUsdUJBQUEsQ0FBMEIsZ0JBQUEsQ0FBL0Msa0JBQUEsQ0FBbEIsZUFBaUUsQ0FDakcsdUJBQWdCLHlCQUFBLENBQTRCLGVBQUEsQ0FBa0IseUJBQUEsQ0FBNEIseUJBQUEsQ0FDMUYsNkJBQXNCLHdCQUFBLENBQ3RCLHVCQUEwQyx1QkFBQSxDQUEwQixnQkFBQSxDQUFwRCx1QkFBb0QsQ0FDcEUsbUJBQVksWUFBQSxDQUFpRSxRQUFBLENBQWxELDZDQUFrRCxDQUM3RSxtQkFBeUgsaUVBQUEsQ0FBL0IsNEJBQUEsQ0FBNUQsb0NBQUEsQ0FBdUMsa0JBQUEsQ0FBekQsZUFBQSxDQUF3SyxpRUFBQSxDQUNwTCx5QkFBK0Msd0NBQUEsQ0FBN0IsMEJBQTZCLENBQy9DLG9CQUFzRyw2SEFBQSxDQUFyRSxZQUFBLENBQWUsWUFBQSxDQUFvQyxlQUFBLENBQXJCLGtCQUFBLENBQWxELGlCQUF5RixDQUN0Ryx5QkFBa0IsYUFBQSxDQUE2QixXQUFBLENBQWMsZ0JBQUEsQ0FBbUIsc0JBQUEsQ0FBOUMsVUFBOEMsQ0FDaEYsMEJBQXFGLDhCQUFBLENBQWlDLHVDQUFBLENBQTBDLFVBQUEsQ0FBekYsV0FBQSxDQUFuRCxpQkFBQSxDQUE0QixPQUFBLENBQVIsS0FBQSxDQUFrQixVQUFzRyxDQUNoSyxtQkFBWSxzQkFBQSxDQUF5QixlQUFBLENBQ3JDLHNCQUEwQixjQUFBLENBQWlCLGVBQUEsQ0FBNUIsUUFBNEIsQ0FDM0MscUJBQStCLHlCQUFBLENBQTRCLGNBQUEsQ0FBN0MsY0FBNkMsQ0FDM0Qsb0JBQWEsWUFBQSxDQUF3QyxRQUFBLENBQXpCLHNCQUFBLENBQW9DLGVBQUEsQ0FDaEUseUJBQTRELGtCQUFBLENBQTZHLGNBQUEsQ0FBL0Qsc0NBQUEsQ0FBMkMsaUJBQUEsQ0FBNkMsd0JBQUEsQ0FBMkIsY0FBQSxDQUEzTSxZQUFBLENBQTRCLFdBQUEsQ0FBbUMsc0JBQUEsQ0FBNkosbUJBQUEsQ0FBN00sVUFBNk0sQ0FDOU8sNkJBQWlELGlCQUFBLENBQWQsV0FBQSxDQUFiLFVBQTJCLENBQ2pELHNFQUFrSCw4QkFBQSxDQUFuQyxnQ0FBQSxDQUFvRSxxQkFBQSxDQUF3QixTQUFBLENBQXBILHFCQUFvSCxDQUMzSyxrQ0FBMkIsa0JBQUEsQ0FDM0IsdUJBQWdCLFlBQUEsQ0FBaUUsUUFBQSxDQUFsRCw2Q0FBa0QsQ0FDakYseUJBQThMLHFFQUFBLENBQWhELDRCQUFBLENBQTVELG9DQUFBLENBQXVDLGtCQUFBLENBQW9ELGNBQUEsQ0FBdkksV0FBQSxDQUFjLGVBQUEsQ0FBa0IsU0FBQSxDQUFwRCxpQkFBQSxDQUEyTyxpRUFBQSxDQUM3UCwrQkFBcUQsdUVBQUEsQ0FBN0IsMEJBQTZCLENBQ3JELHVDQUFnQyxxQ0FBQSxDQUF3QyxrQkFBQSxDQUN4RSx3QkFBaUIsYUFBQSxDQUE2QixXQUFBLENBQWIsVUFBYSxDQUM5Qyw2QkFBZ0UsZUFBQSxDQUE3Qix5QkFBQSxDQUErQyxrQkFBQSxDQUE1RCxVQUE0RCxDQUNsRixzQkFBZ0csd0NBQUEsQ0FBMkMseUJBQUEsQ0FBOEIsZ0JBQUEsQ0FBcEgsZUFBQSxDQUFsQixlQUFBLENBQW9DLHNCQUFBLENBQXhELGlCQUEwSixDQUN6Syx1QkFBNEUsa0JBQUEsQ0FBK0ksNENBQUEsQ0FBNUIseUJBQUEsQ0FBaEMsNkJBQUEsQ0FBbEcsWUFBQSxDQUFWLE9BQUEsQ0FBOEMsc0JBQUEsQ0FBeUIsYUFBQSxDQUFnQixrQkFBQSxDQUExSCxjQUFBLENBQWlCLGVBQTBMLENBQzNOLHVCQUF5RSxXQUFBLENBQWpCLGNBQUEsQ0FBeEMsaUJBQUEsQ0FBb0IsaUJBQXFDLENBQ3pFLHNCQUF5SyxvRUFBQSxDQUExRSw0QkFBQSxDQUE5RCxvQ0FBQSxDQUF5QyxrQkFBQSxDQUFvRCx3Q0FBQSxDQUEvRyxlQUFBLENBQXdOLGtCQUFBLENBQ3ZPLDZCQUFzQix1REFBQSxDQUN0QixpQ0FBMEIsMkRBQUEsQ0FDMUIsNEJBQXFCLHVEQUFBLENBQ3JCLGdDQUF5QiwyREFBQSxDQUN6Qix1QkFBZ0gsa0JBQUEsQ0FBNEcsNEJBQUEsQ0FBOUQscUNBQUEsQ0FBMEMsaUJBQUEsQ0FBbUQsd0JBQUEsQ0FBNEMsY0FBQSxDQUFqTyxZQUFBLENBQWdOLGNBQUEsQ0FBcEwsV0FBQSxDQUFtQyxzQkFBQSxDQUFySCxpQkFBQSxDQUE0QyxPQUFBLENBQVosU0FBQSxDQUF3USxtQkFBQSxDQUFuTyxVQUFBLENBQWpELFNBQW9SLENBQ3hULGtFQUFnSCw4QkFBQSxDQUFuQyxnQ0FBQSxDQUFvRSxxQkFBQSxDQUF3QixTQUFBLENBQXRILHVCQUFzSCxDQUN6SyxxQkFBa0csa0JBQUEsQ0FBeUksNkJBQUEsQ0FBOUQscUNBQUEsQ0FBMEMsaUJBQUEsQ0FBb0Qsd0JBQUEsQ0FBNEMsY0FBQSxDQUEvUCxZQUFBLENBQThPLGNBQUEsQ0FBbE4sV0FBQSxDQUFtQyxzQkFBQSxDQUF6RyxpQkFBQSxDQUFnQyxPQUFBLENBQWtHLDBCQUFBLENBQXdMLG1CQUFBLENBQWpRLFVBQUEsQ0FBckMsU0FBc1MsQ0FDeFUsOERBQTBILDhCQUFBLENBQW5DLGdDQUFBLENBQW9FLHFCQUFBLENBQXdCLFNBQUEsQ0FBcEkscUNBQW9JLENBQ25MLDBCQUFtQixVQUFBLENBQWMsc0JBQWUsV0FBQSxDQUNoRCxzQkFBNEUsa0JBQUEsQ0FBekMsWUFBQSxDQUEwQixZQUFBLENBQW9DLE9BQUEsQ0FBL0MsUUFBQSxDQUFuQyxpQkFBQSxDQUE0RiwwQkFBQSxDQUMzRyxxQkFBa0YsNkJBQUEsQ0FBL0IsUUFBQSxDQUFXLGlCQUFBLENBQXNELGNBQUEsQ0FBMUYsVUFBQSxDQUFhLFNBQUEsQ0FBOEYsa0JBQUEsQ0FBdkgsU0FBdUgsQ0FDckksOERBQStDLDZCQUFBLENBQWtDLHFDQUFBLENBQXdDLGtCQUFBLENBQ3pILDJCQUFxRCw4QkFBQSxDQUFwQixpQkFBQSxDQUFiLFVBQWlDLENBQ3JELHNCQUEwRSxrQkFBQSxDQUEwQyx5QkFBQSxDQUF6RCxZQUFBLENBQXVGLGNBQUEsQ0FBbkQsT0FBQSxDQUE3QyxNQUFpSCxDQUNuSyxnREFEbUMsWUFBQSxDQUFzRSxRQUFBLENBQTFGLGlCQUFBLENBQW9KLGtCQUNMLENBQTlKLDBCQUEyRSx5QkFBQSxDQUE4QixjQUFBLENBQWlCLGlDQUFBLENBQW5GLE9BQXVILENBQzlKLDBCQUEwRCxvQ0FBQSxDQUF5QyxpQkFBQSxDQUFoRixvQkFBQSxDQUFvRyxZQUFBLENBQWUsZ0JBQUEsQ0FBNUYsYUFBNEYsQ0FDdEksaUNBQTBCLEdBQU8sMEJBQUEsQ0FBK0IsR0FBSyx1QkFBQSxDQUFBLENBQ3JFLGdDQUF5QixHQUFPLFNBQUEsQ0FBWSwwQkFBQSxDQUErQixHQUFLLFNBQUEsQ0FBWSx1QkFBQSxDQUFBLENBQzVGLGdDQUF5QixHQUFPLFNBQUEsQ0FBWSxxQ0FBQSxDQUEwQyxHQUFLLFNBQUEsQ0FBWSxnQ0FBQSxDQUFBLENBQ3ZHLG9DQUE2QixHQUFPLFNBQUEsQ0FBWSwwQkFBQSxDQUErQixHQUFLLFNBQUEsQ0FBWSx1QkFBQSxDQUFBLENBQ2hHLG1DQUE0QixHQUFPLFNBQUEsQ0FBWSwwQkFBQSxDQUErQixHQUFLLFNBQUEsQ0FBWSx1QkFBQSxDQUFBLENBQy9GLGdDQUF5QixHQUFPLFNBQUEsQ0FBYyxHQUFLLFNBQUEsQ0FBQSxDQUNuRCx1Q0FBZ0MsR0FBTyxTQUFBLENBQVksdUJBQUEsQ0FBNEIsR0FBSyxTQUFBLENBQVksMkJBQUEsQ0FBQSxDQUNoRywyQ0FBb0MsR0FBTyxTQUFBLENBQVksdUJBQUEsQ0FBNEIsR0FBSyxTQUFBLENBQVksMEJBQUEsQ0FBQSxDQUNwRyxzQ0FBK0IsR0FBTyxTQUFBLENBQVksMEJBQUEsQ0FBK0IsR0FBSyxTQUFBLENBQVksdUJBQUEsQ0FBQSxDQUNsRywwQ0FBbUMsR0FBTyxTQUFBLENBQVksMkJBQUEsQ0FBZ0MsR0FBSyxTQUFBLENBQVksdUJBQUEsQ0FBQSxDQUN2RywwQkFBNkIsbUJBQVksNkNBQUEsQ0FBb0QsdUJBQWdCLDZDQUFBLENBQUEsQ0FDN0cseUJBQ0Usb0JBQWEsZ0JBQUEsQ0FBbUIsbUJBQUEsQ0FBdUIsdUJBQWdCLGNBQUEsQ0FDdkUscUJBQWMsc0JBQUEsQ0FBMEIsdUJBQWdCLG1CQUFBLENBQXVCLHNCQUFlLHNCQUFBLENBQzlGLG1CQUE4RCxRQUFBLENBQWxELDZDQUFrRCxDQUFZLG9CQUFhLFlBQUEsQ0FDdkYsdUJBQWtFLFFBQUEsQ0FBbEQsNkNBQWtELENBQ2xFLHVCQUFnQixpQkFBQSxDQUFxQiw2QkFBdUMsZUFBQSxDQUFqQixjQUFpQixDQUFtQiwwQkFBbUIsUUFBQSxDQUFZLHNCQUFlLFNBQUEsQ0FBYSxzQkFBZSxZQUFBLENBQUEsQ0FFM0sseUJBQTRCLG1CQUFZLHlCQUFBLENBQTZCLG9CQUFhLFlBQUEsQ0FBZ0IsdUJBQWdCLDZDQUFBLENBQW1ELHFCQUEyQixXQUFBLENBQWIsVUFBYSxDQUFlLDBCQUFtQixRQUFBLENBQVksc0JBQWUsU0FBQSxDQUFBLENBQzdQLHVDQUEwQyw2RUFBMEQsK0JBQUEsQ0FBc0MscUNBQUEsQ0FBeUMsZ0NBQUEsQ0FBd0Msb0JBQWEsb0JBQUEsQ0FBQSxDQUV4TywyQkFBb0IsR0FBTyxTQUFBLENBQVksMEJBQUEsQ0FBK0IsR0FBSyxTQUFBLENBQVksdUJBQUEsQ0FBQSxDQUN2RixpREFBcUQsc0JBQWUsY0FBQSxDQUFBLENBQ3BFLHlCQUE0QiwyQ0FBNEIsNkJBQUEsQ0FBbUMsbUJBQVksZ0JBQUEsQ0FBQSxDQUN2RywwQkFBNkIscUJBQWMsNkNBQUEsQ0FBb0QsdUJBQWdCLDZDQUFBLENBQW9ELHNCQUFlLHlCQUFBLENBQUEsQ0FDbEwsMEJBQTZCLDRCQUFxQiw2Q0FBQSxDQUFvRCw2QkFBc0IsNkNBQUEsQ0FBQSxDQUM1SCx5QkFBNEIsbUNBQW9CLGVBQUEsQ0FBb0IsMkNBQTRCLDZCQUFBLENBQW1DLGlCQUFVLGtCQUFBLENBQXVCLHFCQUFjLFlBQUEsQ0FBaUIsbUJBQVksZ0JBQUEsQ0FBbUIsZ0JBQUEsQ0FBcUIsc0JBQWUsK0JBQUEsQ0FBc0MscUJBQWdCLGNBQUEsQ0FBbUIscUJBQWdFLFFBQUEsQ0FBbEQsNkNBQWtELENBQWEsd0JBQWlCLFFBQUEsQ0FBVyxZQUFBLENBQWlCLHFCQUEyQixXQUFBLENBQWIsVUFBYSxDQUFnQix5QkFBK0IsV0FBQSxDQUFiLFVBQWEsQ0FBZ0Isc0JBQWUsY0FBQSxDQUFtQixzQkFBZSxXQUFBLENBQWMsY0FBQSxDQUFtQixzQkFBZSxZQUFBLENBQWlCLGtEQUFtQyxrQkFBQSxDQUF1Qix3QkFBaUIsc0JBQUEsQ0FBeUIscUJBQUEsQ0FBMEIsMkJBQW9CLG1CQUFBLENBQXdCLHVCQUFnQixRQUFBLENBQVcsZUFBQSxDQUFvQix1QkFBZ0IsZ0JBQUEsQ0FBbUIsWUFBQSxDQUFpQixtQkFBWSxjQUFBLENBQW1CLDBCQUFxQyxjQUFBLENBQWxCLGVBQWtCLENBQW1CLG9CQUEwQixrQkFBQSxDQUFiLFVBQWEsQ0FBdUIscUJBQTBDLFFBQUEsQ0FBNUIseUJBQTRCLENBQWEsMEJBQW1CLFlBQUEsQ0FBaUIsd0NBQXdCLGdCQUFBLENBQXFCLHVCQUFnQix5QkFBQSxDQUE4QixzQkFBZSxnQkFBQSxDQUFtQixZQUFBLENBQWlCLHVCQUFnQixzQkFBQSxDQUF5QixxQkFBQSxDQUF3QixlQUFBLENBQ3h6Qyx3QkFBaUIsa0JBQUEsQ0FBdUIsNEJBQXVFLFFBQUEsQ0FBbEQsNkNBQWtELENBQWEsMkJBQXNDLGNBQUEsQ0FBbEIsZUFBa0IsQ0FBa0IsZ0NBQXlCLGVBQUEsQ0FBbUIsNkJBQXNCLHlCQUFBLENBQTZCLDZCQUFzQiw4Q0FBQSxDQUFtRCxxQkFBYyxzQkFBQSxDQUF5QixZQUFBLENBQWdCLHVCQUFnQixjQUFBLENBRHE1QixDQUVwMUMsdUNBQTBDLGlCQUEyRCwrQkFBQSxDQUFzQyxxQ0FBQSxDQUF4RSw4QkFBQSxDQUFpSCxnQ0FBQSxDQUFBIiwiZmlsZSI6IkhvbWVQYWdlLm1vZHVsZS5jc3MifQ== */", true);

// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  homePage_2a396803: "homePage_2a396803",
  hero_2a396803: "hero_2a396803",
  heroGrid_2a396803: "heroGrid_2a396803",
  heroImage_2a396803: "heroImage_2a396803",
  heroShade_2a396803: "heroShade_2a396803",
  heroInner_2a396803: "heroInner_2a396803",
  sectionInner_2a396803: "sectionInner_2a396803",
  header_2a396803: "header_2a396803",
  brandLink_2a396803: "brandLink_2a396803",
  brand_2a396803: "brand_2a396803",
  brandMark_2a396803: "brandMark_2a396803",
  brandTagline_2a396803: "brandTagline_2a396803",
  navigation_2a396803: "navigation_2a396803",
  heroCopy_2a396803: "heroCopy_2a396803",
  riseIn_2a396803: "riseIn_2a396803",
  portalArea_2a396803: "portalArea_2a396803",
  portalGrid_2a396803: "portalGrid_2a396803",
  portalCard_2a396803: "portalCard_2a396803",
  portalGlow_2a396803: "portalGlow_2a396803",
  portalContent_2a396803: "portalContent_2a396803",
  portalTop_2a396803: "portalTop_2a396803",
  portalIcon_2a396803: "portalIcon_2a396803",
  portalArrow_2a396803: "portalArrow_2a396803",
  portalEyebrow_2a396803: "portalEyebrow_2a396803",
  portalTitle_2a396803: "portalTitle_2a396803",
  colorBar_2a396803: "colorBar_2a396803",
  footerColorBar_2a396803: "footerColorBar_2a396803",
  exploreLink_2a396803: "exploreLink_2a396803",
  featuredSection_2a396803: "featuredSection_2a396803",
  sectionHeader_2a396803: "sectionHeader_2a396803",
  sectionTitleBlock_2a396803: "sectionTitleBlock_2a396803",
  eyebrow_2a396803: "eyebrow_2a396803",
  contactIntro_2a396803: "contactIntro_2a396803",
  carouselControls_2a396803: "carouselControls_2a396803",
  pageDots_2a396803: "pageDots_2a396803",
  activeDot_2a396803: "activeDot_2a396803",
  carouselArrow_2a396803: "carouselArrow_2a396803",
  featuredGrid_2a396803: "featuredGrid_2a396803",
  featuredCard_2a396803: "featuredCard_2a396803",
  featuredMeta_2a396803: "featuredMeta_2a396803",
  location_2a396803: "location_2a396803",
  registerLine_2a396803: "registerLine_2a396803",
  dateBadge_2a396803: "dateBadge_2a396803",
  category_2a396803: "category_2a396803",
  registerArrow_2a396803: "registerArrow_2a396803",
  dataMessage_2a396803: "dataMessage_2a396803",
  stagesSection_2a396803: "stagesSection_2a396803",
  stagePattern_2a396803: "stagePattern_2a396803",
  stageTabs_2a396803: "stageTabs_2a396803",
  stageNumber_2a396803: "stageNumber_2a396803",
  stageDescription_2a396803: "stageDescription_2a396803",
  courseGrid_2a396803: "courseGrid_2a396803",
  courseCard_2a396803: "courseCard_2a396803",
  courseLink_2a396803: "courseLink_2a396803",
  courseImageWrap_2a396803: "courseImageWrap_2a396803",
  courseImageFallback_2a396803: "courseImageFallback_2a396803",
  courseIcon_2a396803: "courseIcon_2a396803",
  courseContent_2a396803: "courseContent_2a396803",
  footer_2a396803: "footer_2a396803",
  contactGrid_2a396803: "contactGrid_2a396803",
  contactCards_2a396803: "contactCards_2a396803",
  contactCard_2a396803: "contactCard_2a396803",
  contactIcon_2a396803: "contactIcon_2a396803",
  contactArrow_2a396803: "contactArrow_2a396803",
  footerBottom_2a396803: "footerBottom_2a396803",
  talentSection_2a396803: "talentSection_2a396803",
  talentSubhead_2a396803: "talentSubhead_2a396803",
  talentGroupTitle_2a396803: "talentGroupTitle_2a396803",
  talentServiceGrid_2a396803: "talentServiceGrid_2a396803",
  talentServiceCard_2a396803: "talentServiceCard_2a396803",
  talentServiceIcon_2a396803: "talentServiceIcon_2a396803",
  talentServiceName_2a396803: "talentServiceName_2a396803",
  talentAvatar_2a396803: "talentAvatar_2a396803",
  talentFilterAvatar_2a396803: "talentFilterAvatar_2a396803",
  talentLocationAvatar_2a396803: "talentLocationAvatar_2a396803",
  talentModalAvatar_2a396803: "talentModalAvatar_2a396803",
  talentPersonName_2a396803: "talentPersonName_2a396803",
  talentLocationHeading_2a396803: "talentLocationHeading_2a396803",
  talentFilters_2a396803: "talentFilters_2a396803",
  talentFilter_2a396803: "talentFilter_2a396803",
  talentFilterActive_2a396803: "talentFilterActive_2a396803",
  talentLocationGrid_2a396803: "talentLocationGrid_2a396803",
  talentLocationCard_2a396803: "talentLocationCard_2a396803",
  talentFlag_2a396803: "talentFlag_2a396803",
  talentLocationInfo_2a396803: "talentLocationInfo_2a396803",
  talentLocationName_2a396803: "talentLocationName_2a396803",
  talentCities_2a396803: "talentCities_2a396803",
  talentLocationPerson_2a396803: "talentLocationPerson_2a396803",
  talentLocationArrow_2a396803: "talentLocationArrow_2a396803",
  talentNote_2a396803: "talentNote_2a396803",
  talentNoteIcon_2a396803: "talentNoteIcon_2a396803",
  talentModalBackdrop_2a396803: "talentModalBackdrop_2a396803",
  fadeIn_2a396803: "fadeIn_2a396803",
  talentModal_2a396803: "talentModal_2a396803",
  talentModalClose_2a396803: "talentModalClose_2a396803",
  talentModalRole_2a396803: "talentModalRole_2a396803",
  talentModalTags_2a396803: "talentModalTags_2a396803",
  auditPage_2a396803: "auditPage_2a396803",
  auditHero_2a396803: "auditHero_2a396803",
  auditHeroContent_2a396803: "auditHeroContent_2a396803",
  auditRiseIn_2a396803: "auditRiseIn_2a396803",
  auditUnderline_2a396803: "auditUnderline_2a396803",
  auditSkyline_2a396803: "auditSkyline_2a396803",
  auditGlow_2a396803: "auditGlow_2a396803",
  auditCornerSecondary_2a396803: "auditCornerSecondary_2a396803",
  auditCorner_2a396803: "auditCorner_2a396803",
  auditSlideIn_2a396803: "auditSlideIn_2a396803",
  auditIntro_2a396803: "auditIntro_2a396803",
  auditSection_2a396803: "auditSection_2a396803",
  auditSectionHead_2a396803: "auditSectionHead_2a396803",
  auditSectionBar_2a396803: "auditSectionBar_2a396803",
  auditLead_2a396803: "auditLead_2a396803",
  auditSubhead_2a396803: "auditSubhead_2a396803",
  teamGrid_2a396803: "teamGrid_2a396803",
  teamCard_2a396803: "teamCard_2a396803",
  auditCardIn_2a396803: "auditCardIn_2a396803",
  teamPhoto_2a396803: "teamPhoto_2a396803",
  teamPhotoImage_2a396803: "teamPhotoImage_2a396803",
  teamBody_2a396803: "teamBody_2a396803",
  teamIcons_2a396803: "teamIcons_2a396803",
  teamIconButton_2a396803: "teamIconButton_2a396803",
  postcardGrid_2a396803: "postcardGrid_2a396803",
  postcardButton_2a396803: "postcardButton_2a396803",
  auditPostcardIn_2a396803: "auditPostcardIn_2a396803",
  postcardImage_2a396803: "postcardImage_2a396803",
  postcardImageLarge_2a396803: "postcardImageLarge_2a396803",
  auditFooter_2a396803: "auditFooter_2a396803",
  galleryModal_2a396803: "galleryModal_2a396803",
  auditFadeIn_2a396803: "auditFadeIn_2a396803",
  galleryInner_2a396803: "galleryInner_2a396803",
  galleryCard_2a396803: "galleryCard_2a396803",
  auditGalleryIn_2a396803: "auditGalleryIn_2a396803",
  galleryFadeOutNext_2a396803: "galleryFadeOutNext_2a396803",
  galleryFadeOutPrevious_2a396803: "galleryFadeOutPrevious_2a396803",
  galleryFadeInNext_2a396803: "galleryFadeInNext_2a396803",
  galleryFadeInPrevious_2a396803: "galleryFadeInPrevious_2a396803",
  galleryClose_2a396803: "galleryClose_2a396803",
  galleryNav_2a396803: "galleryNav_2a396803",
  galleryPrevious_2a396803: "galleryPrevious_2a396803",
  galleryNext_2a396803: "galleryNext_2a396803",
  galleryDots_2a396803: "galleryDots_2a396803",
  galleryDot_2a396803: "galleryDot_2a396803",
  galleryDotActive_2a396803: "galleryDotActive_2a396803",
  galleryHint_2a396803: "galleryHint_2a396803",
  galleryPosition_2a396803: "galleryPosition_2a396803"
});


/***/ }),

/***/ 807:
/*!******************************************************!*\
  !*** ./lib/webparts/homePage/components/HomePage.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ HomePage)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _microsoft_sp_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @microsoft/sp-http */ 909);
/* harmony import */ var _microsoft_sp_http__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_http__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _HomePage_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./HomePage.module.scss */ 315);
/* harmony import */ var _assets_img_png__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../assets/img.png */ 411);




var css = _HomePage_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"];
var postcardsApiUrl = "https://sites.ey.com/sites/MENATaxHub/_api/web/lists/getByTitle('PostcardsAndVideos')/items?$select=*,File/Name&$expand=File";
var team = [
    { name: 'Corey Porter', role: 'Audit Transformation Lead' },
    { name: 'Sammi Cassin', role: 'Program Manager' },
    { name: 'Kishore Menon', role: 'Solution Architect' },
    { name: 'Noha Ali', role: 'Communications Lead' },
    { name: 'Rahul L C', role: 'Project Manager' }
];
function MailIcon() {
    return react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", { viewBox: "0 0 24 24", "aria-hidden": "true" },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { d: "M2 5h20v14H2V5zm2 2v.5l8 5.5 8-5.5V7H4zm16 3.2-8 5.5-8-5.5V17h16v-6.8z" }));
}
function PhoneIcon() {
    return react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", { viewBox: "0 0 24 24", "aria-hidden": "true" },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { d: "M6.6 10.8c1.4 2.8 3.8 5.1 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.2.4 2.4.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1C10.6 21 3 13.4 3 4c0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.2.2 2.4.6 3.6.1.3 0 .7-.2 1l-2.3 2.2z" }));
}
function PersonIcon() {
    return react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", { viewBox: "0 0 24 24", "aria-hidden": "true" },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { d: "M12 12a4.5 4.5 0 1 0 0-9 4.5 4.5 0 0 0 0 9zm0 2c-4 0-8 2-8 5v2h16v-2c0-3-4-5-8-5z" }));
}
function Skyline() {
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", { className: css.auditSkyline, viewBox: "0 0 1400 200", preserveAspectRatio: "none", "aria-hidden": "true" },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", { fill: "#1a1a24", opacity: ".92" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", { x: "30", y: "90", width: "70", height: "110" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", { x: "110", y: "60", width: "55", height: "140" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", { x: "180", y: "100", width: "80", height: "100" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", { x: "280", y: "40", width: "60", height: "160" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", { x: "355", y: "80", width: "45", height: "120" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", { x: "415", y: "110", width: "90", height: "90" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", { x: "530", y: "55", width: "65", height: "145" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", { x: "620", y: "95", width: "50", height: "105" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", { x: "690", y: "30", width: "75", height: "170" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", { x: "790", y: "85", width: "55", height: "115" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", { x: "865", y: "65", width: "60", height: "135" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", { x: "950", y: "105", width: "85", height: "95" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", { x: "1060", y: "50", width: "55", height: "150" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", { x: "1135", y: "90", width: "70", height: "110" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", { x: "1225", y: "70", width: "60", height: "130" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", { x: "1305", y: "100", width: "70", height: "100" })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", { fill: "#ffe600", opacity: ".55" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", { x: "295", y: "55", width: "6", height: "6" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", { x: "310", y: "75", width: "6", height: "6" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", { x: "545", y: "70", width: "6", height: "6" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", { x: "705", y: "45", width: "6", height: "6" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", { x: "720", y: "70", width: "6", height: "6" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", { x: "880", y: "80", width: "6", height: "6" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", { x: "1075", y: "65", width: "6", height: "6" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", { x: "1240", y: "85", width: "6", height: "6" }))));
}
function PostcardArtwork(props) {
    return react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "".concat(css.postcardImage, " ").concat(props.large ? css.postcardImageLarge : ''), src: props.postcard.url, alt: props.postcard.name });
}
function readPostcards(data) {
    var items = Array.isArray(data.value) ? data.value : data.d && data.d.results;
    if (!Array.isArray(items)) {
        throw new Error('The PostcardsAndVideos response did not contain a list of items.');
    }
    var imageExtensions = /\.(avif|bmp|gif|jpe?g|png|svg|tiff?|webp)$/i;
    return items.reduce(function (postcardItems, item) {
        var filePath = item.FileRef || (item.File && item.File.ServerRelativeUrl);
        var name = (item.File && item.File.Name) || item.FileLeafRef;
        if (!filePath || !name || !imageExtensions.test(name))
            return postcardItems;
        var fileUrl = new URL(filePath, postcardsApiUrl);
        var isInPostcardsFolder = fileUrl.pathname.split('/').some(function (segment) { return segment.toLowerCase() === 'postcards'; });
        if (!isInPostcardsFolder)
            return postcardItems;
        postcardItems.push({
            id: item.ID !== undefined ? item.ID : (item.Id !== undefined ? item.Id : filePath),
            name: name,
            url: fileUrl.href
        });
        return postcardItems;
    }, []);
}
function HomePage(props) {
    var _a = react__WEBPACK_IMPORTED_MODULE_0__.useState([]), postcards = _a[0], setPostcards = _a[1];
    var _b = react__WEBPACK_IMPORTED_MODULE_0__.useState(true), isLoadingPostcards = _b[0], setIsLoadingPostcards = _b[1];
    var _c = react__WEBPACK_IMPORTED_MODULE_0__.useState(undefined), postcardsError = _c[0], setPostcardsError = _c[1];
    var _d = react__WEBPACK_IMPORTED_MODULE_0__.useState(undefined), activePostcard = _d[0], setActivePostcard = _d[1];
    var _e = react__WEBPACK_IMPORTED_MODULE_0__.useState(''), galleryTransition = _e[0], setGalleryTransition = _e[1];
    var modalCloseButton = react__WEBPACK_IMPORTED_MODULE_0__.useRef(null);
    var activeCardButton = react__WEBPACK_IMPORTED_MODULE_0__.useRef(null);
    var touchStartX = react__WEBPACK_IMPORTED_MODULE_0__.useRef(undefined);
    var activePostcardRef = react__WEBPACK_IMPORTED_MODULE_0__.useRef(undefined);
    var navigationInProgress = react__WEBPACK_IMPORTED_MODULE_0__.useRef(false);
    var navigationTimer = react__WEBPACK_IMPORTED_MODULE_0__.useRef(undefined);
    var isGalleryOpen = activePostcard !== undefined;
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
        var isCancelled = false;
        props.spHttpClient.get(postcardsApiUrl, _microsoft_sp_http__WEBPACK_IMPORTED_MODULE_1__.SPHttpClient.configurations.v1)
            .then(function (response) {
            if (!response.ok) {
                throw new Error("SharePoint returned ".concat(response.status, " ").concat(response.statusText, "."));
            }
            return response.json();
        })
            .then(function (data) {
            if (isCancelled)
                return;
            setPostcards(readPostcards(data));
            setIsLoadingPostcards(false);
        })
            .catch(function (error) {
            if (isCancelled)
                return;
            setPostcardsError(error instanceof Error ? error.message : 'An unexpected error occurred.');
            setIsLoadingPostcards(false);
        });
        return function () {
            isCancelled = true;
        };
    }, [props.spHttpClient]);
    var closeModal = react__WEBPACK_IMPORTED_MODULE_0__.useCallback(function () {
        if (navigationTimer.current !== undefined)
            window.clearTimeout(navigationTimer.current);
        navigationTimer.current = undefined;
        navigationInProgress.current = false;
        activePostcardRef.current = undefined;
        setGalleryTransition('');
        setActivePostcard(undefined);
    }, []);
    var showPostcard = react__WEBPACK_IMPORTED_MODULE_0__.useCallback(function (index) {
        if (postcards.length === 0)
            return;
        var nextIndex = ((index % postcards.length) + postcards.length) % postcards.length;
        if (activePostcardRef.current === undefined) {
            activePostcardRef.current = nextIndex;
            setActivePostcard(nextIndex);
            return;
        }
        if (nextIndex === activePostcardRef.current || navigationInProgress.current)
            return;
        var currentIndex = activePostcardRef.current;
        var direction = (nextIndex - currentIndex + postcards.length) % postcards.length <= postcards.length / 2 ? 1 : -1;
        navigationInProgress.current = true;
        setGalleryTransition(direction > 0 ? css.galleryFadeOutNext : css.galleryFadeOutPrevious);
        navigationTimer.current = window.setTimeout(function () {
            activePostcardRef.current = nextIndex;
            setActivePostcard(nextIndex);
            setGalleryTransition(direction > 0 ? css.galleryFadeInNext : css.galleryFadeInPrevious);
            navigationTimer.current = window.setTimeout(function () {
                setGalleryTransition('');
                navigationInProgress.current = false;
                navigationTimer.current = undefined;
            }, 240);
        }, 180);
    }, [postcards.length]);
    var movePostcard = react__WEBPACK_IMPORTED_MODULE_0__.useCallback(function (direction) {
        var currentIndex = activePostcardRef.current;
        if (currentIndex === undefined)
            return;
        showPostcard(currentIndex + direction);
    }, [showPostcard]);
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
        if (activePostcard === undefined) {
            if (activeCardButton.current)
                activeCardButton.current.focus();
            return;
        }
    }, [activePostcard]);
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
        if (!isGalleryOpen)
            return;
        var previousOverflow = document.body.style.overflow;
        document.body.style.overflow = 'hidden';
        window.setTimeout(function () {
            if (modalCloseButton.current)
                modalCloseButton.current.focus();
        }, 0);
        var handleKeyDown = function (event) {
            if (event.key === 'Escape') {
                event.preventDefault();
                event.stopPropagation();
                closeModal();
            }
            else if (event.key === 'ArrowRight')
                movePostcard(1);
            else if (event.key === 'ArrowLeft')
                movePostcard(-1);
        };
        window.addEventListener('keydown', handleKeyDown, true);
        return function () {
            window.removeEventListener('keydown', handleKeyDown, true);
            document.body.style.overflow = previousOverflow;
        };
    }, [isGalleryOpen, closeModal, movePostcard]);
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () { return function () {
        if (navigationTimer.current !== undefined)
            window.clearTimeout(navigationTimer.current);
    }; }, []);
    var handleTouchStart = function (event) {
        touchStartX.current = event.touches[0].clientX;
    };
    var handleTouchEnd = function (event) {
        if (touchStartX.current === undefined)
            return;
        var distance = event.changedTouches[0].clientX - touchStartX.current;
        if (Math.abs(distance) > 50 && activePostcard !== undefined)
            movePostcard(distance < 0 ? 1 : -1);
        touchStartX.current = undefined;
    };
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("main", { className: css.auditPage },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("header", { className: css.auditHero },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.auditGlow }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(Skyline, null),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: css.auditCorner, "aria-hidden": "true" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: css.auditCornerSecondary, "aria-hidden": "true" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.auditHeroContent },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("h1", null,
                    "Audit Transformation",
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                    "Toolkit"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: css.auditUnderline }))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("section", { className: css.auditIntro, "aria-labelledby": "audit-intro-title" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.auditSectionHead },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: css.auditSectionBar }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("h2", { id: "audit-intro-title" }, "Future of Audit. Now.")),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: css.auditLead }, "EY isn't waiting for the future \u2013 we're shaping it with confidence."),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "By combining top talent with innovative technology, a continuous improvement mindset, and a streamlined methodology, we are redefining what it means to bring assurance to the capital markets. With quality as our foundation, we are elevating the experience for our people and our clients."),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "The contents of this toolkit will help leaders around the globe and their GBC teams convey a consistent, high-level audit transformation narrative. Further tailoring for local markets and audiences may be necessary. In addition to the global assets, we will continue to curate and share best practice from across the regions for the benefit of all."),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null,
                "For questions about this toolkit and the resources in it, please reach out to ",
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { href: "mailto:corey.porter@ey.com" }, "Corey Porter"),
                " and ",
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { href: "mailto:sammi.cassin@ey.com" }, "Sammi Cassin"),
                ".")),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("section", { className: css.auditSection, id: "team", "aria-labelledby": "team-title" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.auditSectionHead },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: css.auditSectionBar }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("h2", { id: "team-title" }, "Our Team")),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: css.auditSubhead }, "Connect with the team for any questions, support, or collaboration."),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.teamGrid }, team.map(function (member, index) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("article", { className: css.teamCard, key: member.name, style: { animationDelay: "".concat(index * 0.08, "s") } },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.teamPhoto },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: css.teamPhotoImage, src: _assets_img_png__WEBPACK_IMPORTED_MODULE_3__, alt: member.name })),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.teamBody },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("h3", null, member.name),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, member.role),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.teamIcons },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { className: css.teamIconButton, href: "mailto:auditsupport@ey.com", "aria-label": "Email ".concat(member.name) },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement(MailIcon, null)),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { className: css.teamIconButton, type: "button", disabled: true, "aria-label": "Phone number unavailable for ".concat(member.name) },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement(PhoneIcon, null)),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { className: css.teamIconButton, type: "button", disabled: true, "aria-label": "Profile information unavailable for ".concat(member.name) },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement(PersonIcon, null)))))); }))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("section", { className: css.auditSection, id: "postcards", "aria-labelledby": "postcards-title" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.auditSectionHead },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: css.auditSectionBar }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("h2", { id: "postcards-title" }, "Postcards")),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: css.auditSubhead }, "Explore the postcards to support your audit transformation journey."),
            isLoadingPostcards && react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: css.auditSubhead, role: "status" }, "Loading postcards..."),
            postcardsError && react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: css.auditSubhead, role: "alert" },
                "Unable to load postcards: ",
                postcardsError),
            !isLoadingPostcards && !postcardsError && postcards.length === 0 && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: css.auditSubhead }, "No postcards are currently available.")),
            postcards.length > 0 && react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.postcardGrid }, postcards.map(function (postcard, index) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { className: css.postcardButton, key: postcard.id, type: "button", "aria-label": "Open postcard ".concat(index + 1, " of ").concat(postcards.length), style: { animationDelay: "".concat(index * 0.06, "s") }, onClick: function (event) {
                    activeCardButton.current = event.currentTarget;
                    showPostcard(index);
                } },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(PostcardArtwork, { postcard: postcard }))); }))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("footer", { className: css.auditFooter },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "\u00A9 All Rights Reserved.")),
        activePostcard !== undefined && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.galleryModal, role: "presentation", onMouseDown: function (event) { if (event.target === event.currentTarget)
                closeModal(); } },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.galleryInner },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { className: css.galleryClose, type: "button", ref: modalCloseButton, onClick: closeModal, "aria-label": "Close postcard viewer" }, "\u00D7"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(css.galleryCard, " ").concat(galleryTransition), onTouchStart: handleTouchStart, onTouchEnd: handleTouchEnd },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(PostcardArtwork, { postcard: postcards[activePostcard], large: true })),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { className: "".concat(css.galleryNav, " ").concat(css.galleryPrevious), type: "button", onClick: function () { return movePostcard(-1); }, "aria-label": "Previous postcard" }, "\u2039"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { className: "".concat(css.galleryNav, " ").concat(css.galleryNext), type: "button", onClick: function () { return movePostcard(1); }, "aria-label": "Next postcard" }, "\u203A"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: css.galleryPosition, "aria-live": "polite" },
                    postcards[activePostcard].name,
                    " (",
                    activePostcard + 1,
                    " of ",
                    postcards.length,
                    ")"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.galleryDots, "aria-label": "Choose postcard" }, postcards.map(function (postcard, index) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { type: "button", key: postcard.id, className: "".concat(css.galleryDot, " ").concat(index === activePostcard ? css.galleryDotActive : ''), "aria-label": "Go to postcard ".concat(index + 1), "aria-current": index === activePostcard ? 'true' : undefined, onClick: function () { return showPostcard(index); } })); })),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: css.galleryHint },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("kbd", null, "\u2190"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("kbd", null, "\u2192"),
                    " navigate\u00A0 \u00B7 \u00A0",
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("kbd", null, "Esc"),
                    " close"))))));
}


/***/ }),

/***/ 315:
/*!******************************************************************!*\
  !*** ./lib/webparts/homePage/components/HomePage.module.scss.js ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
__webpack_require__(/*! ./HomePage.module.css */ 591);
var styles = {
    homePage: 'homePage_2a396803',
    hero: 'hero_2a396803',
    heroImage: 'heroImage_2a396803',
    heroShade: 'heroShade_2a396803',
    heroGrid: 'heroGrid_2a396803',
    heroInner: 'heroInner_2a396803',
    sectionInner: 'sectionInner_2a396803',
    header: 'header_2a396803',
    brandLink: 'brandLink_2a396803',
    brand: 'brand_2a396803',
    brandMark: 'brandMark_2a396803',
    brandTagline: 'brandTagline_2a396803',
    navigation: 'navigation_2a396803',
    heroCopy: 'heroCopy_2a396803',
    riseIn: 'riseIn_2a396803',
    portalArea: 'portalArea_2a396803',
    portalGrid: 'portalGrid_2a396803',
    portalCard: 'portalCard_2a396803',
    portalGlow: 'portalGlow_2a396803',
    portalContent: 'portalContent_2a396803',
    portalTop: 'portalTop_2a396803',
    portalIcon: 'portalIcon_2a396803',
    portalArrow: 'portalArrow_2a396803',
    portalEyebrow: 'portalEyebrow_2a396803',
    portalTitle: 'portalTitle_2a396803',
    colorBar: 'colorBar_2a396803',
    footerColorBar: 'footerColorBar_2a396803',
    exploreLink: 'exploreLink_2a396803',
    featuredSection: 'featuredSection_2a396803',
    sectionHeader: 'sectionHeader_2a396803',
    sectionTitleBlock: 'sectionTitleBlock_2a396803',
    eyebrow: 'eyebrow_2a396803',
    contactIntro: 'contactIntro_2a396803',
    carouselControls: 'carouselControls_2a396803',
    pageDots: 'pageDots_2a396803',
    activeDot: 'activeDot_2a396803',
    carouselArrow: 'carouselArrow_2a396803',
    featuredGrid: 'featuredGrid_2a396803',
    featuredCard: 'featuredCard_2a396803',
    featuredMeta: 'featuredMeta_2a396803',
    location: 'location_2a396803',
    registerLine: 'registerLine_2a396803',
    dateBadge: 'dateBadge_2a396803',
    category: 'category_2a396803',
    registerArrow: 'registerArrow_2a396803',
    dataMessage: 'dataMessage_2a396803',
    stagesSection: 'stagesSection_2a396803',
    stagePattern: 'stagePattern_2a396803',
    stageTabs: 'stageTabs_2a396803',
    stageNumber: 'stageNumber_2a396803',
    stageDescription: 'stageDescription_2a396803',
    courseGrid: 'courseGrid_2a396803',
    courseCard: 'courseCard_2a396803',
    courseLink: 'courseLink_2a396803',
    courseImageWrap: 'courseImageWrap_2a396803',
    courseImageFallback: 'courseImageFallback_2a396803',
    courseIcon: 'courseIcon_2a396803',
    courseContent: 'courseContent_2a396803',
    footer: 'footer_2a396803',
    contactGrid: 'contactGrid_2a396803',
    contactCards: 'contactCards_2a396803',
    contactCard: 'contactCard_2a396803',
    contactIcon: 'contactIcon_2a396803',
    contactArrow: 'contactArrow_2a396803',
    footerBottom: 'footerBottom_2a396803',
    talentSection: 'talentSection_2a396803',
    talentSubhead: 'talentSubhead_2a396803',
    talentGroupTitle: 'talentGroupTitle_2a396803',
    talentServiceGrid: 'talentServiceGrid_2a396803',
    talentServiceCard: 'talentServiceCard_2a396803',
    talentServiceIcon: 'talentServiceIcon_2a396803',
    talentServiceName: 'talentServiceName_2a396803',
    talentAvatar: 'talentAvatar_2a396803',
    talentLocationAvatar: 'talentLocationAvatar_2a396803',
    talentFilterAvatar: 'talentFilterAvatar_2a396803',
    talentModalAvatar: 'talentModalAvatar_2a396803',
    talentPersonName: 'talentPersonName_2a396803',
    talentLocationHeading: 'talentLocationHeading_2a396803',
    talentFilters: 'talentFilters_2a396803',
    talentFilter: 'talentFilter_2a396803',
    talentFilterActive: 'talentFilterActive_2a396803',
    talentLocationGrid: 'talentLocationGrid_2a396803',
    talentLocationCard: 'talentLocationCard_2a396803',
    talentFlag: 'talentFlag_2a396803',
    talentLocationInfo: 'talentLocationInfo_2a396803',
    talentLocationName: 'talentLocationName_2a396803',
    talentCities: 'talentCities_2a396803',
    talentLocationPerson: 'talentLocationPerson_2a396803',
    talentLocationArrow: 'talentLocationArrow_2a396803',
    talentNote: 'talentNote_2a396803',
    talentNoteIcon: 'talentNoteIcon_2a396803',
    talentModalBackdrop: 'talentModalBackdrop_2a396803',
    fadeIn: 'fadeIn_2a396803',
    talentModal: 'talentModal_2a396803',
    talentModalClose: 'talentModalClose_2a396803',
    talentModalRole: 'talentModalRole_2a396803',
    talentModalTags: 'talentModalTags_2a396803',
    auditPage: 'auditPage_2a396803',
    auditHero: 'auditHero_2a396803',
    auditHeroContent: 'auditHeroContent_2a396803',
    auditRiseIn: 'auditRiseIn_2a396803',
    auditUnderline: 'auditUnderline_2a396803',
    auditSkyline: 'auditSkyline_2a396803',
    auditGlow: 'auditGlow_2a396803',
    auditCorner: 'auditCorner_2a396803',
    auditCornerSecondary: 'auditCornerSecondary_2a396803',
    auditSlideIn: 'auditSlideIn_2a396803',
    auditIntro: 'auditIntro_2a396803',
    auditSection: 'auditSection_2a396803',
    auditSectionHead: 'auditSectionHead_2a396803',
    auditSectionBar: 'auditSectionBar_2a396803',
    auditLead: 'auditLead_2a396803',
    auditSubhead: 'auditSubhead_2a396803',
    teamGrid: 'teamGrid_2a396803',
    teamCard: 'teamCard_2a396803',
    auditCardIn: 'auditCardIn_2a396803',
    teamPhoto: 'teamPhoto_2a396803',
    teamPhotoImage: 'teamPhotoImage_2a396803',
    teamBody: 'teamBody_2a396803',
    teamIcons: 'teamIcons_2a396803',
    teamIconButton: 'teamIconButton_2a396803',
    postcardGrid: 'postcardGrid_2a396803',
    postcardButton: 'postcardButton_2a396803',
    auditPostcardIn: 'auditPostcardIn_2a396803',
    postcardImage: 'postcardImage_2a396803',
    postcardImageLarge: 'postcardImageLarge_2a396803',
    auditFooter: 'auditFooter_2a396803',
    galleryModal: 'galleryModal_2a396803',
    auditFadeIn: 'auditFadeIn_2a396803',
    galleryInner: 'galleryInner_2a396803',
    galleryCard: 'galleryCard_2a396803',
    auditGalleryIn: 'auditGalleryIn_2a396803',
    galleryFadeOutNext: 'galleryFadeOutNext_2a396803',
    galleryFadeOutPrevious: 'galleryFadeOutPrevious_2a396803',
    galleryFadeInNext: 'galleryFadeInNext_2a396803',
    galleryFadeInPrevious: 'galleryFadeInPrevious_2a396803',
    galleryClose: 'galleryClose_2a396803',
    galleryNav: 'galleryNav_2a396803',
    galleryPrevious: 'galleryPrevious_2a396803',
    galleryNext: 'galleryNext_2a396803',
    galleryDots: 'galleryDots_2a396803',
    galleryDot: 'galleryDot_2a396803',
    galleryDotActive: 'galleryDotActive_2a396803',
    galleryHint: 'galleryHint_2a396803',
    galleryPosition: 'galleryPosition_2a396803'
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (styles);


/***/ }),

/***/ 323:
/*!***********************************************************************************************************!*\
  !*** ./node_modules/@microsoft/sp-css-loader/node_modules/@microsoft/load-themed-styles/lib-es6/index.js ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ClearStyleOptions: () => (/* binding */ ClearStyleOptions),
/* harmony export */   Mode: () => (/* binding */ Mode),
/* harmony export */   clearStyles: () => (/* binding */ clearStyles),
/* harmony export */   configureLoadStyles: () => (/* binding */ configureLoadStyles),
/* harmony export */   configureRunMode: () => (/* binding */ configureRunMode),
/* harmony export */   detokenize: () => (/* binding */ detokenize),
/* harmony export */   flush: () => (/* binding */ flush),
/* harmony export */   loadStyles: () => (/* binding */ loadStyles),
/* harmony export */   loadTheme: () => (/* binding */ loadTheme),
/* harmony export */   splitStyles: () => (/* binding */ splitStyles)
/* harmony export */ });
// Copyright (c) Microsoft Corporation. All rights reserved. Licensed under the MIT license.
// See LICENSE in the project root for license information.
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
/**
 * In sync mode, styles are registered as style elements synchronously with loadStyles() call.
 * In async mode, styles are buffered and registered as batch in async timer for performance purpose.
 */
var Mode;
(function (Mode) {
    Mode[Mode["sync"] = 0] = "sync";
    Mode[Mode["async"] = 1] = "async";
})(Mode || (Mode = {}));
/**
 * Themable styles and non-themable styles are tracked separately
 * Specify ClearStyleOptions when calling clearStyles API to specify which group of registered styles should be cleared.
 */
var ClearStyleOptions;
(function (ClearStyleOptions) {
    /** only themable styles will be cleared */
    ClearStyleOptions[ClearStyleOptions["onlyThemable"] = 1] = "onlyThemable";
    /** only non-themable styles will be cleared */
    ClearStyleOptions[ClearStyleOptions["onlyNonThemable"] = 2] = "onlyNonThemable";
    /** both themable and non-themable styles will be cleared */
    ClearStyleOptions[ClearStyleOptions["all"] = 3] = "all";
})(ClearStyleOptions || (ClearStyleOptions = {}));
// Store the theming state in __themeState__ global scope for reuse in the case of duplicate
// load-themed-styles hosted on the page.
var _root = typeof window === 'undefined' ? __webpack_require__.g : window; // eslint-disable-line @typescript-eslint/no-explicit-any
// Nonce string to inject into script tag if one provided. This is used in CSP (Content Security Policy).
var _styleNonce = _root && _root.CSPSettings && _root.CSPSettings.nonce;
var _themeState = initializeThemeState();
/**
 * Matches theming tokens. For example, "[theme: themeSlotName, default: #FFF]" (including the quotes).
 */
var _themeTokenRegex = /[\'\"]\[theme:\s*(\w+)\s*(?:\,\s*default:\s*([\\"\']?[\.\,\(\)\#\-\s\w]*[\.\,\(\)\#\-\w][\"\']?))?\s*\][\'\"]/g;
var now = function () {
    return typeof performance !== 'undefined' && !!performance.now ? performance.now() : Date.now();
};
function measure(func) {
    var start = now();
    func();
    var end = now();
    _themeState.perf.duration += end - start;
}
/**
 * initialize global state object
 */
function initializeThemeState() {
    var state = _root.__themeState__ || {
        theme: undefined,
        lastStyleElement: undefined,
        registeredStyles: []
    };
    if (!state.runState) {
        state = __assign(__assign({}, state), { perf: {
                count: 0,
                duration: 0
            }, runState: {
                flushTimer: 0,
                mode: Mode.sync,
                buffer: []
            } });
    }
    if (!state.registeredThemableStyles) {
        state = __assign(__assign({}, state), { registeredThemableStyles: [] });
    }
    _root.__themeState__ = state;
    return state;
}
/**
 * Loads a set of style text. If it is registered too early, we will register it when the window.load
 * event is fired.
 * @param {string | ThemableArray} styles Themable style text to register.
 * @param {boolean} loadAsync When true, always load styles in async mode, irrespective of current sync mode.
 */
function loadStyles(styles, loadAsync) {
    if (loadAsync === void 0) { loadAsync = false; }
    measure(function () {
        var styleParts = Array.isArray(styles) ? styles : splitStyles(styles);
        var _a = _themeState.runState, mode = _a.mode, buffer = _a.buffer, flushTimer = _a.flushTimer;
        if (loadAsync || mode === Mode.async) {
            buffer.push(styleParts);
            if (!flushTimer) {
                _themeState.runState.flushTimer = asyncLoadStyles();
            }
        }
        else {
            applyThemableStyles(styleParts);
        }
    });
}
/**
 * Allows for customizable loadStyles logic. e.g. for server side rendering application
 * @param {(processedStyles: string, rawStyles?: string | ThemableArray) => void}
 * a loadStyles callback that gets called when styles are loaded or reloaded
 */
function configureLoadStyles(loadStylesFn) {
    _themeState.loadStyles = loadStylesFn;
}
/**
 * Configure run mode of load-themable-styles
 * @param mode load-themable-styles run mode, async or sync
 */
function configureRunMode(mode) {
    _themeState.runState.mode = mode;
}
/**
 * external code can call flush to synchronously force processing of currently buffered styles
 */
function flush() {
    measure(function () {
        var styleArrays = _themeState.runState.buffer.slice();
        _themeState.runState.buffer = [];
        var mergedStyleArray = [].concat.apply([], styleArrays);
        if (mergedStyleArray.length > 0) {
            applyThemableStyles(mergedStyleArray);
        }
    });
}
/**
 * register async loadStyles
 */
function asyncLoadStyles() {
    // Use "self" to distinguish conflicting global typings for setTimeout() from lib.dom.d.ts vs Jest's @types/node
    // https://github.com/jestjs/jest/issues/14418
    return self.setTimeout(function () {
        _themeState.runState.flushTimer = 0;
        flush();
    }, 0);
}
/**
 * Loads a set of style text. If it is registered too early, we will register it when the window.load event
 * is fired.
 * @param {string} styleText Style to register.
 * @param {IStyleRecord} styleRecord Existing style record to re-apply.
 */
function applyThemableStyles(stylesArray, styleRecord) {
    if (_themeState.loadStyles) {
        _themeState.loadStyles(resolveThemableArray(stylesArray).styleString, stylesArray);
    }
    else {
        registerStyles(stylesArray);
    }
}
/**
 * Registers a set theme tokens to find and replace. If styles were already registered, they will be
 * replaced.
 * @param {theme} theme JSON object of theme tokens to values.
 */
function loadTheme(theme) {
    _themeState.theme = theme;
    // reload styles.
    reloadStyles();
}
/**
 * Clear already registered style elements and style records in theme_State object
 * @param option - specify which group of registered styles should be cleared.
 * Default to be both themable and non-themable styles will be cleared
 */
function clearStyles(option) {
    if (option === void 0) { option = ClearStyleOptions.all; }
    if (option === ClearStyleOptions.all || option === ClearStyleOptions.onlyNonThemable) {
        clearStylesInternal(_themeState.registeredStyles);
        _themeState.registeredStyles = [];
    }
    if (option === ClearStyleOptions.all || option === ClearStyleOptions.onlyThemable) {
        clearStylesInternal(_themeState.registeredThemableStyles);
        _themeState.registeredThemableStyles = [];
    }
}
function clearStylesInternal(records) {
    records.forEach(function (styleRecord) {
        var styleElement = styleRecord && styleRecord.styleElement;
        if (styleElement && styleElement.parentElement) {
            styleElement.parentElement.removeChild(styleElement);
        }
    });
}
/**
 * Reloads styles.
 */
function reloadStyles() {
    if (_themeState.theme) {
        var themableStyles = [];
        for (var _i = 0, _a = _themeState.registeredThemableStyles; _i < _a.length; _i++) {
            var styleRecord = _a[_i];
            themableStyles.push(styleRecord.themableStyle);
        }
        if (themableStyles.length > 0) {
            clearStyles(ClearStyleOptions.onlyThemable);
            applyThemableStyles([].concat.apply([], themableStyles));
        }
    }
}
/**
 * Find theme tokens and replaces them with provided theme values.
 * @param {string} styles Tokenized styles to fix.
 */
function detokenize(styles) {
    if (styles) {
        styles = resolveThemableArray(splitStyles(styles)).styleString;
    }
    return styles;
}
/**
 * Resolves ThemingInstruction objects in an array and joins the result into a string.
 * @param {ThemableArray} splitStyleArray ThemableArray to resolve and join.
 */
function resolveThemableArray(splitStyleArray) {
    var theme = _themeState.theme;
    var themable = false;
    // Resolve the array of theming instructions to an array of strings.
    // Then join the array to produce the final CSS string.
    var resolvedArray = (splitStyleArray || []).map(function (currentValue) {
        var themeSlot = currentValue.theme;
        if (themeSlot) {
            themable = true;
            // A theming annotation. Resolve it.
            var themedValue = theme ? theme[themeSlot] : undefined;
            var defaultValue = currentValue.defaultValue || 'inherit';
            // Warn to console if we hit an unthemed value even when themes are provided, but only if "DEBUG" is true.
            // Allow the themedValue to be undefined to explicitly request the default value.
            if (theme &&
                !themedValue &&
                console &&
                !(themeSlot in theme) &&
                "boolean" !== 'undefined' &&
                true) {
                // eslint-disable-next-line no-console
                console.warn("Theming value not provided for \"".concat(themeSlot, "\". Falling back to \"").concat(defaultValue, "\"."));
            }
            return themedValue || defaultValue;
        }
        else {
            // A non-themable string. Preserve it.
            return currentValue.rawString;
        }
    });
    return {
        styleString: resolvedArray.join(''),
        themable: themable
    };
}
/**
 * Split tokenized CSS into an array of strings and theme specification objects
 * @param {string} styles Tokenized styles to split.
 */
function splitStyles(styles) {
    var result = [];
    if (styles) {
        var pos = 0; // Current position in styles.
        var tokenMatch = void 0;
        while ((tokenMatch = _themeTokenRegex.exec(styles))) {
            var matchIndex = tokenMatch.index;
            if (matchIndex > pos) {
                result.push({
                    rawString: styles.substring(pos, matchIndex)
                });
            }
            result.push({
                theme: tokenMatch[1],
                defaultValue: tokenMatch[2] // May be undefined
            });
            // index of the first character after the current match
            pos = _themeTokenRegex.lastIndex;
        }
        // Push the rest of the string after the last match.
        result.push({
            rawString: styles.substring(pos)
        });
    }
    return result;
}
/**
 * Registers a set of style text. If it is registered too early, we will register it when the
 * window.load event is fired.
 * @param {ThemableArray} styleArray Array of IThemingInstruction objects to register.
 * @param {IStyleRecord} styleRecord May specify a style Element to update.
 */
function registerStyles(styleArray) {
    if (typeof document === 'undefined') {
        return;
    }
    var head = document.getElementsByTagName('head')[0];
    var styleElement = document.createElement('style');
    var _a = resolveThemableArray(styleArray), styleString = _a.styleString, themable = _a.themable;
    styleElement.setAttribute('data-load-themed-styles', 'true');
    if (_styleNonce) {
        styleElement.setAttribute('nonce', _styleNonce);
    }
    styleElement.appendChild(document.createTextNode(styleString));
    _themeState.perf.count++;
    head.appendChild(styleElement);
    var ev = document.createEvent('HTMLEvents');
    ev.initEvent('styleinsert', true /* bubbleEvent */, false /* cancelable */);
    ev.args = {
        newStyle: styleElement
    };
    document.dispatchEvent(ev);
    var record = {
        styleElement: styleElement,
        themableStyle: styleArray
    };
    if (themable) {
        _themeState.registeredThemableStyles.push(record);
    }
    else {
        _themeState.registeredStyles.push(record);
    }
}


/***/ }),

/***/ 411:
/*!**********************************************!*\
  !*** ./lib/webparts/homePage/assets/img.png ***!
  \**********************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__.p + "img_685f691bd3425988565c.png";

/***/ }),

/***/ 676:
/*!*********************************************!*\
  !*** external "@microsoft/sp-core-library" ***!
  \*********************************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__676__;

/***/ }),

/***/ 909:
/*!*************************************!*\
  !*** external "@microsoft/sp-http" ***!
  \*************************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__909__;

/***/ }),

/***/ 877:
/*!**********************************************!*\
  !*** external "@microsoft/sp-property-pane" ***!
  \**********************************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__877__;

/***/ }),

/***/ 642:
/*!*********************************************!*\
  !*** external "@microsoft/sp-webpart-base" ***!
  \*********************************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__642__;

/***/ }),

/***/ 299:
/*!*****************************************!*\
  !*** external "HomePageWebPartStrings" ***!
  \*****************************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__299__;

/***/ }),

/***/ 959:
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__959__;

/***/ }),

/***/ 398:
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__398__;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/publicPath */
/******/ 	(() => {
/******/ 		var _publicPath = __RUSHSTACK_CURRENT_SCRIPT__ ? __RUSHSTACK_CURRENT_SCRIPT__.src : '';
/******/ 		__webpack_require__.p = _publicPath.slice(0, _publicPath.lastIndexOf('/') + 1);
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/*!**************************************************!*\
  !*** ./lib/webparts/homePage/HomePageWebPart.js ***!
  \**************************************************/
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom */ 398);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @microsoft/sp-core-library */ 676);
/* harmony import */ var _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @microsoft/sp-property-pane */ 877);
/* harmony import */ var _microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _microsoft_sp_webpart_base__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @microsoft/sp-webpart-base */ 642);
/* harmony import */ var _microsoft_sp_webpart_base__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_webpart_base__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var HomePageWebPartStrings__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! HomePageWebPartStrings */ 299);
/* harmony import */ var HomePageWebPartStrings__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(HomePageWebPartStrings__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components_HomePage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./components/HomePage */ 807);
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();







var HomePageWebPart = /** @class */ (function (_super) {
    __extends(HomePageWebPart, _super);
    function HomePageWebPart() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._isDarkTheme = false;
        _this._environmentMessage = '';
        return _this;
    }
    HomePageWebPart.prototype.render = function () {
        var element = react__WEBPACK_IMPORTED_MODULE_0__.createElement(_components_HomePage__WEBPACK_IMPORTED_MODULE_6__["default"], {
            description: this.properties.description,
            isDarkTheme: this._isDarkTheme,
            environmentMessage: this._environmentMessage,
            hasTeamsContext: !!this.context.sdks.microsoftTeams,
            userDisplayName: this.context.pageContext.user.displayName,
            spHttpClient: this.context.spHttpClient
        });
        react_dom__WEBPACK_IMPORTED_MODULE_1__.render(element, this.domElement);
    };
    HomePageWebPart.prototype.onInit = function () {
        var _this = this;
        return this._getEnvironmentMessage().then(function (message) {
            _this._environmentMessage = message;
        });
    };
    HomePageWebPart.prototype._getEnvironmentMessage = function () {
        var _this = this;
        if (!!this.context.sdks.microsoftTeams) { // running in Teams, office.com or Outlook
            return this.context.sdks.microsoftTeams.teamsJs.app.getContext()
                .then(function (context) {
                var environmentMessage = '';
                switch (context.app.host.name) {
                    case 'Office': // running in Office
                        environmentMessage = _this.context.isServedFromLocalhost ? HomePageWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.AppLocalEnvironmentOffice : HomePageWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.AppOfficeEnvironment;
                        break;
                    case 'Outlook': // running in Outlook
                        environmentMessage = _this.context.isServedFromLocalhost ? HomePageWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.AppLocalEnvironmentOutlook : HomePageWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.AppOutlookEnvironment;
                        break;
                    case 'Teams': // running in Teams
                    case 'TeamsModern':
                        environmentMessage = _this.context.isServedFromLocalhost ? HomePageWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.AppLocalEnvironmentTeams : HomePageWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.AppTeamsTabEnvironment;
                        break;
                    default:
                        environmentMessage = HomePageWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.UnknownEnvironment;
                }
                return environmentMessage;
            });
        }
        return Promise.resolve(this.context.isServedFromLocalhost ? HomePageWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.AppLocalEnvironmentSharePoint : HomePageWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.AppSharePointEnvironment);
    };
    HomePageWebPart.prototype.onThemeChanged = function (currentTheme) {
        if (!currentTheme) {
            return;
        }
        this._isDarkTheme = !!currentTheme.isInverted;
        var semanticColors = currentTheme.semanticColors;
        if (semanticColors) {
            this.domElement.style.setProperty('--bodyText', semanticColors.bodyText || null);
            this.domElement.style.setProperty('--link', semanticColors.link || null);
            this.domElement.style.setProperty('--linkHovered', semanticColors.linkHovered || null);
        }
    };
    HomePageWebPart.prototype.onDispose = function () {
        react_dom__WEBPACK_IMPORTED_MODULE_1__.unmountComponentAtNode(this.domElement);
    };
    Object.defineProperty(HomePageWebPart.prototype, "dataVersion", {
        get: function () {
            return _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_2__.Version.parse('1.0');
        },
        enumerable: false,
        configurable: true
    });
    HomePageWebPart.prototype.getPropertyPaneConfiguration = function () {
        return {
            pages: [
                {
                    header: {
                        description: HomePageWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.PropertyPaneDescription
                    },
                    groups: [
                        {
                            groupName: HomePageWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.BasicGroupName,
                            groupFields: [
                                (0,_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_3__.PropertyPaneTextField)('description', {
                                    label: HomePageWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.DescriptionFieldLabel
                                })
                            ]
                        }
                    ]
                }
            ]
        };
    };
    return HomePageWebPart;
}(_microsoft_sp_webpart_base__WEBPACK_IMPORTED_MODULE_4__.BaseClientSideWebPart));
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomePageWebPart);

})();

/******/ 	return __webpack_exports__;
/******/ })()
;
});})();;
//# sourceMappingURL=home-page-web-part.js.map