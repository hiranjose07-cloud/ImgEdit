import * as React from 'react';

const talentStyles = `
  .talent-page { background: #2e2e38; color: #ffffff; font-family: EYInterstate, Arial, sans-serif; overflow: hidden; }
  .talent-page .loading-container { align-items: center; background: #1a1a24; display: flex; inset: 0; justify-content: center; position: fixed; z-index: 9999; }
  .talent-page .loading-container.is-hidden { display: none; }
  .talent-page .loading-container .item { border: .2vw solid #ffe600; border-bottom-color: transparent; border-radius: 50%; border-top-color: transparent; position: absolute; animation: talentSpin 2s ease infinite; }
  .talent-page .loading-container .item:nth-child(1) { height: 30px; width: 30px; }
  .talent-page .loading-container .item:nth-child(2) { animation-delay: .1s; height: 50px; width: 50px; }
  .talent-page .loading-container .item:nth-child(3) { animation-delay: .2s; height: 70px; width: 70px; }
  .talent-page .loading-container .item:nth-child(4) { animation-delay: .3s; height: 90px; width: 90px; }
  @keyframes talentSpin { 50% { transform: rotate(180deg); } 100% { transform: rotate(0); } }
  .talent-page .container_wrapper { display: block; }
  .talent-page .webPart { background: #2e2e38; }
  .talent-page .nav-container { padding: 0; }
  .talent-page .nav-bar { background: #2e2e38; margin: 0; min-height: 6vw; position: relative; width: 100%; z-index: 999; }
  .talent-page .EYlogo { left: 5vw; position: absolute; top: 1.5vw; width: 3vw; }
  .talent-page .logoTxt { color: #ffffff; font-size: 2vw; left: 11vw; margin: 0; position: absolute; top: 2.2vw; }
  .talent-page .navbarMenu { list-style: none; margin: 0; padding: 0; position: absolute; right: 6vw; top: 2.4vw; }
  .talent-page .navbarMenu li { color: #ffffff; display: inline-block; font-size: 1vw; }
  .talent-page .navbarMenu a { color: #ffffff; padding: 0 2vw; text-decoration: none; }
  .talent-page .navbarMenu img { width: 1.3vw; }
  .talent-page .bannerBackground { background: url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/banner.jpg') center / 115% 115%; background-color: #2e2e38; padding: 0; }
  .talent-page .cnt-fdr { background: rgba(46, 46, 56, .5); padding: 2vw 5vw; }
  .talent-page .cf6 { color: #ffffff; font-size: 1.5vw; margin: 0; padding: 1vw; }
  .talent-page .hder { color: #ffffff; font-size: 1vw; line-height: 1.5vw; margin: 0 0 1vw; }
  .talent-page .tabContent { background: url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center / cover; padding: .3vw 5vw 2vw; }
  .talent-page .accordion { width: 100%; }
  .talent-page .card { background: transparent; border: 0; border-bottom: .1vw solid #585858; padding: 0 1vw 0 0; }
  .talent-page .card-header { border: 0; padding: 0; }
  .talent-page .btn-link { background: transparent; border: 0; box-shadow: none; color: #ffffff; font-size: 1.5vw; padding: .6vw 0; text-align: left; text-decoration: none; width: 100%; }
  .talent-page .btn-link:hover { color: #ffe600; }
  .talent-page .fa { color: #ffe600; font-size: 1vw; margin-right: 1vw; }
  .talent-page .card-body { padding: 1vw 0; }
  .talent-page .profile-row { display: grid; gap: .6vw; grid-template-columns: repeat(5, 1fr); }
  .talent-page .profile-column { min-width: 0; }
  .talent-page .profile-people { display: block; }
  .talent-page .profile-box { min-height: 13vw; position: relative; text-align: center; }
  .talent-page .secHead { background: #747480; color: #ffffff; font-size: 1vw; margin-left: 7.5%; padding: 1vw .6vw; position: relative; width: 85%; z-index: 2; }
  .talent-page .secBorder { border: .1vw dashed #ffffff; border-bottom: 0; margin: -2vw 0 1vw; min-height: 3.5vw; position: relative; z-index: 1; }
  .talent-page .proBox { margin-bottom: 1vw; position: relative; }
  .talent-page .psImage { border: .2vw solid #ffffff; border-radius: 100vw; margin-top: .8vw; position: absolute; width: 3vw; }
  .talent-page .psTitle, .talent-page .psTitley1 { background-size: 100% 200%; background-position: bottom center; border: .1vw solid rgba(255, 255, 255, 0); color: #000000; font-size: .9vw; margin-left: 10%; min-height: 2.6vw; padding: .5vw .4vw .5vw 2vw; transition: all .3s ease-in-out; width: 80%; }
  .talent-page .psTitle { background-image: linear-gradient(to top, #ffe600 50%, #2e2e38 50%); }
  .talent-page .psTitley1 { background-image: linear-gradient(to top, #ffffff 50%, #2e2e38 50%); }
  .talent-page .psName, .talent-page .psNamey1 { background-size: 100% 200%; background-position: bottom center; border: .1vw solid #4e4e59; border-top: 0; color: #ffffff; font-size: .8vw; margin-left: 10%; padding: .5vw .5vw .5vw 2vw; transition: all .3s ease-in-out; width: 80%; }
  .talent-page .psName { background-image: linear-gradient(to top, #2e2e38 50%, #ffe600 50%); }
  .talent-page .psNamey1 { background-image: linear-gradient(to top, #2e2e38 50%, #ffffff 50%); }
  .talent-page .proBox:hover .psTitle, .talent-page .proBox:hover .psTitley1 { background-position: top center; border-color: #4e4e59; color: #ffffff; }
  .talent-page .proBox:hover .psName, .talent-page .proBox:hover .psNamey1 { background-position: top center; color: #000000; }
  .talent-page .table-wrap { overflow-x: auto; }
  .talent-page table { border: .01vw solid #474747; color: #ffffff; font-size: .9vw; line-height: 1.1vw; margin: 2vw 0; text-align: center; width: 100%; }
  .talent-page th { background: #1f2027; color: #ffe600; padding: 1vw 0; }
  .talent-page td { border: .01vw solid #474747; padding: .4vw 1.5vw;  text-align:left;}
  .talent-page .tableImg { border-radius: 100vw; display: inline-block; width: 3vw; }
  .talent-page .nme { display: inline-block; margin: 0 0 0 1vw; }
  .talent-page .documents { display: grid; gap: 1vw; grid-template-columns: repeat(5, 1fr); }
  .talent-page .document-card { background: rgba(255, 255, 255, .08); min-height: 7.5vw; position: relative; text-decoration: none; }
  .talent-page .box-banner { background: center / cover; min-height: 8vw; }
  .talent-page .box-content { color: #ffffff; min-height: 6vw; padding: 1vw 1.5vw; }
  .talent-page .box-cnt { font-size: .9vw; line-height: 1.2vw; margin: 0; }
  .talent-page .box-readmore { color: #ffffff; font-size: .9vw; margin: 1vw 0 0; text-align: right; }
  .talent-page .footerTab { background: #1a1a24; padding: 5vw; }
  .talent-page .quicklinks { color: #ffffff; font-size: 1.3vw; margin: 0 0 2vw; }
  .talent-page .footerTab .documents { display: grid; gap: .8vw; grid-template-columns: repeat(4, 1fr); }
  .talent-page .footerTab .document-card { background: #ffffff0f url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center / cover; box-shadow: 0 0 1.5vw rgba(0, 0, 0, .44); min-height: 7.5vw; overflow: hidden; }
  .talent-page .footerTab .box-banner { bottom: 0; left: 0; min-height: 0; position: absolute; top: 0; width: 37%; }
  .talent-page .footerTab .box-content { margin-left: 37%; min-height: 7.5vw; padding: 1.5vw 1vw 1vw 5%; }
  .talent-page .footerTab .box-cnt { color: #ffffff; font-size: 1vw; line-height: 1.3vw; max-height: 3.9vw; overflow: hidden; }
  .talent-page .footerTab .box-readmore { display: none; }
  .talent-page .footerTab .row { display: flex; flex-wrap: wrap; margin: 0 -.4vw; }
  .talent-page .footerTab .cl-3 { flex: 0 0 25%; max-width: 25%; padding: .4vw; }
  .talent-page .footerTab .cl-3 > a { display: block; height: 100%; text-decoration: none; }
  .talent-page .footerTab .col-sm-bx { background: #ffffff0f url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center / cover; box-shadow: 0 0 1.5vw rgba(0, 0, 0, .44); min-height: 7.5vw; overflow: hidden; position: relative; width: 100%; }
  .talent-page .footerTab .img-bx { background-position: center; background-size: cover; bottom: 0; left: 0; min-height: 0; position: absolute; top: 0; transition: all .2s ease-in-out; width: 37%; }
  .talent-page .footerTab .col-sm-bx:hover .img-bx { transform: scale(1.08); }
  .talent-page .footerTab .bx-link { color: #ffffff; font-size: 1vw; left: 42%; line-height: 1.3vw; margin: 0; position: absolute; top: 50%; transform: translateY(-50%); width: 48%; }
  .talent-page .footerTab .col-sm-bx > span { bottom: .3vw; color: rgba(255, 255, 255, .52); font-size: 2vw; font-weight: bold; position: absolute; right: 1vw; }
  .talent-page .footer { background: #000000; color: #ffffff; padding: 1vw 2vw; text-align: right; }
  .talent-page .footer p { font-size: 1vw; margin: 0; }
   .talent-page .btn-link:before {
  content: "-";
}
 .talent-page .btn-link.collapsed:before {
  content: "+";
}
  @media only screen and (max-width: 1200px) {
    .talent-page .nav-bar { min-height: 90px; }
    .talent-page .EYlogo { left: 60px; top: 20px; width: 40px; }
    .talent-page .logoTxt { font-size: 25px; left: 130px; top: 30px; }
    .talent-page .navbarMenu { right: 50px; top: 31px; }
    .talent-page .navbarMenu img { width: 20px; }
    .talent-page .cnt-fdr { padding: 35px 70px; }
    .talent-page .cf6 { font-size: 30px; }
    .talent-page .hder { font-size: 16px; line-height: 23px; }
    .talent-page .tabContent { padding: 50px 70px; }
    .talent-page .btn-link { font-size: 20px; }
    .talent-page .profile-row { gap: 10px; grid-template-columns: repeat(4, 1fr); }
    .talent-page .secHead { font-size: 14px; }
    .talent-page .psTitle, .talent-page .psTitley1, .talent-page .psName, .talent-page .psNamey1 { font-size: 11px; }
    .talent-page table { font-size: 13px; line-height: 18px; }
    .talent-page .box-cnt, .talent-page .box-readmore { font-size: 13px; line-height: 18px; }
    .talent-page .footer p { font-size: 13px; }
    .talent-page .footerTab .documents { grid-template-columns: repeat(3, 1fr); }
    .talent-page .footerTab .box-content { min-height: 70px; padding: 15px 10px 10px 5%; }
    .talent-page .footerTab .box-cnt { font-size: 13px; line-height: 16px; max-height: 48px; }
    .talent-page .footerTab .bx-link { font-size: 13px; line-height: 16px; }
    .talent-page .footerTab .col-sm-bx > span { bottom: 0; font-size: 15px; }
  }
  @media only screen and (max-width: 800px) {
    .talent-page .tabContent { padding: 50px 30px; }
    .talent-page .profile-row { grid-template-columns: repeat(2, 1fr); }
    .talent-page .documents { grid-template-columns: repeat(3, 1fr); }
    .talent-page .footerTab .cl-3 { flex-basis: 33.3333%; max-width: 33.3333%; }
    .talent-page .footerTab .documents { grid-template-columns: repeat(2, 1fr); }
  }
  @media only screen and (max-width: 575px) {
    .talent-page .navbarMenu { top: 110px; }
    .talent-page .profile-row, .talent-page .documents { grid-template-columns: 1fr; }
    .talent-page .footerTab .documents { grid-template-columns: 1fr; }
    .talent-page .footerTab .cl-3 { flex-basis: 50%; max-width: 50%; }
  }
  @media only screen and (max-width: 500px) { .talent-page .footerTab .cl-3 { flex-basis: 100%; max-width: 100%; } }

  .talent-pocs { --poc-bg: #1a1a24; --poc-panel: #2e2e38; --poc-yellow: #ffe600; background: var(--poc-bg); color: #ffffff; font-family: Arial, Helvetica, sans-serif; line-height: 1.5; padding: 1px 28px 20px; }
  .talent-pocs, .talent-pocs * { box-sizing: border-box; }
  .talent-pocs section { padding: 32px 0 8px; }
  .talent-pocs .sec-head { align-items: center; display: flex; gap: 18px; margin-bottom: 14px; }
  .talent-pocs .sec-icon { align-items: center; background: var(--poc-panel); border: 1px solid #ffffff; border-radius: 14px; display: grid; flex: none; height: 52px; justify-items: center; width: 52px; }
  .talent-pocs .sec-icon svg { fill: none; height: 26px; stroke: var(--poc-yellow); stroke-linecap: round; stroke-linejoin: round; stroke-width: 1.8; width: 26px; }
  .talent-pocs .sec-bar { background: var(--poc-yellow); border-radius: 3px; flex: none; height: 44px; width: 4px; }
  .talent-pocs .sec-head h2 { color: #ffffff; font-size: 30px; font-weight: 800; margin: 0; }
  .talent-pocs .poc-grid { display: grid; gap: 18px; grid-template-columns: repeat(6, minmax(0, 1fr)); margin-top: 30px; }
  .talent-pocs .poc-card { animation: pocsRise .6s both; background: var(--poc-panel); border: 1px solid #ffffff3d; border-radius: 10px; color: #ffffff; cursor: pointer; min-width: 0; overflow: hidden; padding: 0; position: relative; transition: transform .3s, border-color .3s; }
  .talent-pocs .poc-card::before { background: var(--poc-yellow); content: ''; inset: 0; position: absolute; transform: scaleY(0); transform-origin: bottom; transition: transform .35s ease; z-index: 0; }
  .talent-pocs .poc-card:hover, .talent-pocs .poc-card:focus-visible { border-color: var(--poc-yellow); color: #000000; transform: translateY(-6px); }
  .talent-pocs .poc-card:hover::before, .talent-pocs .poc-card:focus-visible::before { transform: scaleY(1); }
  .talent-pocs .poc-card:focus-visible, .talent-pocs .loc-card:focus-visible, .talent-pocs .chip:focus-visible { outline: 3px solid var(--poc-yellow); outline-offset: 2px; }
  .talent-pocs .poc-hint { align-items: center;  border-radius: 50%; display: grid; height: 26px; opacity: 0; position: absolute; right: 12px; top: 12px; transition: opacity .2s; width: 26px; z-index: 3; }
  .talent-pocs .poc-card:hover .poc-hint, .talent-pocs .poc-card:focus-visible .poc-hint { opacity: 1; }
  .talent-pocs .poc-icon { align-items: center; display: grid; height: 76px; justify-items: center; padding-top: 16px; position: relative; z-index: 1; }
  .talent-pocs .poc-icon svg { fill: none; height: 44px; stroke: var(--poc-yellow); stroke-linecap: round; stroke-linejoin: round; stroke-width: 1.6; transition: stroke .25s; width: 44px; }
  .talent-pocs .poc-card:hover .poc-icon svg, .talent-pocs .poc-card:focus-visible .poc-icon svg { stroke: #000000; }
  .talent-pocs .poc-title { color: #ffffff; font-size: 15px; font-weight: 800; margin: 0 4px 12px; position: relative; transition: color .25s; z-index: 1; }
  .talent-pocs .poc-card:hover .poc-title, .talent-pocs .poc-card:focus-visible .poc-title { color: #000000; }
  .talent-pocs .poc-avatar { align-items: center; background: var(--poc-yellow); border: 2px solid #ffffff; border-radius: 50%; color: var(--poc-bg); display: grid; font-size: 24px; font-weight: 800; height: 86px; justify-items: center; margin: 0 auto -32px; overflow: hidden; position: relative; width: 86px; z-index: 2; }
  .talent-pocs .poc-avatar img { height: 100%; object-fit: cover; position: absolute; width: 100%; }
  .talent-pocs .poc-name { background: var(--poc-yellow); color: var(--poc-bg); display: block; font-size: 15px; font-weight: 800; height: 88px; line-height: 1.25; padding: 42px 8px 10px; position: relative; transition: background-color .25s, color .25s; width: 100%; z-index: 1; }
  .talent-pocs .poc-card:hover .poc-name, .talent-pocs .poc-card:focus-visible .poc-name { background: transparent; color: #000000; }
  .talent-pocs .filter-bar { align-items: center; display: flex; flex-wrap: wrap; gap: 12px; margin-top: 30px; }
  .talent-pocs .chips { display: flex; flex-wrap: wrap; gap: 10px; }
  .talent-pocs .chip { align-items: center; background: var(--poc-panel); border: 1px solid #ffffff; border-radius: 999px; color: #ffffff; cursor: pointer; display: inline-flex; flex-direction: row; font-size: 13px; font-weight: 600; gap: 8px; justify-content: flex-start; padding: 8px 14px; transition: background .2s, color .2s, border-color .2s; }
  .talent-pocs .chip:hover { border-color: var(--poc-yellow); }
  .talent-pocs .chip.active { background: var(--poc-yellow); border-color: var(--poc-yellow); color: var(--poc-bg); }
  .talent-pocs .chip-avatar { align-items: center; background: var(--poc-yellow); border-radius: 50%; color: var(--poc-bg); display: inline-grid; flex: none; font-size: 9px; font-weight: 800; height: 22px; justify-items: center; overflow: hidden; order: -1; position: relative; width: 22px; }
  .talent-pocs .chip-avatar img { border-radius: 50%; height: 100%; inset: 0; object-fit: cover; position: absolute; width: 100%; }
  .talent-pocs .loc-grid { display: grid; gap: 16px; grid-template-columns: repeat(3, minmax(0, 1fr)); margin-top: 22px; }
  .talent-pocs .loc-card { align-items: center; animation: pocsRise .5s both; background: var(--poc-panel); border: 1px solid #ffffff54; border-radius: 10px; color: #ffffff; cursor: pointer; display: grid; gap: 12px; grid-template-columns: 44px minmax(0, 1fr) 1px minmax(115px, auto); min-height: 76px; overflow: hidden; padding: 12px; position: relative; text-align: left; transition: transform .2s, border-color .2s; }
  .talent-pocs .loc-card:hover { border-color: var(--poc-yellow); transform: translateY(-3px); }
  .talent-pocs .loc-card.hidden { display: none; }
  .talent-pocs .loc-flag { align-items: center; background: #ffffff22; border: 1px solid #ffffff70; border-radius: 50%; display: grid; font-size: 21px; height: 44px; justify-items: center; width: 44px; }
  .talent-pocs .loc-info { min-width: 0; }
  .talent-pocs .loc-name { color: #ffffff; display: block; font-size: 14px; font-weight: 700; line-height: 1.3; }
  .talent-pocs .loc-name em { color: var(--poc-yellow); display: block; font-size: 10px; font-style: normal; font-weight: 700; margin-top: 2px; text-transform: uppercase; }
  .talent-pocs .loc-cities { color: #ffffff; font-size: 11px; line-height: 1.35; margin-top: 3px; }
  .talent-pocs .loc-sep { align-self: stretch; background: #ffffff57; }
  .talent-pocs .loc-poc { align-items: center; display: flex; gap: 8px; min-width: 0; }
  .talent-pocs .loc-av { align-items: center; background: var(--poc-yellow); border: 2px solid #ffffff; border-radius: 50%; color: var(--poc-bg); display: grid; flex: none; font-size: 12px; font-weight: 800; height: 38px; justify-items: center; overflow: hidden; position: relative; width: 38px; }
  .talent-pocs .loc-av img { height: 100%; object-fit: cover; position: absolute; width: 100%; }
  .talent-pocs .loc-poc-name { font-size: 12px; font-weight: 700; line-height: 1.2; }
  .talent-pocs .loc-arrow { color: var(--poc-yellow); font-size: 18px; opacity: 0; position: absolute; right: 8px; transition: opacity .2s; }
  .talent-pocs .loc-card:hover .loc-arrow { opacity: 1; }
  .talent-pocs .no-results { color: #ffffff; display: none; grid-column: 1 / -1; padding: 30px 0; text-align: center; }
  .talent-pocs .note-banner { align-items: center; animation: pocsRise .6s both; background: var(--poc-yellow); border-radius: 12px; color: var(--poc-bg); display: flex; gap: 14px; margin: 36px 0 12px; padding: 14px 18px; }
  .talent-pocs .note-icon { align-items: center; background: var(--poc-bg); border-radius: 50%; color: var(--poc-yellow); display: grid; flex: none; font-family: Georgia, serif; font-size: 18px; font-weight: 900; height: 34px; justify-items: center; width: 34px; }
  .talent-pocs .note-sep { background: #1a1a24; height: 28px; width: 2px; }
  .talent-pocs .note-banner p { color: var(--poc-bg); font-size: 13px; font-weight: 600; margin: 0; }
  .talent-pocs .note-banner a { color: var(--poc-bg); font-weight: 800; text-decoration: underline; }
  .talent-poc-dialog-backdrop { align-items: center; background: #1a1a24dd; display: grid; inset: 0; justify-items: center; opacity: 0; padding: 20px; pointer-events: none; position: fixed; transition: opacity .2s; z-index: 100000; }
  .talent-poc-dialog-backdrop.is-open { opacity: 1; pointer-events: auto; }
  .talent-poc-dialog { background: #2e2e38; border: 1px solid #ffffff; border-radius: 16px; color: #ffffff; max-height: calc(100vh - 40px); overflow-y: auto; padding: 30px 24px 24px; position: relative; transform: translateY(12px); transition: transform .2s; width: min(460px, 100%); }
  .talent-poc-dialog-backdrop.is-open .talent-poc-dialog { transform: none; }
  .talent-poc-dialog-close { background: #1a1a24; border: 1px solid #ffffff; border-radius: 50%; color: #ffffff; cursor: pointer; font-size: 16px; height: 34px; position: absolute; right: 12px; top: 12px; width: 34px; }
  .talent-poc-dialog-avatar { align-items: center; background: #ffe600; border: 3px solid #ffffff; border-radius: 50%; color: #1a1a24; display: grid; font-size: 24px; font-weight: 800; height: 78px; justify-items: center; margin: 0 auto 12px; overflow: hidden; position: relative; width: 78px; }
  .talent-poc-dialog-avatar img { height: 100%; object-fit: cover; position: absolute; width: 100%; }
  .talent-poc-dialog h3 { color: #ffffff; font-size: 22px; margin: 0; text-align: center; }
  .talent-poc-dialog .role { color: #ffe600; font-size: 12px; font-weight: 700; margin-top: 5px; text-align: center; text-transform: uppercase; }
  .talent-poc-dialog-tags { display: flex; flex-wrap: wrap; gap: 8px; justify-content: center; margin: 18px 0 0; }
  .talent-poc-dialog-tags span { background: #1a1a24; border: 1px solid #ffffff55; border-radius: 999px; color: #ffffff; font-size: 12px; padding: 6px 10px; }
  @keyframes pocsRise { from { opacity: 0; transform: translateY(16px); } to { opacity: 1; transform: none; } }
  @media (max-width: 1080px) { .talent-pocs .poc-grid { grid-template-columns: repeat(3, minmax(0, 1fr)); } .talent-pocs .loc-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); } }
  @media (max-width: 680px) { .talent-pocs { padding-left: 14px; padding-right: 14px; } .talent-pocs .poc-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); } .talent-pocs .loc-grid { grid-template-columns: 1fr; } .talent-pocs .sec-head h2 { font-size: 22px; } .talent-pocs .sec-sub { margin-left: 0; } .talent-pocs .loc-card { grid-template-columns: 44px minmax(0, 1fr) minmax(100px, auto); } .talent-pocs .loc-sep { display: none; } }
`;

interface IMenaTaxTalentProps {
  onShowHome: () => void;
}

interface Profile {
  email: string;
  image: string;
  title: string;
  name: string;
  titleClass?: string;
  nameClass?: string;
}

const imageRoot = 'https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/';
const profileImageRoot = 'https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/';
const profilePdfRoot = 'https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/pdf/';

const profiles: Array<{ heading: string; people: Profile[] }> = [
  {
    heading: 'Talent Consulting',
    people: [
      { email: 'eman.ayyoub@jo.ey.com', image: `${imageRoot}Eman-Ayyoub.jpg`, title: 'Strategic Talent Leader', name: 'Eman Ayyoub' },
      { email: 'alyaa.almulla@bh.ey.com', image: `${profileImageRoot}Alyaa-Almulla.jpg`, title: 'Lead Talent Consultant', name: 'Alyaa Almulla', titleClass: 'psTitley1', nameClass: 'psNamey1' },
      { email: 'asha.rajan1@kw.ey.com', image: `${profileImageRoot}Asha%20Rajan.jpg`, title: 'Lead Talent Consultant', name: 'Asha Rajan', titleClass: 'psTitley1', nameClass: 'psNamey1' },
      { email: 'Danish.Khan@pk.ey.com', image: `${profileImageRoot}Danish%20Khan.png`, title: 'Lead Talent Consultant', name: 'Danish Khan', titleClass: 'psTitley1', nameClass: 'psNamey1' }
    ]
  },
  {
    heading: 'Experience Management',
    people: [
      { email: 'bobin.abraham@gds.ey.com', image: `${profileImageRoot}Bobin%20T.jpg`, title: 'Experience Management Leader', name: 'Bobin T Abraham' },
      { email: 'jellen.jose@ae.ey.com', image: `${profileImageRoot}Jellen%20Jose.jpg`, title: 'EM Consultant', name: 'Jellen Jose', titleClass: 'psTitley1', nameClass: 'psNamey1' },
      { email: 'dileep.rajasekhar@kw.ey.com', image: `${profileImageRoot}Dileep%20Rajasekhar.jpg`, title: 'EM Consultant', name: 'Dileep Rajasekhar', titleClass: 'psTitley1', nameClass: 'psNamey1' },
      { email: 'meghna.jayachandran@gds.ey.com', image: `${profileImageRoot}fa4b0e99-0d5a-4485-bca4-de12736bb7b1_LThumb.jpg`, title: 'EM Analyst', name: 'Meghna Jayachandran', titleClass: 'psTitley1', nameClass: 'psNamey1' },
      { email: 'Jose.T@gds.ey.com', image: `${profileImageRoot}Jose%20Thomas.jpg`, title: 'EM Analyst', name: 'Jose Thomas', titleClass: 'psTitley1', nameClass: 'psNamey1' }
    ]
  },
  {
    heading: 'Recruitment',
    people: [
      { email: 'dania.zalatimo@jo.ey.com', image: `${profileImageRoot}dania_zalatimo_jo_ey_com_LThumb.jpg`, title: 'DAP/NEP recruiter-Tax', name: 'Dania Zalatimo' },
      { email: 'Ali.Abdulla@bh.ey.com', image: `${profileImageRoot}ali-abdulla.jpg`, title: 'Recruitment Leader - Experienced Hire - Tax', name: 'Ali Abdulla' },
      { email: 'anum.z.merchant@rapid.ey.com', image: `${profileImageRoot}Anum%20Merchant.jpg`, title: 'MENA Tax Experience Hire Recruiter', name: 'Anum Merchant', titleClass: 'psTitley1', nameClass: 'psNamey1' },
      { email: 'reem.farghaly@eg.ey.com', image: `${profileImageRoot}Reem%20A%20Farghaly.jpg`, title: 'MENA Tax Experience Hire Recruiter', name: 'Reem Farghaly', titleClass: 'psTitley1', nameClass: 'psNamey1' },
      { email: 'amna.zarin@rapid.ey.com', image: `${profileImageRoot}amna%20zarin.jpg`, title: 'MENA Tax Experience Hire Recruiter', name: 'Amna Zarin', titleClass: 'psTitley1', nameClass: 'psNamey1' },
      { email: 'Talal.Obeidat@jo.ey.com', image: 'https://people.ey.com/User%20Photos/Profile%20Pictures/17bb805e-d935-446e-8fcb-8667711129dd_LThumb.jpg', title: 'MENA Tax Experience Hire Recruiter', name: 'Talal Obeidat', titleClass: 'psTitley1', nameClass: 'psNamey1' }
    ]
  },
  {
    heading: 'Learning',
    people: [
      { email: 'subarna.ramamoorthy@bh.ey.com', image: `${profileImageRoot}subarna.ramamoorthy.png`, title: 'Tax Learning Lead', name: 'Subarna Ramamoorthy', titleClass: 'psTitley1', nameClass: 'psNamey1' },
      { email: 'Shari.J@gds.ey.com', image: `${profileImageRoot}Shari%20-1.jpg`, title: 'Learning Coordinator', name: 'Shari J', titleClass: 'psTitley1', nameClass: 'psNamey1' },
      { email: 'Anusree.Bhaskar@gds.ey.com', image: `${profileImageRoot}Anusree%20Bhaskar.jpg`, title: 'Learning Coordinator', name: 'Anusree Bhaskar', titleClass: 'psTitley1', nameClass: 'psNamey1' }
    ]
  }
];

const TalentProfiles: React.FC<{ group: { heading: string; people: Profile[] } }> = ({ group }) => (
  <div>
    <div className="secHead">{group.heading}</div>
    <div className="secBorder" />
    <div className="profile-column">
      {group.people.map((person) => (
        <a data-interception="off" key={person.email} href={`mailto:${person.email}`} style={{ textDecoration: 'none' }}>
          <div className="proBox">
            <img src={person.image} className="psImage" alt={person.name} />
            <div className={person.titleClass || 'psTitle'}>{person.title}</div>
            <div className={person.nameClass || 'psName'}>{person.name}</div>
          </div>
        </a>
      ))}
    </div>
  </div>
);

interface TalentPoc {
  name: string;
  initials: string;
  avatarClass: string;
  image: string;
  role: string;
  services: string[];
  locations: string[];
}

interface TalentServiceLine {
  title: string;
  poc: string;
  icon: 'coins' | 'scales' | 'laptop' | 'chart' | 'team' | 'case';
}

interface TalentLocation {
  flag: string;
  name: string;
  tag?: string;
  cities?: string;
  poc: string;
}

const talentPocs: TalentPoc[] = [
  { name: 'Alyaa Almulla', initials: 'AA', avatarClass: 'av-alyaa', image: `${profileImageRoot}Alyaa-Almulla.jpg`, role: 'Talent POC · ITTS & LAW — MENA', services: ['ITTS – MENA', 'LAW – MENA'], locations: ['Saudi Arabia (Riyadh, Jeddah, Al-Khobar)', 'Bahrain', 'Egypt'] },
  { name: 'Asha Rajan', initials: 'AR', avatarClass: 'av-asha', image: `${profileImageRoot}Asha%20Rajan.jpg`, role: 'Talent POC · IDT & PAS — MENA', services: ['IDT – MENA', 'PAS – MENA'], locations: ['UAE (Dubai, Abu Dhabi)', 'Qatar', 'Oman', 'Kuwait'] },
  { name: 'Danish Khan', initials: 'DK', avatarClass: 'av-danish', image: `${profileImageRoot}Danish%20Khan.png`, role: 'Talent POC · TTT & ACR — MENA', services: ['TTT – MENA', 'ACR – MENA'], locations: ['Pakistan – EYFR', 'Pakistan (Nearshore only)', 'Egypt (Nearshore only)'] },
  { name: 'Eman Ayyoub', initials: 'EA', avatarClass: 'av-eman', image: `${imageRoot}Eman-Ayyoub.jpg`, role: 'GCR Core Talent POC', services: [], locations: ['Levant (Jordan, Libya, Palestine, Syria, Iraq, Lebanon)'] }
];

const talentServiceLines: TalentServiceLine[] = [
  { title: 'ITTS – MENA', poc: 'Alyaa Almulla', icon: 'coins' },
  { title: 'LAW – MENA', poc: 'Alyaa Almulla', icon: 'scales' },
  { title: 'IDT – MENA', poc: 'Asha Rajan', icon: 'laptop' },
  { title: 'PAS – MENA', poc: 'Asha Rajan', icon: 'chart' },
  { title: 'TTT – MENA', poc: 'Danish Khan', icon: 'team' },
  { title: 'ACR – MENA', poc: 'Danish Khan', icon: 'case' }
];

const talentLocations: TalentLocation[] = [
  { flag: '🇸🇦', name: 'Saudi Arabia', cities: 'Riyadh, Jeddah, Al-Khobar', poc: 'Alyaa Almulla' },
  { flag: '🇧🇭', name: 'Bahrain', poc: 'Alyaa Almulla' },
  { flag: '🇪🇬', name: 'Egypt', poc: 'Alyaa Almulla' },
  { flag: '🇦🇪', name: 'UAE', cities: 'Dubai, Abu Dhabi', poc: 'Asha Rajan' },
  { flag: '🇶🇦', name: 'Qatar', poc: 'Asha Rajan' },
  { flag: '🇴🇲', name: 'Oman', poc: 'Asha Rajan' },
  { flag: '🇰🇼', name: 'Kuwait', poc: 'Asha Rajan' },
  { flag: '🇵🇰', name: 'Pakistan', tag: 'EYFR', poc: 'Danish Khan' },
  { flag: '🇵🇰', name: 'Pakistan', tag: 'Nearshore only', poc: 'Danish Khan' },
  { flag: '🇪🇬', name: 'Egypt', tag: 'Nearshore only', poc: 'Danish Khan' },
  { flag: '🇱🇧', name: 'Levant', cities: 'Jordan, Libya, Palestine, Syria, Iraq, Lebanon', poc: 'Eman Ayyoub' }
];

const talentServiceIcons: Record<TalentServiceLine['icon'], React.ReactNode> = {
  coins: <svg viewBox="0 0 24 24"><ellipse cx="12" cy="6" rx="7" ry="3" /><path d="M5 6v6c0 1.7 3.1 3 7 3s7-1.3 7-3V6" /><path d="M5 12v6c0 1.7 3.1 3 7 3s7-1.3 7-3v-6" /></svg>,
  scales: <svg viewBox="0 0 24 24"><path d="M12 3v18M8 21h8M12 6l-6 2 6-2 6 2" /><path d="M6 8l-3 6a3.2 3.2 0 0 0 6 0L6 8zM18 8l-3 6a3.2 3.2 0 0 0 6 0l-3-6z" /></svg>,
  laptop: <svg viewBox="0 0 24 24"><rect x="4" y="5" width="16" height="11" rx="1.5" /><path d="M2 19h20" /></svg>,
  chart: <svg viewBox="0 0 24 24"><path d="M4 20V10M10 20V4M16 20v-8M21 20H3" /><path d="M15 7l4-3 1.5 4" /></svg>,
  team: <svg viewBox="0 0 24 24"><circle cx="8" cy="8" r="2.8" /><circle cx="16.5" cy="9" r="2.3" /><path d="M2.5 20c0-3.2 2.5-5.3 5.5-5.3s5.5 2.1 5.5 5.3M14.5 15.2c2.8.2 5 2 5 4.8" /></svg>,
  case: <svg viewBox="0 0 24 24"><rect x="3" y="8" width="18" height="12" rx="2" /><path d="M9 8V6a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2M3 13h18" /></svg>
};

const getTalentPoc = (name: string): TalentPoc | undefined => {
  for (let index = 0; index < talentPocs.length; index += 1) {
    if (talentPocs[index].name === name) return talentPocs[index];
  }
  return undefined;
};

const MenaTaxTalentPocs: React.FC<{ onSelectPoc: (person: TalentPoc) => void }> = ({ onSelectPoc }) => {
  const [activeFilter, setActiveFilter] = React.useState('all');
  const visibleLocations = talentLocations.filter((location) => activeFilter === 'all' || location.poc === activeFilter);

  const renderAvatar = (person: TalentPoc, className: string): JSX.Element => (
    <span className={`${className} ${person.avatarClass}`}>
      <span>{person.initials}</span>
      <img src={person.image} alt={person.name} onError={(event) => { event.currentTarget.style.display = 'none'; }} />
    </span>
  );

  return (
    <div className="talent-pocs">
      <section id="service-lines">
        <div className="sec-head">
          <div className="sec-icon"><svg viewBox="0 0 24 24"><circle cx="9" cy="7" r="3.2" /><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6" /><circle cx="17" cy="8" r="2.6" /><path d="M16 14.4c3 .3 5.5 2.4 5.5 5.6" /></svg></div>
          <div className="sec-bar" />
          <h2>Talent POC by Service Line</h2>
        </div>
        <div className="poc-grid">
          {talentServiceLines.map((serviceLine, index) => {
            const person = getTalentPoc(serviceLine.poc);
            if (!person) return null;
            return (
              <button className="poc-card" data-poc={person.name} key={serviceLine.title} type="button" aria-label={`${serviceLine.title} contact ${person.name}`} style={{ animationDelay: `${(index + 1) * 0.06}s` }} onClick={() => onSelectPoc(person)}>
                <span className="poc-hint" aria-hidden="true">↗</span>
                <span className="poc-icon">{talentServiceIcons[serviceLine.icon]}</span>
                <span className="poc-title">{serviceLine.title}</span>
                {renderAvatar(person, 'poc-avatar')}
                <span className="poc-name">{person.name.split(' ')[0]}<br />{person.name.split(' ').slice(1).join(' ')}</span>
              </button>
            );
          })}
        </div>
      </section>

      <section id="locations">
        <div className="sec-head">
          <div className="sec-icon"><svg viewBox="0 0 24 24"><path d="M12 21s-7-5.6-7-11a7 7 0 0 1 14 0c0 5.4-7 11-7 11z" /><circle cx="12" cy="10" r="2.6" /></svg></div>
          <div className="sec-bar" />
          <h2>GCR Core Talent POC by Location</h2>
        </div>
        <div className="filter-bar">
          <div className="chips" aria-label="Filter locations by contact">
            <button type="button" className={`chip${activeFilter === 'all' ? ' active' : ''}`} onClick={() => setActiveFilter('all')}>All locations</button>
            {talentPocs.map((person) => (
              <button type="button" key={person.name} className={`chip${activeFilter === person.name ? ' active' : ''}`} onClick={() => setActiveFilter(person.name)}>
                <span className="chip-avatar" aria-hidden="true"><span>{person.initials}</span><img src={person.image} alt="" onError={(event) => { event.currentTarget.style.display = 'none'; }} /></span>{person.name}
              </button>
            ))}
          </div>
        </div>
        <div className="loc-grid">
          {visibleLocations.map((location, index) => {
            const person = getTalentPoc(location.poc);
            if (!person) return null;
            return (
              <button type="button" className="loc-card" data-poc={person.name} key={`${location.name}-${location.tag || ''}-${person.name}`} aria-label={`${location.name} contact ${person.name}`} style={{ animationDelay: `${index * 0.05}s` }} onClick={() => onSelectPoc(person)}>
                <span className="loc-flag" aria-hidden="true">{location.flag}</span>
                <span className="loc-info">
                  <span className="loc-name">{location.name}{location.tag && <em>{location.tag}</em>}</span>
                  {location.cities && <span className="loc-cities">{location.cities}</span>}
                </span>
                <span className="loc-sep" />
                <span className="loc-poc">
                  {renderAvatar(person, 'loc-av')}
                  <span className="loc-poc-name">{person.name}</span>
                </span>
                <span className="loc-arrow" aria-hidden="true">›</span>
              </button>
            );
          })}
          {visibleLocations.length === 0 && <p className="no-results">No locations match your search.</p>}
        </div>
        <div className="note-banner">
          <span className="note-icon">i</span>
          <span className="note-sep" />
          <p>For Talent policy queries (leaves, etc.), please refer to <a href="#">MENA Talent Hub</a> and <a href="#">SAFI</a>.</p>
        </div>
      </section>

    </div>
  );
};

const MenaTaxTalent: React.FC<IMenaTaxTalentProps> = ({ onShowHome }) => {
  const [openSection, setOpenSection] = React.useState<string | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [selectedTalentPoc, setSelectedTalentPoc] = React.useState<TalentPoc | null>(null);

  React.useEffect(() => {
    const timer = window.setTimeout(() => setLoading(false), 2000);
    window.scrollTo(0, 0);
    return () => window.clearTimeout(timer);
  }, []);

  React.useEffect(() => {
    if (!selectedTalentPoc) return undefined;
    const handleKeyDown = (event: KeyboardEvent): void => {
      if (event.key === 'Escape') setSelectedTalentPoc(null);
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [selectedTalentPoc]);

  const toggleSection = (sectionId: string): void => {
    setOpenSection((currentSection) => currentSection === sectionId ? null : sectionId);
  };

  return (
  <>
    <style>{talentStyles}</style>
    <div className="talent-page">
      <div className={`loading-container${loading ? '' : ' is-hidden'}`} aria-hidden={!loading}>
        <div className="item" />
        <div className="item" />
        <div className="item" />
        <div className="item" />
      </div>
      <div className="container_wrapper">
        <div className="webPart">
          <div className="container-fluid nav-container">
            <div className="row nav-bar">
              <img
                className="EYlogo"
                src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/EY_logo.png"
                alt="EY logo"
              />
              <p className="logoTxt">MENA Tax Hub</p>
              <ul className="navbarMenu">
                <li>
                  <a data-interception="off" href="#" onClick={(event) => { event.preventDefault(); onShowHome(); }}>
                    <img
                      className="home"
                      src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home.png"
                      alt="Home"
                    />
                  </a>
                </li>
              </ul>
              
            </div>
          </div>

      <div className="container-fluid">
      <div className="row">
      <div className="col-sm-12 bannerBackground">
        <div className="container-fluid cnt-fdr">
        <div className="row">
          <p className="cf6">Tax Talent</p>
          <p className="hder">You come to EY to be even better, to be exceptional. You come here because of the people and the culture, to contribute to the highest performing teams, to be challenged and stretched every step of the way. You can be yourself in a place where people value differences and listen to each other.<br /><br />What is the EY experience? It's the opportunity to do something exceptional, something that matters. It's owning your career, shaping your future and becoming the leader you want to be.<br /><br />It's how together we build a better working world, because better begins with you.</p>
      </div>
      </div>
      </div>
      </div>
      </div>

      <div className="container-fluid tabContent">
        <div className="accordion" id="accordionExample">
          <div className="card">
            <div className="card-header" id="headingOne"><h2 className="mb-0"><button type="button" className={`btn btn-link ${openSection === 'collapseOne' ? '' : 'collapsed'}`} onClick={() => toggleSection('collapseOne')} aria-expanded={openSection === 'collapseOne'} aria-controls="collapseOne"><i className="fa fa-plus" />MENA Tax Talent Functions</button></h2></div>
            <div id="collapseOne" className={openSection === 'collapseOne' ? 'collapse show' : 'collapse'} aria-labelledby="headingOne">
              <div className="card-body">
                <p className="hder">The Talent function supports our business in various ways relating to our people. Talent supports with Diversity, Equity and Inclusiveness (DE&amp;I), Learning &amp; Development (L&amp;D), Mobility, Talent Attraction and Acquisition (TA²), Talent Consulting, Performance and Reward, Talent Strategy &amp; Organizational Effectiveness (TS&amp;OE), and Talent Delivery. You can read more about the Talent function on the Global Talent Function homepage and MENA Talent Hub.<br /><br />In MENA, many of these functions are run cross-Service Line. However, Talent has teams that focus specifically on the Tax Service Line for Talent Consulting, Experience Management, Recruitment and Learning.</p>
                <div className="profile-row">{profiles.map((group) => <TalentProfiles key={group.heading} group={group} />)}</div>
                <p className="hder">Matters related to Experience Management and Recruitment should be discussed and agreed with your Subservice Line Leader in the first instance before any hiring requests or communications are initiated. If an issue requires assistance from Tax Operations, Dave McKenna is the Tax Operations Point of Contact.<br /><br />Tax Learning is under the oversight of Paul Cooper, with support from Venice Segarra. Subarna’s team deals with most day-to-day issues that arise (e.g., support in matters related to SuccessFactors, recording CE hours for one-time-opportunity training sessions). However, if you want to explore learning campaigns or events that may require budget allocation, Paul Cooper should be looped into the conversation.</p>
              </div>
            </div>
          </div>

          <div className="card">
            <div className="card-header" id="headingTwo"><h2 className="mb-0"><button type="button" className={`btn btn-link ${openSection === 'collapseTwo' ? '' : 'collapsed'}`} onClick={() => toggleSection('collapseTwo')} aria-expanded={openSection === 'collapseTwo'} aria-controls="collapseTwo"><i className="fa fa-plus" />MENA Tax Talent POCs</button></h2></div>
            <div id="collapseTwo" className={openSection === 'collapseTwo' ? 'collapse show' : 'collapse'} aria-labelledby="headingTwo">
              <div className="card-body">
                <MenaTaxTalentPocs onSelectPoc={setSelectedTalentPoc} />
              </div>
            </div>
          </div>

          <div className="card">
            <div className="card-header" id="headingThree"><h2 className="mb-0"><button type="button" className={`btn btn-link ${openSection === 'collapseThree' ? '' : 'collapsed'}`} onClick={() => toggleSection('collapseThree')} aria-expanded={openSection === 'collapseThree'} aria-controls="collapseThree"><i className="fa fa-plus" />MENA Tax SSL Talent Champions</button></h2></div>
            <div id="collapseThree" className={openSection === 'collapseThree' ? 'collapse show' : 'collapse'} aria-labelledby="headingThree">
              <div className="card-body">
                <p className="hder">At EY, we are committed to create an inclusive environment where our people are enabled to strive and perform at their best. For that, we have appointed a Talent Champion across our SSLs and geographies to ensure you have the support and guidance needed to maintain your full engagement and wellbeing.<br /><br />Talent Champions work closely with Tax Talent team to support the successful implementation of talent initiatives and priorities and be your go to person to seek the support you need in addressing any of your needs, concerns and issues.</p>
                <div className="table-wrap"><table className="table table-bordered ts_7 ty_7"><thead><tr><th>SSL</th><th>Talent champion</th><th>Garde</th><th>Geographic scope</th></tr></thead><tbody>
                  <tr><td rowSpan={2}>GCR</td><td><a data-interception="off" href="mailto:imran.iqbal@sa.ey.com" style={{ color: '#ffffff', textDecoration: 'none' }}><img src={`${profileImageRoot}imran_iqbal_sa_ey_com_LThumb.jpg`} className="tableImg" alt="Imran Iqbal" /><p className="nme">Imran Iqbal</p></a></td><td>Partner</td><td>GCC</td></tr>
                  <tr><td><a data-interception="off" href="mailto:ahmed.aboelfotouh@eg.ey.com" style={{ color: '#ffffff', textDecoration: 'none' }}><img src={`${profileImageRoot}ahmed_aboelfotouh_eg_ey_com_LThumb.jpg`} className="tableImg" alt="Ahmed Abo El Fotouh" /><p className="nme">Ahmed Abo El Fotouh</p></a></td><td>Partner</td><td>Levent</td></tr>
                  <tr><td>ACR</td><td><a data-interception="off" href="mailto:sohail.nini@sa.ey.com" style={{ color: '#ffffff', textDecoration: 'none' }}><img src={`${profileImageRoot}21bd67ba-4dca-434b-b090-ffa3da600ddc_LThumb.jpg`} className="tableImg" alt="Sohail Nini" /><p className="nme">Sohail Nini</p></a></td><td>Partner</td><td>MENA</td></tr>
                  <tr><td>IDT</td><td><a data-interception="off" href="mailto:mohammedbilal.akram@sa.ey.com" style={{ color: '#ffffff', textDecoration: 'none' }}><img src={`${profileImageRoot}Mohammed%20Bilal.jpg`} className="tableImg" alt="Mohammed Bilal Akram" /><p className="nme">Mohammed Bilal Akram</p></a></td><td>Partner</td><td>MENA</td></tr>
                  <tr><td>ITTS</td><td><a data-interception="off" href="mailto:mina.alkhudairi@ae.ey.com" style={{ color: '#ffffff', textDecoration: 'none' }}><img src={`${profileImageRoot}6b98dfff-b2bf-487e-b065-767ac640ac1f_LThumb.jpg`} className="tableImg" alt="Mina Al-Khudairi" /><p className="nme">Mina Al-Khudairi</p></a></td><td>Partner</td><td>MENA</td></tr>
                  <tr><td>PAS</td><td><a data-interception="off" href="mailto:roman.gusev@bh.ey.com" style={{ color: '#ffffff', textDecoration: 'none' }}><img src={`${profileImageRoot}roman-gusev.jpg`} className="tableImg" alt="Roman Gusev" /><p className="nme">Roman Gusev</p></a></td><td>Partner</td><td>MENA</td></tr>
                  <tr><td>Law</td><td><a data-interception="off" href="mailto:rodolphe.pellerin@ae.ey.com" style={{ color: '#ffffff', textDecoration: 'none' }}><img src={`${profileImageRoot}rodolphe-pellerin.jpg`} className="tableImg" alt="Rodolphe R Pellerin" /><p className="nme">Rodolphe R Pellerin</p></a></td><td>Partner</td><td>MENA</td></tr>
                </tbody></table></div>
              </div>
            </div>
          </div>

          <div className="card">
            <div className="card-header" id="headingFour"><h2 className="mb-0"><button type="button" className={`btn btn-link ${openSection === 'collapseFour' ? '' : 'collapsed'}`} onClick={() => toggleSection('collapseFour')} aria-expanded={openSection === 'collapseFour'} aria-controls="collapseFour"><i className="fa fa-plus" />Key Talent Documents and references</button></h2></div>
            <div id="collapseFour" className={openSection === 'collapseFour' ? 'collapse show' : 'collapse'} aria-labelledby="headingFour">
              <div className="card-body"><div className="documents">
                <a data-interception="off" className="document-card" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/Your%20Career%20Guide%20at%20MENA%20Tax%20-%20FY26%20(003).pdf" target="_blank" rel="noreferrer"><div className="box-banner" style={{ backgroundImage: `url(${profilePdfRoot}Career%20Guide%20FY26%20Image.png)` }} /><div className="box-content"><p className="box-cnt">Your Career Guide at MENA Tax</p><p className="box-readmore">READ MORE</p></div></a>
                <a data-interception="off" className="document-card" style={{ display: 'none' }} href="https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/FY23%20Tax%20-%20Rapid%20Pakistan%20PQ%20Policy.pdf" target="_blank" rel="noreferrer"><div className="box-banner" style={{ backgroundImage: `url(${profileImageRoot}thum3.png)` }} /><div className="box-content"><p className="box-cnt">Rapid Innovation TAX Professional Qualification Policy</p><p className="box-readmore">READ MORE</p></div></a>
                <a data-interception="off" className="document-card" style={{ display: 'none' }} href="https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/MENA%20TAX_PQ%20Policy_FY26.pdf" target="_blank" rel="noreferrer"><div className="box-banner" style={{ backgroundImage: `url(${profileImageRoot}thum02.png)` }} /><div className="box-content"><p className="box-cnt">MENA Tax Professional Qualification Policy FY26</p><p className="box-readmore">READ MORE</p></div></a>
                <a data-interception="off" className="document-card" href="https://sites.ey.com/sites/TaxLearning/SitePages/HomepageCopy.aspx" target="_blank" rel="noreferrer"><div className="box-banner" style={{ backgroundImage: `url(${profileImageRoot}tax-learning-hub.jpg)` }} /><div className="box-content"><p className="box-cnt">Tax Learning Hub</p><p className="box-readmore">READ MORE</p></div></a>
              </div></div>
            </div>
          </div>
 </div>  </div>
          <div className="container-fluid footerTab">
            <div className="row">
              <div className="col-sm-12"><p className="quicklinks">Quick links</p></div>
              <div className="col-sm-3 cl-3"><a data-interception="off" href="https://sites.ey.com/sites/EYMENA/SiteAssets/PDF/MENA%20TE%20Policy/ME%20TE%20Policy.pdf" target="_blank" rel="noreferrer"><div className="col-sm-bx"><div className="img-bx" style={{ backgroundImage: `url(${imageRoot}MENA-Expense-Policy.jpg)` }} /><p className="bx-link">MENA Expense<br />Policy</p><span>01</span></div></a></div>
              <div className="col-sm-3 cl-3"><a data-interception="off" href="https://sites.ey.com/sites/menapeopleconnect/SitePages/TotalReward.aspx" target="_blank" rel="noreferrer"><div className="col-sm-bx"><div className="img-bx" style={{ backgroundImage: `url(${profileImageRoot}People-News.png)` }} /><p className="bx-link">MENA Total <br />Reward</p><span>02</span></div></a></div>
              <div className="col-sm-3 cl-3"><a data-interception="off" href="https://sites.ey.com/sites/menapeopleconnect/SitePages/Policies%20and%20Procedures.aspx" target="_blank" rel="noreferrer"><div className="col-sm-bx"><div className="img-bx" style={{ backgroundImage: `url(${profileImageRoot}tx03.jpg)` }} /><p className="bx-link">MENA Talent Policies &amp; Procedures</p><span>03</span></div></a></div>
              <div className="col-sm-3 cl-3"><a data-interception="off" href="https://intranet.ey.com/sites/career-development/SitePageModern/342011/career-development" target="_blank" rel="noreferrer"><div className="col-sm-bx"><div className="img-bx" style={{ backgroundImage: `url(${profileImageRoot}tx04.jpg)` }} /><p className="bx-link">Career &amp; <br />development</p><span>04</span></div></a></div>
              <div className="col-sm-3 cl-3"><a data-interception="off" href="https://sites.ey.com/sites/menapeopleconnect/SitePages/Onboarding.aspx" target="_blank" rel="noreferrer"><div className="col-sm-bx"><div className="img-bx" style={{ backgroundImage: `url(${imageRoot}eng_02.jpg)` }} /><p className="bx-link">New starters (first 90 days)</p><span>05</span></div></a></div>
              <div className="col-sm-3 cl-3"><a data-interception="off" href="https://sites.ey.com/sites/menapeopleconnect/SitePages/Home.aspx" target="_blank" rel="noreferrer"><div className="col-sm-bx"><div className="img-bx" style={{ backgroundImage: `url(${profileImageRoot}talent-hub.jpg)` }} /><p className="bx-link">The Talent<br />Hub</p><span>06</span></div></a></div>
              <div className="col-sm-3 cl-3"><a data-interception="off" href="https://jam12.sapjam.com/home" target="_blank" rel="noreferrer"><div className="col-sm-bx"><div className="img-bx" style={{ backgroundImage: `url(${profileImageRoot}badges.jpg)` }} /><p className="bx-link">EY <br />Badges</p><span>07</span></div></a></div>
              <div className="col-sm-3 cl-3"><a data-interception="off" href="https://jam12.sapjam.com/groups/nBYctR4FmssgPPbOZnL19h/overview_page/qDLfmkXJzgezWV5L4yWoJr" target="_blank" rel="noreferrer"><div className="col-sm-bx"><div className="img-bx" style={{ backgroundImage: `url(${profileImageRoot}tech-mba.jpg)` }} /><p className="bx-link">EY Tech <br />MBA</p><span>08</span></div></a></div>
              <div className="col-sm-3 cl-3"><a data-interception="off" href="https://sites.ey.com/sites/MENATaxHub/ProFinda/Forms/AllItems.aspx" target="_blank" rel="noreferrer"><div className="col-sm-bx"><div className="img-bx" style={{ backgroundImage: `url(${profileImageRoot}AdobeStock-331188576.jpeg)` }} /><p className="bx-link">ProFinda</p><span>09</span></div></a></div>
            </div>
          </div>
          <div className="footer"><p>&#169; 2026 EYGM Limited. All rights reserved.</p></div>
       
    
    </div>
    </div>
    </div>
    {selectedTalentPoc && (
      <div className="talent-poc-dialog-backdrop is-open" role="presentation" onClick={(event) => { if (event.target === event.currentTarget) setSelectedTalentPoc(null); }}>
        <section className="talent-poc-dialog" role="dialog" aria-modal="true" aria-labelledby="talent-poc-modal-name">
          <button type="button" className="talent-poc-dialog-close" aria-label="Close profile" onClick={() => setSelectedTalentPoc(null)}>×</button>
          <span className="talent-poc-dialog-avatar">
            <span>{selectedTalentPoc.initials}</span>
            <img src={selectedTalentPoc.image} alt={selectedTalentPoc.name} onError={(event) => { event.currentTarget.style.display = 'none'; }} />
          </span>
          <h3 id="talent-poc-modal-name">{selectedTalentPoc.name}</h3>
          <p className="role">{selectedTalentPoc.role}</p>
          <div className="talent-poc-dialog-tags">
            {selectedTalentPoc.services.map((service) => <span key={service}>🧩 {service}</span>)}
            {selectedTalentPoc.locations.map((location) => <span key={location}>📍 {location}</span>)}
          </div>
        </section>
      </div>
    )}
  </>
  );
};

export default MenaTaxTalent;
