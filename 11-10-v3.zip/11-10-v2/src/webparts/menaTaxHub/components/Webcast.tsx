import * as React from 'react';

const webcastStyles = `
html, body { overflow-x: hidden !important; font-family: EYInterstate; }
.webcast-page { background: #2e2e38; color: #ffffff; font-family: EYInterstate, Arial, sans-serif; overflow: hidden; }
.webcast-page .loading-container { align-items: center; background: #1a1a24; display: flex; inset: 0; justify-content: center; position: fixed; z-index: 9999; }
.webcast-page .loading-container .item { border: .2vw solid #ffe600; border-bottom-color: transparent; border-radius: 50%; border-top-color: transparent; height: 30px; position: absolute; width: 30px; animation: webcastSpin 2s ease infinite; }
.webcast-page .loading-container .item:nth-child(2) { height: 50px; width: 50px; animation-delay: .1s; }
.webcast-page .loading-container .item:nth-child(3) { height: 70px; width: 70px; animation-delay: .2s; }
.webcast-page .loading-container .item:nth-child(4) { height: 90px; width: 90px; animation-delay: .3s; }
@keyframes webcastSpin { 50% { transform: rotate(180deg); } 100% { transform: rotate(0deg); } }
.webcast-page .container-wrapper { display: block; }
.webcast-page .nav-bar { background: #2e2e38; margin: 0; min-height: 6vw; position: relative; width: 100%; z-index: 999; }
.webcast-page .EYlogo { left: 5vw; position: absolute; top: 1.5vw; width: 3vw; }
.webcast-page p.logoTxt { color: #ffffff; font-size: 2vw; left: 11vw; position: absolute; top: 2.2vw; }
.webcast-page img.home { width: 1.3vw; }
.webcast-page ul.navbarMenu { font-family: EYInterstate; list-style: none; margin: 0; padding: 0; position: absolute; right: 6vw; top: 2.4vw; }
.webcast-page ul.navbarMenu li { color: #ffffff; display: inline-block; font-size: 1vw; }
.webcast-page ul.navbarMenu li a { color: #ffffff; padding: 0 2vw; text-decoration: none; }
.webcast-page .navToggle { display: none; }
.webcast-page .bannerBackground { background: #2e2e38 url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/banner.jpg);
    animation: communicationsShrink 20s infinite alternate;    min-height: 8vw;
    padding: 0;
    background-size: cover !important;
    background-position: 0% 21%; }
.webcast-page .cf6 { color: #ffffff; font-size: 1.5vw; margin: 0; padding: 1vw; }
@keyframes webcastShrink { 0% { background-size: 115% 115%; } 100% { background-size: 100% 100%; } }
.webcast-page .tabContent { background: #2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center / cover; min-height: 100vh; padding: 4vw 7vw; }
.webcast-page .cl-3 { cursor: pointer; padding: .7vw; }
.webcast-page .col-sm-3.cl-3 { flex: 0 0 20%; max-width: 20%; }
.webcast-page .col-sm-bx { background: #ffffff0f url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center / cover; box-shadow: 0 0 1.5vw rgba(0, 0, 0, .44); min-height: 21vw; position: relative; width: 100%; }
.webcast-page .img-bx { background-position: center; background-size: 110%; min-height: 10vw; transition: all .2s ease-in-out; width: 100%; }
.webcast-page .col-sm-bx:hover .img-bx { background-size: 130%; }
.webcast-page .bx-link { color: #ffffff; font-size: 1vw; line-height: 1.4vw; margin: 0; padding: 2vw 2vw 0; }
.webcast-page .date01 { color: #ffffff; display: block; font-size: .7vw; font-weight: lighter; padding: 0 2vw; }
.webcast-page .pName { color: #ffe600; font-size: .8vw; margin: 1vw 0 0; padding: 0 2vw; }
.webcast-page .pName span { color: #ffffff; }
.webcast-page .playIcon { float: right; margin-right: 2vw; margin-top: -1.2vw; width: 2.5vw; }
.webcast-page .footer { background: #000000; float: left; width: 100%; }
.webcast-page .footer p { color: #ffffff; font-size: 1vw; margin: 0; padding: 1vw 2vw; text-align: right; }
.webcast-page .modal-content { background: transparent; border: hidden; }
.webcast-page .modal-body { padding: 0; }
.webcast-page .modal-dialog { max-width: 60% !important; }
.webcast-page .webcast-modal { align-items: center; background: rgba(0, 0, 0, .8); display: flex; inset: 0; justify-content: center; position: fixed; z-index: 1000006; }
.webcast-page .webcast-modal-content { max-width: 900px; position: relative; width: 90%; }
.webcast-page .webcast-modal-content video { display: block; height: auto; position: static; width: 100%; }
.webcast-page .close { background: #ffe600; color: #000000; cursor: pointer; font-size: 1.5vw; line-height: 1.5vw; opacity: 1; padding: 0 .5vw; position: absolute; right: 0; top: 0; z-index: 1; }
.webcast-page .video-wrap { height: 0; overflow: hidden; padding-bottom: 56.25%; position: relative; }
.webcast-page video { border: none; height: 100%; left: 0; max-width: 100%; position: absolute; top: 0; width: 100%; }
 .webcast-page .cnt-fdr {background: rgba(46, 46, 56, .5);
    padding: 2vw 5vw;
    width: 100%;}
@media only screen and (max-width: 1200px) {
  .webcast-page .cnt-fdr { padding: 35px 70px; }
  .webcast-page .EYlogo { left: 60px; top: 20px; width: 40px; }
  .webcast-page .logoTxt { font-size: 25px; left: 130px; top: 30px; }
  .webcast-page .nav-bar { min-height: 90px; }
  .webcast-page .cf6 { font-size: 30px; }
  .webcast-page .footer p { font-size: 13px; padding: 15px 20px; }
  .webcast-page .bx-link { font-size: 13px; line-height: 14px; }
  .webcast-page .date01 { font-size: 15px; }
}
@media only screen and (max-width: 992px) { .webcast-page .col-sm-3.cl-3 { flex: 0 0 33.333%; max-width: 33.333%; } .webcast-page .col-sm-bx { min-height: 70px; } .webcast-page .cl-3 { padding: 7px; } }
@media only screen and (max-width: 750px) { .webcast-page .col-sm-3.cl-3 { flex: 0 0 50%; max-width: 50%; } }
@media only screen and (max-width: 500px) { .webcast-page .col-sm-3.cl-3 { flex: 0 0 100%; max-width: 100%; } }
`;

interface IWebcastItem { id: string; image: string; date: string; presenter: string; video: string; }

const imageRoot = 'https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/';
const videoRoot = 'https://sites.ey.com/:v:/r/sites/MENATaxHub/SiteAssets/MENATax/Videos/';
const webcastItems: IWebcastItem[] = [
  { id: 'webCast15', image: 'june2026.jpg', date: '30-06-2026', presenter: 'Ahmed Eldessouky', video: 'MENA-Tax-All-People-Webcast-20260630_090205UTC-Meeting%20Recording.mp4' },
  { id: 'webCastFrtn', image: 'mar2026.jpg', date: '31-03-2026', presenter: 'Ahmed Eldessouky', video: 'MENA%20Tax%20All%20People%20Webcast-20260331-Meeting%20Recording.mp4' },
  { id: 'webCastThrtn', image: 'Jan2026.jpg', date: '12-01-2026', presenter: 'Ahmed Eldessouky', video: 'MENA%20Tax%20All%20People%20Webcast-20260112_073200UTC-Meeting%20Recording.mp4' },
  { id: 'webCastTwl', image: 'MENA-Tax-All-People-Webcast-Oct-2025.png', date: '02-10-2025', presenter: 'Ahmed Eldessouky', video: 'Recording_MENA%20Tax%20All%20People%20Webcast_02102025.mp4' },
  { id: 'webCastElv', image: 'webcast%20june%202025.png', date: '30-06-2025', presenter: 'Ahmed Al Esry', video: 'Recording_MENA%20Tax%20All%20People%20Webcast_30062025.mp4' },
  { id: 'webCastTen', image: 'webcast%20april%202025.png', date: '10-04-2025', presenter: 'Ahmed Al Esry', video: 'Recording_MENA%20Tax%20All%20People%20Webcast_10042025.mp4' },
  { id: 'webCastNine', image: 'video-thumb19December.png', date: '19-12-2024', presenter: 'Ahmed Al Esry', video: 'Recording_MENA%20Tax%20All%20People%20Webcast_19122024%20(1).mp4' },
  { id: 'webCastEight', image: 'sept2024.jpg', date: '30-09-2024', presenter: 'Ahmed Al Esry', video: 'Recording_MENA%20Tax%20All%20People%20webcast_30%20Sept.mp4' },
  { id: 'webCastSeven', image: 'webcast-30April.png', date: '30-04-2024', presenter: 'Ahmed Al Esry', video: 'Recording_MENA%20Tax%20All%20People%20Webcast_30042024.mp4' },
  { id: 'webCastSix', image: 'mena-all-people-webcat-final.png', date: '19-12-2023', presenter: 'Ahmed Al Esry', video: 'MENA_All_People_webcast_Final.mp4' },
  { id: 'webCastFive', image: 'Recording_MENA%20Tax%20All%20People%20Webcast.PNG', date: '12-10-2023', presenter: 'Ahmed Al Esry', video: 'Recording_MENA%20Tax%20All%20People%20Webcast.mp4' },
  { id: 'webCastFour', image: 'video-thumba.jpg', date: '22-06-2023', presenter: 'Ahmed Al Esry', video: 'Recording%20-%20MENA%20Tax%20All%20People%20Webcast_Trim.mp4' },
  { id: 'webCastThree', image: 'video-thumb.jpg', date: '10-04-2023', presenter: 'Ahmed Al Esry', video: 'Recording_MENA%20Tax%20All%20People%20Webcastmp4.mp4' },
  { id: 'webCastTwo', image: 'webcastTwo.png', date: '20-12-2022', presenter: 'Ahmed Al Esry', video: 'MENA%20Tax%20All%20People%20Webcast%2020th%20Dec%202022.mp4' },
  { id: 'webCast', image: 'webcast.jpg', date: '13-10-2022', presenter: 'Ahmed Al Esry', video: 'MENA%20Tax%20All%20People%20Webcast%2013th%20Oct.mp4' }
];

interface IWebcastProps {
  onShowHome: () => void;
}

const Webcast: React.FC<IWebcastProps> = ({ onShowHome }) => {
  const [loading, setLoading] = React.useState<boolean>(true);
  const [selectedWebcast, setSelectedWebcast] = React.useState<IWebcastItem | null>(null);

  React.useEffect(() => {
    window.scrollTo(0, 0);
    const timer = window.setTimeout(() => setLoading(false), 2000);
    return () => window.clearTimeout(timer);
  }, []);

  return (
    <div className="webcast-page">
      <style>{webcastStyles}</style>
      {loading && <div className="loading-container"><div className="item" /><div className="item" /><div className="item" /><div className="item" /></div>}
      <div className="container-wrapper">
        <div className="webPart">
          <div className="row nav-bar"><img className="EYlogo" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/EY_logo.png" alt="EY logo" /><p className="logoTxt">MENA Tax Hub</p><ul className="navbarMenu"><li><a data-interception="off" href="#" onClick={(event) => { event.preventDefault(); onShowHome(); }}><img className="home" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home.png" alt="Home" /></a></li></ul><img className="navToggle" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/toggle.png" alt="Toggle navigation" /></div>
          <div className="container-fluid"><div className="row"><div className="col-sm-12 bannerBackground"><div className="container-fluid cnt-fdr"><div className="row"><p className="cf6">MENA Tax all people webcast</p><div className="col-sm-4 c57" /></div></div></div></div></div>
          <div className="container-fluid tabContent"><div className="row">{webcastItems.map((item) => <div className="col-sm-3 cl-3" key={item.id} onClick={() => setSelectedWebcast(item)} onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') setSelectedWebcast(item); }} role="button" tabIndex={0}><div className="col-sm-bx"><div className="img-bx" style={{ backgroundImage: `url(${imageRoot}${item.image})` }} /><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/play.png" className="playIcon" alt="Play" /><p className="bx-link">MENA Tax All People Webcast</p><span className="date01">Date: {item.date}</span><p className="pName">{item.presenter}<br /><span>MENA Tax Leader</span></p></div></div>)}</div></div>
        </div>
        <div className="footer"><a data-interception="off" href="#ssl"><p>&#169; 2026 EYGM Limited. All rights reserved.</p></a></div>
      </div>
      {selectedWebcast && <div className="webcast-modal" role="dialog" aria-modal="true" aria-label="MENA Tax All People Webcast" onClick={() => setSelectedWebcast(null)}><div className="webcast-modal-content" onClick={(event) => event.stopPropagation()}><button type="button" className="close" onClick={() => setSelectedWebcast(null)} aria-label="Close">&times;</button><video src={`${videoRoot}${selectedWebcast.video}`} controls autoPlay title="MENA Tax All People Webcast" /></div></div>}
    </div>
  );
};

export default Webcast;