import * as React from 'react';

const myDocsStyles = `
html,
body {
    overflow-x: hidden !important;
    font-family: EYInterstate;
}

::-moz-selection {
    color: #ffffff;
    background: #27ACAA;
}

::selection {
    color: #ffffff;
    background: #27ACAA;
}

body::-webkit-scrollbar {
    display: none;
}

body {
    -ms-overflow-style: none;
    scrollbar-width: none;
    position: relative;
}

.bannerBackground {
    background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/banner.jpg);
    background-color: #2e2e38;
    background-size: 115% 115%;
    background-position: center center;
    position: relative;
    background-attachment: fixed;
    animation: shrink 20s infinite alternate;
    padding: 0px;
}

.cf6 {
    color: #ffffff;
    width: 100%;
    font-size: 1.5vw;
    padding: 1vw 1vw;
    margin-bottom: 0;
}

@keyframes shrink {
    0% {
        background-size: 115% 115%;
    }
    100% {
        background-size: 100% 100%;
    }
}

.nav-bar {
    position: relative;
    z-index: 999;
    background: #2e2e38;
    min-height: 6vw;
    width: 100%;
    margin: 0;
}

.nav-container {
    padding: 0px;
}

.EYlogo {
    width: 3vw;
    position: absolute;
    left: 5vw;
    top: 1.5vw;
}

p.logoTxt {
    color: #ffffff;
    font-size: 2vw;
    position: absolute;
    left: 11vw;
    top: 2.2vw;
}

img.home {
    width: 1.3vw;
}

ul.navbarMenu {
    position: absolute;
    right: 6vw;
    top: 2.4vw;
    font-family: EYInterstate;
}

ul.navbarMenu li {
    display: inline-block;
    font-size: 1vw;
    color: #ffffff;
}

ul.navbarMenu li a {
    color: #ffffff;
    text-decoration: none;
    padding: 0vw 2vw;
}

.cnt-fdr {
    padding: 2vw 5vw 2vw 5vw;
    background: rgba(46, 46, 56, .5);
    bottom: 0;
    width: 100%;
}

.footerTab {
    background: #1a1a24;
    padding: 5vw;
}

a.qLInk {
    color: #ffffff;
    font-family: EYInterstate;
    font-size: 1vw;
    font-weight: lighter;
    border: .1vw solid #9f9f9f;
    padding: 0.5vw 1.6vw;
    border-radius: .4vw;
    margin-right: .7vw;
    text-decoration: none;
    float: left;
    -webkit-transition: all .2s ease-in-out;
    -moz-transition: all .2s ease-in-out;
    -o-transition: all .2s ease-in-out;
    transition: all .2s ease-in-out;
    margin-bottom: .8vw;
}

a.qLInk:hover {
    background: rgba(255, 255, 255, .2)
}

.quicklinks {
    color: #ffffff;
    font-size: 2vw;
    margin-bottom: 2vw;
}

img.qklinks {
    width: 1.4vw;
    margin-top: -0.2vw;
    margin-right: .4vw;
}

p.hder {
    color: #ffffff;
    padding-left: 1vw;
    font-size: 1vw;
    line-height: 1.5vw;
    margin-bottom: 1vw;
}

.main-Content {
    background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);
    min-height: 30vw;
    background-attachment: fixed;
    background-position: center;
    background-color: #2e2e38;
    background-size: cover;
    padding: 4vw 8vw;
}

.box-header {
    color: #ffffff;
    font-size: 1.3vw;
    text-align: center;
    margin-bottom: -.4vw;
    padding-top: 3vw;
    font-family: EYInterstate;
}

.box-volume {
    color: #ffe600;
    font-family: EYInterstate;
    text-align: center;
    margin-bottom: 0;
    font-size: 1.4vw;
}

.box-volume span {
    font-size: 1.4vw;
}

.box-banner {
    background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bg_box.jpg);
    min-height: 8vw;
    background-size: cover;
    background-position: center;
}

.box-readmore {
    margin-top: 1.5vw;
    font-size: .9vw;
    color: #ffe600;
    text-align: right;
    margin-bottom: 0;
}

p.box-cnt {
    font-size: .9vw;
    line-height: 1.2vw;
    margin: 0;
}

.box-content {
    background: rgba(255, 255, 255, 0.129);
    min-height: 10vw;
    padding: 2vw 1.5vw;
    color: #ffffff;
}

.col-sm-3.col-3-sm {
    -ms-flex: 0 0 25%;
    flex: 0 0 20%;
    max-width: 20%;
}

.col-3-sm a {
    text-decoration: none;
}

.col-sm-3.col-3-sm {
    margin-bottom: 2vw;
}

.footer {
    background-color: #000000;
    float: left;
    width: 100%;
}

.footer p {
    margin-bottom: 0px;
    color: #ffffff;
    font-size: 1vw;
    padding: 1vw 2vw;
    text-align: right;
}

.navToggle {
    display: none;
}

@media only screen and (max-width: 1200px) {
    .cnt-fdr {
        position: static;
    }

    .cnt-fdr {
        padding: 35px 70px;
    }

    .quicklinks {
        font-size: 30px;
        margin-bottom: 25px;
    }

    a.qLInk {
        font-size: 15px;
        border: 1px solid #9f9f9f;
        padding: 7px 25px;
        border-radius: .4vw;
        margin-bottom: 10px;
        margin-right: 10px;
    }

    .footerTab {
        background: #1a1a24;
        padding: 60px;
    }

    .EYlogo {
        width: 40px;
        left: 60px;
        top: 20px;
    }

    p.logoTxt {
        font-size: 25px;
        left: 130px;
        top: 30px;
    }

    ul.navbarMenu {
        right: 50px;
        top: 25px;
    }

    ul.navbarMenu li {
        font-size: 15px;
    }

    ul.navbarMenu li a {
        padding: 0vw 20px;
    }

    img.home {
        width: 20px;
    }

    .nav-bar {
        min-height: 90px;
    }

    ul.navbarMenu {
        right: 50px;
        top: 31px;
    }

    .footer p {
        margin-bottom: 0px;
        color: #ffffff;
        font-size: 13px;
        padding: 15px 20px;
        text-align: right;
    }

    .cf6 {
        font-size: 30px;
        margin-bottom: 0;
    }

    p.hder {
        color: #ffffff;
        font-size: 16px;
        line-height: 23px;
        margin-bottom: 10px;
    }

    .main-Content {
        padding: 60px 70px;
    }

    .box-banner {
        min-height: 90px;
    }

    .box-header {
        font-size: 16px;
        margin-bottom: -5px;
        padding-top: 35px;
    }

    .box-content {
        min-height: 100px;
        padding: 20px 20px;
    }

    p.box-cnt {
        font-size: 12px;
        line-height: 15px;
    }

    .box-readmore {
        margin-top: 14px;
        font-size: 12px;
    }

    .col-sm-3.col-3-sm {
        -ms-flex: 0 0 30%;
        flex: 0 0 30%;
        max-width: 30%;
    }

    .box-volume span {
        font-size: 20px;
    }

    .col-sm-3.col-3-sm {
        margin-bottom: 20px;
    }
}

@media only screen and (max-width: 850px) {
    .col-sm-3.col-3-sm {
        -ms-flex: 0 0 50%;
        flex: 0 0 50%;
        max-width: 50%;
    }
}

@media only screen and (max-width: 800px) {
    .col-sm-4.c57 {
        -ms-flex: 0 0 100%;
        flex: 0 0 100%;
        max-width: 100%;
    }
}

@media only screen and (max-width: 750px) {
    .footerTab {
        float: left;
    }

    img.qklinks {
        display: none;
    }
}

@media only screen and (max-width: 575px) {
    ul.navbarMenu {
        top: 110px;
    }

    .col-sm-3.col-3-sm {
        -ms-flex: 0 0 100%;
        flex: 0 0 100%;
        max-width: 100%;
        margin-bottom: 20px;
    }

    p.box-cnt {
        font-size: 17px;
        line-height: 21px;
    }
}

@media only screen and (max-width: 400px) {
    .main-Content {
        padding: 50px 40px;
    }
}
`;

interface IMyDocsMinutesProps {
  onShowHome: () => void;
}

type JQueryApi = (selector: string | Document) => {
  ready: (callback: () => void) => void;
  scrollTop: (value: number) => void;
  click: (callback: () => void) => void;
  animate: (properties: { scrollTop: number | undefined }, duration: number) => void;
  offset: () => { top: number };
};

const MyDocsMinutes: React.FC<IMyDocsMinutesProps> = ({ onShowHome }) => {
  React.useEffect(() => {
    const $ = (window as unknown as { jQuery?: JQueryApi }).jQuery;
    if (!$) {
      return;
    }

    $(document).ready(function () {
      $(document).scrollTop(0);

      $('.nav-item').click(function () {
        $('html, body').animate({
          scrollTop: $('.tabCol').offset().top
        }, 1000);
      });
    });
  }, []);

  return (
    <>
      <style>{myDocsStyles}</style>

      <div>
        <div className="webPart">
          <div className="container-fluid nav-container">
            <div className="row nav-bar">
              <img className="EYlogo" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/EY_logo.png" alt="EY logo" />
              <p className="logoTxt">MENA Tax Hub</p>
              <ul className="navbarMenu">
                <li>
                  <a data-interception="off" href="#" onClick={(event) => { event.preventDefault(); onShowHome(); }}>
                    <img className="home" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home.png" alt="Home" />
                  </a>
                  <span>|</span>
                </li>
                <li hidden>
                  <a data-interception="off" href="#quality">Tax Quality</a>
                </li>
              </ul>
              <img className="navToggle" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/toggle.png" alt="Toggle" />
            </div>
          </div>

          <div className="container-fluid">
            <div className="row">
              <div className="col-sm-12 bannerBackground">
                <div className="container-fluid cnt-fdr">
                  <div className="row">
                    <p className="cf6">MyDocs Minutes</p>
                    <p className="hder">Increase your EYI MyDocs knowledge in minutes</p>
                    <div className="col-sm-4 c57" />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="main-Content">
            <div className="row">
              <div className="col-sm-3 col-3-sm">
                <a data-interception="off" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/MyDocs%20Minutes_01.pdf" target="_blank" rel="noreferrer">
                  <div className="col-sm-3-box">
                    <div className="box-banner">
                      <p className="box-header">MyDocs Minutes</p>
                      <p className="box-volume">Vol - <span>01</span></p>
                    </div>
                    <div className="box-content">
                      <p className="box-cnt">Closing an Engagement Workspace and Library - why, when and how</p>
                      <p className="box-readmore">READ MORE</p>
                    </div>
                  </div>
                </a>
              </div>

              <div className="col-sm-3 col-3-sm">
                <a data-interception="off" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/MyDocs%20Minutes_02.pdf" target="_blank" rel="noreferrer">
                  <div className="col-sm-3-box">
                    <div className="box-banner">
                      <p className="box-header">MyDocs Minutes</p>
                      <p className="box-volume">Vol - <span>02</span></p>
                    </div>
                    <div className="box-content">
                      <p className="box-cnt">Take care when removing synced libraries from Windows File Explorer</p>
                      <p className="box-readmore">READ MORE</p>
                    </div>
                  </div>
                </a>
              </div>

              <div className="col-sm-3 col-3-sm">
                <a data-interception="off" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/MyDocs%20Minutes_03.pdf" target="_blank" rel="noreferrer">
                  <div className="col-sm-3-box">
                    <div className="box-banner">
                      <p className="box-header">MyDocs Minutes</p>
                      <p className="box-volume">Vol - <span>03</span></p>
                    </div>
                    <div className="box-content">
                      <p className="box-cnt">Deleting Workspaces - steps for workspace owners/administrators</p>
                      <p className="box-readmore">READ MORE</p>
                    </div>
                  </div>
                </a>
              </div>

              <div className="col-sm-3 col-3-sm">
                <a data-interception="off" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/MyDocs%20Minutes04.pdf" target="_blank" rel="noreferrer">
                  <div className="col-sm-3-box">
                    <div className="box-banner">
                      <p className="box-header">MyDocs Minutes</p>
                      <p className="box-volume">Vol - <span>04</span></p>
                    </div>
                    <div className="box-content">
                      <p className="box-cnt">Increase your EYI MyDocs knowledge in minutes</p>
                      <p className="box-readmore">READ MORE</p>
                    </div>
                  </div>
                </a>
              </div>

              <div className="col-sm-3 col-3-sm">
                <a data-interception="off" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/Timely%20filing.pdf" target="_blank" rel="noreferrer">
                  <div className="col-sm-3-box">
                    <div className="box-banner" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/timely.png)' }}>
                      <p className="box-header">MyDocs Minutes</p>
                      <p className="box-volume">Vol - <span>05</span></p>
                    </div>
                    <div className="box-content">
                      <p className="box-cnt">Timely filing - Save directly to your workspaces</p>
                      <p className="box-readmore">READ MORE</p>
                    </div>
                  </div>
                </a>
              </div>

              <div className="col-sm-3 col-3-sm">
                <a data-interception="off" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/MyDocs_06.pdf" target="_blank" rel="noreferrer">
                  <div className="col-sm-3-box">
                    <div className="box-banner" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/timely.png)' }}>
                      <p className="box-header">MyDocs Minutes</p>
                      <p className="box-volume">Vol - <span>06</span></p>
                    </div>
                    <div className="box-content">
                      <p className="box-cnt">Quickly update document tags (metadata)</p>
                      <p className="box-readmore">READ MORE</p>
                    </div>
                  </div>
                </a>
              </div>

              <div className="col-sm-3 col-3-sm">
                <a data-interception="off" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/MyDocs_07.pdf" target="_blank" rel="noreferrer">
                  <div className="col-sm-3-box">
                    <div className="box-banner" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/timely.png)' }}>
                      <p className="box-header">MyDocs Minutes</p>
                      <p className="box-volume">Vol - <span>07</span></p>
                    </div>
                    <div className="box-content">
                      <p className="box-cnt">Assistance with bulk access management</p>
                      <p className="box-readmore">READ MORE</p>
                    </div>
                  </div>
                </a>
              </div>

              <div className="col-sm-3 col-3-sm">
                <a data-interception="off" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/MyDocs_08.pdf" target="_blank" rel="noreferrer">
                  <div className="col-sm-3-box">
                    <div className="box-banner" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/timely.png)' }}>
                      <p className="box-header">MyDocs Minutes</p>
                      <p className="box-volume">Vol - <span>08</span></p>
                    </div>
                    <div className="box-content">
                      <p className="box-cnt">Why and how to create additional libraries</p>
                      <p className="box-readmore">READ MORE</p>
                    </div>
                  </div>
                </a>
              </div>
            </div>
          </div>

          <div className="container-fluid footerTab" hidden>
            <div className="row">
              <div className="col-sm-12">
                <p className="quicklinks">Quick links</p>
                <a data-interception="off" href="https://sites.ey.com/sites/EYMENA/SiteAssets/PDF/MENA%20TE%20Policy/ME%20TE%20Policy.pdf" target="_blank" className="qLInk" rel="noreferrer">
                  <img className="qklinks" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png" alt="MENA Expense Policy" />MENA Expense Policy
                </a>
                <a data-interception="off" href="https://sites.ey.com/sites/menapeopleconnect/SitePages/TotalReward.aspx" target="_blank" className="qLInk" rel="noreferrer">
                  <img className="qklinks" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png" alt="MENA Total Reward" />MENA Total Reward
                </a>
                <a data-interception="off" href="https://sites.ey.com/sites/menapeopleconnect/SitePages/Policies%20and%20Procedures.aspx" target="_blank" className="qLInk" rel="noreferrer">
                  <img className="qklinks" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png" alt="MENA Talent Policies" />MENA Talent Policies & Procedures
                </a>
                <a data-interception="off" href="https://lms.ey.net/" target="_blank" className="qLInk" rel="noreferrer">
                  <img className="qklinks" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png" alt="LMS" />LMS
                </a>
                <a data-interception="off" href="https://sort.ey.net/" target="_blank" className="qLInk" rel="noreferrer">
                  <img className="qklinks" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png" alt="SORT" />SORT
                </a>
                <a data-interception="off" href="https://sf.ey.net" target="_blank" className="qLInk" rel="noreferrer">
                  <img className="qklinks" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png" alt="SuccessFactors" />SuccessFactors
                </a>
                <a data-interception="off" href="https://intranet.ey.com/sites/career-development/SitePageModern/342011/career-development" target="_blank" className="qLInk" rel="noreferrer">
                  <img className="qklinks" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png" alt="Career & development" />Career & development
                </a>
                <a data-interception="off" href="https://sites.ey.com/sites/menapeopleconnect/SitePages/Onboarding.aspx" target="_blank" className="qLInk" rel="noreferrer">
                  <img className="qklinks" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png" alt="New starters" />New starters (first 90 days)
                </a>
              </div>
            </div>
          </div>

          <div className="footer">
            <p>&#169; 2026 EYGM Limited. All rights reserved.</p>
          </div>
        </div>
      </div>

    </>
  );
};

export default MyDocsMinutes;
