import * as React from 'react';
import styles from './MenaTaxHub.module.scss';
import type { IMenaTaxHubProps } from './IMenaTaxHubProps';
import Homepage from './Homepage';
import SSL from './SSL';
import CST from './CST';
import MenaTaxQuality from './MenaTaxQuality';
import MenaTaxLeadership from './MenaTaxLeadership';
import MyDocsMinutes from './MyDocsMinutes';
import EYIDocumentation from './EYIDocumentation';
import MenaTaxQualityFAQs from './MenaTaxQualityFAQs';
import MenaTaxResourcingHub from './MenaTaxResourcingHub';
import OnshoreResourcing from './OnshoreResourcing';
import NonGccResourcing from './NonGccResourcing';
import GDS from './GDS';
import MenaTaxTalent from './MenaTaxTalent';
import Webcast from './Webcast';
import Communications from './Communications';
import MenaTaxMarkets from './MenaTaxMarkets';
import EngagementLifecycleManagement from './EngagementLifecycleManagement';
import PoliciesAndProcedures from './PoliciesAndProcedures';
import MyTraining from './MyTraining';
import TrainingPackAndDocuments from './TrainingPackAndDocuments';
import TrainingRecordedSession from './TrainingRecordedSession';
import VirtualClinicsTrainingSessions from './VirtualClinicsTrainingSessions';

declare global {
  interface Window {
    loadMenaTaxPage?: (pageName: string) => void;
  }
}

const BOOTSTRAP_CSS_ID = 'mena-tax-hub-bootstrap-css';
const JQUERY_SCRIPT_ID = 'mena-tax-hub-jquery';
const BOOTSTRAP_SCRIPT_ID = 'mena-tax-hub-bootstrap-js';

const ASSET_URLS = {
  css: 'https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css',
  jquery: 'https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js',
  bootstrap: 'https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js'
};

let globalAssetUsers = 0;

const createElement = (
  tagName: 'link' | 'script',
  attrs: Record<string, string>,
  container: HTMLElement
): HTMLElement => {
  const existing = document.getElementById(attrs.id || '');
  if (existing) return existing;

  const element = document.createElement(tagName);
  for (const key in attrs) {
    if (Object.prototype.hasOwnProperty.call(attrs, key)) {
      element.setAttribute(key, attrs[key]);
    }
  }

  container.appendChild(element);
  return element;
};

const createScript = (id: string, src: string): HTMLScriptElement => {
  const existing = document.getElementById(id) as HTMLScriptElement | null;
  if (existing) return existing;

  const script = document.createElement('script');
  script.id = id;
  script.src = src;
  script.async = false;
  document.body.appendChild(script);
  return script;
};

const addGlobalAssets = (): void => {
  createElement('link', { id: BOOTSTRAP_CSS_ID, rel: 'stylesheet', href: ASSET_URLS.css }, document.head);

  const loadBootstrap = (): void => {
    if (!document.getElementById(BOOTSTRAP_SCRIPT_ID)) {
      createScript(BOOTSTRAP_SCRIPT_ID, ASSET_URLS.bootstrap);
    }
  };

  const jqueryScript = createScript(JQUERY_SCRIPT_ID, ASSET_URLS.jquery);
  const isJQueryReady = typeof (window as Window & { jQuery?: unknown }).jQuery !== 'undefined';

  if (isJQueryReady) {
    loadBootstrap();
  } else {
    jqueryScript.onload = loadBootstrap;
  }
};

const removeGlobalAssets = (): void => {
  [BOOTSTRAP_CSS_ID, JQUERY_SCRIPT_ID, BOOTSTRAP_SCRIPT_ID].forEach((assetId: string) => {
    const element = document.getElementById(assetId);
    if (element?.parentNode) {
      element.parentNode.removeChild(element);
    }
  });
};

interface IMenaTaxHubState {
  activeView: 'home' | 'ssl' | 'cst' | 'quality' | 'leadership' | 'mydocs' | 'eyi' | 'faqs' | 'resourcing' | 'onshore' | 'nongcc' | 'gds' | 'talent' | 'webcast' | 'communications' | 'markets' | 'engagement' | 'policies' | 'training' | 'training-pack' | 'training-recorded' | 'virtual-clinics';
  menuOpen: boolean;
  routeLoading: boolean;
}

type MenaTaxView = IMenaTaxHubState['activeView'];

const viewNames: MenaTaxView[] = [
  'home',
  'ssl',
  'cst',
  'quality',
  'leadership',
  'mydocs',
  'eyi',
  'faqs',
  'resourcing',
  'onshore',
  'nongcc',
  'gds',
  'talent',
  'webcast',
  'communications',
  'markets',
  'engagement',
  'policies',
  'training',
  'training-pack',
  'training-recorded',
  'virtual-clinics'
];

const getViewFromHash = (): MenaTaxView => {
  const hashView = decodeURIComponent(window.location.hash.slice(1)).toLowerCase() as MenaTaxView;
  return viewNames.indexOf(hashView) >= 0 ? hashView : 'home';
};

const menuItems: Array<{ label: string; view?: MenaTaxView; href?: string }> = [
  { label: 'Home', view: 'home' },
  { label: 'MENA Tax SSLs', view: 'ssl' },
  { label: 'Engagement Lifecycle Management', view: 'engagement' },
  { label: 'Central Support Team', view: 'cst' },
  { label: 'MENA Tax Quality', view: 'quality' },
  { label: 'MENA Tax Leadership', view: 'leadership' },
  { label: 'MENA Tax Resourcing Hub', view: 'resourcing' },
  { label: 'MENA Tax Talent', view: 'talent' },
  { label: 'MENA Tax Markets', view: 'markets' },
  { label: 'MENA Tax Learning', href: 'https://sites.ey.com/sites/MENALearningPortal/TaxLearning/SitePages/Homepage.aspx' }

  // { label: 'MENA Tax Quality FAQs', view: 'faqs' },

  // { label: 'MyDocs Minutes', view: 'mydocs' },
  // { label: 'EYI Documentation', view: 'eyi' },

  // { label: 'Onshore Resourcing', view: 'onshore' },
  // { label: 'Non-GCC Resourcing', view: 'nongcc' },
  // { label: 'GDS', view: 'gds' },

  // { label: 'MENA Tax All People Webcast', view: 'webcast' },
  // { label: 'Archived Communications', view: 'communications' },

 
  // { label: 'Policies and procedures', view: 'policies' },
  // { label: 'My Training', view: 'training' },
  // { label: 'Training pack and documents', view: 'training-pack' },
  // { label: 'Training recorded session', view: 'training-recorded' },
  // { label: 'Virtual clinics training sessions', view: 'virtual-clinics' },

];

export default class MenaTaxHub extends React.Component<IMenaTaxHubProps, IMenaTaxHubState> {
  public state: IMenaTaxHubState = {
    activeView: getViewFromHash(),
    menuOpen: false,
    routeLoading: false
  };

  private routeLoadingTimer?: number;
  private skipRouteLoading = false;

  private scrollToTop = (): void => {
    window.scrollTo(0, 0);
    const hubElement = document.querySelector<HTMLElement>(`.${styles.menaTaxHub}`);
    if (hubElement) {
      hubElement.scrollTop = 0;
      hubElement.scrollTo(0, 0);
    }
  };

  private handleHashChange = (): void => {
    const activeView = getViewFromHash();
    if (activeView !== this.state.activeView) {
      this.skipRouteLoading = true;
      this.setState({ activeView, menuOpen: false, routeLoading: false });
    }
  };

  public componentDidMount(): void {
    this.scrollToTop();
    globalAssetUsers += 1;
    if (globalAssetUsers === 1) {
      addGlobalAssets();
    }
    window.addEventListener('hashchange', this.handleHashChange);
    window.loadMenaTaxPage = (pageName: string): void => {
      const nextView = pageName.trim().toLowerCase() as MenaTaxView;
      if (viewNames.indexOf(nextView) >= 0) {
        window.location.hash = nextView === 'home' ? '' : nextView;
      }
    };
    this.handleHashChange();
  }

  public componentWillUnmount(): void {
    if (this.routeLoadingTimer) {
      window.clearTimeout(this.routeLoadingTimer);
    }
    window.removeEventListener('hashchange', this.handleHashChange);
    delete window.loadMenaTaxPage;
    globalAssetUsers -= 1;
    if (globalAssetUsers <= 0) {
      removeGlobalAssets();
      globalAssetUsers = 0;
    }
  }

  public componentDidUpdate(_previousProps: IMenaTaxHubProps, previousState: IMenaTaxHubState): void {
    if (previousState.activeView !== this.state.activeView) {
      this.scrollToTop();
      const nextHash = this.state.activeView === 'home' ? '' : `#${this.state.activeView}`;
      if (window.location.hash !== nextHash) {
        window.history.replaceState(null, '', `${window.location.pathname}${window.location.search}${nextHash}`);
      }
    }
    if (this.skipRouteLoading) {
      this.skipRouteLoading = false;
      return;
    }
    if (previousState.activeView !== this.state.activeView && !this.state.routeLoading && this.state.activeView !== 'home') {
      this.setState({ routeLoading: true });
      this.routeLoadingTimer = window.setTimeout(() => this.setState({ routeLoading: false }), 2000);
    }
  }

  private showSSL = (): void => {
    this.setState({ activeView: 'ssl' });
  };

  private showCST = (): void => {
    this.setState({ activeView: 'cst' });
  };

  private showQuality = (): void => {
    this.setState({ activeView: 'quality' });
  };

  private showLeadership = (): void => {
    this.setState({ activeView: 'leadership' });
  };

  private showMyDocs = (): void => {
    this.setState({ activeView: 'mydocs' });
  };

  private showEYI = (): void => {
    this.setState({ activeView: 'eyi' });
  };

  private showFAQs = (): void => {
    this.setState({ activeView: 'faqs' });
  };

  private showResourcing = (): void => {
    this.setState({ activeView: 'resourcing' });
  };

  private showOnshore = (): void => {
    this.setState({ activeView: 'onshore' });
  };

  private showNonGcc = (): void => {
    this.setState({ activeView: 'nongcc' });
  };

  private showGDS = (): void => {
    this.setState({ activeView: 'gds' });
  };

  private showTalent = (): void => {
    this.setState({ activeView: 'talent' });
  };

  private showWebcast = (): void => {
    this.setState({ activeView: 'webcast' });
  };

  private showCommunications = (): void => {
    this.setState({ activeView: 'communications' });
  };

  private showMarkets = (): void => {
    this.setState({ activeView: 'markets' });
  };

  private showEngagement = (): void => {
    this.setState({ activeView: 'engagement' });
  };

  private showPolicies = (): void => {
    this.setState({ activeView: 'policies' });
  };

  private showTraining = (): void => {
    this.setState({ activeView: 'training' });
  };

  private showTrainingPack = (): void => {
    this.setState({ activeView: 'training-pack' });
  };

  private showRecordedSession = (): void => {
    this.setState({ activeView: 'training-recorded' });
  };

  private showVirtualClinics = (): void => {
    this.setState({ activeView: 'virtual-clinics' });
  };

  private showHome = (): void => {
    this.setState({ activeView: 'home' });
  };

  private toggleMenu = (): void => {
    this.setState((currentState) => ({ menuOpen: !currentState.menuOpen }));
  };

  private openExternalLink = (event: React.MouseEvent<HTMLElement>): void => {
    if (event.defaultPrevented || !(event.target instanceof Element)) {
      return;
    }

    const link = event.target.closest('a');
    const href = link?.getAttribute('href');
    if (!link || !href || href.charAt(0) === '#') {
      return;
    }

    const url = new URL(href, window.location.href);
    if (url.protocol !== 'http:' && url.protocol !== 'https:') {
      return;
    }

    event.preventDefault();
    window.open(url.href, '_blank', 'noopener,noreferrer');
  };

  private navigateFromMenu = (view: MenaTaxView): void => {
    this.setState({ activeView: view, menuOpen: false, routeLoading: view !== 'home' });
    this.routeLoadingTimer = window.setTimeout(() => this.setState({ routeLoading: false }), 2000);
  };

  public render(): React.ReactElement<IMenaTaxHubProps> {
    const { hasTeamsContext } = this.props;
    const { activeView, menuOpen, routeLoading } = this.state;

    return (
      <section
        className={`${styles.menaTaxHub} ${hasTeamsContext ? styles.teams : ''}`}
        onClick={this.openExternalLink}
      >
        {activeView !== 'home' && (
          <>
            <button
              type="button"
              className={styles.menuButton}
              onClick={this.toggleMenu}
              aria-label={menuOpen ? 'Close navigation menu' : 'Open navigation menu'}
              aria-expanded={menuOpen}
              aria-controls="mena-tax-hub-navigation"
            >
              <img src="https://sites.ey.com/sites/MENA_Tax/SiteAssets/MENATax/images/toggle.png" alt="" />
            </button>
            <div className={`${styles.menuOverlay} ${menuOpen ? styles.menuOverlayOpen : ''}`} onClick={this.toggleMenu} aria-hidden="true" />
            <nav
              id="mena-tax-hub-navigation"
              className={`${styles.menuPanel} ${menuOpen ? styles.menuPanelOpen : ''}`}
              aria-label="MENA Tax Hub navigation"
            >
              <div className={styles.menuHeader}>
                <span>Menu</span>
                <button type="button" className={styles.menuClose} onClick={this.toggleMenu} aria-label="Close navigation menu">&times;</button>
              </div>
              <ul>
                {menuItems.map((item) => (
                  <li key={item.view || item.href}>
                    {item.href ? (
                      <a data-interception="off" className={styles.menuLink} href={item.href} target="_blank" rel="noreferrer">
                        {item.label}
                      </a>
                    ) : (
                      <button
                        type="button"
                        className={item.view === activeView ? styles.menuItemActive : ''}
                        onClick={() => this.navigateFromMenu(item.view as MenaTaxView)}
                      >
                        {item.label}
                      </button>
                    )}
                  </li>
                ))}
              </ul>
            </nav>
          </>
        )}
        {routeLoading && (
          <div className={styles.routeLoading} role="status" aria-label="Loading">
            <div className={styles.loadingRing} />
            <div className={styles.loadingRing} />
            <div className={styles.loadingRing} />
            <div className={styles.loadingRing} />
          </div>
        )}
        {activeView === 'home' ? (
          <Homepage onShowSSL={this.showSSL} onShowCST={this.showCST} onShowQuality={this.showQuality} onShowFAQs={this.showFAQs} onShowLeadership={this.showLeadership} onShowMyDocs={this.showMyDocs} onShowEYI={this.showEYI} onShowResourcing={this.showResourcing} onShowOnshore={this.showOnshore} onShowNonGcc={this.showNonGcc} onShowGDS={this.showGDS} onShowTalent={this.showTalent} onShowWebcast={this.showWebcast} onShowCommunications={this.showCommunications} onShowMarkets={this.showMarkets} onShowEngagement={this.showEngagement} onShowPolicies={this.showPolicies} userDisplayName={this.props.userDisplayName} userEmail={this.props.userEmail} />
        ) : activeView === 'ssl' ? (
          <>
            <SSL onShowHome={this.showHome} />
          </>
        ) : activeView === 'cst' ? (
          <CST onShowHome={this.showHome} />
        ) : activeView === 'quality' ? (
          <MenaTaxQuality onShowHome={this.showHome} onShowFAQs={this.showFAQs} />
        ) : activeView === 'leadership' ? (
          <MenaTaxLeadership onShowHome={this.showHome} />
        ) : activeView === 'mydocs' ? (
          <MyDocsMinutes onShowHome={this.showHome} />
        ) : activeView === 'faqs' ? (
          <MenaTaxQualityFAQs onShowHome={this.showHome} />
        ) : activeView === 'resourcing' ? (
          <MenaTaxResourcingHub onShowHome={this.showHome} onShowOnshore={this.showOnshore} onShowNonGcc={this.showNonGcc} />
        ) : activeView === 'onshore' ? (
          <OnshoreResourcing onShowResourcing={this.showResourcing} onShowHome={this.showHome} />
        ) : activeView === 'nongcc' ? (
          <NonGccResourcing onShowResourcing={this.showResourcing} onShowHome={this.showHome} />
        ) : activeView === 'gds' ? (
          <GDS onShowHome={this.showHome} />
        ) : activeView === 'talent' ? (
          <MenaTaxTalent onShowHome={this.showHome} />
        ) : activeView === 'webcast' ? (
          <Webcast onShowHome={this.showHome} />
        ) : activeView === 'communications' ? (
          <Communications onShowHome={this.showHome} />
        ) : activeView === 'markets' ? (
          <MenaTaxMarkets onShowHome={this.showHome} />
        ) : activeView === 'engagement' ? (
          <EngagementLifecycleManagement onShowHome={this.showHome} onShowPolicies={this.showPolicies} onShowTraining={this.showTraining} />
        ) : activeView === 'policies' ? (
          <PoliciesAndProcedures onShowHome={this.showHome} />
        ) : activeView === 'training' ? (
          <MyTraining onShowHome={this.showHome} onShowTrainingPack={this.showTrainingPack} onShowRecordedSession={this.showRecordedSession} onShowVirtualClinics={this.showVirtualClinics} />
        ) : activeView === 'training-pack' ? (
          <TrainingPackAndDocuments onShowHome={this.showHome} />
        ) : activeView === 'training-recorded' ? (
          <TrainingRecordedSession onShowHome={this.showHome} />
        ) : activeView === 'virtual-clinics' ? (
          <VirtualClinicsTrainingSessions onShowHome={this.showHome} />
        ) : (
          <EYIDocumentation onShowHome={this.showHome} />
        )}
      </section>
    );
  }
}
