import * as React from 'react';

const gdsStyles = `
  html,
  body {
      overflow-x: hidden !important;
      font-family: EYInterstate;
  }

  .container_wrapper {
      display: none;
  }

  ::-moz-selection {
      color: #ffffff;
      background: #27ACAA;
  }

  ::selection {
      color: #ffffff;
      background: #27ACAA;
  }

  body::-webkit-scrollbar {
      display: none;
  }

  .loading-container {
      position: relative;
      position: fixed;
      z-index: 9999;
      background: #1a1a24;
      width: 100%;
      height: 100vh;
      margin: auto;
  }

  .loading-container .item {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      border: .2vw solid #ffe600;
      border-radius: 50%;
      border-top-color: transparent;
      border-bottom-color: transparent;
      animation: spin 2s ease infinite;
  }

  .loading-container .item:nth-child(1) {
      width: 30px;
      height: 30px;
  }

  .loading-container .item:nth-child(2) {
      width: 50px;
      height: 50px;
      animation-delay: 0.1s;
  }

  .loading-container .item:nth-child(3) {
      width: 70px;
      height: 70px;
      animation-delay: 0.2s;
  }

  .loading-container .item:nth-child(4) {
      width: 90px;
      height: 90px;
      animation-delay: 0.3s;
  }

  @keyframes spin {
      50% {
          transform: translate(-50%, -50%) rotate(180deg);
      }
      100% {
          transform: translate(-50%, -50%) rotate(0deg);
      }
  }

  body {
      -ms-overflow-style: none;
      scrollbar-width: none;
      position: relative;
  }

  .bannerBackground {
      background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Offshore-GDS.png);
      background-color: #2e2e38;
      background-size: cover !important;
      background-position: center;
      position: relative;
      background-attachment: unset !important;
      animation: none !important;
      padding: 0px;
  }

  .cnt-fdr {
      min-height: 17vw;
  }

  .tabCol {
      padding: 2vw 2vw 1vw 6vw;
  }

  span.s1-cg {
      font-size: 1.4vw;
      color: #ffffff;
      display: block;
      width: 100%;
      padding: 1vw 0vw 0.6vw 0vw;
      margin-top: 2vw;
      margin-bottom: 0.5vw;
      border: hidden;
      line-height: 1.9vw;
  }

  .vid-parent {
      padding-right: 0px;
  }

  hr.hr {
      margin-top: 0vw;
      margin-bottom: 0vw;
      border: 0;
      border-top: .11vw solid #ffe600;
      width: 3vw;
      display: block;
  }

  hr.hr1 {
      margin-left: .1vw;
  }

  .tab-left {
      background-color: #2e2e38;
      background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/gettyimages-607638780-1024x102.png);
      background-position: center;
      background-size: cover;
      overflow: hidden;
      position: relative;
      padding: 0px;
  }

  .left-1 {
      position: absolute;
      right: -1vw;
      top: -2vw;
      width: 22vw;
      transform: rotate(90deg);
  }

  .left-2 {
      position: absolute;
      left: -1vw;
      bottom: -2vw;
      width: 22vw;
      transform: rotate(0deg);
  }

  .quicklink-Head {
      color: #ffffff;
      font-size: 2vw;
      font-family: arial;
  }

  .quicklink-Head img {
      width: 2.5vw;
      margin-right: 0.4vw;
  }

  ul.ul-links {
      list-style: none;
      padding-left: 0;
      color: #ffffff;
      font-size: 1.2vw;
      font-family: arial;
  }

  ul.ul-links li {
      width: 50%;
      float: left;
      margin: 0;
      padding: .5vw .5vw;
  }

  ul.ul-links li a {
      color: #ffffff !important;
      text-decoration: none !important;
  }

  ul.ul-links li span {
      background: #ffffff17;
      padding: 2vw 4vw;
      height: 9vw;
      text-align: center;
      font-size: 1vw;
      line-height: 1.2vw;
      display: block;
      transition: all .6s ease-in-out;
  }

  ul.ul-links li span img {
      width: 2.3vw;
      display: block;
      position: relative;
      left: 50%;
      transform: translate(-50%, -20%);
      margin-bottom: 0.2vw;
      transition: all .6s ease-in-out;
  }

  .box-quicklinks {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      width: 85%;
  }

  ul.ul-links li:hover span img {
      transform: translate(-50%, -20%) rotateY(180deg);
  }

  ul.ul-links li:hover span {
      background: #ffffff47;
  }

  .col-06 {
      background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/GettyImages-1460853312-1.png);
      background-position: center;
      background-size: cover;
      background-color: #2e2e38;
  }

  span.s1-cf {
      font-size: 1.4vw;
      color: #ffffff;
      display: block;
      width: 100%;
      padding: 0vw 0vw;
      margin-top: 2vw;
      margin-bottom: 0.7vw;
      border: hidden;
  }

  .s1-cf-1 {
      text-align: center;
      font-size: 2vw !important;
      margin-bottom: 0vw !important;
      font-family: arial;
  }

  .tab-col {
      padding: 1vw 2vw 0vw 6vw;
  }

  .tmp3 {
      color: #ffffff;
      font-size: .8vw;
      text-align: center;
      width: 100%;
      padding: 0vw 10% 1vw 10%;
  }

  .TmBox {
      height: 15vw;
  }

  .col-sm-12.sm-tm-5 {
      margin-top: 0px;
  }

  .cf6 {
      color: #ffffff;
      width: 100%;
      font-size: 2vw;
      padding: 0;
      margin-bottom: 0;
      float: left;
      border-bottom: hidden;
      padding-bottom: 3px;
      margin-left: 1vw;
      width: 100%;
      margin-bottom: 0.3vw;
      margin-top: 5vw;
  }

  hr.hrt {
      margin-top: 0vw;
      margin-bottom: 0vw;
      border: 0;
      border-top: .2vw solid #ffe600;
      width: 3vw;
      display: block;
      margin-left: 1.2vw;
  }

  .accordion {
      color: #ffffff;
      width: 100%;
  }

  .accordion .card {
      border: none;
      margin-bottom: 0px;
      background: transparent;
  }

  .accordion .card h2 {
      background-size: 1.5vw;
      cursor: pointer;
      font-size: 1.3vw;
      margin-bottom: .6vw !important;
      background-position: 95% 0.3vw;
      color: #ffe600;
  }

  .accordion .card-body {
      padding-left: 0;
      padding-right: 0;
  }

  .CollapsibleText {
      font-size: 1vw;
      font-family: arial;
      line-height: 1.5vw;
      color: #ffffff;
  }

  .tc-col {
      background: #00000017;
      min-height: auto;
      border-bottom: .1vw solid #363636;
  }

  li strong {
      color: #ffe600;
  }

  ul.cf-u li {
      margin-bottom: .6vw !important
  }

  ul.cf-u1 li {
      margin-top: 1.1vw !important;
  }

  .tabCol ul.ul_01 {
      padding-left: 2vw;
  }

  col:nth-child(odd) {
      background: #ffffff12;
  }

  col:nth-child(even) {
      background: #ffffff2b;
  }

  td {
      height: 80px;
      padding: 2vw 1vw;
  }

  table {
      color: #ffffff;
      font-size: .9vw;
      text-align: center;
      line-height: 1.1vw;
      margin-left: 2.5%;
      width: 95%;
      border: .1vw solid #ffffff24;
      margin-top: 1vw;
      margin-top: 3.5vw;
      position: relative;
      overflow: hidden;
  }

  tr.rowOne {
      border-bottom: .1vw solid #ffffff1c;
  }

  td {
      border-right: .1vw solid #ffffff1c;
  }

  tr.rowOne td {
      padding: 1vw 1vw;
  }

  td {
      padding: 1vw 1vw;
      position: relative;
      overflow: visible;
  }

  td::after {
      background: rgba(255, 255, 255, 0) !important;
      content: "";
      height: 500%;
      left: 0;
      position: absolute;
      top: -200%;
      width: 100%;
      z-index: 1;
      transition: all .6s ease-in-out;
  }

  td:hover::after {
      background: rgb(255 255 255 / 32%) !important;
      content: "";
      height: 500%;
      left: 0;
      position: absolute;
      top: -200%;
      width: 100%;
      z-index: 1;
  }

  li i {
      color: #ffe600;
      font-size: .9vw;
  }

  iframe.vg-1 {
      width: 100%;
      height: 30vw;
  }

  .cv-g {
      padding: 3vw 7vw;
  }

  .ft-g {
      color: #ffffff;
      font-size: 1.3vw;
      text-align: center;
      margin-bottom: 2vw;
  }

  .ft-g span {
      font-size: 1vw;
      color: #ffe600;
  }

  ul.navbarMenu li {
      font-size: .9vw;
  }

  ul.navbarMenu li img {
      width: 1vw;
      margin-right: .5vw;
  }

  ul.navbarMenu li a {
      padding: 0vw .5vw;
  }

  strong.strong {
      font-size: 1vw;
      display: block;
      line-height: 1vw;
      margin-bottom: -1.5vw;
      font-weight: 100 !important;
  }

  .EYlogo {
      width: 3vw;
      position: absolute;
      left: 5vw;
      top: 1.5vw;
  }

  p.logoTxt {
      color: #ffffff;
      font-size: 2vw;
      position: absolute;
      left: 11vw;
      top: 2.2vw;
  }

  img.home {
      width: 1.3vw;
  }

  ul.navbarMenu {
      position: absolute;
      right: 6vw;
      top: 2.4vw;
      font-family: EYInterstate;
  }

  ul.navbarMenu li {
      display: inline-block;
      font-size: 1vw;
      color: #ffffff;
  }

  ul.navbarMenu li a {
      color: #ffffff;
      text-decoration: none;
      padding: 0vw 2vw;
  }

  .nav-bar {
      position: relative;
      z-index: 999;
      background: #2e2e38;
      min-height: 6vw;
      width: 100%;
      margin: 0;
  }

  .nav-container {
      padding: 0px;
  }

  .footer {
      background-color: #000000;
      float: left;
      width: 100%;
  }

  .footer p {
      margin-bottom: 0px;
      color: #ffffff;
      font-size: 1vw;
      padding: 1vw 2vw;
      text-align: right;
  }

  .container-fluid {
      max-width: 100%;
  }

  .webPart {
      background: #2e2e38;
      color: #ffffff;
  }

  .tabContent {
      background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);
      background-position: center;
      background-size: cover;
      background-attachment: fixed;
      background-color: #2e2e38;
  }

  .tabCol ul.ul_01 {
      color: #ffffff;
      font-size: 1vw;
      list-style: none;
      padding: 0;
      margin: 0;
      font-family: EYInterstate;
      font-weight: lighter;
  }

  .tabCol ul.ul_01 li {
      position: relative;
      padding-left: 1.5vw;
      margin-bottom: 1.7vw;
  }

  .tabCol ul.ul_01 li::before {
      content: "";
      background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/arrow_png.png);
      position: absolute;
      width: 0.7vw;
      height: 0.6vw;
      background-size: contain;
      background-repeat: no-repeat;
      margin-top: 0.4vw;
      left: 0;
  }

  .accordion .card h2 {
      background-size: 1.5vw;
      cursor: pointer;
      font-size: 1.3vw;
      margin-bottom: .6vw !important;
      background-position: 95% 0.3vw;
      color: #ffe600;
  }

  .card {
      border: none;
      margin-bottom: 0px;
      background: transparent;
  }

  .card-body {
      padding-left: 0;
      padding-right: 0;
  }

  .tmImg {
      background: #000000;
      width: 5.5vw;
      height: 5.5vw;
      border-radius: 100vw;
      position: relative;
      left: 50%;
      transform: translate(-50%, 0);
      top: 1.5vw;
      overflow: hidden;
  }

  .tmImg img {
      width: 105%;
      position: absolute;
      left: 50%;
      top: 50%;
      transform: translate(-50%, -50%);
  }

  .tmName {
      font-size: .9vw;
      font-family: EYInterstate;
      text-align: center;
      margin-top: 2.5vw;
      margin-bottom: 0;
      color: #ffe600;
  }

  .tmp2 {
      font-size: 0.9vw;
      text-align: center;
      margin-top: -0.1vw;
      color: #ffffff;
      font-weight: bold;
      margin-bottom: 0.5vw;
  }

  .cf {
      background: rgb(255 255 255 / 6%);
      min-height: 13vw;
  }

  .col-sm-12.sm-tm-5 {
      -ms-flex: 0 0 16.6666%;
      flex: 0 0 16.6666%;
      max-width: 16.6666%;
      padding: 0vw 0.4vw;
      padding-bottom: 0.8vw;
      margin-top: 2vw;
  }

  @media only screen and (max-width: 1200px) {
      .cf6 {
          font-size: 30px;
          margin-bottom: 0;
      }
      .tabCol {
          padding: 50px 70px;
      }
      .tabCol ul.ul_01 {
          font-size: 14px;
      }
      .tabCol ul.ul_01 li::before {
          width: 15px;
          height: 8px;
          margin-top: 6px;
          left: 0;
      }
      .tabCol ul.ul_01 li {
          position: relative;
          padding-left: 17px;
          margin-bottom: 10px;
      }
      span.s1-cf {
          font-size: 18px;
          border-top: 1px solid #ffffff63;
          border-bottom: 1px solid #ffffff63;
          padding: 11px 15px;
      }
      .col-sm-12.sm-tm-5 {
          padding: 0vw 4px;
          margin-top: 8px;
          padding-bottom: 0;
          -ms-flex: 0 0 160px;
          flex: 0 0 160px;
          max-width: 160px;
      }
      .tmImg {
          width: 56px;
          height: 56px;
          top: 24px;
          overflow: hidden;
      }
      .tmName {
          font-size: 13px;
          margin-top: 28px;
          line-height: 13px;
          margin-bottom: 3px;
      }
      .tmp2 {
          font-size: 11px;
          margin-top: 0px;
          margin-bottom: 5px;
      }
      .cf {
          min-height: 160px;
          max-height: 160px;
      }
  }

  @media only screen and (max-width: 800px) {
      .tabCol {
          padding: 50px 30px;
      }
  }
`;

interface IGDSProps {
  onShowHome?: () => void;
}

const GDS: React.FC<IGDSProps> = ({ onShowHome }) => {
  return (
    <>
      <style>{gdsStyles}</style>
      <div className="webPart">
        <div className="container-fluid nav-container">
          <div className="row nav-bar">
            <img className="EYlogo" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/EY_logo.png" alt="EY Logo" />
            <p className="logoTxt">MENA Tax Hub</p>
            <ul className="navbarMenu">
              <li>
                <a data-interception="off" href="#" onClick={(e) => { e.preventDefault(); if (onShowHome) onShowHome(); }} style={{ cursor: 'pointer' }}>
                  <img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home.png" alt="Home" className="home" />
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div className="container-fluid">
          <div className="row">
            <div className="col-sm-12 bannerBackground">
              <div className="container-fluid cnt-fdr">
                <div className="row">
                  <p className="cf6">GDS</p>
                  <hr className="hrt" />
                  <div className="col-sm-4 c57"></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="container-fluid tabContent">
          <div className="row tabCol tc-col">
            <p className="CollapsibleText">GDS continues to be a strategic enabler for MENA. Global KPIs are driving increasing consumption of hours.</p>
            <div className="accordion" id="accordionExample">
              <div className="card">
                <h2 className="mb-0">
                  Key Considerations:
                </h2>

                <div id="collapseOne" className="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                  <div className="card-body">
                    <div className="vid-parent">
                      <ul className="ul_01 u2 cf-u">
                        <li>Utilization of onshore resources against capacity and rank utilization expectations </li>
                        <li>Utilization of sponsored GDS FTE and Rapid pool against expectations </li>
                        <li>Is this within your SSL financial plan for GDS hours? </li>
                        <li>Internal promotion/ progression opportunities </li>
                        <li>Is a type of skills needed available onshore or within the existing GDS FTE pool </li>
                        <li>GDS T&M to be considered on a case-by-case basis after factoring in the current capacity and Skill set of the GDS FTE sponsored pool </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>

              <div className="card">
                <h2 className="mb-0">
                  What happens next?
                </h2>

                <div id="collapseOne" className="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                  <div className="card-body">
                    <div className="vid-parent">
                      <ul className="ul_01 u2 cf-u">
                        <li>Carry out an assessment of your current state using the <a data-interception="off" href="https://app.powerbi.com/groups/me/apps/88b138f5-216c-4ac6-b72a-a19e005bd381/reports/224a0ea2-bd8c-4441-b136-31641b8a8103/ReportSectionbd6d72f0b28d653ff863?ctid=5b973f99-77df-4beb-b27d-aa0c70b8482c&experience=power-bi" target="_blank" rel="noreferrer"> Tax People Dashboard</a>, <a data-interception="off" href="https://app.powerbi.com/groups/me/apps/88b138f5-216c-4ac6-b72a-a19e005bd381/reports/db646e19-5e24-4e38-accc-9a8c2e8743e9/ReportSection?ctid=5b973f99-77df-4beb-b27d-aa0c70b8482c&chromeless=1&experience=power-bi" target="_blank" rel="noreferrer"> Finance & Engagement Dashboard </a> and the FTE demand plan for the current FY </li>
                        <li>If your request aligns with the FY FTE plan and the considerations above, you may proceed with raising a resource request on the <a data-interception="off" href="https://apps.powerapps.com/play/e/a3c669f6-ac2e-4e77-ad43-beab3e15bee7/a/a422fad2-0a90-4117-b14b-3da399c77b75?tenantId=5b973f99-77df-4beb-b27d-aa0c70b8482c&sourcetime=1721291017599&hidenavbar=true" target="_blank" rel="noreferrer"> MENA Tax Hiring Tool</a></li>
                        <li>Your request would be routed through EXM (Experience Management), SSL leader and COO for approval </li>
                        <li>Once fully approved, the EXM team will raise the request through the GDS Gateway tool.</li>
                        <li>Typical turnaround time for approval is between 2- 4 business days </li>
                        <li>For requests that do not meet the requirements, please connect with your respective EXM contact for any additional information and guidance on the optimal approach to fulfil your requirement </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>

              <div className="card">
                <h2 className="mb-0">
                  Cost components:
                </h2>

                <div id="collapseOne" className="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                  <div className="card-body">
                    <div className="vid-parent">
                      <ul className="ul_01 u2 cf-u">
                        <li> Cost of the offshore resources will be guided by the GDS rate cards for both FTE and T&M resources available <a data-interception="off" href="https://sites.ey.com/sites/GlobalPlanningOperations/GDS%20FY25%20Rate%20Cards/Forms/AllItems.aspx" target="_blank" rel="noreferrer"> here</a></li>
                        <li>FTE yearly cost (GDS rate card) Note:<i> *For GDS FTE resources, it is the responsibility of the hiring manager to ensure target utilization is achievable for the entire duration of the agreement.</i></li>
                        <li>T&M hourly cost (GDS rate card)</li>
                        <li>Out of pocket expenses- this will apply for onsite MENA deployments. An example is illustrated below:</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <div className="card">
                <h2 className="mb-0">
                  Out-of-pocket expenses (this will apply for onsite MENA deployments).
                </h2>

                <div id="collapseOne" className="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                  <div className="card-body">
                    <div className="vid-parent">
                      <ul className="ul_01 u2 cf-u">
                        <li>Travel OPE Cost Estimation - EXAMPLE </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="row">
            <table className="ck-table-resized">
              <colgroup>
                <col style={{ width: '5%' }} />
                <col style={{ width: '5%' }} />
                <col style={{ width: '5%' }} />
                <col style={{ width: '6.24%' }} />
                <col style={{ width: '6.25%' }} />
                <col style={{ width: '6.67%' }} />
                <col style={{ width: '6.67%' }} />
                <col style={{ width: '6.67%' }} />
                <col style={{ width: '6.67%' }} />
                <col style={{ width: '6.67%' }} />
                <col style={{ width: '6.67%' }} />
                <col style={{ width: '6.67%' }} />
                <col style={{ width: '7.43%' }} />
                <col style={{ width: '7.6%' }} />
                <col style={{ width: '7.01%' }} />
              </colgroup>
              <tbody>
                <tr className="rowOne">
                  <td style={{ height: '28.2pt', width: '62pt' }}>Country</td>
                  <td style={{ width: '62pt' }}>Visa Type</td>
                  <td style={{ width: '62pt' }}>Entry</td>
                  <td style={{ width: '62pt' }}>Visa Cost</td>
                  <td style={{ width: '62pt' }}>Flight Cost (Round trip)</td>
                  <td style={{ width: '62pt' }}>Hotel Cost</td>
                  <td style={{ width: '62pt' }}>Sim Card</td>
                  <td style={{ width: '62pt' }}>Telephone Expenses (monthly)</td>
                  <td style={{ width: '62pt' }}>Airport Transfers (both ways)</td>
                  <td style={{ width: '62pt' }}>Additional Baggage</td>
                  <td style={{ width: '62pt' }}>Taxi Expenses</td>
                  <td style={{ width: '62pt' }}>Per Diem</td>
                  <td style={{ width: '62pt' }}>Duration</td>
                  <td style={{ width: '62pt' }}>Cost per resource (1st month)</td>
                  <td style={{ width: '62pt' }}>Next Time Travel (per month)</td>
                </tr>
                <tr>
                  <td>KSA (Riyadh)</td>
                  <td>Work Permit</td>
                  <td>Multiple</td>
                  <td>$ 800</td>
                  <td>$ 600</td>
                  <td>$ 130</td>
                  <td>$ 50</td>
                  <td>$ 25</td>
                  <td>$ 100</td>
                  <td>$ 200</td>
                  <td>$ 40</td>
                  <td>$ 70</td>
                  <td>$ 30</td>
                  <td>$ 9,025</td>
                  <td>$ 8,175</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="row cv-g">
            <div className="col-sm-6">
              <p className="ft-g">FTE<br /><strong className="strong"> Active until 1st October 2024</strong><br /><span> (India/Kerala)</span></p>
              <iframe className="e_a_866d546b vg-1" frameBorder="0" tabIndex={0} src="https://sites.ey.com/sites/MENAEXM-TestSite/_layouts/15/embed.aspx?UniqueId=8b61dbf6-1ccb-4702-b232-989e19db0c09&amp;client_id=FileViewerWebPart&amp;showNewWindow=true&amp;embed=%7B%22af%22%3Afalse%2C%22p%22%3A1%2C%22z%22%3A%22width%22%7D&amp;auth=readwrite" title="Embedded document" role="document" style={{ visibility: 'visible' }}></iframe>
            </div>

            <div className="col-sm-6">
              <p className="ft-g"> T&M <br /><strong className="strong"> Active until 1st October 2024</strong><br /><span>
                (India, Philippines, Argentina, Poland, Hungary and Spain)</span></p>
              <iframe className="e_a_866d546b vg-1" frameBorder="0" tabIndex={0} src="https://sites.ey.com/sites/MENAEXM-TestSite/_layouts/15/embed.aspx?UniqueId=c93295a7-ef55-4e16-a848-0a5862bf74f6&amp;client_id=FileViewerWebPart&amp;showNewWindow=true&amp;embed=%7B%22af%22%3Afalse%2C%22p%22%3A1%2C%22z%22%3A%22width%22%7D&amp;auth=readwrite" title="Embedded document" role="document" style={{ visibility: 'visible' }}></iframe>
            </div>
          </div>

          <div className="row tabCol trs-padding">
            <div className="col-sm-12">
              <span className="s1-cf" style={{ marginTop: '0px' }}>Meet The Team</span>
              <hr className="hr ht" />
            </div>

            <div className="col-sm-12 sm-tm-5 ">
              <div className="cf ">
                <div className="TmBox ">
                  <div className="tmImg "><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Dileep-Rajasekhar.png" alt="Dileep Rajasekhar" />
                  </div>
                  <p className="tmName ">Dileep Rajasekhar
                  </p>
                  <p className="tmp2 ">Assistant Director</p>
                </div>
              </div>
            </div>

            <div className="col-sm-12 sm-tm-5 ">
              <div className="cf ">
                <div className="TmBox ">
                  <div className="tmImg "><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/ellen-M-Jose.png" alt="Jellen M Jose" />
                  </div>
                  <p className="tmName ">Jellen M Jose</p>
                  <p className="tmp2 "> Assistant Director</p>
                </div>
              </div>
            </div>
          </div>

          <div className="row ">
            <div className="footer ">
              <p>&#169; 2026 EYGM Limited. All rights reserved.</p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default GDS;
