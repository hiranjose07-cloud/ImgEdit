import * as React from 'react';

interface IMenaTaxResourcingHubProps {
  onShowHome: () => void;
  onShowOnshore: () => void;
  onShowNonGcc: () => void;
}

const imageRoot = 'https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/';

const quickLinks = [
  ['https://apps.powerapps.com/play/e/c8ee9bdf-796c-e519-a5df-582e17394e4b/a/e5843273-4dd0-456f-bc51-a11b2a7b3b07', 'i1.png', 'High Level Budget Calculator'],
  ['https://app.powerbi.com/groups/me/apps/88b138f5-216c-4ac6-b72a-a19e005bd381/reports/db646e19-5e24-4e38-accc-9a8c2e8743e9/ReportSection?chromeless=1', 'i2.png', 'Finance & Engagement Report'],
  ['https://app.powerbi.com/groups/me/apps/88b138f5-216c-4ac6-b72a-a19e005bd381/reports/224a0ea2-bd8c-4441-b136-31641b8a8103/ReportSection7e1a9e9c667034ba4b14?chromeless=1', 'i3.png', 'People Dashboard (Utilzation & Nationalization)'],
  ['https://apps.powerapps.com/play/e/a3c669f6-ac2e-4e77-ad43-beab3e15bee7/a/a422fad2-0a90-4117-b14b-3da399c77b75', 'i4.png', 'Hiring Tool'],
  ['https://apps.powerapps.com/play/e/a3c669f6-ac2e-4e77-ad43-beab3e15bee7/a/3cfbfa9b-b76f-4eda-ac6d-4fca290223ed', 'apps.png', 'Hourly Cost Rate Comparison App']
];

const resources = [
  ['Onshore', '#onshore', 'onshore.jpg'],
  ['Non-GCC (Levant / Rapid Pakistan)', '#nongcc', 'thumbnail-203.png'],
  ['GDS', '#gds', 'thumbnail-304.jpg'],
  ['FY25-GDS FTE MENA Tax Rate Card', 'https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/ResourcingHub/FY25-GDS-FTE-Tax-Rate-Card_MENA%20.pdf', 'thumbnail306.png'],
  ['FY25-GDS T&M MENA Tax Rate Card', 'https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/ResourcingHub/FY25-GDS-T-M-Tax-Rate-Card_MENA%20.pdf', 'thumbnail307.png']
];

const people = [
  ['Bobin Abraham', 'MENA Tax EXM Leader', 'Riyadh, KSA', 'Bobin%20T.jpg'],
  ['Dileep Rajasekhar', 'Tax EXM Consultant', 'Kuwait', 'Dileep%20Rajasekhar.jpg'],
  ['Jellen M Jose', 'Tax EXM Consultant', 'Dubai, UAE', 'Jellen%20Jose.jpg'],
  ['Meghna Jayachandran', 'Tax EXM Analyst', 'GDS, India', 'fa4b0e99-0d5a-4485-bca4-de12736bb7b1_LThumb.jpg'],
  ['Jose Thomas', 'Tax EXM Analyst', 'GDS, India', 'Jose%20thomas.jpg']
];

const ResourcingStyles: React.FC = () => (
  <style>{`
    .resourcingHub{background:#2e2e38;color:#fff;font-family:EYInterstate,Arial,sans-serif;overflow:hidden}.resourcingHub *{box-sizing:border-box}.resourcingHub__loading{align-items:center;background:#1a1a24;display:flex;inset:0;justify-content:center;position:fixed;z-index:9999}.resourcingHub__loading.is-hidden{display:none}.resourcingHub__loading .item{border:.2vw solid #ffe600;border-bottom-color:transparent;border-top-color:transparent;border-radius:50%;position:absolute;animation:resourcingSpin 2s ease infinite}.resourcingHub__loading .item:nth-child(1){height:30px;width:30px}.resourcingHub__loading .item:nth-child(2){height:50px;width:50px;animation-delay:.1s}.resourcingHub__loading .item:nth-child(3){height:70px;width:70px;animation-delay:.2s}.resourcingHub__loading .item:nth-child(4){height:90px;width:90px;animation-delay:.3s}@keyframes resourcingSpin{50%{transform:rotate(180deg)}100%{transform:rotate(0)}}
    .resourcingHub__nav{background:#2e2e38;min-height:6vw;position:relative}.resourcingHub__nav .EYlogo{left:5vw;position:absolute;top:1.5vw;width:3vw}.resourcingHub__nav .logoTxt{color:#fff;font-size:2vw;left:11vw;margin:0;position:absolute;top:2.2vw}.resourcingHub__nav .homeLink{position:absolute;right:6vw;top:2.4vw}.resourcingHub__nav .homeLink img{width:1.3vw}.resourcingHub__hero{background:url('${imageRoot}banner-images.png') center/cover;padding:2vw 5vw;min-height:17vw}.resourcingHub__hero h1{font-size:2vw;font-weight:400;margin:5vw 0 .3vw 1vw}.resourcingHub__hero hr,.resourcingHub__section hr{border:0;border-top:.2vw solid #ffe600;margin:0 0 0 1.2vw;width:3vw}.resourcingHub__accordion{background:#00000017;border-bottom:.1vw solid #363636;padding:1vw 6vw}.resourcingHub__accordion h2{background:url('${imageRoot}arrow-down.png') no-repeat 95% .3vw/1.23vw;cursor:pointer;font-size:1.5vw;font-weight:400;margin:0;padding:.4vw 6.5vw .4vw 0}.resourcingHub__accordion h2.is-open{background-image:url('${imageRoot}arrow-up.png')}.resourcingHub__accordionHint{color:#ffe600;float:right;font-size:.9vw}.resourcingHub__accordionBody{padding:1vw 0}.resourcingHub__accordionBody p,.resourcingHub__accordionBody li{font:1vw/1.5 Arial,sans-serif}.resourcingHub__accordionBody ul,.resourcingHub__intro ul{list-style:none;margin:0;padding:0}.resourcingHub__accordionBody li,.resourcingHub__intro li{margin-bottom:1.1vw;padding-left:1.5vw;position:relative}.resourcingHub__accordionBody li:before,.resourcingHub__intro li:before{content: "";
    background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/arrow_png.png);
    position: absolute;
    width: 0.7vw;
    height: 0.6vw;
    background-size: contain;
    background-repeat: no-repeat;
    margin-top: 0.4vw;
    left: 0;}.resourcingHub__quickLinks ul li:before{content ""; display:none;}.resourcingHub__accordionBody strong{color:#ffe600}.resourcingHub__intro{background:url('${imageRoot}bgc.png') center/cover;display:grid;grid-template-columns:1fr 1fr}.resourcingHub__introContent{padding:2vw 6vw}.resourcingHub__introContent h2{color:#ffe600;font-size:1.2vw;font-weight:400}.resourcingHub__introContent p,.resourcingHub__introContent li{font:1vw/1.5 Arial,sans-serif}.resourcingHub__quickLinks{background:#2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/gettyimages-607638780-1024x102.png') center/cover;overflow:hidden;padding:4vw;position:relative}.resourcingHub__quickLinks:before,.resourcingHub__quickLinks:after{background:url('${imageRoot}honeyComb.png') center/contain no-repeat;content:'';height:22vw;position:absolute;width:22vw}.resourcingHub__quickLinks:before{right:-1vw;top:-2vw;transform:rotate(90deg)}.resourcingHub__quickLinks:after{bottom:-2vw;left:-1vw}.resourcingHub__quickLinks h2{font:2vw Arial;margin:0 0 1vw}.resourcingHub__quickLinks ul{display:grid;grid-template-columns:1fr 1fr;list-style:none;margin:0;padding:0;position:relative;z-index:1}.resourcingHub__quickLinks li{padding:.5vw}.resourcingHub__quickLinks a{align-items:center;background:#ffffff17;color:#fff;display:grid;font:1vw/1.2 Arial;height:9vw;justify-content:center;padding:1vw;text-align:center;text-decoration:none}.resourcingHub__quickLinks a:hover{background:#ffffff47}.resourcingHub__quickLinks img{display:inline-block;margin:0 auto;width:2.3vw}.resourcingHub__section{padding:1vw 6vw 0}.resourcingHub__sectionTitle{color:#fff;display:block;font-size:1.4vw;margin:1vw 0 .7vw}.resourcingHub__cards{display:grid;gap:1vw;grid-template-columns:repeat(3,1fr)}.resourcingHub__card{min-height:11vw;overflow:hidden;position:relative}.resourcingHub__card a{display:block;height:11vw;position:relative}.resourcingHub__cardImage{background-position:center;background-size:cover;inset:0;position:absolute;transition:transform .2s}.resourcingHub__cardImage:after{background:linear-gradient(transparent,#000);content:'';inset:0;position:absolute}.resourcingHub__card:hover .resourcingHub__cardImage{transform:scale(1.05)}.resourcingHub__cardLabel{bottom:1.5vw;color:#fff;font-size:1vw;left:1.5vw;position:absolute;width:83%;z-index:1}.resourcingHub__team{padding:0 6vw 2vw}.resourcingHub__teamGrid{display:grid;gap:.8vw;grid-template-columns:repeat(5,1fr)}.resourcingHub__person{background:#ffffff0f;min-height:15vw;text-align:center}.resourcingHub__person img{border-radius:50%;height:5.5vw;margin-top:1.5vw;object-fit:cover;width:5.5vw}.resourcingHub__person strong{color:#ffe600;display:block;font-size:.9vw;margin-top:1vw}.resourcingHub__person span{display:block;font-size:.8vw;margin-top:.4vw}.resourcingHub__footer{background:#000;color:#fff;font-size:1vw;padding:1vw 2vw;text-align:right}
    @media(max-width:1200px){.resourcingHub__nav{min-height:90px}.resourcingHub__nav .EYlogo{left:60px;top:20px;width:40px}.resourcingHub__nav .logoTxt{font-size:25px;left:130px;top:30px}.resourcingHub__nav .homeLink{right:50px;top:31px}.resourcingHub__nav .homeLink img{width:20px}.resourcingHub__hero h1{font-size:30px}.resourcingHub__accordion h2{font-size:20px}.resourcingHub__accordionHint{font-size:12px}.resourcingHub__introContent h2,.resourcingHub__sectionTitle{font-size:18px}.resourcingHub__introContent p,.resourcingHub__introContent li,.resourcingHub__accordionBody p,.resourcingHub__accordionBody li{font-size:14px}.resourcingHub__cardLabel,.resourcingHub__quickLinks a{font-size:13px}.resourcingHub__person strong{font-size:13px}.resourcingHub__person span{font-size:11px}.resourcingHub__footer{font-size:13px}}
    @media(max-width:800px){.resourcingHub__intro{grid-template-columns:1fr}.resourcingHub__cards{grid-template-columns:repeat(2,1fr)}.resourcingHub__teamGrid{grid-template-columns:repeat(3,1fr)}}
    @media(max-width:575px){.resourcingHub__nav .homeLink{top:110px}.resourcingHub__hero h1{font-size:24px;margin-top:20px}.resourcingHub__introContent,.resourcingHub__accordion,.resourcingHub__section,.resourcingHub__team{padding-left:30px;padding-right:30px}.resourcingHub__quickLinks ul{grid-template-columns:1fr}.resourcingHub__cards{grid-template-columns:1fr}.resourcingHub__teamGrid{grid-template-columns:repeat(2,1fr)}}
    @media(max-width:400px){.resourcingHub__teamGrid{grid-template-columns:1fr}}
  `}</style>
);

const MenaTaxResourcingHub: React.FC<IMenaTaxResourcingHubProps> = ({ onShowHome, onShowOnshore, onShowNonGcc }) => {
  const [open, setOpen] = React.useState(false);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const timer = window.setTimeout(() => setLoading(false), 2000);
    window.scrollTo(0, 0);
    return () => window.clearTimeout(timer);
  }, []);

  const renderResource = (resource: string[], index: number): React.ReactElement => (
    <div className="resourcingHub__card" key={resource[0]}><a data-interception="off" href={resource[1]} target="_blank" rel="noreferrer" onClick={(event) => { if (index === 0) { event.preventDefault(); onShowOnshore(); } if (index === 1) { event.preventDefault(); onShowNonGcc(); } }}><div className="resourcingHub__cardImage" style={{ backgroundImage: `url('${imageRoot}${resource[2]}')` }} /><span className="resourcingHub__cardLabel">{resource[0]}</span></a></div>
  );

  return (
    <div className="resourcingHub">
      <ResourcingStyles />
      <div className={`resourcingHub__loading${loading ? '' : ' is-hidden'}`} aria-hidden={!loading}><div className="item" /><div className="item" /><div className="item" /><div className="item" /></div>
      <nav className="resourcingHub__nav"><img className="EYlogo" src={`${imageRoot}EY_logo.png`} alt="EY logo" /><p className="logoTxt">MENA Tax Hub</p><a data-interception="off" className="homeLink" href="#home" onClick={(event) => { event.preventDefault(); onShowHome(); }}><img src={`${imageRoot}home.png`} alt="Home" /></a></nav>
      <header className="resourcingHub__hero"><h1>Welcome to MENA Tax Resourcing Hub</h1><hr /></header>
      <main>
        <section className="resourcingHub__accordion"><h2 className={open ? 'is-open' : ''} onClick={() => setOpen(!open)} aria-expanded={open}>The Role of Experience Management <span className="resourcingHub__accordionHint">{open ? 'Close' : 'Click here for more information'}</span></h2>{open && <div className="resourcingHub__accordionBody"><p>The Experience Management function supports the business to maximize business performance and deliver on our talent promise through proactive management of our talent pool. Supporting MENA Tax by ensuring teams allocate the right people, to the right role, at the right time and support project demand prioritization. EXM provides specialist knowledge and manages relationships to ensure we maximize productivity and develop our talent through their on-the-job experiences.</p><p><strong>Key responsibilities</strong></p><ul><li><strong>Stakeholder Management</strong> - Responsible for managing key relationships within Leadership Team, Partner Group and Business Enablement Team across MENA.</li><li><strong>Pipeline &amp; Demand management</strong> - Ensuring direct connectivity between pursuits teams and the experience management team across MENA Tax, Graduates, Experienced and sponsored pool of GDS FTE&apos;s.</li><li><strong>Talent pool management &amp; experience optimization</strong> - Actively managing resourcing and available capacity by understanding capability and proactively identifying opportunities for all available resources.</li><li><strong>Experience optimization</strong> - Highlighting capability outside the home talent pool via cross-functional, cross-border or cross-region allocation to maximize productivity.</li><li><strong>Experience management</strong> - Promoting identification and delivery of career experiences as part of every engagement.</li><li><strong>Continuous improvement</strong> - Roll out of initiatives on behalf of the Tax COO and identifying opportunities to improve the Tax team performance.</li></ul></div>}</section>
        <section className="resourcingHub__intro"><div className="resourcingHub__introContent"><h2>Our purpose- built intranet site will serve as a convenient, comprehensive resource guide for Experience Management operations</h2><hr /><h2>Here&apos;s what this platform provides:</h2><ul><li>An introduction to Experience Management where you&apos;ll get to meet our dedicated team with a focus on the services the EXM team offer. These include strategic and operational workforce planning, capacity management, headcount planning, and skills matching.</li><li>An overview and insight on key considerations, next steps, cost components and contacts of the diverse resource options for smart delivery<ul><li>Onshore</li><li>Non-GCC (Levant / Rapid Pakistan)</li><li>GDS (T&amp;M/FTE)</li><li>Contingent Worker (CW)</li><li>Global Mobility Assignments (Mobility program) - <span style={{ color: '#ff4136' }}>Coming soon</span></li></ul></li><li>Accessibility to useful links that provide a smooth working experience such as People, Finance reporting, the Tax Hiring tool and more.</li></ul></div><div className="resourcingHub__quickLinks"><h2><img src={`${imageRoot}external-link.png`} alt="" /> Quick Links</h2><ul>{quickLinks.map((link) => <li key={link[2]}><a data-interception="off" href={link[0]} target="_blank" rel="noreferrer"><img src={`${imageRoot}${link[1]}`} alt="" />{link[2]}</a></li>)}</ul></div></section>
        <section className="resourcingHub__section"><span className="resourcingHub__sectionTitle">Onshore / Non-GCC (Levant / Rapid Pakistan)</span><hr /><div className="resourcingHub__cards">{resources.slice(0, 2).map((resource, index) => renderResource(resource, index))}</div><span className="resourcingHub__sectionTitle">GDS</span><hr /><div className="resourcingHub__cards">{resources.slice(2).map((resource, index) => renderResource(resource, index + 2))}</div></section>
        <section className="resourcingHub__team"><span className="resourcingHub__sectionTitle">Meet The Team</span><hr /><div className="resourcingHub__teamGrid">{people.map((person) => <div className="resourcingHub__person" key={person[0]}><img src={`${imageRoot}${person[3]}`} alt={person[0]} /><strong>{person[0]}</strong><span>{person[1]}</span><span>{person[2]}</span></div>)}</div></section>
      </main>
      <footer className="resourcingHub__footer">&#169; 2026 EYGM Limited. All rights reserved.</footer>
    </div>
  );
};

export default MenaTaxResourcingHub;
