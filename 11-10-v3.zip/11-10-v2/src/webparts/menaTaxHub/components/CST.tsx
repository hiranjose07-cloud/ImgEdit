import * as React from 'react';

const cstStyles = `
html,
body {
  overflow-x: hidden !important;
  font-family: EYInterstate;
}

.container_wrapper {
  display: none;
}

::-moz-selection {
  color: #ffffff;
  background: #27ACAA;
}

::selection {
  color: #ffffff;
  background: #27ACAA;
}

body::-webkit-scrollbar {
  display: none;
}

.loading-container {
  position: relative;
  position: fixed;
  z-index: 9999;
  background: #1a1a24;
  width: 100%;
  height: 100vh;
  margin: auto;
}

.loading-container .item {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  border: .2vw solid #ffe600;
  border-radius: 50%;
  border-top-color: transparent;
  border-bottom-color: transparent;
  animation: spin 2s ease infinite;
}

.loading-container .item:nth-child(1) {
  width: 30px;
  height: 30px;
}

.loading-container .item:nth-child(2) {
  width: 50px;
  height: 50px;
  animation-delay: 0.1s;
}

.loading-container .item:nth-child(3) {
  width: 70px;
  height: 70px;
  animation-delay: 0.2s;
}

.loading-container .item:nth-child(4) {
  width: 90px;
  height: 90px;
  animation-delay: 0.3s;
}

@keyframes spin {
  50% {
    transform: translate(-50%, -50%) rotate(180deg);
  }
  100% {
    transform: translate(-50%, -50%) rotate(0deg);
  }
}

body {
  -ms-overflow-style: none;
  scrollbar-width: none;
  position: relative;
}

.bannerBackground {
  background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/banner.jpg);
  background-color: #2e2e38;
  background-size: 115% 115%;
  background-position: center center;
  position: relative;
  background-attachment: fixed;
  animation: shrink 20s infinite alternate;
  padding: 0px;
}

.cf6 {
  color: #ffffff;
  width: 100%;
  font-size: 1.9vw;
  padding: 0;
  margin-bottom: 0;
  float: left;
  border-bottom: .1vw solid #ffffff;
  padding-bottom: 3px;
  margin-left: 1vw;
  width: 34vw;
  margin-bottom: 1.3vw;
}

@keyframes shrink {
  0% {
    background-size: 115% 115%;
  }
  100% {
    background-size: 100% 100%;
  }
}

.nav-bar {
  position: relative;
  z-index: 999;
  background: #2e2e38;
  min-height: 6vw;
  width: 100%;
  margin: 0;
}

.nav-container {
  padding: 0px;
}

.EYlogo {
  width: 3vw;
  position: absolute;
  left: 5vw;
  top: 1.5vw;
}

p.logoTxt {
  color: #ffffff;
  font-size: 2vw;
  position: absolute;
  left: 11vw;
  top: 2.2vw;
}

img.home {
  width: 1.3vw;
}

ul.navbarMenu {
  position: absolute;
  right: 6vw;
  top: 2.4vw;
  font-family: EYInterstate;
}

ul.navbarMenu li {
  display: inline-block;
  font-size: 1vw;
  color: #ffffff;
}

ul.navbarMenu li a {
  color: #ffffff;
  text-decoration: none;
  padding: 0vw 2vw;
}

.boxContent span {
  color: #ffe600;
  font-size: 1.2vw;
  margin-right: .3vw;
  font-weight: bold;
}

.cnt-fdr {
  padding: 2vw 5vw 2vw 5vw;
  background: rgba(46, 46, 56, .5);
  bottom: 0;
  width: 100%;
}

.vh3 {
  margin-top: 1.3vw;
}

.boxContent p {
  color: #ffffff;
  font-size: .9vw;
  line-height: 1.3vw;
  font-family: EYInterstate;
  font-weight: lighter;
}

.boxContent p b {
  font-size: 1.2vw;
  line-height: 2.5vw;
}

.boxContent img {
  width: 3vw;
  margin-bottom: .4vw;
}

p.c4 {
  color: #ffffff;
  font-size: 1.1vw;
  font-family: EYInterstate;
  line-height: 1.5vw;
  margin-bottom: 1.3vw;
}

ul.c5 {
  color: #ffffff;
  list-style: none;
  padding: 0;
}

ul.c5 li {
  position: relative;
  padding-left: 1.3vw;
  margin-bottom: 0.6vw;
  font-size: 1vw;
}

ul.c5 li::before {
  content: "";
  background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/arrow_icon.png);
  position: absolute;
  width: .6vw;
  height: .6vw;
  background-size: contain;
  background-repeat: no-repeat;
  top: 0.5vw;
  left: 0;
}

.footerTab {
  background: #1a1a24;
  padding: 5vw;
}

a.qLInk {
  color: #ffffff;
  font-family: EYInterstate;
  font-size: 1vw;
  font-weight: lighter;
  border: .1vw solid #9f9f9f;
  padding: 0.5vw 1.6vw;
  border-radius: .4vw;
  margin-right: .7vw;
  text-decoration: none;
  float: left;
  -webkit-transition: all .2s ease-in-out;
  -moz-transition: all .2s ease-in-out;
  -o-transition: all .2s ease-in-out;
  transition: all .2s ease-in-out;
  margin-bottom: .8vw;
}

a.qLInk:hover {
  background: rgba(255, 255, 255, .2)
}

.quicklinks {
  color: #ffffff;
  font-size: 2vw;
  margin-bottom: 2vw;
}

img.qklinks {
  width: 1.4vw;
  margin-top: -0.2vw;
  margin-right: .4vw;
}

.tabContent {
  background-image: url(../images/bgc.png);
  background-position: center;
  background-size: cover;
  background-attachment: fixed;
  background-color: #2e2e38;
}

.tabCol {
  min-height: 10vw;
}

.nav-tabs .nav-link {
  margin-bottom: 0vw;
  border: hidden;
  border-radius: 0px;
  color: #ffffff !important;
  font-size: 1.1vw;
  font-family: EYInterstate;
  font-weight: lighter;
  border-right: .1vw solid #9e9e9e !important;
  padding: 0.2vw 2.5vw
}

.nav-tabs .nav-item.show .nav-link,
.nav-tabs .nav-link.active {
  color: #ffe600 !important;
  background-color: transparent;
}

#myTab {
  border-bottom: .1vw solid #7e7e7e;
  padding-bottom: 1vw;
  margin-bottom: 0px;
}

.tabCol {
  min-height: 10vw;
  padding: 2vw 6vw;
}

p.tabTxt {
  color: #ffffff;
  font-size: 1vw;
  line-height: 1.5vw;
  margin-bottom: 0;
  min-height: 5vw;
}

a.cgt7 {
  position: absolute;
  right: 0vw;
  bottom: 1vw;
  color: #000000;
  background: #ffe600;
  width: 17vw;
  padding: 0.5vw 0vw;
  text-align: center;
  text-decoration: none;
}

a.cgt7 img {
  width: 1.5vw;
  margin-right: 0.5vw;
}

.cl-tx {
  border-bottom: .01vw solid #ffffff61;
  padding-bottom: 2vw;
  margin-bottom: 2vw !important;
}

p.tabTxt a {
  color: #ffe600;
  text-decoration: none;
  font-weight: bold;
}

ul.ul_01 li a {
  color: #ffe600;
  text-decoration: none;
  font-weight: bold;
}

.tab-pane {
  padding: 3vw 4vw !important;
}

.tabCol ul.ul_01 {
  color: #ffffff;
  font-size: 1vw;
  list-style: none;
  padding: 0;
  margin: 0;
  font-family: EYInterstate;
  font-weight: lighter;
}

.tabCol ul.ul_02 {
  color: #ffffff;
  font-size: 1vw;
  list-style: none;
  padding: 0;
  margin: 0;
  font-family: EYInterstate;
  font-weight: lighter;
}

p.bt_7 {
  color: #ffffff;
  font-size: 2vw;
  margin-bottom: 1vw;
  margin-top: -1vw;
}

.tabCol ul.ul_01 li {
  position: relative;
  padding-left: 1.5vw;
  margin-bottom: 1.7vw;
}

.tabCol ul.ul_02 li {
  position: relative;
  padding-left: 1.5vw;
  margin-bottom: .7vw;
}

.tabCol ul.ul_01 li::before {
  content: "";
  background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/arrow_png.png);
  position: absolute;
  width: 0.7vw;
  height: 0.6vw;
  background-size: contain;
  background-repeat: no-repeat;
  margin-top: 0.4vw;
  left: 0;
}

.tabCol ul.ul_02 li::before {
  content: "";
  background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/tick.png);
  position: absolute;
  width: 0.7vw;
  height: 0.6vw;
  background-size: contain;
  background-repeat: no-repeat;
  margin-top: 0.4vw;
  left: 0;
}

.col_1 {
  width: 20%;
  background: rgba(255, 255, 255, .08);
  color: #ffffff;
  font-size: .9vw;
  line-height: 1.3vw;
  float: left;
  border-right: .1vw solid #616161;
}

.col_1:last-child {
  border-right: hidden
}

.Hdline {
  background: #1a1a24;
  padding: 1.5vw;
  min-height: 7vw;
}

.p-text {
  padding: 1.5vw;
  margin: 0;
  min-height: 17vw;
}

p.c8 {
  color: #ffe600;
  padding: 0vw 1.5vw;
}

ul.c9 {
  padding: 0vw 1.5vw 1.5vw 1.5vw;
  list-style: none;
  margin-bottom: 0;
  min-height: 20vw;
}

ul.c9 li {
  position: relative;
  padding-left: 1vw;
  margin-bottom: 1vw;
}

ul.c9 li::before {
  content: "";
  background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/arrow_png.png);
  position: absolute;
  width: 0.7vw;
  height: 0.6vw;
  background-size: contain;
  background-repeat: no-repeat;
  margin-top: 0.4vw;
  left: 0;
}

img.cf_img {
  width: 100%;
  height: 8vw;
}

.cf_head {
  background: #747480;
  padding: 0.6vw 0vw;
  text-align: center;
  color: #ffffff;
  font-size: 1.2vw;
  float: left;
  width: 100%;
}

img.proImg {
  width: 5vw;
  border-radius: 100vw;
  float: left;
  margin-right: 1vw;
}

p.proName {
  color: #ffffff;
  font-size: 1vw;
  margin-bottom: 0vw;
  padding-top: 1.3vw;
}

p.proDes {
  color: #ffe600;
  font-size: .9vw;
  margin-bottom: 0;
  margin-top: -.2vw;
}

.profileDetails {
  float: left;
  width: 100%;
  margin-bottom: 2vw;
}

li.subList {
  margin: 2vw 0vw !important;
  font-size: 1.5vw !important;
}

li.subList::before {
  display: none !important;
}

#Six-tab {
  border-right: hidden !important;
}

p.hder {
  color: #ffffff;
  padding-left: 1vw;
  font-size: 1vw;
  line-height: 1.5vw;
  margin-bottom: 1vw;
}

.news_box {
  float: left;
  margin-right: 1.5vw;
  background: rgba(255, 255, 255, .08);
  width: 28%;
  border: .01vw solid #444343;
  border-radius: .2vw;
  overflow: hidden;
}

.nws02.nsw a .news_box {
  width: 60%;
}

.imgTile {
  width: 100%;
  height: 7vw;
  background-size: cover;
  background-position: center;
}

.newsHd {
  color: #ffffff;
  font-size: 2vw;
  margin-bottom: 0.5vw;
  margin-top: 3vw;
}

hr.newsHr {
  margin-top: 0;
  margin-bottom: 2vw;
  border: 0;
  border-top: 1px solid rgba(255, 255, 255, .64);
  width: 4vw;
}

.Ntitle {
  color: #ffe600;
  margin-bottom: .5vw;
  font-size: .9vw
}

.Nsubtitle {
  color: #ffe600;
  font-size: 1vw;
  margin-bottom: 0.6vw;
  margin-top: -0.4vw;
}

.Ndes {
  color: #ffffff;
  font-size: .8vw;
  line-height: 1.1vw;
  margin-bottom: 0;
}

.Nread {
  color: #ffffff;
  font-size: .8vw;
  font-style: italic;
  margin: 0;
  text-align: right;
  margin-top: 0.4vw;
  position: absolute;
  right: 1vw;
  bottom: 1vw;
}

.newsDes {
  padding: 2vw 1vw;
  position: relative;
  min-height: 10vw;
}

.footer {
  background-color: #000000;
  float: left;
  width: 100%;
}

.footer p {
  margin-bottom: 0px;
  color: #ffffff;
  font-size: 1vw;
  padding: 1vw 2vw;
  text-align: right;
}

.txtTwo {
  margin-bottom: 1vw !important;
}

.navToggle {
  display: none;
}

.cl-v1 {
  background: #ffe600;
  color: #000000 !important;
  font-family: EYInterstate;
  padding: 0.7vw 2vw;
  float: right;
  text-decoration: none !important;
  font-size: .9vw;
  position: relative;
  z-index: 1;
  margin-top: 5px;
}

.cl-v1 img {
  width: 2vw;
  margin-right: .6vw;
}

.u0 {
  color: #ffe600 !important;
}

.u1 {
  margin: 1vw 0vw !important;
}

.u2 li {
  margin-bottom: .5vw !important;
}

.hotNews {
  background: #ffe600;
  width: 6vw;
  margin-bottom: -1vw;
  position: relative;
  z-index: 1;
  margin-left: 1vw;
}

.hotNews img {
  width: 1.6vw;
  padding: 0.2vw 0.1vw 0.3vw 0.5vw;
}

.hotNews span {
  color: #000000;
  font-size: .8vw;
  padding: 0vw 0.3vw;
}

.table.table-bordered {
  color: #ffffff;
  margin-top: 2vw;
}

.table-bordered thead th {
  color: #ffe600;
  padding: 1vw 1.5vw;
  font-size: 1.1vw;
  line-height: 1.4vw;
}

.table-bordered.ty_7 thead th {
  padding: 1vw 0vw;
}

.table-bordered tbody td {
  padding: 0.7vw 1.5vw;
  font-size: .9vw;
}

.table-bordered td,
.table-bordered th,
.table-bordered {
  border: .01vw solid #474747 !important;
}

table.table-bordered thead tr {
  background-color: #1f2027;
}

.col_20 {
  background-color: #1f2027;
}

.col_10 td ul {
  list-style: none;
  padding: 0px;
  margin-top: 1vw;
}

.col_10 td ul li {
  margin-bottom: .7vw !important;
}

.nws01 {
  float: left;
  width: 65%;
  border-right: .1vw solid #8e8e8e;
  padding-bottom: 2vw;
}

.nws02 {
  float: left;
  width: 35%;
  padding-left: 4vw;
}

a.cr7 {
  text-decoration: none;
  position: relative;
}

.news_1 {
  background: rgba(255, 255, 255, 0.1);
  padding: 1.5vw 1.5vw;
  margin-top: 0;
  margin-bottom: 1vw;
  -webkit-transition: all .2s ease-in-out;
  -moz-transition: all .2s ease-in-out;
  -o-transition: all .2s ease-in-out;
  transition: all .2s ease-in-out;
  padding-left: 10vw;
  position: relative;
  min-height: 8.4vw;
}

.fy7 {
  background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/FSleader.png?csf=1&web=1&e=t2oWU0);
  width: 8vw;
  height: 84%;
  position: absolute;
  left: .8vw;
  top: .8vw;
  background-size: cover;
  background-position: right;
  opacity: 0.9;
}

.pr_txt {
  color: #ffffff;
  font-size: .9vw;
  margin-bottom: .5vw;
  margin-top: 1vw;
  line-height: 1.2vw;
  width: 100%;
}

.c4a7 {
  color: #ffffff !important;
  font-size: .9vw;
  text-decoration: none !important;
  margin-bottom: 0px;
}

a.btn-yellow {
  background: #ffe600;
  text-align: center;
  color: #000000;
  font-size: 1vw;
  text-decoration: none;
  padding: 0.8vw 2vw;
  width: 40%;
  display: inline-block;
}

p.cf7 {
  text-align: center;
  margin: 0;
  padding: 2vw 0vw;
}

.ifrme {
  width: 100%;
  padding: 0vw;
  margin-bottom: 3vw;
  margin-top: 2vw;
}

.videoTab {
  float: left;
  width: 100%;
  margin-bottom: .2vw;
}

.videoTab a {
  float: left;
  width: 100%;
  padding: 1vw 0vw;
  padding-top: 0px;
}

.vidThumb {
  width: 18vw;
  float: left;
}

.hder.vid-hdr {
  float: left;
  margin-top: 2.5vw;
}

.textPhace {
  float: left;
}

span.s-span {
  color: #ffe600;
}

span.c-span {
  font-size: .85vw;
}

.tmp2 {
  font-size: 0.9vw;
  text-align: center;
  margin-top: -0.1vw;
  color: #ffffff;
  font-weight: bold;
  margin-bottom: 0.5vw;
}

.tabCol {
  min-height: 10vw;
}

.tabCol {
  min-height: 10vw;
  padding: 2vw 6vw;
}

.m-Title {
  color: #ffffff;
  width: 100%;
  font-size: 1.5vw;
  padding: 1vw 1vw;
  margin-bottom: 2vw;
}

.col-sm-12.sm-tm-5 {
  -ms-flex: 0 0 16.6666%;
  flex: 0 0 16.6666%;
  max-width: 16.6666%;
  padding: 0vw 0.4vw;
  padding-bottom: 0.8vw;
  margin-top: 2vw;
}

.cf {
  background: rgb(255 255 255 / 6%);
  min-height: 13vw;
}

.tmImg {
  background: #000000;
  width: 5.5vw;
  height: 5.5vw;
  border-radius: 100vw;
  position: relative;
  left: 50%;
  transform: translate(-50%, 0);
  top: 1.5vw;
  overflow: hidden;
}

.tmImg img {
  width: 105%;
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
}

.tmProfile {
  font-size: 0.8vw;
  text-align: center;
  margin-top: -0.1vw;
  margin-bottom: 0.5vw;
  color: #ffffff;
  padding: 0vw 1vw;
  padding-bottom: 1vw;
}

.tmName {
  font-size: .9vw;
  font-family: EYInterstate;
  text-align: center;
  margin-top: 2.5vw;
  margin-bottom: 0;
  color: #ffe600;
}

iframe#cst {
  width: 60vw;
  height: 35.4vw;
  margin-top: 1.5vw;
}

iframe#csts {
  width: 65vw;
  height: 28.5vw;
}

.trs-padding {
  padding-top: 0px !important;
}

span.s1-cf {
  font-size: 1.4vw;
  color: #ffe600;
  display: block;
  width: 100%;
  border-top: .1vw solid #ffffff63;
  border-bottom: .1vw solid #ffffff63;
  padding: 1vw 0vw;
}

.cg-6 {
  font-size: 1.2vw;
}

img.vid {
  position: absolute;
  top: 2px;
  right: 0;
  width: 460px;
  border: 1px solid #474747;
}

.vid-parent {
  position: relative;
  padding-right: 500px;
}

.cst-back-btn {
  position: absolute;
  right: 2vw;
  top: 1.2vw;
  color: #ffe600 !important;
  border: 1px solid #ffe600;
  padding: 0.35rem 0.8rem;
  font-size: 0.9rem;
}

@media only screen and (max-width: 1200px) {
  .cnt-fdr {
    position: static;
  }
  .cnt-fdr {
    padding: 35px 70px;
  }
  .EYlogo {
    width: 40px;
    left: 60px;
    top: 20px;
  }
  p.logoTxt {
    font-size: 25px;
    left: 130px;
    top: 30px;
  }
  ul.navbarMenu {
    right: 50px;
    top: 25px;
  }
  ul.navbarMenu li {
    font-size: 15px;
  }
  ul.navbarMenu li a {
    padding: 0vw 20px;
  }
  img.home {
    width: 20px;
  }
  .nav-bar {
    min-height: 90px;
  }
  ul.navbarMenu {
    right: 50px;
    top: 31px;
  }
  .footer p {
    margin-bottom: 0px;
    color: #ffffff;
    font-size: 13px;
    padding: 15px 20px;
    text-align: right;
  }
  .cf6 {
    font-size: 30px;
    margin-bottom: 0;
  }
  p.hder {
    color: #ffffff;
    font-size: 16px;
    line-height: 23px;
    margin-bottom: 10px;
  }
  .tabCol {
    padding: 50px 70px;
  }
  .profileDetails {
    margin-bottom: 25px;
  }
  img.proImg {
    width: 65px;
    margin-right: 15px;
  }
  p.proName {
    font-size: 15px;
    padding-top: 12px;
  }
  p.proDes {
    font-size: 13px;
    margin-top: -1px;
  }
  p.tabTxt {
    font-size: 14px;
    line-height: 20px;
    margin-bottom: 0;
  }
  .tabCol ul.ul_01 {
    font-size: 14px;
  }
  .tabCol ul.ul_01 li::before {
    width: 15px;
    height: 8px;
    margin-top: 6px;
    left: 0;
  }
  .tabCol ul.ul_01 li {
    position: relative;
    padding-left: 17px;
    margin-bottom: 10px;
  }
  span.s1-cf {
    font-size: 18px;
    border-top: 1px solid #ffffff63;
    border-bottom: 1px solid #ffffff63;
    padding: 11px 15px;
  }
  .col-sm-12.sm-tm-5 {
    padding: 0vw 4px;
    margin-top: 8px;
    padding-bottom: 0;
    -ms-flex: 0 0 160px;
    flex: 0 0 160px;
    max-width: 160px;
  }
  .tmImg {
    width: 56px;
    height: 56px;
    top: 24px;
    overflow: hidden;
  }
  .tmName {
    font-size: 13px;
    margin-top: 28px;
    line-height: 13px;
    margin-bottom: 3px;
  }
  .tmp2 {
    font-size: 11px;
    margin-top: 0px;
    margin-bottom: 5px;
  }
  .cf {
    min-height: 160px;
    max-height: 160px;
  }
  .cg-6 {
    font-size: 16px;
  }
  a.btn-yellow {
    background: #ffe600;
    text-align: center;
    color: #000000;
    font-size: 13px;
    text-decoration: none;
    padding: 5px 10px;
    width: 65%;
    display: inline-block;
  }
  .vidThumb {
    width: 205px;
    float: left;
    margin-right: 10px;
  }
}

@media only screen and (max-width: 800px) {
  .col-sm-4.c57 {
    -ms-flex: 0 0 100%;
    flex: 0 0 100%;
    max-width: 100%;
  }
  .tabCol {
    padding: 50px 30px;
  }
}

@media only screen and (max-width: 760px) {
  img.vid {
    position: static;
    width: 380px;
    border: 1px solid #474747;
    transform: translate(0%, 0%);
  }
  .vid-parent {
    position: relative;
    padding-right: 0px;
  }
}

@media only screen and (max-width: 600px) {
  img.vid {
    width: 100%;
  }
}

@media only screen and (max-width: 575px) {
  ul.navbarMenu {
    top: 110px;
  }
  .col-sm-12.sm-tm-5 {
    -ms-flex: 0 0 50%;
    flex: 0 0 50%;
    max-width: 50%;
  }
}

@media only screen and (max-width: 400px) {
  .col-sm-12.sm-tm-5 {
    -ms-flex: 0 0 100%;
    flex: 0 0 100%;
    max-width: 100%;
  }
}
`;

interface ICSTProps {
  onShowHome: () => void;
}

const CST: React.FC<ICSTProps> = ({ onShowHome }) => {
  React.useEffect(() => {
    const loader = document.querySelector('.loading-container') as HTMLElement | null;
    const wrapper = document.querySelector('.container_wrapper') as HTMLElement | null;

    if (loader) {
      setTimeout(() => {
        loader.style.display = 'none';
      }, 2000);
    }

    window.scrollTo(0, 0);

    setTimeout(() => {
      if (wrapper) {
        wrapper.style.display = 'block';
      }
    }, 1999);
  }, []);

  return (
    <>
      <style>{cstStyles}</style>

      <div className="loading-container" style={{ display: 'none' }}>
        <div className="item" />
        <div className="item" />
        <div className="item" />
        <div className="item" />
      </div>

      <div className="container_wrapper" style={{ display: 'block' }}>
        <div className="webPart">
          <div className="container-fluid nav-container">
            <div className="row nav-bar">
              <img
                className="EYlogo"
                src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/EY_logo.png"
                alt="EY logo"
              />
              <p className="logoTxt">MENA Tax Hub</p>
              <ul className="navbarMenu">
                <li>
                  <a data-interception="off" href="#" onClick={(event) => { event.preventDefault(); onShowHome(); }}>
                    <img className="home" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home.png" alt="Home" />
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="container-fluid">
            <div className="row">
              <div className="col-sm-12 bannerBackground">
                <div className="container-fluid cnt-fdr">
                  <div className="row">
                    <p className="cf6">MENA Tax CST (Central Support Team)</p>
                    <p className="hder">
                      Our aim is to reduce the time you spend on routine tasks and to improve governance of the MENA Tax engagement portfolio.
                      <br /> The MENA Tax CST, based in the Philippines, forms part of Global Delivery Services (GDS). The team supports MENA Tax service line (SL) engagements to enhance service delivery, by ensuring proactive coordination,
                      timely communication and efficient engagement management.
                    </p>
                    <div className="col-sm-4 c57" />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="container-fluid tabContent">
            <div className="row">
              <div className="col-sm-12 tabCol">
                <div>
                  <div className="vid-parent">
                    <p className="tabTxt txtTwo"><span className="cg-6">Our activities include:</span></p>
                    <ul className="ul_01 u2">
                      <li>New and existing entity onboarding in MDM and GIS (Create Prospect Process)</li>
                      <li>Creating new opportunity in CRM/EY Dynamics</li>
                      <li>Initiating new PACE</li>
                      <li>Setting up detailed pricing plans</li>
                      <li>Creating new engagement codes</li>
                      <li>Setting up engagement budgets</li>
                      <li>Setting up and maintaining engagement activities</li>
                      <li>Performing estimate to complete (ETC)</li>
                      <li>Performing invoice billing &amp; invoice adjustment</li>
                      <li>Updating client details (i.e., client address, client VAT ID) via MDM for invoice billing</li>
                      <li>Monitoring and following up on collections (when required)</li>
                      <li>Closing an engagement</li>
                    </ul>
                    <p className="tabTxt txtTwo">
                      This helps our Engagement team spend less time on routine Mercury processes and focus more on serving clients and winning in the market.<br /><br />
                    </p>
                    <a data-interception="off" href="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/Videos/CST%20Training%20_2-20230302_110511-Meeting%20Recording.mp4" target="_blank" rel="noreferrer">
                      <img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/VideoThumbnail.jpg" className="vid" alt="CST training" />
                    </a>
                    <a data-interception="off" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/CST%20Training%20FAQs%20V1.1.pdf" target="_blank" className="cgt7" rel="noreferrer">
                      <img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/question.png" alt="FAQs" />Click here to view FAQs
                    </a>
                  </div>
                  <span className="s1-cf">So, how does it work?</span>

                  <p className="tabTxt txtTwo">
                    <br />Engagement teams will send the request using the form below. When selecting the service required, simply input all the necessary information requested.
                  </p>
                  <p className="cf7">
                    <a data-interception="off" className="btn-yellow" href="https://apps.powerapps.com/play/e/a3c669f6-ac2e-4e77-ad43-beab3e15bee7/a/716780f0-e2a9-49e5-9fbb-d7437adc6298?tenantId=5b973f99-77df-4beb-b27d-aa0c70b8482c" target="_blank" rel="noreferrer">
                      Central Support Team - Request Form (Click here)
                    </a>
                  </p>
                  <div className="ifrme" style={{ textAlign: 'center' }}>
                    <iframe
                      id="csts"
                      src="https://apps.powerapps.com/play/e/a3c669f6-ac2e-4e77-ad43-beab3e15bee7/a/716780f0-e2a9-49e5-9fbb-d7437adc6298?tenantId=5b973f99-77df-4beb-b27d-aa0c70b8482c"
                      scrolling="no"
                      allow="geolocation *; microphone *; camera *; fullscreen *;"
                      allowFullScreen={true}
                      sandbox="allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts allow-forms allow-orientation-lock allow-downloads"
                      width="100%"
                      height="100%"
                      title="Power Apps"
                      name="webPlayer-iFrame-1"
                      style={{ boxSizing: 'border-box', border: 'none' }}
                    />
                  </div>

                  <p className="tabTxt txtTwo">
                    <span className="s1-cf">What details do I need to provide?</span>
                    <br /><span className="cg-6">A. Prospect Creation</span>
                  </p>
                  <p className="tabTxt txtTwo cgh" style={{ paddingLeft: '25px' }}>
                    <span style={{ marginLeft: '-12px' }}>1.</span> Client details must be provided completely as per the request form as well as any of the available listed legal documents below which has national ID, entity name &amp; business
                    location address given in it:
                    <br/>
                    <ul className="ul_01 u2" style={{ padding: '0 25px'}}>
                      <li>Any official letter/doc from the company representative (with registration, new name/address)</li>
                      <li>Company website of current year copyright</li>
                      <li>Email from company representative with company registered number/Commercial register with new entity name and address</li>
                      <li>Letter of incorporation (new name/address)</li>
                      <li>Any Government registered proof having registration ID</li>
                      <li>Company structure for entity onboarding process in GIS</li>
                    </ul>
                  </p>

                  <p className="tabTxt txtTwo" style={{ minHeight: 'auto' }}>
                    <span className="cg-6"> B. Opportunity Creation</span>
                  </p>
                  <p className="tabTxt txtTwo cgh" style={{ paddingLeft: '25px' }}>
                    <span style={{ marginLeft: '-12px' }}>1.</span> Essential details must be provided as per the request form
                    <br /> <span style={{ marginLeft: '-12px' }}>2.</span> Entity must be in “Data Validation Completed” status and must be linked <a data-interception="off" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/Tax_CST/PACE%20submissions%20for%20Clients%20which%20are%20not%20on%20GIS.pdf" target="_blank" rel="noreferrer">to Global Independence system</a> (except for individual and private households). Prospect creation must be requested if the entity is not properly onboarded in MDM and GIS
                  </p>

                  <p className="tabTxt txtTwo" style={{ minHeight: 'auto' }}>
                    <span className="cg-6">C. Engagement set up (Lean and Standard)</span>
                  </p>
                  <p className="tabTxt txtTwo cgh" style={{ paddingLeft: '25px' }}>
                    <span style={{ marginLeft: '-12px' }}>1.</span> Opportunity must be in “Won” status and PACE should be in “Approved” status to proceed with the engagement creation
                    <br /> <span style={{ marginLeft: '-12px' }}>2.</span> For lean engagements (TOV &lt;25K USD), the essential metrics have to be provided as per the request form (In order for the Engagement Team to provide an appropriate
                    data in high-level budget, download the <a data-interception="off" href="https://sites.ey.com/sites/MENATaxHub/SitePages/Policies_and_procedures.aspx" target="_blank" rel="noreferrer">high-level budget calculator</a> and input the necessary information to
                    come up with the metrics. This will help the Engagement Team to predict the outcome of Margin% and EAF% prior to submitting a request)
                    <br /> <span style={{ marginLeft: '-12px' }}>3.</span> For Standard Engagements (TOV&gt;25K USD), the financial metrics, resource details (Named, Unnamed &amp; GDS) and external engagement details must be provided.
                    <br /> <span style={{ marginLeft: '-12px' }}>4.</span> EL/EA/SOW must be provided (If EL/EA/SOW is not yet signed, approval from Tax Quality Leader is required by filling out the <a data-interception="off" href="https://sites.ey.com/sites/MENATaxQualityKnowledge/_layouts/15/AccessDenied.aspx?Source=https%3A%2F%2Fsites%2Eey%2Ecom%2Fsites%2FMENATaxQualityKnowledge%2FSitePages%2Fform%2Easpx&correlation=8793dea0%2D806c%2D7000%2D6063%2Dce5f631be70c&Type=item&name=49016cbf%2D9d9f%2D44f3%2D80f2%2Db636a258df94&listItemId=6&listItemUniqueId=7a254ba3%2D166e%2D4372%2D8d66%2D127f91de24b6" target="_blank" rel="noreferrer">Tax Exception: the 30-day rule monitoring form</a>)
                  </p>

                  <p className="tabTxt txtTwo" style={{ minHeight: 'auto' }}>
                    <span className="cg-6" style={{ minHeight: 'auto' }}>D. ETC (Engagement Economics)</span>
                  </p>
                  <p className="tabTxt txtTwo cgh" style={{ minHeight: 'auto', paddingLeft: '25px' }}>
                    <span style={{ marginLeft: '-12px' }}>1.</span> Engagement must be in “Released” status to proceed with the ETC request
                    <br /> <span style={{ marginLeft: '-12px' }}>2.</span> Engagement team is expected to review the latest E2E report before providing instruction in the ETC Template
                    <br /> <span style={{ marginLeft: '-12px' }}>3.</span> Provide the ETC specifics using the <a data-interception="off" href="https://sites.ey.com/sites/MENATaxHub/_layouts/15/download.aspx?UniqueId=d2239996%2D13af%2D452e%2Dbec2%2Df98dcc1f2fb9" target="_blank" rel="noreferrer" download>ETC Template</a> which can be filled for both single and bulk requests. For
                    guidance on how to use the ETC Template, please check out the video below
                  </p>

                  <div className="videoTab" style={{ paddingLeft: '25px' }}>
                    <a data-interception="off" href="https://sites.ey.com/:v:/r/sites/MENATaxHub/SiteAssets/MENATax/Videos/MENA%20Tax%20-%20ETC%20template%20guided%20video.webm" target="_blank" rel="noreferrer">
                      <img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/vid-thumb.png" className="vidThumb" alt="ETC video" />
                      <p className="hder vid-hdr">MENA Tax - ETC template guided video<br /><span>sites.ey.com</span></p>
                    </a>
                  </div>

                  <p className="tabTxt txtTwo" style={{ minHeight: 'auto' }}>
                    <span className="cg-6">E. Billing and Collections</span>
                  </p>
                  <p className="tabTxt txtTwo cgh" style={{ paddingLeft: '25px' }}>
                    <span style={{ marginLeft: '-12px' }}>1.</span> Engagement must be in “Released” status and Engagement Code must be a MENA code to proceed with the Billing Request
                    <br /> <span style={{ marginLeft: '-12px' }}>2.</span> All mandatory details to be updated
                    <br /> <span style={{ marginLeft: '-12px' }}>3.</span> For PSM Invoicing, EY Office/EY Entity code should be provided in the Client Name field; If it&apos;s a direct billed to the client, local entity should be provided in
                    the Client Name Field
                    <br /> <span style={{ marginLeft: '-12px' }}>4.</span> If technology fee is already known, update field as &apos;0%&apos; and provide the amount in the comments section
                    <br /> <span style={{ marginLeft: '-12px' }}>5.</span> For Invoice Reversal above 30 days, approval from Ghazanfar Iqbal/Paul Cooper (via email) is required
                    <br /> <span style={{ marginLeft: '-12px' }}>6.</span> EL/EA/SOW/PSM must be provided
                  </p>

                  <p className="tabTxt txtTwo" style={{ minHeight: 'auto' }}>
                    <span className="cg-6">F. Engagement Code Closure</span>
                  </p>
                  <p className="tabTxt txtTwo cgh" style={{ paddingLeft: '25px' }}>
                    <span style={{ marginLeft: '-12px' }}>1.</span> Essential details must be provided as per the Global process request form
                  </p>

                  <p className="tabTxt txtTwo" style={{ minHeight: 'auto' }}>
                    <span className="cg-6">*NOTE*</span>
                  </p>
                  <ul className="ul_01 u2" style={{ padding: '0 25px 25px' }}>
                    <li>Please ensure ALL time and expense have been charged and ALL billing issued prior to submitting this closing form</li>
                    <li>Once the engagement close process is initiated NO time, expense or billing may be processed</li>
                    <li>You can block time OR expense by accessing the &lsquo;My Engagement: Maintenance and Billing&rsquo; page in Mercury and click the engagement number hyperlink</li>
                  </ul>

                  <div className="textPhace">
                    <p className="tabTxt txtTwo">
                      <span className="s1-cf"> What happens next?</span>
                      <br />Upon submission, you will receive a notification letting you know the CST have successfully received your request. Your request will be automatically added to the workflow queue (prioritizing oldest task
                      first) to be reviewed &amp; performed.<br /><br /> We&apos;ll update you throughout the process and if any additional/missing information is required, we will reach out via email and occasionally on Teams. <span className="s-span">In order to complete your request as soon as possible and avoid any changes on ETC metrics - please aim to respond on the same working day</span><br /><br />
                      Once the request is completed, the requestor will get an automated notification confirming the case has been successfully closed.<br /><br /> <span className="s1-cf">How long will it take to complete my request?</span><br />
                      <span className="c-span">*SLA&apos;s are based on same day response &amp; no rework required</span>
                    </p>
                    <div className="framesTwo" style={{ textAlign: 'center' }}>
                      <iframe
                        id="cst"
                        src="https://sites.ey.com/sites/MENA_Tax/_layouts/15/Doc.aspx?sourcedoc={618c6ce9-288c-4b20-9bbf-82900442b414}&action=embedview&wdAr=1.7777777777777777"
                        frameBorder="0"
                        title="MENA Tax CST SLA Dashboard"
                      >
                        This is an embedded <a data-interception="off" target="_blank" href="https://office.com" rel="noreferrer">Microsoft Office</a> presentation, powered by <a data-interception="off" target="_blank" href="https://office.com/webapps" rel="noreferrer">Office</a>.
                      </iframe>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="row tabCol trs-padding">
              <span className="s1-cf">Meet The Team</span>

              <div className="col-sm-12 sm-tm-5 ">
                <div className="cf ">
                  <div className="TmBox ">
                    <div className="tmImg "><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Nomah%20Nasir.jpg" alt="Nomah Nasir" /></div>
                    <p className="tmName ">Nomah Nasir</p>
                    <p className="tmp2 ">Supervising Associate</p>
                  </div>
                </div>
              </div>

              <div className="col-sm-12 sm-tm-5 ">
                <div className="cf ">
                  <div className="TmBox ">
                    <div className="tmImg "><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Nida%20Rasool.jpg" alt="Nida Rasool" /></div>
                    <p className="tmName ">Nida Rasool</p>
                    <p className="tmp2 ">Senior Associate</p>
                  </div>
                </div>
              </div>

              <div className="col-sm-12 sm-tm-5 ">
                <div className="cf ">
                  <div className="TmBox ">
                    <div className="tmImg "><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Ahmed%20Raza%20Aftab.jpg" alt="Ahmed Raza Aftab" /></div>
                    <p className="tmName ">Ahmed Raza Aftab</p>
                    <p className="tmp2 ">Associate</p>
                  </div>
                </div>
              </div>

              <div className="col-sm-12 sm-tm-5 ">
                <div className="cf ">
                  <div className="TmBox ">
                    <div className="tmImg "><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Ayan%20Rashid.jpg" alt="Ayan Rashid" /></div>
                    <p className="tmName ">Ayan Rashid</p>
                    <p className="tmp2 ">Associate</p>
                  </div>
                </div>
              </div>

              <div className="col-sm-12 sm-tm-5 ">
                <div className="cf ">
                  <div className="TmBox ">
                    <div className="tmImg "><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Faiza%20Daood%20Shah.jpg" alt="Faiza Daood Shah" /></div>
                    <p className="tmName ">Faiza Daood Shah</p>
                    <p className="tmp2 ">Associate</p>
                  </div>
                </div>
              </div>

              <div className="col-sm-12 sm-tm-5 ">
                <div className="cf ">
                  <div className="TmBox ">
                    <div className="tmImg "><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Hazique%20Abdul%20Rehman.jpg" alt="Hazique Abdul Rehman" /></div>
                    <p className="tmName ">Hazique Abdul Rehman</p>
                    <p className="tmp2 ">Associate</p>
                  </div>
                </div>
              </div>

              <div className="col-sm-12 sm-tm-5 ">
                <div className="cf ">
                  <div className="TmBox ">
                    <div className="tmImg "><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Iqra%20Qabool.jpg" alt="Iqra Qabool" /></div>
                    <p className="tmName ">Iqra Qabool</p>
                    <p className="tmp2 ">Associate</p>
                  </div>
                </div>
              </div>

              <div className="col-sm-12 sm-tm-5 ">
                <div className="cf ">
                  <div className="TmBox ">
                    <div className="tmImg "><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Kashan%20Qamar.jpg" alt="Kashan Qamar" /></div>
                    <p className="tmName ">Kashan Qamar</p>
                    <p className="tmp2 ">Associate</p>
                  </div>
                </div>
              </div>

              <div className="col-sm-12 sm-tm-5 ">
                <div className="cf ">
                  <div className="TmBox ">
                    <div className="tmImg "><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Muhammad%20A%20Hasan.jpg" alt="Muhammad A Hasan" /></div>
                    <p className="tmName ">Muhammad A Hasan</p>
                    <p className="tmp2 ">Associate</p>
                  </div>
                </div>
              </div>

              <div className="col-sm-12 sm-tm-5 ">
                <div className="cf ">
                  <div className="TmBox ">
                    <div className="tmImg "><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Muhammad%20Muhaiudin.jpg" alt="Muhammad Muhaidin" /></div>
                    <p className="tmName ">Muhammad Muhaidin</p>
                    <p className="tmp2 ">Associate</p>
                  </div>
                </div>
              </div>

              <div className="col-sm-12 sm-tm-5 ">
                <div className="cf ">
                  <div className="TmBox ">
                    <div className="tmImg "><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Ayan%20Rashid.jpg" alt="Fazal Abbas" /></div>
                    <p className="tmName ">Fazal Abbas</p>
                    <p className="tmp2 ">Associate</p>
                  </div>
                </div>
              </div>

              <div className="col-sm-12 sm-tm-5 ">
                <div className="cf ">
                  <div className="TmBox ">
                    <div className="tmImg "><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Safiya%20Yameen.jpg" alt="Safiya Yameen" /></div>
                    <p className="tmName ">Safiya Yameen</p>
                    <p className="tmp2 ">Associate</p>
                  </div>
                </div>
              </div>

              <div className="col-sm-12 sm-tm-5 ">
                <div className="cf ">
                  <div className="TmBox ">
                    <div className="tmImg "><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Sania%20Sami.jpg" alt="Maria Arif" /></div>
                    <p className="tmName ">Maria Arif</p>
                    <p className="tmp2 ">Associate</p>
                  </div>
                </div>
              </div>

              <div className="col-sm-12 sm-tm-5 ">
                <div className="cf ">
                  <div className="TmBox ">
                    <div className="tmImg "><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Sehrish%20Akhtar.jpg" alt="Sehrish Akhtar" /></div>
                    <p className="tmName ">Sehrish Akhtar</p>
                    <p className="tmp2 ">Associate</p>
                  </div>
                </div>
              </div>

              <div className="col-sm-12 sm-tm-5 ">
                <div className="cf ">
                  <div className="TmBox ">
                    <div className="tmImg "><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Shayan%20Imran.jpg" alt="Bhadur Khan" /></div>
                    <p className="tmName ">Bhadur Khan</p>
                    <p className="tmp2 ">Associate</p>
                  </div>
                </div>
              </div>

              <div className="col-sm-12 sm-tm-5 ">
                <div className="cf ">
                  <div className="TmBox ">
                    <div className="tmImg "><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Syed%20M%20Ukasha.jpg" alt="Syed M Ukasha" /></div>
                    <p className="tmName ">Syed M Ukasha</p>
                    <p className="tmp2 ">Associate</p>
                  </div>
                </div>
              </div>

              <div className="col-sm-12 sm-tm-5 ">
                <div className="cf ">
                  <div className="TmBox ">
                    <div className="tmImg "><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Zoha%20Humayun.jpg" alt="Zoha Humayun" /></div>
                    <p className="tmName ">Zoha Humayun</p>
                    <p className="tmp2 ">Associate</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="row ">
              <div className="footer ">
                <p>&#169; 2026 EYGM Limited. All rights reserved.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default CST;
