import * as React from 'react';

const marketsStyles = `
html, body { overflow-x: hidden !important; font-family: EYInterstate; }
.markets-page { background: #2e2e38; color: #ffffff; min-height: 100vh; }
.markets-page .container_wrapper { display: block; }
.markets-page .bannerBackground { background: #2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/market-header.jpg') center / cover; min-height: 100vh; padding: 0; min-height:16vw}
.markets-page .EYlogo { left: 5vw !important; position: absolute; top: 3vw !important; width: 4vw !important; }
.markets-page .logoTxt { color: #ffffff; font-size: 2vw !important; left: 11vw !important; position: absolute; top: 4.6vw !important; }
.markets-page .navbarMenu { list-style: none; margin: 0; padding: 0; position: absolute; right: 6vw !important; top: 5vw !important; }
.markets-page .navbarMenu li { display: inline-block; }
.markets-page .navbarMenu a { color: #ffffff; padding: 0 2vw; text-decoration: none; }
.markets-page .home { width: 1.3vw; }
.markets-page .navToggle { display: none; }
.markets-page .row-2 { margin-top: 12vw; padding: 0; }
.markets-page  .hd1 {
    color: #ffe600;
    font-size: 3vw;
    width: 50%;
    line-height: 3.4vw;
    font-family: EYinterstate;
    margin-top: 9vw;
    margin-left: 5.5vw;
    margin-bottom: 2vw; }
    .row.tabCol{display:block;}
.markets-page .hd1 span { color: #ffffff; }
.markets-page .rightBox { background: #2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center / cover; padding: 2vw 4vw 4vw; width: 100%; }
.markets-page .pageQuote { min-height: 0; }
.markets-page .quoteLine { color: #ffffff; font-size: 1.05vw; font-weight: normal; line-height: 1.55; margin: 0 0 2.5vw; padding: 0; }
.markets-page .quoteLine p { margin: 0 0 1.5vw; }
.markets-page .quoteLine ul { list-style: none; margin: 0 0 1.5vw; padding: 0 0 0 1.6vw; }
.markets-page .quoteLine li { margin: .35vw 0; position: relative; }
.markets-page .quoteLine li::before { content: "";
    background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/arrow_png.png);
    position: absolute;
    width: 0.7vw;
    height: 0.6vw;
    background-size: contain;
    background-repeat: no-repeat;
       margin-top: .6vw;
    left: -1vw; }
.markets-page .m-Title { color: #ffe600; font-size: 1.5vw; margin: 0 0 2vw; }
.markets-page .teamGrid { display: flex; flex-wrap: wrap; gap: .6vw; }
.markets-page .teamCard { background: rgba(255, 255, 255, .08); flex: 0 0 14vw; margin: 0 0 1.6vw; min-height: 14vw; padding: 1vw .6vw; text-align: center; }
.markets-page .tmImg { background: #000000; border-radius: 50%; height: 5.5vw; margin: 0 auto 1vw; overflow: hidden; width: 5.5vw; }
.markets-page .tmImg img { height: 100%; object-fit: cover; width: 100%; }
.markets-page .tmName { color: #ffe600; font-size: 1vw; font-weight: 700; margin: 0; }
.markets-page .tmp2, .markets-page .tmProfile { color: #ffffff; font-size: .8vw; line-height: 1.45; margin: .4vw 0; }
.markets-page .footerTab { background: #1a1a24; padding: 5vw; }
.markets-page .quicklinks { color: #ffffff; display: block; font-size: 1.3vw; margin: 0 0 2vw; width: 100%; }
.markets-page .quickLinksGrid { display: flex; flex-wrap: wrap; margin: 0 -.4vw; }
.markets-page .quickLink { flex: 0 0 20%; max-width: 20%; padding: .4vw; }
.markets-page .footerTab > .row { display: flex; flex-wrap: wrap; margin: 0 -.4vw; }
.markets-page .footerTab .cl-3 { flex: 0 0 20%; max-width: 20%; padding: .4vw; }
.markets-page .footerTab .cl-3 > a { color: #ffffff; display: block; height: 100%; text-decoration: none; }
.markets-page .quickLink a { color: #ffffff; text-decoration: none; }
.markets-page .col-sm-bx { background: #ffffff0f url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center / cover; box-shadow: 0 0 1.5vw rgba(0, 0, 0, .44); min-height: 7.5vw; position: relative; }
.markets-page .img-bx { background-position: center; background-size: 160%; bottom: 0; left: 0; position: absolute; top: 0; transition: all .2s ease-in-out; width: 37%; }
.markets-page .col-sm-bx:hover .img-bx { background-size: 190%; }
.markets-page .bx-link { font-size: 1vw; left: 45%; line-height: 1.4vw; margin: 0; padding-right: 1vw; position: absolute; top: 2.6vw; width: 44%; }
.markets-page .bx-link strong { display: block; font-size: .8vw; opacity: .5; }
.markets-page .col-sm-bx span { bottom: .3vw; color: rgba(255, 255, 255, .52); font-size: 2vw; font-weight: bold; position: absolute; right: 1vw; }
.markets-page .footer { background: #000000; }
.markets-page .footer p { color: #ffffff; margin: 0; padding: 1vw 2vw; text-align: right; }
@media only screen and (max-width: 1200px) { .markets-page .bx-link { font-size: 13px; left: 45%; top: 20px; line-height: 14px; padding-right: 30px; } .markets-page .col-sm-bx span { bottom: 0; font-size: 15px; right: 10px; } .markets-page .col-sm-bx { min-height: 70px; } }
@media only screen and (max-width: 992px) { .markets-page .teamCard { flex-basis: 33.3333%; max-width: calc(33.3333% - .8vw); } .markets-page .quickLink, .markets-page .footerTab .cl-3 { flex-basis: 33.3333%; max-width: 33.3333%; } }
@media only screen and (max-width: 768px) { .markets-page .quickLink, .markets-page .footerTab .cl-3 { flex-basis: 50%; max-width: 50%; } }
@media only screen and (max-width: 575px) { .markets-page .bannerBackground { min-height: 0; } .markets-page .EYlogo { top: 30px !important; width: 40px !important; } .markets-page .logoTxt { font-size: 25px !important; left: 130px !important; top: 30px !important; } .markets-page .navbarMenu { right: 50px !important; top: 60px !important; } .markets-page .home { width: 20px; } .markets-page .row-2 { margin-top: 110px; } .markets-page .hd1 { font-size: 40px; line-height: 36px; margin-top: 70px; width: 100%; } .markets-page .teamCard { flex-basis: 100%; max-width: 100%; } .markets-page .m-Title { font-size: 20px; } .markets-page .tmImg { height: 60px; width: 60px; } .markets-page .tmName { font-size: 13px; } .markets-page .tmp2, .markets-page .tmProfile { font-size: 11px; } }
@media only screen and (max-width: 500px) { .markets-page .quickLink, .markets-page .footerTab .cl-3 { flex-basis: 100%; max-width: 100%; } }
`;

interface IMarketTeam { name: string; rank: string; details: string; image?: string; }
interface IMarketQuickLink { name: string; order: number; url?: string; image?: string; status?: string; }
interface IMarketsProps { onShowHome: () => void; }
interface IPageIntroduction { LeaderTitle?: string; LeaderQuote?: string; }
interface ITeamResponse { d: { results: Array<{ Rank?: string; ProfileDetails?: string; ProfileName?: { Title?: string }; File?: { Name?: string } }> }; }
interface IIntroductionResponse { d: { results: IPageIntroduction[] }; }

const apiRoot = 'https://sites.ey.com/sites/MENA_Tax/';
const imageRoot = `${apiRoot}SiteAssets/MENATax/`;
const defaultQuickLinks: IMarketQuickLink[] = [
  { name: 'TAL programme', order: 1, url: `${apiRoot}SitePages/TAL%20programme.aspx`, image: `${imageRoot}images/FY23%20tax%20account%20planning%20template.png` },
  { name: 'Pipeline Management - EY CRM Dynamics', order: 2, url: `${apiRoot}SitePages/Pipeline%20Management.aspx`, image: `${imageRoot}Markets/mercury-management.png` },
  { name: 'Deal Review Process', order: 3, url: `${apiRoot}SitePages/Deal%20Review%20Process.aspx`, image: `${imageRoot}Markets/deal-review-icon.png` },
  { name: 'CX Lens - Our client feedback journey', order: 4, url: 'https://sites.ey.com/:u:/r/sites/MENA_Tax/SitePages/CX%20lens.aspx', image: `${imageRoot}Markets/feedback.png` },
  { name: 'Win-wire - Our successes in the market', order: 5, url: 'https://sites.ey.com/:u:/r/sites/MENA_Tax/SitePages/Win-wire.aspx', image: `${imageRoot}Markets/success.png` },
  { name: 'External marketing', order: 6, url: `${apiRoot}SitePages/External-marketing.aspx`, image: `${imageRoot}Markets/external-marketing.png` },
  { name: 'Management information reporting', order: 7, url: `${apiRoot}SitePages/Management-information-Reporting.aspx`, image: `${imageRoot}Markets/management.png` },
  { name: 'Pricing', order: 8, image: `${imageRoot}Markets/pricing.png`, status: '(Coming soon)' },
  { name: 'MENA Tax Knowledge and Publications', order: 9, url: `${apiRoot}SitePages/MENA-Tax-Knowledge-and-Publications.aspx`, image: `${imageRoot}Markets/mercury-management.png` }
];

const decodeHtml = (value: string): string => {
  const textarea = document.createElement('textarea');
  textarea.innerHTML = value;
  return textarea.value;
};

const MenaTaxMarkets: React.FC<IMarketsProps> = ({ onShowHome }) => {
  const [team, setTeam] = React.useState<IMarketTeam[]>([]);
  const quickLinks = defaultQuickLinks;
  const [introduction, setIntroduction] = React.useState<IPageIntroduction>({});

  React.useEffect(() => {
    const headers = { accept: 'application/json;odata=verbose' };
    const load = async (): Promise<void> => {
      const [teamResponse, introResponse] = await Promise.all([
        fetch(`${apiRoot}_api/web/lists/getByTitle('TeamDetails')/items?$select=Title,Rank,ProfileDetails,ProfileName/Title,File/Name&$expand=ProfileName,File`, { headers }),
        fetch(`${apiRoot}_api/web/lists/getByTitle('PageIntroduction')/items?$select=Title,LeaderTitle,LeaderQuote`, { headers })
      ]);
      const teamData = await teamResponse.json() as ITeamResponse;
      const introData = await introResponse.json() as IIntroductionResponse;
      setTeam(teamData.d.results.map((item) => ({ name: item.ProfileName?.Title || item.Rank || '', rank: item.Rank || '', details: item.ProfileDetails || '', image: item.File?.Name ? `${apiRoot}TeamDetails/${item.File.Name}` : undefined })));
      const pageIntroduction = introData.d.results[0] || {};
      setIntroduction({ ...pageIntroduction, LeaderQuote: pageIntroduction.LeaderQuote ? decodeHtml(pageIntroduction.LeaderQuote) : '' });
    };
    void load();
  }, []);

  return (
    <div className="markets-page">
      <style>{marketsStyles}</style>
      <div className="container_wrapper">
        <div className="webPart">
          <div className="container-fluid bannerBackground">
            <div className="row">
              <img className="EYlogo" src={`${imageRoot}images/EY_logo.png`} alt="EY logo" />
              <p className="logoTxt">MENA Tax Hub</p>
              <ul className="navbarMenu"><li><a data-interception="off" href="#" onClick={(event) => { event.preventDefault(); onShowHome(); }}><img className="home" src={`${imageRoot}images/home.png`} alt="Home" /></a></li></ul>
              <img className="navToggle" src={`${imageRoot}images/toggle.png`} alt="Navigation toggle" />
            </div>
            <div className="row row-2">
              <p className="hd1">MENA<br /><span>Tax Markets</span></p>
              
              </div>
              </div>
              <div className="rightBox">
                <div id="PageContent">
                  <div className="profileDetails" />
                  <div className="pageQuote"><div className="quoteLine" dangerouslySetInnerHTML={{ __html: introduction.LeaderQuote || '' }} /></div>
                </div>
                <div className="row tabCol" id="team-container">
                  <p className="m-Title">MENA Tax Markets team</p>
                  <div className="teamGrid">
                    {team.map((member) => <div className="teamCard" key={`${member.name}-${member.rank}`}><div className="tmImg">{member.image && <img src={member.image} alt={member.name} />}</div><p className="tmName">{member.name}</p><p className="tmp2">{member.rank}</p><p className="tmProfile">{member.details}</p></div>)}
                  </div>
                </div>
              </div>
            
          
          <div className="container-fluid footerTab">
            <div className="row">
              <div className="col-sm-12"><p className="quicklinks">Quick links</p></div>
              {quickLinks.map((link) => <div className="col-sm-3 cl-3" key={link.order}><a data-interception="off" href={link.url} target="_blank" rel="noreferrer"><div className="col-sm-bx"><div className="img-bx" style={{ backgroundImage: `url(${link.image})` }} /><p className="bx-link">{link.name}{link.status && <strong>{link.status}</strong>}</p><span>{link.order < 10 ? `0${link.order}` : String(link.order)}</span></div></a></div>)}
            </div>
          </div>
        </div>
        <div className="footer"><p>&#169; 2026 EYGM Limited. All rights reserved.</p></div>
      </div>
    </div>
  );
};

export default MenaTaxMarkets;
