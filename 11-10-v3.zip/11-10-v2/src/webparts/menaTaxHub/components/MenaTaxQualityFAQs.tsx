import * as React from 'react';

const faqStyles = `
  .menaFaqs {
    background: #2e2e38;
    color: #ffffff;
    font-family: EYInterstate, Arial, sans-serif;
  }

  .menaFaqs__banner {
    background-color: #2e2e38;
    background-image: url('https://sites.ey.com/sites/MENATaxQualityKnowledge/SiteAssets/MENA_Tax_Qaulity_Knowledge/images/GettyImages-1130492410.jpg');
    background-position: center;
    background-size: cover;
    min-height: 30vh;
    padding: 0 5vw;
    position: relative;
  }

  .menaFaqs__user {
    align-items: center;
    display: flex;
    gap: 1vw;
    justify-content: flex-end;
    padding-top: 4vw; display:none;
  }

  .menaFaqs__user p {
    font-size: 1vw;
    margin: 0;
  }

  .menaFaqs__user img {
    border-radius: 50%;
    height: 2.5vw;
    object-fit: cover;
    width: 2.5vw;
  }

  .menaFaqs__logo {
    display: block;
    padding-top: 3vw;
    width: 3vw;
  }

  .menaFaqs__title {
    color: #ffffff;
    font-size: 2vw;
    line-height: 3.3vw;
    margin: 3vw 0 0;
  }

  .menaFaqs__content {
    background-color: #2e2e38;
    background-image: url('https://sites.ey.com/sites/MENATaxQualityKnowledge/SiteAssets/MENA_Tax_Qaulity_Knowledge/images/bgm.png');
    background-position: center;
    background-size: cover;
    padding: 3vw 7vw;
  }

  .menaFaqs__section {
    border-bottom: 1px solid rgba(255, 255, 255, 0.24);
  }
.menaFaqs__section button{}
  .menaFaqs__trigger {
    align-items: center;
    background: transparent;
    border: 0;
    color: #ffffff;
    cursor: pointer;
    display: flex;
    font-family: inherit;
    font-size: 1.3vw;
    justify-content: space-between;
    line-height: 1.8vw;
    padding: 0.8vw 0;
    text-align: left;
    width: 100%;
  }

  .menaFaqs__trigger:hover,
  .menaFaqs__trigger:focus {
    color: #ffe600;
  }

  .menaFaqs__icon {
    color: #ffe600;
    flex: 0 0 auto;
    font-size: 1.5vw;
    margin-left: 1vw;
  }

  .menaFaqs__answer {
    color: #ffffff;
    font-family: Arial, sans-serif;
    font-size: 1vw;
    line-height: 1.6;
    padding: 0 2vw 1.5vw;
  }

  .menaFaqs__answer p {
    margin: 0 0 1vw;
  }

  .menaFaqs__answer ul {
    margin: 0 0 1vw;
    padding-left: 2vw;
  }

  .menaFaqs__answer a {
    color: #ffe600;
  }

  .menaFaqs__footer {
    background: #000000;
    color: #ffffff;
    font-size: 1vw;
    padding: 1vw 2vw;
    text-align: right;
  }

  .menaFaqs__back {
    background: #ffe600;
    border: 0;
    color: #2e2e38;
    cursor: pointer;
    font-weight: 700;
    margin: 1vw 0 0 2vw;
    padding: 0.6vw 1vw;
  }

  @media only screen and (max-width: 1200px) {
    .menaFaqs__user { padding-top: 55px; }
    .menaFaqs__user p { font-size: 12px; }
    .menaFaqs__user img { height: 32px; width: 32px; }
    .menaFaqs__logo { margin-top: 46px; width: 35px; }
    .menaFaqs__title { font-size: 25px; line-height: 30px; margin-top: 40px; }
    .menaFaqs__trigger { font-size: 18px; line-height: 26px; }
    .menaFaqs__answer { font-size: 13px; line-height: 20px; }
    .menaFaqs__footer { font-size: 12px; padding: 10px 20px; }
  }

  @media only screen and (max-width: 575px) {
    .menaFaqs__banner { min-height: auto; padding-bottom: 30px; }
    .menaFaqs__content { padding: 20px 40px; }
    .menaFaqs__trigger { font-size: 16px; line-height: 23px; }
    .menaFaqs__icon { font-size: 18px; }
    .menaFaqs__answer { padding: 0 0 18px; }
    .menaFaqs__back { margin: 12px 0 0 20px; }
  }
`;

interface IMenaTaxQualityFAQsProps {
  onShowHome: () => void;
}

interface IFaqItem {
  question: string;
  answer: React.ReactNode;
}

const faqSections: Array<{ title: string; items: IFaqItem[] }> = [
  {
    title: 'Tax Quality (TQ) essentials',
    items: [
      {
        question: 'How to achieve effective MENA Tax Quality (TQ) consultation?',
        answer: (
          <>
            <p>Experience shows that engagement teams that consult as early as possible, and provide detailed background information from the outset, get quicker and better responses.</p>
            <p>Before approaching TQ, reference relevant guidance and consult the TQ Champion dedicated to your jurisdiction. A productive consultation should include:</p>
            <ul>
              <li>The full legal name of the client</li>
              <li>The scope of the proposed work, including the SORT code</li>
              <li>Relevant contractual frameworks, such as MSAs or GFAs</li>
              <li>Approximate fees and any non-standard fee arrangements</li>
              <li>Third-party involvement and prior Quality or RM/Legal involvement</li>
            </ul>
            <p>For complicated matters, use a phone call, face-to-face meeting, or email rather than lengthy Teams chats so the consultation can be properly documented.</p>
          </>
        )
      },
      {
        question: 'If a client asks us to raise an invoice to another entity of its group, what do we do?',
        answer: <p>Push back first. If the client persists, obtain proof that the entity is part of the client group, update the PACE form, issue a variation letter, and clarify that the original client remains ultimately responsible for the fees and liability.</p>
      },
      {
        question: 'Where can we find the list of TQ Champions?',
        answer: <p>The list is available on the <a data-interception="off" href="https://sites.ey.com/sites/MENATaxQualityKnowledge/SitePages/TQchampions.aspx" target="_blank" rel="noreferrer">MENA TQ SharePoint site</a>.</p>
      },
      {
        question: 'What is the policy around sharing deliverables in editable format?',
        answer: <p>Our standard policy is not to share editable deliverables. Ask why the client needs the editable version and assess the risk with the Partner, who remains responsible for the decision.</p>
      },
      {
        question: 'When do time reversals require approval from TQ?',
        answer: <><p>Time reversals require approval as follows:</p><ul><li>0-20 hours: EP</li><li>20-40 hours: SSL</li><li>40 hours or above: TQL</li></ul></>
      },
      {
        question: "Where can I obtain EY's Professional Indemnity Insurance certificate?",
        answer: <p>A copy of the certificate can be located on the <a data-interception="off" href="https://sites.ey.com/sites/MENAGCOSharePoint/SitePages/MENA-Professional-Indemnity-Insurance-(PII).aspx" target="_blank" rel="noreferrer">GCO SharePoint site</a>.</p>
      }
    ]
  },
  {
    title: 'Process for Acceptance of Clients and Engagements (PACE)',
    items: []
  },
  {
    title: 'Contracting',
    items: [
      {
        question: 'Is it possible to amend or remove clauses from standard GTCs?',
        answer: <p>Refer first to the Global Business Guidelines Non-Audit GTCs and the contracting guidance. These resources explain when consultation with GCO is required and which additional approvals may be needed.</p>
      },
      {
        question: 'Can we use an addendum instead of a variation letter?',
        answer: <p>Addendum and variation letters serve the same purpose. An EY variation/addendum template is available in the <a data-interception="off" href="https://sites.ey.com/sites/MENAGCOSharePoint/Shared%20Documents/Forms/AllItems.aspx" target="_blank" rel="noreferrer">GCO repository</a>.</p>
      },
      {
        question: 'How do we implement a client data protection agreement request?',
        answer: <p>Consult MENA TQ and GCO before sharing or signing additional data protection agreements. All client requests must be reviewed internally before signing.</p>
      },
      {
        question: 'Is a new Engagement Agreement mandatory every year for recurring tax services?',
        answer: <p>Engagement agreements should be valid for the project duration. Agreements for recurring annual services must not remain effective for more than five years without a review of their terms.</p>
      },
      {
        question: 'Where can we find the Acknowledgment Agreement?',
        answer: <p>It is available under the Cross-border contracting guidance document. It should be used only when local billing under a PSM is necessary.</p>
      },
      {
        question: 'What are the requirements of a PSM?',
        answer: <p>The Prime Member Firm remains solely responsible and liable to the client. It must ensure the Engagement Agreement is signed, issue a PSM in line with the EAGP, satisfy itself about local work quality, and retain required working papers.</p>
      }
    ]
  },
  {
    title: 'EYI MyDocs',
    items: [
      {
        question: 'Are all client communications required to be filed under EYI during a project?',
        answer: <p>Yes. All key emails should be filed during the project so the EYI folder tells the engagement story from beginning to end. Refer to the Global Tax Service Line Policy and EYI MyDocs Global Protocols for further guidance.</p>
      }
    ]
  },
  { title: 'Tax Technology Approval Roadmap (TTAR)', items: [] },
  { title: 'Deal Review', items: [] }
];

const MenaTaxQualityFAQs: React.FC<IMenaTaxQualityFAQsProps> = ({ onShowHome }) => {
  const [openSection, setOpenSection] = React.useState<string | null>(faqSections[0].title);
  const [openQuestion, setOpenQuestion] = React.useState<string | null>(null);

  const toggleSection = (title: string): void => {
    setOpenSection((current) => current === title ? null : title);
    setOpenQuestion(null);
  };

  const toggleQuestion = (questionKey: string): void => {
    setOpenQuestion((current) => current === questionKey ? null : questionKey);
  };

  return (
    <div className="menaFaqs">
      <style>{faqStyles}</style>
      <header className="menaFaqs__banner">
        <a data-interception="off" href="#" onClick={(event) => { event.preventDefault(); onShowHome(); }} style={{ position: 'absolute', right: '5vw', top: '2vw' }}>
          <img className="home" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home.png" alt="Home" style={{ width: '1.3vw' }} />
        </a>
        <div className="menaFaqs__user">
          <p>Hi Hiran Jose</p>
          <img src="https://sites.ey.com/sites/MENAInnovation/_layouts/15/userphoto.aspx?size=M&amp;accountname=Hiran.Jose@gds.ey.com" alt="Current user" />
        </div>
        <a data-interception="off" href="https://sites.ey.com/sites/MENATaxQualityKnowledge/SitePages/MENA_Tax_Quality.aspx" target="_blank" rel="noreferrer">
          <img className="menaFaqs__logo" src="https://sites.ey.com/sites/MENATaxQualityKnowledge/SiteAssets/MENA_Tax_Qaulity_Knowledge/images/EY_logo.png" alt="EY logo" />
        </a>
        <h1 className="menaFaqs__title">MENA Tax Quality FAQs</h1>
      </header>
      <main className="menaFaqs__content" id="mena-tax-quality-faqs">
        {faqSections.map((section, sectionIndex) => {
          const sectionOpen = openSection === section.title;
          const sectionId = `faq-section-${sectionIndex}`;
          return (
            <section className="menaFaqs__section" key={section.title}>
              <button type="button" className="menaFaqs__trigger" aria-expanded={sectionOpen} aria-controls={sectionId} onClick={() => toggleSection(section.title)}>
                <span>{section.title}</span>
                <span className="menaFaqs__icon" aria-hidden="true">{sectionOpen ? '-' : '+'}</span>
              </button>
              <div id={sectionId} hidden={!sectionOpen}>
                {sectionOpen && section.items.length > 0 && section.items.map((item, questionIndex) => {
                    const questionKey = `${sectionIndex}-${questionIndex}`;
                    const questionId = `faq-question-${questionKey}`;
                    const answerId = `faq-answer-${questionKey}`;
                    const questionOpen = openQuestion === questionKey;
                    return (
                      <div key={questionKey}>
                        <button type="button" id={questionId} className="menaFaqs__trigger" aria-expanded={questionOpen} aria-controls={answerId} onClick={() => toggleQuestion(questionKey)}>
                          <span>{item.question}</span>
                          <span className="menaFaqs__icon" aria-hidden="true">{questionOpen ? '-' : '+'}</span>
                        </button>
                        {questionOpen && <div id={answerId} className="menaFaqs__answer" role="region" aria-labelledby={questionId}>{item.answer}</div>}
                      </div>
                    );
                })}
              </div>
            </section>
          );
        })}
      </main>
      <footer className="menaFaqs__footer">&#169; 2026 EYGM Limited. All rights reserved.</footer>
    </div>
  );
};

export default MenaTaxQualityFAQs;
