import * as React from 'react';

const onshoreStyles = `
  .onshoreResourcing { background: #2e2e38; color: #ffffff; font-family: EYInterstate, Arial, sans-serif; overflow: hidden; }
  .onshoreResourcing__nav { background: #2e2e38; min-height: 6vw; position: relative; }
  .onshoreResourcing__nav .EYlogo { left: 5vw; position: absolute; top: 1.5vw; width: 3vw; }
  .onshoreResourcing__nav .logoTxt { color: #ffffff; font-size: 2vw; left: 11vw; margin: 0; position: absolute; top: 2.2vw; }
  .onshoreResourcing__nav .navLinks { display: flex; gap: 1vw; list-style: none; margin: 0; padding: 0; position: absolute; right: 6vw; top: 2.4vw; }
  .onshoreResourcing__nav .navLinks a { align-items: center; color: #ffffff; display: flex; font-size: 1vw; gap: .5vw; text-decoration: none; }
  .onshoreResourcing__nav .navLinks img { width: 1vw; }
  .onshoreResourcing__nav .navLinks img.home { width: 1.3vw; }
  .onshoreResourcing__nav .navToggle { display: none; }
  .onshoreResourcing__hero { background-color: #2e2e38; background-image: url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/banner-images-onshore.png'); background-position: center; background-size: cover; min-height: 17vw; padding: 0 5vw; }
  .onshoreResourcing__hero h1 { border-bottom: 2px solid #ffffff; font-size: 1.9vw; margin: 0 0 1.3vw 1vw; padding-top: 5vw; padding-bottom: 3px; width: 34vw; }
  .onshoreResourcing__hero hr { border: 0; border-top: .2vw solid #ffe600; margin: 0 0 0 1.2vw; width: 3vw; }
  .onshoreResourcing__main { background-image: url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png'); background-position: center; background-size: cover; }
  .onshoreResourcing__intro { background: rgba(0, 0, 0, .09); border-bottom: .1vw solid #363636; padding: 2vw 6vw 1vw; }
  .onshoreResourcing__intro p, .onshoreResourcing__accordionBody li { font-family: Arial, sans-serif; font-size: 1vw; line-height: 1.5; }
  .onshoreResourcing__accordion { padding: 0 6vw 2vw; }
  .onshoreResourcing__item { border-bottom: 1px solid rgba(255, 255, 255, .25); }
  .onshoreResourcing__heading { color: #ffe600; font-size: 1.3vw; margin: 1.2vw 0 .6vw; }
  .onshoreResourcing__accordionBody { padding-bottom: .5vw; }
  .onshoreResourcing__accordionBody ul { list-style: none; margin: 0; padding: 0; }
  .onshoreResourcing__accordionBody li { margin-bottom: .6vw; padding-left: 1.5vw; position: relative; }
  .onshoreResourcing__accordionBody li::before { color: #ffe600; content: '>'; left: 0; position: absolute; }
  .onshoreResourcing__accordionBody a { color: #ffe600; font-weight: 700; }
  .onshoreResourcing__team { padding: 0 6vw 2vw; }
  .onshoreResourcing__sectionTitle { border-bottom: 1px solid rgba(255, 255, 255, .4); border-top: 1px solid rgba(255, 255, 255, .4); color: #ffffff; display: block; font-size: 1.4vw; margin: 0 0 2vw; padding: 1vw 0; }
  .onshoreResourcing__teamGrid { display: grid; gap: .8vw; grid-template-columns: repeat(5, 1fr); }
  .onshoreResourcing__person { background: rgba(255, 255, 255, .06); min-height: 13vw; padding: 1vw .4vw; text-align: center; }
  .onshoreResourcing__person img { border-radius: 50%; height: 5.5vw; object-fit: cover; width: 5.5vw; }
  .onshoreResourcing__person strong { color: #ffe600; display: block; font-size: .9vw; margin-top: 1vw; }
  .onshoreResourcing__person span { display: block; font-size: .8vw; margin-top: .4vw; }
  .onshoreResourcing__footer { background: #000000; color: #ffffff; font-size: 1vw; padding: 1vw 2vw; text-align: right; }
  .onshoreResourcing__back { align-items: center; background: #ffe600; border: 0; color: #000000; cursor: pointer; display: flex; font-weight: 700; gap: .5vw; margin: 1vw 0 0 2vw; padding: .6vw 1vw; }
  .onshoreResourcing__back img { width: 1vw; }
  @media only screen and (max-width: 1200px) {
    .onshoreResourcing__nav { min-height: 90px; }
    .onshoreResourcing__nav .EYlogo { left: 60px; top: 20px; width: 40px; }
    .onshoreResourcing__nav .logoTxt { font-size: 25px; left: 130px; top: 30px; }
    .onshoreResourcing__nav .navLinks { right: 50px; top: 31px; }
    .onshoreResourcing__nav .navLinks a { font-size: 13px; }
    .onshoreResourcing__nav .navLinks img { width: 13px; }
    .onshoreResourcing__nav .navLinks img.home { width: 20px; }
    .onshoreResourcing__hero { min-height: 220px; }
    .onshoreResourcing__hero h1 { font-size: 30px; padding-top: 70px; width: 420px; }
    .onshoreResourcing__intro p, .onshoreResourcing__accordionBody li { font-size: 14px; }
    .onshoreResourcing__heading { font-size: 18px; }
    .onshoreResourcing__sectionTitle { font-size: 18px; }
    .onshoreResourcing__person strong { font-size: 13px; }
    .onshoreResourcing__person span { font-size: 11px; }
    .onshoreResourcing__footer { font-size: 13px; }
  }
  @media only screen and (max-width: 800px) {
    .onshoreResourcing__hero { min-height: 190px; }
    .onshoreResourcing__teamGrid { grid-template-columns: repeat(3, 1fr); }
  }
  @media only screen and (max-width: 575px) {
    .onshoreResourcing__nav .navLinks { top: 110px; }
    .onshoreResourcing__nav .navLinks a { font-size: 12px; }
    .onshoreResourcing__hero { min-height: 170px; padding: 0 30px; }
    .onshoreResourcing__hero h1 { font-size: 24px; padding-top: 55px; width: 100%; }
    .onshoreResourcing__intro, .onshoreResourcing__accordion, .onshoreResourcing__team { padding-left: 30px; padding-right: 30px; }
    .onshoreResourcing__heading { font-size: 17px; line-height: 23px; }
    .onshoreResourcing__teamGrid { grid-template-columns: repeat(2, 1fr); }
    .onshoreResourcing__person { min-height: 180px; }
    .onshoreResourcing__person img { height: 80px; width: 80px; }
    .onshoreResourcing__back { margin-left: 20px; }
  }
  @media only screen and (max-width: 400px) {
    .onshoreResourcing__teamGrid { grid-template-columns: 1fr; }
  }
`;

interface IOnshoreResourcingProps {
  onShowResourcing: () => void;
  onShowHome: () => void;
}

const OnshoreResourcing: React.FC<IOnshoreResourcingProps> = ({ onShowResourcing, onShowHome }) => {
  return (
    <div className="onshoreResourcing">
      <style>{onshoreStyles}</style>
      <nav className="onshoreResourcing__nav">
        <img className="EYlogo" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/EY_logo.png" alt="EY logo" />
        <p className="logoTxt">MENA Tax Hub</p>
        <ul className="navLinks">
          <li><a data-interception="off" href="#resourcing"><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/back-button_resource-hub.png" alt="" />Back</a></li>
          <li><a data-interception="off" href="#" onClick={(event) => { event.preventDefault(); onShowHome(); }}><img className="home" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home.png" alt="Home" /></a></li>
        </ul>
        <img className="navToggle" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/toggle.png" alt="Navigation toggle" />
      </nav>
      <header className="onshoreResourcing__hero">
        <h1>Onshore Resourcing</h1>
        <hr />
      </header>
      <main className="onshoreResourcing__main">
        <section className="onshoreResourcing__intro">
          <p>Onshore resources are associated with high costs to deliver, which in turn impacts expected margins. As profit margins become a decisive factor in onshore staffing decisions, the high direct costs associated with onshore resources, such as salaries, are shifting demand towards locations with lower costs.</p>
          <p>Cost remains a key element when considering/ validating value driven from an onshore vs. offshore resource, and the following considerations are integral to making the right resourcing decision.</p>
        </section>
        <section className="onshoreResourcing__accordion">
          <div className="onshoreResourcing__item">
            <h2 className="onshoreResourcing__heading">Key Considerations:</h2>
            <div className="onshoreResourcing__accordionBody">
              <ul>
                <li>Is this request within your SSL Financial plan?</li>
                <li>Have you reviewed utilization of onshore resources against capacity and rank utilization expectations?</li>
                <li>Are Internal promotion/ progression opportunities an option?</li>
                <li>Are the types of skills required available internally?</li>
                <li>Have you reviewed utilization of sponsored GDS FTE, GDS T&amp;M and Rapid pool against expectations?</li>
                <li>Have you considered offshoring the role? If not, what is stopping you?</li>
                <li>Would FTTE, contractors, and manpower agencies be suitable?</li>
                <li>Consider the effects on your current Nationalization, and Diversity &amp; Inclusivity objectives, particularly when considering expatriates.</li>
              </ul>
            </div>
          </div>
          <div className="onshoreResourcing__item">
            <h2 className="onshoreResourcing__heading">What happens next?</h2>
            <div className="onshoreResourcing__accordionBody">
              <ul>
                <li>Carry out an assessment of your current state using the <a data-interception="off" href="https://app.powerbi.com/groups/me/apps/88b138f5-216c-4ac6-b72a-a19e005bd381/reports/224a0ea2-bd8c-4441-b136-31641b8a8103/ReportSectionbd6d72f0b28d653ff863?ctid=5b973f99-77df-4beb-b27d-aa0c70b8482c&amp;experience=power-bi" target="_blank" rel="noreferrer">Tax People Dashboard</a>, <a data-interception="off" href="https://app.powerbi.com/groups/me/apps/88b138f5-216c-4ac6-b72a-a19e005bd381/reports/db646e19-5e24-4e38-accc-9a8c2e8743e9/ReportSection?ctid=5b973f99-77df-4beb-b27d-aa0c70b8482c&amp;chromeless=1&amp;experience=power-bi" target="_blank" rel="noreferrer">Finance &amp; Engagement Dashboard</a></li>
                <li>If your request aligns with the considerations above and the Financial Plan, proceed with raising a resource request on the <a data-interception="off" href="https://apps.powerapps.com/play/e/a3c669f6-ac2e-4e77-ad43-beab3e15bee7/a/8617d89c-6f71-4969-ace8-5904bcfefc65?tenantId=5b973f99-77df-4beb-b27d-aa0c70b8482c&amp;source=portal&amp;screenColor=rgba%280%2c+176%2c+240%2c+1%29&amp;skipAppMetadata=true" target="_blank" rel="noreferrer">MENA Tax Hiring Tool</a></li>
                <li>Your request would be routed through EXM (Experience Management), SSL leader and COO for approval</li>
                <li>Once fully approved, an automated email is generated and sent to the appropriate recruitment team for next steps</li>
                <li>Typical turnaround time for approval is between 2- 4 business days</li>
                <li>For requests that do not meet the requirements, please connect with your respective EXM contact for any additional information and guidance on the optimal approach to fulfil your requirement along with a business case.</li>
              </ul>
            </div>
          </div>
          <div className="onshoreResourcing__item">
            <h2 className="onshoreResourcing__heading">Cost components:</h2>
            <div className="onshoreResourcing__accordionBody">
              <ul>
                <li>Cost of the onshore resources will be guided by the EY salary banding for that rank and location. Alternatively please feel free to use the "MENA Tax - Cost Comparison App"</li>
              </ul>
            </div>
          </div>
        </section>
        <section className="onshoreResourcing__team">
          <span className="onshoreResourcing__sectionTitle">Meet The Team</span>
          <div className="onshoreResourcing__teamGrid">
            <div className="onshoreResourcing__person"><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Dania-Zalatimo.png" alt="Dania Zalatimo" /><strong>Dania Zalatimo</strong><span>Assistant Director</span><span>Tax Experience Hire Leader</span></div>
            <div className="onshoreResourcing__person"><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Farrah-Imran.png" alt="Farrah Imran" /><strong>Farrah Imran</strong><span>Assistant Director</span><span>MENA Campus Hire leader</span></div>
            <div className="onshoreResourcing__person"><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Bobin%20T.jpg" alt="Bobin T Abraham" /><strong>Bobin T Abraham</strong><span>Associate Director</span></div>
            <div className="onshoreResourcing__person"><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Dileep%20Rajasekhar.jpg" alt="Dileep Rajasekhar" /><strong>Dileep Rajasekhar</strong><span>Assistant Director</span></div>
            <div className="onshoreResourcing__person"><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Jellen%20Jose.jpg" alt="Jellen M Jose" /><strong>Jellen M Jose</strong><span>Assistant Director</span></div>
          </div>
        </section>
      </main>
      <footer className="onshoreResourcing__footer">&#169; 2026 EYGM Limited. All rights reserved.</footer>
    </div>
  );
};

export default OnshoreResourcing;
