
require("./MenaTaxHub.module.css");
const styles = {
  menaTaxHub: 'menaTaxHub_befce39d',
  teams: 'teams_befce39d',
  menuButton: 'menuButton_befce39d',
  menuOverlay: 'menuOverlay_befce39d',
  menuOverlayOpen: 'menuOverlayOpen_befce39d',
  routeLoading: 'routeLoading_befce39d',
  loadingRing: 'loadingRing_befce39d',
  routeSpin: 'routeSpin_befce39d',
  menuPanel: 'menuPanel_befce39d',
  menuLink: 'menuLink_befce39d',
  menuPanelOpen: 'menuPanelOpen_befce39d',
  menuHeader: 'menuHeader_befce39d',
  menuClose: 'menuClose_befce39d',
  menuItemActive: 'menuItemActive_befce39d',
  welcome: 'welcome_befce39d',
  welcomeImage: 'welcomeImage_befce39d',
  links: 'links_befce39d'
};

export default styles;
