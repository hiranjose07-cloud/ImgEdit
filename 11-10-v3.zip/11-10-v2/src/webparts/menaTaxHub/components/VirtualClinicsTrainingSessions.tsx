import * as React from 'react';

const imageRoot = 'https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/';

interface IVirtualClinicsTrainingSessionsProps {
  onShowHome: () => void;
}

const virtualClinicsStyles = `
html,body{overflow-x:hidden!important;font-family:EYInterstate}.virtual-clinics{background:#2e2e38;color:#fff;min-height:100vh}.virtual-clinics .loading-container{align-items:center;background:#1a1a24;display:flex;inset:0;justify-content:center;position:fixed;z-index:9999}.virtual-clinics .loading-container .item{border:.2vw solid #ffe600;border-bottom-color:transparent;border-radius:50%;border-top-color:transparent;position:absolute;animation:clinic-spin 2s ease infinite}.virtual-clinics .loading-container .item:nth-child(1){height:30px;width:30px}.virtual-clinics .loading-container .item:nth-child(2){animation-delay:.1s;height:50px;width:50px}.virtual-clinics .loading-container .item:nth-child(3){animation-delay:.2s;height:70px;width:70px}.virtual-clinics .loading-container .item:nth-child(4){animation-delay:.3s;height:90px;width:90px}@keyframes clinic-spin{50%{transform:rotate(180deg)}100%{transform:rotate(0)}}.virtual-clinics .nav-bar{background:#2e2e38;min-height:6vw;position:relative}.virtual-clinics .EYlogo{left:5vw;position:absolute;top:1.5vw;width:3vw}.virtual-clinics .logoTxt{color:#fff;font-size:2vw;left:11vw;position:absolute;top:2.2vw}.virtual-clinics .navbarMenu{list-style:none;margin:0;padding:0;position:absolute;right:6vw;top:2.4vw}.virtual-clinics .navbarMenu li{display:inline-block;font-size:1vw}.virtual-clinics .navbarMenu a{color:#fff;padding:0 2vw;text-decoration:none}.virtual-clinics .home{width:1.3vw}.virtual-clinics .bannerBackground{background:#2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/banner.jpg') center/cover;min-height:8vw}.virtual-clinics .cnt-fdr{background:rgba(46,46,56,.5);min-height:8vw;padding:2vw 3.5vw}.virtual-clinics .cf6{color:#fff;font-size:1.5vw;margin:0}.virtual-clinics .tabContent{background:#2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center/cover;min-height:35vw;padding:4vw 5.5vw}.virtual-clinics .cl-3{cursor:pointer;padding:.35vw}.virtual-clinics .boxTag{display:block;text-decoration:none}.virtual-clinics .col-sm-bx{background:#ffffff0f url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center/cover;box-shadow:0 0 1.5vw rgba(0,0,0,.44);min-height:19vw;overflow:hidden;position:relative;width:100%}.virtual-clinics .img-bx{background-position:right;background-size:100%;min-height:10vw;transition:all .2s ease-in-out;width:100%}.virtual-clinics .col-sm-bx:hover .img-bx{background-size:110%}.virtual-clinics .playIcon{background:#fff;border:.3vw solid #fff;border-radius:50%;float:right;margin-right:2vw;margin-top:-1.2vw;width:2.5vw}.virtual-clinics .bx-link{color:#fff;font-size:.9vw;line-height:1.3vw;margin:0;padding:2vw 1vw 0 1.5vw}.virtual-clinics .footer{background:#000;float:left;width:100%}.virtual-clinics .footer p{font-size:1vw;margin:0;padding:1vw 2vw;text-align:right}
 .col-sm-3 {
        -ms-flex: 0 0 20%;
        flex: 0 0 20%;
        max-width: 20%;
    }
@media(max-width:1200px){.virtual-clinics .EYlogo{left:60px;top:20px;width:40px}.virtual-clinics .logoTxt{font-size:25px;left:130px;top:30px}.virtual-clinics .navbarMenu{right:50px;top:31px}.virtual-clinics .home{width:20px}.virtual-clinics .nav-bar{min-height:90px}.virtual-clinics .cf6{font-size:30px}.virtual-clinics .cnt-fdr{padding:35px 70px}.virtual-clinics .tabContent{padding:50px 70px}.virtual-clinics .col-sm-bx{min-height:70px}.virtual-clinics .bx-link{font-size:13px;line-height:17px;padding:30px}.virtual-clinics .playIcon{border:3px solid #fff;margin-right:30px;margin-top:-13px;width:30px}.virtual-clinics .footer p{font-size:13px;padding:15px 20px}}

@media(max-width:992px){.virtual-clinics .col-sm-3.cl-3{flex:0 0 33.333%;max-width:33.333%}}
@media(max-width:750px){.virtual-clinics .tabContent{padding:40px 30px}.virtual-clinics .col-sm-3.cl-3{flex:0 0 50%;max-width:50%}.virtual-clinics .img-bx{min-height:140px}}
@media(max-width:575px){.virtual-clinics .logoTxt{font-size:20px;left:115px}.virtual-clinics .EYlogo{left:30px}.virtual-clinics .navbarMenu{top:110px}.virtual-clinics .col-sm-3.cl-3{flex:0 0 100%;max-width:100%}.virtual-clinics .col-sm-bx{min-height:0}.virtual-clinics .img-bx{min-height:200px}.virtual-clinics .bx-link{font-size:14px;line-height:20px;padding:20px}.virtual-clinics .tabContent{padding:40px 20px}}
`;

const VirtualClinicsTrainingSessions: React.FC<IVirtualClinicsTrainingSessionsProps> = ({ onShowHome }) => {
  const [isLoading, setIsLoading] = React.useState<boolean>(true);

  React.useEffect(() => {
    const timer = window.setTimeout(() => setIsLoading(false), 2000);
    return () => window.clearTimeout(timer);
  }, []);

  return (
    <div className="virtual-clinics">
      <style>{virtualClinicsStyles}</style>
      {isLoading && <div className="loading-container" aria-label="Loading"><div className="item" /><div className="item" /><div className="item" /><div className="item" /></div>}
      <div className="webPart">
        <div className="container-fluid nav-container">
          <div className="row nav-bar">
            <img className="EYlogo" src={`${imageRoot}EY_logo.png`} alt="EY logo" />
            <p className="logoTxt">MENA Tax Hub</p>
            <ul className="navbarMenu"><li><a data-interception="off" href="#home" onClick={(event) => { event.preventDefault(); onShowHome(); }}><img className="home" src={`${imageRoot}home.png`} alt="Home" /></a></li></ul>
          </div>
        </div>
        <div className="container-fluid">
          <div className="row">
            <div className="col-sm-12 bannerBackground"><div className="container-fluid cnt-fdr"><p className="cf6">Virtual clinics training sessions</p></div></div>
          </div>
        </div>
        <div className="container-fluid tabContent">
          <div className="row">
            <div className="col-sm-3 cl-3">
              <a data-interception="off" className="boxTag" href="https://sites.ey.com/:v:/r/sites/MENATaxHub/SiteAssets/MENATax/Videos/VC%201A%20%E2%80%93%20Estimate%20to%20Complete%20(12%20Dec%2022)-20221212_120301-Meeting%20Recording.mp4" target="_blank" rel="noreferrer">
                <div className="col-sm-bx"><div className="img-bx" style={{ backgroundImage: `url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/vid_001.jpg?csf=1&web=1&e=1Us2Bh)` }} /><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/play.png" className="playIcon" alt="Play" /><p className="bx-link">Estimate to Complete Demo_12 Dec 22</p></div>
              </a>
            </div>
            <div className="col-sm-3 cl-3">
              <a data-interception="off" className="boxTag" href="https://sites.ey.com/:v:/r/sites/MENATaxHub/SiteAssets/MENATax/Videos/VC%201B%20%E2%80%93%20Lean%20Opportunity%20and%20Engagement%20(13%20Dec%2022)-20221213_130314-Meeting%20Recording.mp4" target="_blank" rel="noreferrer">
                <div className="col-sm-bx"><div className="img-bx" style={{ backgroundImage: `url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/vid_002.jpg)` }} /><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/play.png" className="playIcon" alt="Play" /><p className="bx-link">Lean Opportunity and Engagement Demo_13 Dec 22</p></div>
              </a>
            </div>
          </div>
        </div>
        <div className="footer"><p>&#169; 2026 EYGM Limited. All rights reserved.</p></div>
      </div>
    </div>
  );
};

export default VirtualClinicsTrainingSessions;
