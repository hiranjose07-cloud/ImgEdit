import * as React from 'react';

interface ISSLProps {
  onShowHome: () => void;
}

const SSL: React.FC<ISSLProps> = ({ onShowHome }) => {
  const [activeTab, setActiveTab] = React.useState<'two' | 'three' | 'four' | 'five' | 'six'>('two');

  const sslStyles = `
html,body {
  overflow-x: hidden !important;
  font-family: EYInterstate;
}
::-moz-selection {
  color: #ffffff;
  background: #27ACAA;
}
::selection {
  color: #ffffff;
  background: #27ACAA;
}
body::-webkit-scrollbar {
  display: none;
}
body {
  -ms-overflow-style: none;
  scrollbar-width: none;
  position: relative;
}
.bannerBackground {
  background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/banner.jpg);
  background-color: #2e2e38;
  background-size: 115% 115%;
  background-position: center center;
  position: relative;
  background-attachment: fixed;
  animation: shrink 20s infinite alternate;
  padding: 0px;
}
.cf6 {
  color: #ffffff;
  width: 100%;
  font-size: 1.5vw;
  padding: 1vw 1vw;
  margin-bottom: 0;
}
@keyframes shrink {
  0% {
    background-size: 115% 115%;
  }
  100% {
    background-size: 100% 100%;
  }
}
.nav-bar {
  position: relative;
  z-index: 999;
  background: #2e2e38;
  min-height: 6vw;
  width: 100%;
  margin: 0;
}
.nav-container {
  padding: 0px;
}
.EYlogo {
  width: 3vw;
  position: absolute;
  left: 5vw;
  top: 1.5vw;
}
p.logoTxt {
  color: #ffffff;
  font-size: 2vw;
  position: absolute;
  left: 11vw;
  top: 2.2vw;
}
img.home {
  width: 1.3vw;
}
ul.navbarMenu {
  position: absolute;
  right: 6vw;
  top: 2.4vw;
  font-family: EYInterstate;
}
ul.navbarMenu li {
  display: inline-block;
  font-size: 1vw;
  color: #ffffff;
}
ul.navbarMenu li a {
  color: #ffffff;
  text-decoration: none;
  padding: 0vw 2vw;
}
.boxContent span {
  color: #ffe600;
  font-size: 1.2vw;
  margin-right: .3vw;
  font-weight: bold;
}
.cnt-fdr {
  padding: 2vw 5vw 2vw 3.5vw;
  background: rgba(46, 46, 56, .5);
  bottom: 0;
  width: 100%;
}
.vh3 {
  margin-top: 1.3vw;
}
.boxContent p {
  color: #ffffff;
  font-size: .9vw;
  line-height: 1.3vw;
  font-family: EYInterstate;
  font-weight: lighter;
}
.boxContent p b {
  font-size: 1.2vw;
  line-height: 2.5vw;
}
.boxContent img {
  width: 3vw;
  margin-bottom: .4vw;
}
p.c4 {
  color: #ffffff;
  font-size: 1.1vw;
  font-family: EYInterstate;
  line-height: 1.5vw;
  margin-bottom: 1.3vw;
}
ul.c5 {
  color: #ffffff;
  list-style: none;
  padding: 0;
}
ul.c5 li {
  position: relative;
  padding-left: 1.3vw;
  margin-bottom: 0.6vw;
  font-size: 1vw;
}
ul.c5 li::before {
  content: "";
  background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/arrow_icon.png);
  position: absolute;
  width: .6vw;
  height: .6vw;
  background-size: contain;
  background-repeat: no-repeat;
  top: 0.5vw;
  left: 0;
}
.footerTab {
  background: #1a1a24;
  padding: 5vw;
}
a.qLInk {
  color: #ffffff;
  font-family: EYInterstate;
  font-size: 1vw;
  font-weight: lighter;
  border: .1vw solid #9f9f9f;
  padding: 0.5vw 1.6vw;
  border-radius: .4vw;
  margin-right: .7vw;
  text-decoration: none;
  float: left;
  transition: all .2s ease-in-out;
  margin-bottom: .8vw;
}
a.qLInk:hover {
  background: rgba(255, 255, 255, .2);
}
.quicklinks {
  color: #ffffff;
  font-size: 2vw;
  margin-bottom: 2vw;
}
img.qklinks {
  width: 1.4vw;
  margin-top: -0.2vw;
  margin-right: .4vw;
}
.tabContent {
  background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);
  background-position: center;
  background-size: cover;
  background-attachment: fixed;
  background-color: #2e2e38;
}
.tabCol {
  min-height: 10vw;
}
.nav-tabs .nav-link {
  margin-bottom: 0vw;
  border: hidden;
  border-radius: 0px;
  color: #ffffff !important;
  font-size: 1.1vw;
  font-family: EYInterstate;
  font-weight: lighter;
  border-right: .1vw solid #9e9e9e !important;
  padding: 0.2vw 2.5vw;
}
.nav-tabs .nav-item.show .nav-link,
.nav-tabs .nav-link.active {
  color: #ffe600 !important;
  background-color: transparent;
}
#myTab {
  border-bottom: .1vw solid #7e7e7e;
  padding-bottom: 1vw;
  margin-bottom: 0px;
}
.tabCol {
  min-height: 10vw;
  padding: 4vw 6vw;
}
p.tabTxt {
  color: #ffffff;
  font-size: 1vw;
  line-height: 1.5vw;
  margin-bottom: 0;
}
.cl-tx {
  border-bottom: .01vw solid #ffffff61;
  padding-bottom: 2vw;
  margin-bottom: 2vw !important;
}
p.tabTxt a {
  color: #ffe600;
  text-decoration: none;
  font-weight: bold;
}
ul.ul_01 li a {
  color: #ffe600;
  text-decoration: none;
  font-weight: bold;
}
.tab-pane {
  padding: 3vw 4vw !important;
}
.tabCol ul.ul_01 {
  color: #ffffff;
  font-size: 1vw;
  list-style: none;
  padding: 0;
  margin: 0;
  font-family: EYInterstate;
  font-weight: lighter;
}
.tabCol ul.ul_02 {
  color: #ffffff;
  font-size: 1vw;
  list-style: none;
  padding: 0;
  margin: 0;
  font-family: EYInterstate;
  font-weight: lighter;
}
p.bt_7 {
  color: #ffffff;
  font-size: 2vw;
  margin-bottom: 1vw;
  margin-top: -1vw;
}
.tabCol ul.ul_01 li {
  position: relative;
  padding-left: 1.5vw;
  margin-bottom: 1.7vw;
}
.tabCol ul.ul_02 li {
  position: relative;
  padding-left: 1.5vw;
  margin-bottom: .7vw;
}
.tabCol ul.ul_01 li::before {
  content: "";
  background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/arrow_png.png);
  position: absolute;
  width: 0.7vw;
  height: 0.6vw;
  background-size: contain;
  background-repeat: no-repeat;
  margin-top: 0.4vw;
  left: 0;
}
.tabCol ul.ul_02 li::before {
  content: "";
  background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/tick.png);
  position: absolute;
  width: 0.7vw;
  height: 0.6vw;
  background-size: contain;
  background-repeat: no-repeat;
  margin-top: 0.4vw;
  left: 0;
}
.col_1 {
  width: 20%;
  background: rgba(255, 255, 255, .08);
  color: #ffffff;
  font-size: .9vw;
  line-height: 1.3vw;
  float: left;
  border-right: .1vw solid #616161;
}
.col_1:last-child {
  border-right: hidden;
}
.Hdline {
  background: #1a1a24;
  padding: 1.5vw;
  min-height: 7vw;
}
.p-text {
  padding: 1.5vw;
  margin: 0;
  min-height: 17vw;
}
p.c8 {
  color: #ffe600;
  padding: 0vw 1.5vw;
}
ul.c9 {
  padding: 0vw 1.5vw 1.5vw 1.5vw;
  list-style: none;
  margin-bottom: 0;
  min-height: 20vw;
}
ul.c9 li {
  position: relative;
  padding-left: 1vw;
  margin-bottom: 1vw;
}
ul.c9 li::before {
  content: "";
  background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/arrow_png.png);
  position: absolute;
  width: 0.7vw;
  height: 0.6vw;
  background-size: contain;
  background-repeat: no-repeat;
  margin-top: 0.4vw;
  left: 0;
}
img.cf_img {
  width: 100%;
  height: 8vw;
}
.cf_head {
  background: #747480;
  padding: 0.6vw 0vw;
  text-align: center;
  color: #ffffff;
  font-size: 1.2vw;
  float: left;
  width: 100%;
}
img.proImg {
  width: 5vw;
  border-radius: 100vw;
  float: left;
  margin-right: 1vw;
}
p.proName {
  color: #ffffff;
  font-size: 1vw;
  margin-bottom: 0vw;
  padding-top: 1.3vw;
}
p.proDes {
  color: #ffe600;
  font-size: .9vw;
  margin-bottom: 0;
  margin-top: -.2vw;
}
.profileDetails {
  float: left;
  width: 100%;
  margin-bottom: 2vw;
}
li.subList {
  margin: 2vw 0vw !important;
  font-size: 1.5vw !important;
}
li.subList::before {
  display: none !important;
}
#Six-tab {
  border-right: hidden !important;
}
p.hder {
  color: #ffffff;
  padding-left: 1vw;
  font-size: 1vw;
  line-height: 1.5vw;
  margin-bottom: 1vw;
}
.news_box {
  float: left;
  margin-right: 1.5vw;
  background: rgba(255, 255, 255, .08);
  width: 22%;
  border: .01vw solid #444343;
  border-radius: .2vw;
  overflow: hidden;
  margin-bottom: 20px;
  min-height: 18vw;
}
.nws02.nsw a .news_box {
  width: 100%;
}
.imgTile {
  width: 100%;
  height: 7vw;
  background-size: cover;
  background-position: center;
}
.newsHd {
  color: #ffffff;
  font-size: 2vw;
  margin-bottom: 0.5vw;
  margin-top: 3vw;
}
hr.newsHr {
  margin-top: 0;
  margin-bottom: 2vw;
  border: 0;
  border-top: 1px solid rgba(255, 255, 255, .64);
  width: 4vw;
}
.Ntitle {
  color: #ffe600;
  margin-bottom: .5vw;
  font-size: .9vw;
}
.Nsubtitle {
  color: #ffe600;
  font-size: 1vw;
  margin-bottom: 0.6vw;
  margin-top: -0.4vw;
}
.Ndes {
  color: #ffffff;
  font-size: .8vw;
  line-height: 1.1vw;
  margin-bottom: 0;
}
.Nread {
  color: #ffffff;
  font-size: .8vw;
  font-style: italic;
  margin: 0;
  text-align: right;
  margin-top: 0.4vw;
  position: absolute;
  right: 1vw;
  bottom: 1vw;
}
.newsDes {
  padding: 2vw 1vw;
  position: relative;
  min-height: 10vw;
}
.footer {
  background-color: #000000;
  float: left;
  width: 100%;
}
.footer p {
  margin-bottom: 0px;
  color: #ffffff;
  font-size: 1vw;
  padding: 1vw 2vw;
  text-align: right;
}
.txtTwo {
  border-bottom: .01vw solid #ffffff61;
  padding-bottom: 1vw;
  margin-bottom: 2vw !important;
}
.navToggle {
  display: none;
}
.cl-v1 {
  background: #ffe600;
  color: #000000 !important;
  font-family: EYInterstate;
  padding: 0.7vw 2vw;
  float: right;
  text-decoration: none !important;
  font-size: .9vw;
  position: relative;
  z-index: 1;
  margin-top: 5px;
}
.cl-v1 img {
  width: 2vw;
  margin-right: .6vw;
}
.u0 {
  color: #ffe600 !important;
}
.u1 {
  margin: 1vw 0vw !important;
}
.u2 li {
  margin-bottom: .5vw !important;
}
.hotNews {
  background: #ffe600;
  width: 6vw;
  margin-bottom: -1vw;
  position: relative;
  z-index: 1;
  margin-left: 1vw;
}
.hotNews img {
  width: 1.6vw;
  padding: 0.2vw 0.1vw 0.3vw 0.5vw;
}
.hotNews span {
  color: #000000;
  font-size: .8vw;
  padding: 0vw 0.3vw;
}
.table.table-bordered {
  color: #ffffff;
  margin-top: 2vw;
}
.table-bordered thead th {
  color: #ffe600;
  padding: 1vw 1.5vw;
  font-size: 1.1vw;
  line-height: 1.4vw;
}
.table-bordered.ty_7 thead th {
  padding: 1vw 0vw;
}
.table-bordered tbody td {
  padding: 0.7vw 1.5vw;
  font-size: .9vw;
}
.table-bordered td,.table-bordered th,.table-bordered {
  border: .01vw solid #474747 !important;
}
table.table-bordered thead tr {
  background-color: #1f2027;
}
.col_20 {
  background-color: #1f2027;
}
.col_10 td ul {
  list-style: none;
  padding: 0px;
  margin-top: 1vw;
}
.col_10 td ul li {
  margin-bottom: .7vw !important;
}
.nws01 {
  float: left;
  width: 80%;
  border-right: .1vw solid #8e8e8e;
  padding-bottom: 2vw;
}
.nws02 {
  float: left;
  width: 20%;
  padding-left: 2vw;
}
a.cr7 {
  text-decoration: none;
  position: relative;
}
.news_1 {
  background: rgba(255, 255, 255, 0.1);
  padding: 1.5vw 1.5vw;
  margin-top: 0;
  margin-bottom: 1vw;
  transition: all .2s ease-in-out;
  padding-left: 10vw;
  position: relative;
  min-height: 8.4vw;
}
.fy7 {
  background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/FSleader.png?csf=1&web=1&e=t2oWU0);
  width: 8vw;
  height: 84%;
  position: absolute;
  left: .8vw;
  top: .8vw;
  background-size: cover;
  background-position: right;
  opacity: 0.9;
}
.pr_txt {
  color: #ffffff;
  font-size: .9vw;
  margin-bottom: .5vw;
  margin-top: 1vw;
  line-height: 1.2vw;
  width: 100%;
}
.c4a7 {
  color: #ffffff !important;
  font-size: .9vw;
  text-decoration: none !important;
  margin-bottom: 0px;
}
a.newClass {
  color: #ffe600;
  text-decoration: none;
  font-weight: bold;
  margin-top: 20px;
  display: block;
  margin-bottom: 12px;
}
@media only screen and (min-width: 641px) and (max-width: 1000px) {
  .container_wrapper p,
  .container_wrapper li,
  .container_wrapper a,
  .container_wrapper td,
  .container_wrapper th,
  .container_wrapper span,
  .container_wrapper button {
    font-size: 15px !important;
    line-height: 1.45 !important;
  }
  .container_wrapper p.logoTxt { font-size: 25px !important; }
  .container_wrapper .cf6,
  .container_wrapper .quicklinks,
  .container_wrapper .newsHd,
  .container_wrapper p.bt_7 { font-size: 24px !important; line-height: 1.2 !important; }
  .container_wrapper .nav-tabs .nav-link { font-size: 15px !important; padding: 8px 18px; }
  .container_wrapper .table-bordered thead th { font-size: 16px !important; line-height: 1.35 !important; }
  .container_wrapper .table-bordered tbody td { font-size: 15px !important; }
  .container_wrapper .col_1 { width: 50%; }
  .container_wrapper .news_box { width: 47%; margin-right: 2%; min-height: 260px; }
  .container_wrapper .Ntitle { font-size: 16px !important; }
  .container_wrapper .Ndes,
  .container_wrapper .Nread,
  .container_wrapper .pr_txt,
  .container_wrapper .c4a7 { font-size: 14px !important; line-height: 1.4 !important; }
  .container_wrapper .hotNews { width: auto; }
  .container_wrapper .hotNews span { font-size: 14px !important; }
}
`;

  return (
    <>
      <style>{sslStyles}</style>
      <div className="loading-container" style={{ display: 'none' }}>
        <div className="item" />
        <div className="item" />
        <div className="item" />
        <div className="item" />
      </div>

      <div className="container_wrapper" style={{ display: 'block' }}>
        <div className="webPart">
          <div className="container-fluid nav-container">
            <div className="row nav-bar">
              <img
                className="EYlogo"
                src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/EY_logo.png"
                alt="EY logo"
              />
              <p className="logoTxt">MENA Tax Hub</p>
              <ul className="navbarMenu">
                <li>
                  <a data-interception="off" href="#" onClick={(event) => { event.preventDefault(); onShowHome(); }}>
                    <img
                      className="home"
                      src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home.png"
                      alt="Home"
                    />
                  </a>
                </li>
              </ul>
              <img
                className="navToggle"
                src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/toggle.png"
                alt="Toggle navigation"
              />
            </div>
          </div>
          <div className="container-fluid">
            <div className="row">
              <div className="col-sm-12 bannerBackground">
                <div className="container-fluid cnt-fdr">
                  <div className="row">
                    <p className="cf6">Tax Sub Service Lines (SSLs)</p>
                    <p className="hder">
                      In Tax, we equip clients to make better business decisions by bringing insights to the
                      forefront. We help companies understand the tax policies and tax laws of governments
                      around the world to plan and comply accordingly. Our teams leverage transformative
                      technologies to deliver strategy and execution, from tax and regulatory obligations to
                      operations and workforce management, to reduce risk and drive sustainable value.
                    </p>
                    <div className="col-sm-4 c57" />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="container-fluid tabContent">
            <div className="row">
              <div className="col-sm-12 tabCol">
                <ul className="nav nav-tabs card-header-tabs" id="myTab" role="tablist">
                  <li className="nav-item">
                    <a data-interception="off"
                      className={activeTab === 'two' ? 'nav-link active' : 'nav-link'}
                      id="two-tab"
                      href="#two"
                      role="tab"
                      aria-controls="Two"
                      aria-selected={activeTab === 'two'}
                      onClick={(event) => {
                        event.preventDefault();
                        setActiveTab('two');
                      }}
                    >
                      GCR
                    </a>
                  </li>
                  <li className="nav-item">
                    <a data-interception="off"
                      className={activeTab === 'three' ? 'nav-link active' : 'nav-link'}
                      id="three-tab"
                      href="#three"
                      role="tab"
                      aria-controls="Three"
                      aria-selected={activeTab === 'three'}
                      onClick={(event) => {
                        event.preventDefault();
                        setActiveTab('three');
                      }}
                    >
                      Law
                    </a>
                  </li>
                  <li className="nav-item">
                    <a data-interception="off"
                      className={activeTab === 'four' ? 'nav-link active' : 'nav-link'}
                      id="four-tab"
                      href="#four"
                      role="tab"
                      aria-controls="four"
                      aria-selected={activeTab === 'four'}
                      onClick={(event) => {
                        event.preventDefault();
                        setActiveTab('four');
                      }}
                    >
                      IDT
                    </a>
                  </li>
                  <li className="nav-item">
                    <a data-interception="off"
                      className={activeTab === 'five' ? 'nav-link active' : 'nav-link'}
                      id="five-tab"
                      href="#five"
                      role="tab"
                      aria-controls="Five"
                      aria-selected={activeTab === 'five'}
                      onClick={(event) => {
                        event.preventDefault();
                        setActiveTab('five');
                      }}
                    >
                      ITTS
                    </a>
                  </li>
                  <li className="nav-item">
                    <a data-interception="off"
                      className={activeTab === 'six' ? 'nav-link l1 active' : 'nav-link l1'}
                      id="Six-tab"
                      href="#six"
                      role="tab"
                      aria-controls="Six"
                      aria-selected={activeTab === 'six'}
                      onClick={(event) => {
                        event.preventDefault();
                        setActiveTab('six');
                      }}
                    >
                      PAS
                    </a>
                  </li>
                </ul>
                <div className="tab-content" id="myTabContent">
                  <div className={activeTab === 'two' ? 'tab-pane fade show active p-3' : 'tab-pane fade p-3'} id="two" role="tabpanel" aria-labelledby="two-tab">
                    <p className="bt_7">Global Compliance and Reporting (GCR)</p>
                    <div className="profileDetails">
                      <img
                        src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Ahmed%20Aboelfotouh.jpg"
                        className="proImg"
                        alt="Ahmed Aboelfotouh"
                      />
                      <p className="proName">Ahmed Aboelfotouh</p>
                      <p className="proDes">MENA GCR Leader</p>
                    </div>
                    <p className="tabTxt">
                      Global Compliance and Reporting (GCR) represents an integrated service offering, drawing on competencies
                      across our practice to become the outsourcing answer to our clients' compliance and reporting challenges
                      around the world. Whether we are delivering in a single country or worldwide, our standardized approach
                      across the <a data-interception="off" href="https://sites.ey.com/sites/DS_Tax/GCR/Pages/Home.aspx" target="_blank" rel="noreferrer">Record to Report (R2R)</a> cycle achieves
                      efficiencies for our clients and identifies other EY opportunities.
                      <br />
                      <br />
                      <a data-interception="off" href="https://sites.ey.com/sites/DS_Tax/GCR/Pages/Home.aspx" target="_blank" rel="noreferrer">Visit the Discover GCR site to know more.</a>
                      <br />
                      <br />
                    </p>
                    <ul className="ul_01">
                      <li>
                        <a data-interception="off" href="https://sites.ey.com/sites/DS_Tax/GCR/Pages/accounting-compliance-and-reporting.aspx" target="_blank" rel="noreferrer">
                          Accounting Compliance and Reporting (ACR)
                        </a>
                      </li>
                      <li>
                        <a data-interception="off" href="https://sites.ey.com/sites/DS_Tax/GCR/Pages/direct-tax-compliance.aspx" target="_blank" rel="noreferrer">
                          Business Tax Compliance (BTC)
                        </a>
                      </li>
                      <li>
                        <a data-interception="off" href="https://sites.ey.com/sites/DS_Tax/GCR/Pages/global-operations.aspx" target="_blank" rel="noreferrer">
                          GCR Global Operations
                        </a>
                      </li>
                      <li>
                        <a data-interception="off" href="https://sites.ey.com/sites/DS_Tax/GCR/Pages/indirect-tax-compliance.aspx" target="_blank" rel="noreferrer">
                          Indirect Tax Compliance
                        </a>
                      </li>
                      <li>
                        <a data-interception="off" href="https://sites.ey.com/sites/DS_Tax/GCR/Pages/tax-accounting-and-risk-advisory-services.aspx" target="_blank" rel="noreferrer">
                          Tax Accounting and Risk Advisory Services (TARAS)
                        </a>
                      </li>
                      <li>
                        <a data-interception="off" href="https://sites.ey.com/sites/DS_Tax/BTS/Pages/global-customer-tax-operations-and-reporting-ctors.aspx" target="_blank" rel="noreferrer">
                          Global Customer Tax Operations and Reporting (CTORS)
                        </a>
                      </li>
                      <li>
                        <a data-interception="off" href="https://sites.ey.com/sites/DS_Tax/BTS/Pages/ey-private-tax.aspx" target="_blank" rel="noreferrer">
                          EY Private Tax
                        </a>
                      </li>
                      <li>
                        <a data-interception="off" href="https://sites.ey.com/sites/DS_Tax/BTS/Pages/quantitative-services.aspx" target="_blank" rel="noreferrer">
                          Quantitative Services (QS)
                        </a>
                      </li>
                    </ul>
                  </div>

                  <div className={activeTab === 'three' ? 'tab-pane fade show active p-3' : 'tab-pane fade p-3'} id="three" role="tabpanel" aria-labelledby="three-tab">
                    <p className="bt_7">Law</p>
                    <div className="profileDetails">
                      <img
                        src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/law.png"
                        className="proImg"
                        alt="Law team"
                      />
                      <p className="proName">Chris P. Sioufi</p>
                      <p className="proDes">MENA Law Leader</p>
                    </div>
                    <p className="tabTxt txtTwo">
                      The EY MENA Law team are a team of lawyers who together have decades of experience and multinational
                      legal qualifications. The team is led by Chris P. Sioufi, a leading corporate and finance transactional lawyer
                      with over 25 years' experience.
                      <br />
                      <br />
                      EY MENA Law services include transaction law (corporate/M&A), commercial law, entity compliance & governance,
                      digital & data privacy, financial services and energy and infrastructure.
                      <br />
                      <br />
                      The team can and has advised on a large range of corporate transactions including M&A, private equity, structured
                      finance and Islamic finance matters as well as several advisory mandates, market entry analyses, digital law and
                      data protection advice. The team also boasts experienced regulatory and energy lawyers with years of experience in
                      their field. The team has advised on private and public corporate and financial transactions totaling billions of dollars
                      including a number of high-profile deals in the MENA region. Members of the team have been consistently recognised by
                      leading publications which highlight their regional practice and expertise.
                      <br />
                      <br />
                      The EY MENA Law team understands the increasingly complex regulatory frameworks and corporate compliance laws and
                      regulations of this global economy. The team has a strong local knowledge of the laws and regulations of a number of
                      jurisdictions within MENA, including the United Arab Emirates and the Kingdom of Saudi Arabia but has also familiarity of
                      the different legal systems across the MENA region and regularly manages multi-jurisdiction transactions. It also has a
                      close network of advisors throughout the MENA region who can support on technical local aspects of transactions in the region.
                      <br />
                      <br />
                      Our lawyers have an entrepreneurial, innovative and solution-based approach that has earned us an outstanding reputation
                      in the market. We understand that legal solutions must, above all, be practical solutions for our clients focusing on our
                      clients' objectives.
                      <br />
                      <br />
                      The EY MENA Law team works alongside other EY professionals, including tax, transactions, consulting and advisory. Serving
                      you across borders. EY's sector-focused, multidisciplinary approach means EY MENA Law can offer integrated, broad and pertinent
                      advice you can trust. EY MENA Law has access to the international EY Law network of legal practices affiliated to EY. The EY Law
                      network currently consists of 3,500+ qualified legal professionals in 90 countries. EY Law has a truly global footprint.
                    </p>
                    <ul className="ul_01">
                      <li className="subList">Our services</li>
                      <li>
                        <a data-interception="off" className="u0">Corporate/M&A</a>
                        <p className="tabTxt u1">Help companies grow their market share, expanding into new geographies, or support for carve-outs and divestitures to streamline client's portfolio.</p>
                        <ul className="ul_01 u2">
                          <li>Mid-market M&A transactions</li>
                          <li>Private equity and joint venture transactions</li>
                          <li>Stand alone buy or sell side legal due diligence</li>
                          <li>Pre and post transaction reorganizations</li>
                          <li>Pre and post transaction integration</li>
                          <li>Joint ventures</li>
                          <li>Regulatory authorizations: multi-jurisdictional merger control analysis</li>
                        </ul>
                      </li>
                      <li>
                        <a data-interception="off" className="u0">Commercial</a>
                        <p className="tabTxt u1">Help companies confidently cover the range of issues that may arise in a single corporate transaction and make the most of today's business opportunities.</p>
                        <ul className="ul_01 u2">
                          <li>Company law and commercial law</li>
                          <li>Commercial contracts</li>
                          <li>Corporate governance</li>
                          <li>Restructuring</li>
                          <li>Legal entity rationalization</li>
                          <li>Operating model effectiveness</li>
                        </ul>
                      </li>
                      <li>
                        <a data-interception="off" className="u0">Entity, Compliance & Governance (ECG)</a>
                        <p className="tabTxt u1">Help multinational clients with corporate regulatory advice and practical assistance with establishing a presence in the chosen jurisdiction.</p>
                        <ul className="ul_01 u2">
                          <li>Market entry report</li>
                          <li>Implementation and set up assistance</li>
                          <li>Annual and ongoing compliance services</li>
                        </ul>
                      </li>
                      <li>
                        <a data-interception="off" className="u0">Financial services</a>
                        <p className="tabTxt u1">Help multinational financial sector to comply with ongoing regulatory changes globally and address challenges relating to developing disruptive technologies.</p>
                        <ul className="ul_01 u2">
                          <li>Corporate finance (ordinary, structured and special financing, through bank lending and debt securities)</li>
                          <li>Incorporation, expansion, reorganization and branch registration for financial institutions</li>
                          <li>Regulatory compliance for financial Institutions</li>
                          <li>Banking and Finance (including Islamic Finance)</li>
                          <li>Banking and financial regulations</li>
                        </ul>
                        <p className="tabTxt u1" style={{ fontWeight: 'bolder', fontSize: '1.1vw' }}>Capability</p>
                        <p className="tabTxt u1">The Financial Services Team at EY Law (FS Law Team) provides legal assistance to private and public clients across the following markets on matters linked to the MENA Region:</p>
                        <p className="tabTxt u1" style={{ fontWeight: 'bolder', fontSize: '1.1vw' }}>Markets</p>
                        <table className="table table-bordered ts_7 ty_7">
                          <thead>
                            <tr style={{ textAlign: 'center' }}>
                              <th scope="col" style={{ verticalAlign: 'middle' }} />
                              <th scope="col" style={{ verticalAlign: 'middle' }}>Banking & Finance</th>
                              <th scope="col" style={{ verticalAlign: 'middle' }}>Capital Markets</th>
                              <th scope="col" style={{ verticalAlign: 'middle' }}>Wealth & Asset Management</th>
                              <th scope="col" style={{ verticalAlign: 'middle' }}>Insurance</th>
                              <th scope="col" style={{ verticalAlign: 'middle' }}>Fintech</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr className="col_10">
                              <td style={{ verticalAlign: 'middle' }}>Clients</td>
                              <td style={{ verticalAlign: 'middle' }}>Corporate borrowers, banks, finance companies, central banks</td>
                              <td style={{ verticalAlign: 'middle' }}>Issuers, arrangers, placement managers and intermediaries, financial services authorities and stock exchanges</td>
                              <td style={{ verticalAlign: 'middle' }}>Sovereign/Government funds, investment funds, investment managers, asset managers, investors and asset owners</td>
                              <td style={{ verticalAlign: 'middle' }}>Insurance and reinsurance companies</td>
                              <td style={{ verticalAlign: 'middle' }}>Tech companies, financial institutions, JVs, investment and asset managers.</td>
                            </tr>
                            <tr className="col_20">
                              <td style={{ verticalAlign: 'middle' }}>Matters</td>
                              <td style={{ verticalAlign: 'middle' }}>Corporate finance, Project and asset finance, trade finance; Payment services, cash pooling and treasury centers; Investment banking; ESG Financing; Public finance</td>
                              <td style={{ verticalAlign: 'middle' }}>Debt, equity and hybrid securities offering, placement and listing; Debt restructuring and liability management; Capital markets readiness</td>
                              <td style={{ verticalAlign: 'middle' }}>Public, Exempt and QI funds; Alternative Investment Management; ESG Investment</td>
                              <td style={{ verticalAlign: 'middle' }}>Life and Non-life insurance; Credit insurance; Investment policies and unit-linked policies; JVs and outsourcing</td>
                              <td style={{ verticalAlign: 'middle' }}>Virtual assets; Digital banking and investment; Crypto currencies and Central Bank Digital Currencies</td>
                            </tr>
                          </tbody>
                        </table>
                        <p className="tabTxt u1" style={{ fontWeight: 'bolder', fontSize: '1.1vw' }}>Services</p>
                        <p className="tabTxt u1">
                          In the above market context, the FS Law Team offers its main legal services in the below areas on a stand-alone basis or on an integrated, multi-disciplinary basis, together with EY Strategy and Transactions, EY Consulting and EY Tax. In specific circumstances, the FS Law Team can plug-in subject matter experts within the EY network on specific business and operational propositions, as a project may require.
                        </p>
                        <table className="table table-bordered ts_7 ty_7">
                          <thead>
                            <tr style={{ textAlign: 'center' }}>
                              <th scope="col" style={{ verticalAlign: 'middle' }}>Legal and Regulatory<br />Advice</th>
                              <th scope="col" style={{ verticalAlign: 'middle' }}>Transactions and Legal <br />Documentation</th>
                              <th scope="col" style={{ verticalAlign: 'middle' }}>Entity Compliance<br />and Governance</th>
                              <th scope="col" style={{ verticalAlign: 'middle' }}>Product Structuring<br />and Review</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr className="col_10">
                              <td>
                                Regulatory roadmaps and analysis on:
                                <ul>
                                  <li>Business transformation (single and multi-jurisdiction);</li>
                                  <li>Intragroup operability;</li>
                                  <li>Investment and asset management structuring;</li>
                                  <li>Cross-border activities (through permanent establishments or not);</li>
                                  <li>ESG financing and investment compliance and implementation.Legal and regulatory risk assessment and opinions.</li>
                                </ul>
                              </td>
                              <td>
                                <ul>
                                  <li>Transactional due diligence;</li>
                                  <li>Draft, review, negotiation and execution of contractual and disclosure documents and internal authorization documents;</li>
                                  <li>Legal opinions for internal (e.g., BoDs) and external (e.g., lenders, investors, regulatory and rating agencies) use.</li>
                                </ul>
                              </td>
                              <td>
                                <ul>
                                  <li>Incorporation and licensing (onshore/free zones) of financial and investment entities, branches;</li>
                                  <li>Investment fund registration; Passporting advice;</li>
                                  <li>Market entry guidelines and jurisdictional comparison;</li>
                                  <li>Entities relocation and reorganization; Dealing with regulatory authorities.</li>
                                </ul>
                              </td>
                              <td>
                                <ul>
                                  <li>Regulatory review and advice;</li>
                                  <li>Drafting and reviewing legal and disclosure templates and guidelines;</li>
                                  <li>Assistance with approvals of new products by BoDs;</li>
                                  <li>Legal and regulatory risk assessment and opinions.</li>
                                </ul>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                        
                        <li>
                          <a className="u0">Energy and Infrastructure
                         
                        
                                                            </a>
                        
                                                                    <p className="tabTxt u1">The EY Law MENA team provides legal advice on all aspects of energy and infrastructure projects in MENA. EY Law provides legal advice on such projects in the following areas: </p>
                                                                    <ul className="ul_01 u2">
                                                                        <li>Transaction advice; </li>
                                                                        <li>Construction (EPC/O&amp;M); </li>
                                                                        <li>Off-take arrangements, PPAs, fuel supply arrangements; </li>
                                                                        <li>Project development arrangements; </li>
                                                                        <li>Project financing; </li>
                                                                        <li>Fund raising; </li>
                                                                        <li>PPP/concession arrangements; and </li>
                                                                        <li>Procurement advice.</li>
                                                                    </ul>
                                                                    <p className="tabTxt u1">
                                                                        Most of our energy and infrastructure work is focused on UAE, KSA and North Africa but we obviously follow our clients and have extensive legal experience in other markets in MENA.
                                                                        <br /><br /> 
                                                                        We focus on
                                                                        all technology types in the energy sector including oil, gas, nuclear, wind, solar and hydrogen projects.
                                                                        
                                                                        <br /><br /> 
                                                                        Increasingly our focus is on ESG projects where we advise clients on decarbonization. In
                                                                        this area we review the existing ESG position with clients through due diligence; we advise clients on implementing change to the existing ESG position and in particular advise clients how to avoid value
                                                                        reduction and achieve increase in value for their businesses.
                                                                        <br /><br /> 
                                                                        We also advise on all types of social infrastructure projects regionally including clean water; wastewater; water transmission pipeline;
                                                                        schools; hospitals; transport including roads; urban waste and leisure facilities. 
                                                                        </p>
                        
                                                                    
                                                                </li>
                        
                                                                <li><a className="u0">Digital &amp; Data Privacy
                         
                        
                                                            </a>
                                                                    <p className="tabTxt u1">Address today's business issues with technology, data and analytics, and help clients to navigate through digital disruption.
                        
                        
                                                                    </p>
                                                                    <ul className="ul_01 u2">
                                                                        <li>Data privacy &amp; protection law</li>
                                                                        <li> Cybersecurity (in conjunction with EY cybersecurity team)</li>
                                                                        <li> Digital intellectual property</li>
                                                                        <li> Digital regulatory law, including IT and E-commerce</li>
                        
                        
                        
                        
                                                                    </ul>
                                                                </li>
                        <div className="nws01 nsw">
                          <p className="newsHd">Newsletters</p>
                          <hr className="newsHr" />
                          <a data-interception="off" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/Newsletter/Law%20Edition%2018.pdf" target="_blank" rel="noreferrer" style={{ textDecoration: 'none' }}>
                            <div className="news_box">
                              <div className="imgTile" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' }} />
                              <div className="newsDes">
                                <p className="Ntitle">Edition-18</p>
                                <p className="Ndes">Welcome to the Eighteenth edition of 'To The Point', the internal MENA Law Team Newsletter.</p>
                                <p className="Nread">READ MORE</p>
                              </div>
                            </div>
                          </a>
                          <a data-interception="off" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/Newsletter/Law%20Edition%2017.pdf" target="_blank" rel="noreferrer" style={{ textDecoration: 'none' }}>
                            <div className="news_box">
                              <div className="imgTile" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' }} />
                              <div className="newsDes">
                                <p className="Ntitle">Edition-17</p>
                                <p className="Ndes">Welcome to the Seventeenth edition of 'To The Point', the internal MENA Law Team Newsletter.</p>
                                <p className="Nread">READ MORE</p>
                              </div>
                            </div>
                          </a>
                          <a data-interception="off" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/Newsletter/Law_edition%2015.pdf" target="_blank" rel="noreferrer" style={{ textDecoration: 'none' }}>
                            <div className="news_box">
                              <div className="imgTile" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' }} />
                              <div className="newsDes">
                                <p className="Ntitle">Edition-15</p>
                                <p className="Ndes">Welcome to the fifteenth edition of 'To The Point', the internal MENA Law Team Newsletter.</p>
                                <p className="Nread">READ MORE</p>
                              </div>
                            </div>
                          </a>
                          <a data-interception="off" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/Newsletter/Law_edition%2014.pdf" target="_blank" rel="noreferrer" style={{ textDecoration: 'none' }}>
                            <div className="news_box">
                              <div className="imgTile" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' }} />
                              <div className="newsDes">
                                <p className="Ntitle">Edition-14</p>
                                <p className="Ndes">Welcome to the fourteenth edition of 'To The Point', the internal MENA Law Team Newsletter.</p>
                                <p className="Nread">READ MORE</p>
                              </div>
                            </div>
                          </a>
                          <a data-interception="off" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/Newsletter/To%20The%20Point%20-%20Edition%2013.pdf" target="_blank" rel="noreferrer" style={{ textDecoration: 'none' }}>
                            <div className="news_box">
                              <div className="imgTile" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' }} />
                              <div className="newsDes">
                                <p className="Ntitle">Edition-13</p>
                                <p className="Ndes">Welcome to the thirteenth edition of 'To The Point', the internal MENA Law Team Newsletter.</p>
                                <p className="Nread">READ MORE</p>
                              </div>
                            </div>
                          </a>
                          <a data-interception="off" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/Newsletter/To%20The%20Point%20-%20Edition%2012.pdf" target="_blank" rel="noreferrer" style={{ textDecoration: 'none' }}>
                            <div className="news_box">
                              <div className="imgTile" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' }} />
                              <div className="newsDes">
                                <p className="Ntitle">Edition-12</p>
                                <p className="Ndes">Welcome to the twelveth edition of 'To The Point', the internal MENA Law Team Newsletter.</p>
                                <p className="Nread">READ MORE</p>
                              </div>
                            </div>
                          </a>
                          <a data-interception="off" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/Newsletter/To%20the%20point-edition-11.pdf" target="_blank" rel="noreferrer" style={{ textDecoration: 'none' }}>
                            <div className="news_box">
                              <div className="imgTile" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' }} />
                              <div className="newsDes">
                                <p className="Ntitle">Edition-11</p>
                                <p className="Ndes">Welcome to the eleventh edition of 'To The Point', the internal MENA Law Team Newsletter.</p>
                                <p className="Nread">READ MORE</p>
                              </div>
                            </div>
                          </a>
                          <a data-interception="off" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/To-the-point-editon-10.pdf" target="_blank" rel="noreferrer" style={{ textDecoration: 'none' }}>
                            <div className="news_box">
                              <div className="imgTile" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' }} />
                              <div className="newsDes">
                                <p className="Ntitle">Edition-10</p>
                                <p className="Ndes">Welcome to the tenth edition of 'To The Point', the internal MENA Law Team Newsletter.</p>
                                <p className="Nread">READ MORE</p>
                              </div>
                            </div>
                          </a>
                          <a data-interception="off" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/To-the-point-editon-9.pdf" target="_blank" rel="noreferrer" style={{ textDecoration: 'none' }}>
                            <div className="news_box">
                              <div className="imgTile" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' }} />
                              <div className="newsDes">
                                <p className="Ntitle">Edition-09</p>
                                <p className="Ndes">Welcome to the ninth edition of 'To The Point', the internal MENA Law Team Newsletter.</p>
                                <p className="Nread">READ MORE</p>
                              </div>
                            </div>
                          </a>
                          <a data-interception="off" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/Newsletter/To%20the%20Point%20Edition%208.pdf" target="_blank" rel="noreferrer" style={{ textDecoration: 'none' }}>
                            <div className="news_box">
                              <div className="imgTile" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' }} />
                              <div className="newsDes">
                                <p className="Ntitle">Edition-08</p>
                                <p className="Ndes">Welcome to the eighth edition of 'To The Point', the internal MENA Law Team Newsletter.</p>
                                <p className="Nread">READ MORE</p>
                              </div>
                            </div>
                          </a>
                          <a data-interception="off" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/To%20the%20Point%20Edition%207.pdf" target="_blank" rel="noreferrer" style={{ textDecoration: 'none' }}>
                            <div className="news_box">
                              <div className="imgTile" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' }} />
                              <div className="newsDes">
                                <p className="Ntitle">Edition-07</p>
                                <p className="Ndes">Welcome to the seventh edition of 'To The Point', the internal MENA Law Team Newsletter.</p>
                                <p className="Nread">READ MORE</p>
                              </div>
                            </div>
                          </a>
                          <a data-interception="off" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/To%20the%20Point%20Edition%206.pdf" target="_blank" rel="noreferrer" style={{ textDecoration: 'none' }}>
                            <div className="news_box">
                              <div className="imgTile" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' }} />
                              <div className="newsDes">
                                <p className="Ntitle">Edition-06</p>
                                <p className="Ndes">Welcome to the sixth edition of 'To The Point', the internal MENA Law Team Newsletter.</p>
                                <p className="Nread">READ MORE</p>
                              </div>
                            </div>
                          </a>
                          <a data-interception="off" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/To-The-Point-Edition-5.pdf" target="_blank" rel="noreferrer" style={{ textDecoration: 'none' }}>
                            <div className="news_box">
                              <div className="imgTile" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' }} />
                              <div className="newsDes">
                                <p className="Ntitle">Edition-05</p>
                                <p className="Ndes">Welcome to the fifth edition of 'To The Point', the internal MENA Law Team Newsletter.</p>
                                <p className="Nread">READ MORE</p>
                              </div>
                            </div>
                          </a>
                          <a data-interception="off" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/To-The-Point-Edition-4.pdf" target="_blank" rel="noreferrer" style={{ textDecoration: 'none' }}>
                            <div className="news_box">
                              <div className="imgTile" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' }} />
                              <div className="newsDes">
                                <p className="Ntitle">Edition-04</p>
                                <p className="Ndes">Welcome to the fourth edition of 'To The Point', the internal MENA Law Team Newsletter.</p>
                                <p className="Nread">READ MORE</p>
                              </div>
                            </div>
                          </a>
                          <a data-interception="off" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/To-The-Point-Edition-3.pdf" target="_blank" rel="noreferrer" style={{ textDecoration: 'none' }}>
                            <div className="news_box">
                              <div className="imgTile" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' }} />
                              <div className="newsDes">
                                <p className="Ntitle">Edition-03</p>
                                <p className="Ndes">Welcome to the third edition of 'To The Point', the internal MENA Law Team Newsletter.</p>
                                <p className="Nread">READ MORE</p>
                              </div>
                            </div>
                          </a>
                          <a data-interception="off" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/MENA_Law_Team_Newsletter-02.pdf" target="_blank" rel="noreferrer" style={{ textDecoration: 'none' }}>
                            <div className="news_box">
                              <div className="imgTile" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' }} />
                              <div className="newsDes">
                                <p className="Ntitle">Edition-02</p>
                                <p className="Ndes">Welcome to the second edition of 'To The Point', the internal MENA Law Team Newsletter.</p>
                                <p className="Nread">READ MORE</p>
                              </div>
                            </div>
                          </a>
                          <a data-interception="off" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/images/Dear%20All.pdf" target="_blank" rel="noreferrer" style={{ textDecoration: 'none' }}>
                            <div className="news_box">
                              <div className="imgTile" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' }} />
                              <div className="newsDes">
                                <p className="Ntitle">Edition-01</p>
                                <p className="Ndes">Welcome to 'To The Point', our first edition of the internal MENA Law Team Newsletter.</p>
                                <p className="Nread">READ MORE</p>
                              </div>
                            </div>
                          </a>
                        </div>
                        <div className="nws02 nsw">
                          <p className="newsHd">LT updates</p>
                          <hr className="newsHr" />
                          <a data-interception="off" href="https://sites.ey.com/sites/MENATaxHub/Newsletter/New%20MENA%20Law%20FS%20Leader.pdf" target="_blank" rel="noreferrer">
                            <div className="news_box">
                              <div
                                className="imgTile"
                                style={{
                                  backgroundImage:
                                    'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/FSleader_.png)',
                                }}
                              />
                              <div className="newsDes">
                                <p className="Ntitle" style={{ visibility: 'hidden' }}>
                                  Edition-01
                                </p>
                                <p className="Ndes">New MENA Law FS Leader</p>
                                <p className="Nread">READ MORE</p>
                              </div>
                            </div>
                          </a>
                        </div>
                      </li>
                    </ul>
                  </div>

                  <div className={activeTab === 'four' ? 'tab-pane fade show active p-3' : 'tab-pane fade p-3'} id="four" role="tabpanel" aria-labelledby="four-tab">
                    <p className="bt_7">Indirect Tax (IDT)</p>
                    <div className="profileDetails">
                      <img
                        src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Mohammed%20Bilal%20Akram.jpg"
                        className="proImg"
                        alt="Mohammed Bilal Akram"
                      />
                      <p className="proName">Mohammed Bilal Akram</p>
                      <p className="proDes">MENA IDT Leader</p>
                    </div>
                    <p className="tabTxt">
                      Indirect taxes affect the supply chain and the financial system of companies. Our network combines technical knowledge with industry
                      understanding and access to technologically advanced tools and methodologies. We identify risk areas and sustainable planning opportunities
                      for indirect taxes throughout the tax life cycle, helping clients meet their compliance obligations and business goals around the world. <a data-interception="off" href="https://sites.ey.com/sites/DS_Tax/IndirectTax/Pages/Home.aspx" target="_blank" rel="noreferrer">
                        Visit the Discover Global Indirect site to know more.
                      </a>
                    </p>
                    <br/>
                    <ul className="ul_01">
                      <li>
                        <a data-interception="off" href="https://sites.ey.com/sites/DS_Tax/IndirectTax/Pages/vatgst.aspx" target="_blank" rel="noreferrer">
                          Value-added tax (VAT)
                        </a>
                      </li>
                      <li>
                        <a data-interception="off" href="https://sites.ey.com/sites/DS_Tax/IndirectTax/Pages/global-trade.aspx" target="_blank" rel="noreferrer">
                          Global Trade
                        </a>
                      </li>
                      <li>
                        <a data-interception="off" href="https://sites.ey.com/sites/DS_Tax/IndirectTax/Pages/excise-taxes.aspx" target="_blank" rel="noreferrer">
                          Excise taxes
                        </a>
                      </li>
                      <li>
                        <a data-interception="off" href="#">Sustainability tax</a>
                      </li>
                    </ul>
                  </div>

                  <div className={activeTab === 'five' ? 'tab-pane fade show active p-3' : 'tab-pane fade p-3'} id="five" role="tabpanel" aria-labelledby="five-tab">
                    <p className="bt_7">International Tax & Transaction Services (ITTS)</p>
                    <div className="profileDetails">
                      <img
                        src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Rajan%20Parmar.png"
                        className="proImg"
                        alt="Rajan Parmar"
                      />
                      <p className="proName">Rajan Parmar</p>
                      <p className="proDes">MENA ITTS Leader</p>
                    </div>
                    <p className="tabTxt">
                      <a data-interception="off" href="https://sites.ey.com/sites/DS_Tax/Pages/international-tax-transaction-services.aspx" target="_blank" rel="noreferrer">
                        International Tax and Transaction Services (ITTS)
                      </a>
                      is comprised of three competencies: International Corporate Tax Advisory (ICTA), Transaction Tax Advisory (TTA) and Transfer Pricing (TP).
                      Our practice helps financial sponsors, private capital enterprises and multinational corporations proactively address challenges by bringing globally
                      connected services to all tax aspects of their business and investment models, corporate structure, treasury management and overall tax and transaction strategy.
                      This encompasses the client's full transaction life cycle, from strategy and corporate finance, through to acquisition, optimization and eventual disposal.
                      <br />
                      <br />
                      The ITTS go-to-market approach is organized around five global services pillars. Our teams are organized and deployed globally, they aim to create innovative
                      and saleable content and to support you in tailoring, and where relevant delivering, these offerings to your clients.
                      <br />
                      <br />
                      <a data-interception="off" href="https://sites.ey.com/sites/DS_Tax/Pages/international-tax-transaction-services.aspx" target="_blank" rel="noreferrer">
                        Visit the Discover ITTS site to know more.
                      </a>
                    </p>
                    <a data-interception="off" href="https://sites.ey.com/sites/DS_Tax/BTS/Pages/business-tax-advisory.aspx" className="newClass" target="_blank" rel="noreferrer">
                      Corporate Tax Advisory (CTA)
                    </a>
                    <p className="tabTxt">
                      CTA advises clients on a broad range of tax planning and advisory matters based on both in-country tax technical knowledge and sector insights.
                      It helps corporations, partnerships, joint ventures and other business entities to build sustainable tax strategies in order to achieve
                      their full potential. This can include day-to-day domestic tax advice, as well as project work on a variety of aspects across a client's tax life cycle.
                    </p>
                    <a data-interception="off" href="https://sites.ey.com/sites/DS_Tax/BTS/Pages/global-tax-controversy.aspx" className="newClass" target="_blank" rel="noreferrer">
                      Tax Controversy (TC)
                    </a>
                    <p className="tabTxt">
                      In an increasingly interconnected global tax environment, Tax Controversy helps companies address multi-dimensional, multi-country tax issues and keep up
                      with the latest regulatory and technology developments, maintaining a focus on compliance and risk management. Organizations that want to manage current
                      and future tax disputes effectively need to make investments - in people, processes and technology - now.
                      <br />
                      The <a data-interception="off" href="https://sites.ey.com/sites/DS_Tax_BTS/Pages/tax-controversy-department-of-the-future.aspx" target="_blank" rel="noreferrer">
                        Tax Controversy Department of the Future
                      </a>
                      can help them do just that, identifying leading practices, gathered through intense research and collective experience, across every area of the tax controversy
                      management lifecycle.
                    </p>
                    <a data-interception="off" className="newClass" href="https://sites.ey.com/sites/DS_Tax/BTS/Pages/ey-private-tax.aspx" target="_blank" rel="noreferrer">
                      EY Private Tax
                    </a>
                    <p className="tabTxt">
                      EY Private Tax takes an integrated and global approach in delivering a range of tax and advisory services to private owners, their families and their businesses,
                      private equity and asset management stakeholders and high-net-worth individuals. We support Private Tax clients with speciality services that are "designed for Private"
                      including Private Business tax advisory and compliance services, family office advisory services, and wealth transition and succession planning.
                    </p>
                    <div style={{ marginBottom: '5vw', marginRight: '0.4vw' }}>
                      <a data-interception="off" href="https://eyus.sharepoint.com/sites/Navigate-ITTS-Global" target="_blank" rel="noreferrer" className="cl-v1">
                        <img
                          src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/icon-png.png"
                          className="info-img"
                          alt="Icon"
                        />
                        Navigate to ITTS Global
                      </a>
                    </div>
                    <div className="cf_head">Five Global Services Pillars</div>
                    <div className="tableSection">
                      <div className="col_1">
                        <div className="Hdline">IP Alignment, Operating Model and Supply Chain</div>
                        <div className="cnt-sec">
                          <p className="p-text">
                            Integrates Tax (indirect and direct), Transaction, Advisory and other service lines for supply chain and operating model effectiveness.
                          </p>
                          <p className="c8"><strong>Service offerings</strong></p>
                          <ul className="c9">
                            <li>Operating model effectiveness (OME)/ Supply chain</li>
                            <li>IP alignment and industry convergence (IAIC)</li>
                            <li>Permanent establishment management</li>
                          </ul>
                        </div>
                      </div>
                      <div className="col_1">
                        <div className="Hdline">Corporate Structure</div>
                        <div className="cnt-sec">
                          <p className="p-text">
                            Provides advice on the tax implications of global legal structure, internal restructuring and third-party transaction structuring.
                          </p>
                          <p className="c8"><strong>Service offerings</strong></p>
                          <ul className="c9">
                            <li>Holding, Finance and SPV Structuring</li>
                            <li>Internal corporate restructuring</li>
                            <li>Legal entity rationalization</li>
                          </ul>
                        </div>
                      </div>
                      <div className="col_1">
                        <div className="Hdline">Global Treasury</div>
                        <div className="cnt-sec">
                          <p className="p-text">
                            Brings tax efficiency to treasury goals, including capital structure planning, internal financing of domestic or cross-border activities.
                          </p>
                          <p className="c8"><strong>Service offerings</strong></p>
                          <ul className="c9">
                            <li>Cross border risk management</li>
                            <li>Liquidity management</li>
                            <li>Bankruptcy and distressed debt restructuring (Reshaping Results)</li>
                            <li>Cross border capital structure planning</li>
                            <li>Transfer pricing for global treasury</li>
                          </ul>
                        </div>
                      </div>
                      <div className="col_1">
                        <div className="Hdline">Transaction Advisory</div>
                        <div className="cnt-sec">
                          <p className="p-text">
                            Serves corporate and private capital markets clients undertaking third-party transactions in tax diligence, general transaction advisory and overall transaction project management.
                          </p>
                          <p className="c8"><strong>Service offerings</strong></p>
                          <ul className="c9">
                            <li>Bankruptcy and distressed debt restructuring (Reshaping Results)</li>
                            <li>Buy-side and sell-side diligence</li>
                            <li>Private equity</li>
                            <li>Buy & Integrate</li>
                            <li>Sell & Separate</li>
                          </ul>
                        </div>
                      </div>
                      <div className="col_1">
                        <div className="Hdline">Tax Operations</div>
                        <div className="cnt-sec">
                          <p className="p-text">
                            Provides assistance to multinational corporations with cross border controversy, policy related matters, international tax compliance and quantitative decision support as well as transfer pricing documentation.
                          </p>
                          <p className="c8"><strong>Service offerings</strong></p>
                          <ul className="c9">
                            <li>Transfer pricing documentation and transparency</li>
                            <li>Cross-border controversy</li>
                            <li>International Tax policy</li>
                            <li>Quantitative decision support</li>
                            <li>Inter-company effectiveness</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className={activeTab === 'six' ? 'tab-pane fade show active p-3' : 'tab-pane fade p-3'} id="six" role="tabpanel" aria-labelledby="Six-tab">
                    <p className="bt_7">People Advisory Services (PAS)</p>
                    <div className="profileDetails">
                      <img
                        src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Xavier.jpg"
                        className="proImg"
                        alt="Xavier Delaunay"
                      />
                      <p className="proName">Xavier Delaunay</p>
                      <p className="proDes">MENA PAS Leader</p>
                    </div>
                    <p className="tabTxt">
                      PAS helps clients with their people agenda, working with them to cultivate impactful people, human resource (HR) and organizational alignment at critical business crossroads.
                      <br />
                      <br />
                      The <a data-interception="off" href="https://sites.ey.com/sites/DS_PAS/Pages/org-culture-people-and-workforce-experience-fop.aspx" target="_blank" rel="noreferrer">
                        Organization and People Field of Play
                      </a>
                      is one of the 14 cross-Service line Fields of Play that have been established to help our account teams translate the needs of our clients' most pressing people-related needs and align them to our solutions,
                      services and capabilities.
                      <br />
                      <br />
                      Our solutions underpin the Organization and People Field of Play. These are designed to provide clients with the right set of services to address their needs at the critical junctures of their journey.
                      <br />
                      <br />
                      Visit the <a data-interception="off" href="https://sites.ey.com/sites/DS_PAS/Pages/Home.aspx" target="_blank" rel="noreferrer">Discover PAS site</a> to know more.
                    </p>
                    <ul className="ul_01">
                      <li>Organization and Workforce Transformation - Aligning organization and workforce capability</li>
                      <li>HR Transformation - Outpacing the competition to get work done efficiently</li>
                      <li>People Mobility - Enables quicker decision-making across the mobility agenda</li>
                      <li>People Experience - Enhancing employee engagement, productivity, and well-being through new ways of working.</li>
                      <li>
                        <a data-interception="off" href="https://sites.ey.com/sites/DS_Tax/GCR/Pages/payroll-operations.aspx" target="_blank" rel="noreferrer">
                          Payroll Operate
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="container-fluid footerTab" hidden>
            <div className="row">
              <div className="col-sm-12">
                <p className="quicklinks">Quick links</p>
                <a data-interception="off" href="https://sites.ey.com/sites/EYMENA/SiteAssets/PDF/MENA%20TE%20Policy/ME%20TE%20Policy.pdf" target="_blank" rel="noreferrer" className="qLInk">
                  <img
                    className="qklinks"
                    src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png"
                    alt="Link icon"
                  />
                  MENA Expense Policy
                </a>
                <a data-interception="off" href="https://sites.ey.com/sites/menapeopleconnect/SitePages/TotalReward.aspx" target="_blank" rel="noreferrer" className="qLInk">
                  <img
                    className="qklinks"
                    src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png"
                    alt="Link icon"
                  />
                  MENA Total Reward
                </a>
                <a data-interception="off" href="https://sites.ey.com/sites/menapeopleconnect/SitePages/Policies%20and%20Procedures.aspx" target="_blank" rel="noreferrer" className="qLInk">
                  <img
                    className="qklinks"
                    src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png"
                    alt="Link icon"
                  />
                  MENA Talent Policies & Procedures
                </a>
                <a data-interception="off" href="https://lms.ey.net/" target="_blank" rel="noreferrer" className="qLInk">
                  <img
                    className="qklinks"
                    src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png"
                    alt="Link icon"
                  />
                  LMS
                </a>
                <a data-interception="off" href="https://sort.ey.net/" target="_blank" rel="noreferrer" className="qLInk">
                  <img
                    className="qklinks"
                    src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png"
                    alt="Link icon"
                  />
                  SORT
                </a>
                <a data-interception="off" href="https://sf.ey.net" target="_blank" rel="noreferrer" className="qLInk">
                  <img
                    className="qklinks"
                    src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png"
                    alt="Link icon"
                  />
                  SuccessFactors
                </a>
                <a data-interception="off"
                  href="https://intranet.ey.com/sites/career-development/SitePageModern/342011/career-development"
                  target="_blank"
                  rel="noreferrer"
                  className="qLInk"
                >
                  <img
                    className="qklinks"
                    src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png"
                    alt="Link icon"
                  />
                  Career & development
                </a>
                <a data-interception="off" href="https://sites.ey.com/sites/menapeopleconnect/SitePages/Onboarding.aspx" target="_blank" rel="noreferrer" className="qLInk">
                  <img
                    className="qklinks"
                    src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png"
                    alt="Link icon"
                  />
                  New starters (first 90 days)
                </a>
              </div>
            </div>
          </div>
          <div className="footer">
            <p>© 2026 EYGM Limited. All rights reserved.</p>
          </div>
        </div>
      </div>
    </>
  );
};

export default SSL;
