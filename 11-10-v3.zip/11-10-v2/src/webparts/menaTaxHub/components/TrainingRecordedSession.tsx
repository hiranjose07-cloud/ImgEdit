import * as React from 'react';

const imageRoot = 'https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/';

interface ITrainingRecordedSessionProps {
  onShowHome: () => void;
}

const recordedSessionStyles = `
html,body{overflow-x:hidden!important;font-family:EYInterstate}.training-recorded{background:#2e2e38;color:#fff;min-height:100vh}.training-recorded .loading-container{align-items:center;background:#1a1a24;display:flex;inset:0;justify-content:center;position:fixed;z-index:9999}.training-recorded .loading-container .item{border:.2vw solid #ffe600;border-bottom-color:transparent;border-radius:50%;border-top-color:transparent;position:absolute;animation:recorded-spin 2s ease infinite}.training-recorded .loading-container .item:nth-child(1){height:30px;width:30px}.training-recorded .loading-container .item:nth-child(2){animation-delay:.1s;height:50px;width:50px}.training-recorded .loading-container .item:nth-child(3){animation-delay:.2s;height:70px;width:70px}.training-recorded .loading-container .item:nth-child(4){animation-delay:.3s;height:90px;width:90px}@keyframes recorded-spin{50%{transform:rotate(180deg)}100%{transform:rotate(0)}}.training-recorded .nav-bar{background:#2e2e38;min-height:6vw;position:relative}.training-recorded .EYlogo{left:5vw;position:absolute;top:1.5vw;width:3vw}.training-recorded .logoTxt{color:#fff;font-size:2vw;left:11vw;position:absolute;top:2.2vw}.training-recorded .navbarMenu{list-style:none;margin:0;padding:0;position:absolute;right:6vw;top:2.4vw}.training-recorded .navbarMenu li{display:inline-block;font-size:1vw}.training-recorded .navbarMenu a{color:#fff;padding:0 2vw;text-decoration:none}.training-recorded .home{width:1.3vw}.training-recorded .bannerBackground{background:#2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/banner.jpg') center/cover;min-height:8vw}.training-recorded .cnt-fdr{background:rgba(46,46,56,.5);min-height:8vw;padding:2vw 3.5vw}.training-recorded .cf6{color:#fff;font-size:1.5vw;margin:0}.training-recorded .tabContent{background:#2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center/cover;min-height:35vw;padding:4vw 5.5vw}.training-recorded .cl-3{cursor:pointer;padding:.35vw}.training-recorded .boxTag{display:block;text-decoration:none}.training-recorded .col-sm-bx{background:#ffffff0f url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center/cover;box-shadow:0 0 1.5vw rgba(0,0,0,.44);min-height:19vw;overflow:hidden;position:relative;width:100%}.training-recorded .img-bx{background-position:right;background-size:100%;min-height:10vw;transition:all .2s ease-in-out;width:100%}.training-recorded .col-sm-bx:hover .img-bx{background-size:110%}.training-recorded .playIcon{background:#fff;border:.3vw solid #fff;border-radius:50%;float:right;margin-right:2vw;margin-top:-1.2vw;width:2.5vw}.training-recorded .bx-link{color:#fff;font-size:.9vw;line-height:1.3vw;margin:0;padding:2vw 1vw 0 1.5vw}.training-recorded .footer{background:#000;float:left;width:100%}.training-recorded .footer p{font-size:1vw;margin:0;padding:1vw 2vw;text-align:right}
@media(max-width:1200px){.training-recorded .EYlogo{left:60px;top:20px;width:40px}.training-recorded .logoTxt{font-size:25px;left:130px;top:30px}.training-recorded .navbarMenu{right:50px;top:31px}.training-recorded .home{width:20px}.training-recorded .nav-bar{min-height:90px}.training-recorded .cf6{font-size:30px}.training-recorded .cnt-fdr{padding:35px 70px}.training-recorded .tabContent{padding:50px 70px}.training-recorded .col-sm-bx{min-height:70px}.training-recorded .bx-link{font-size:13px;line-height:17px;padding:30px}.training-recorded .playIcon{border:3px solid #fff;margin-right:30px;margin-top:-13px;width:30px}.training-recorded .footer p{font-size:13px;padding:15px 20px}}

  .col-sm-3 {
        -ms-flex: 0 0 20%;
        flex: 0 0 20%;
        max-width: 20%;
    }


@media(max-width:992px){.training-recorded .col-sm-3.cl-3{flex:0 0 33.333%;max-width:33.333%}}
@media(max-width:750px){.training-recorded .tabContent{padding:40px 30px}.training-recorded .col-sm-3.cl-3{flex:0 0 50%;max-width:50%}.training-recorded .img-bx{min-height:140px}}
@media(max-width:575px){.training-recorded .logoTxt{font-size:20px;left:115px}.training-recorded .EYlogo{left:30px}.training-recorded .navbarMenu{top:110px}.training-recorded .col-sm-3.cl-3{flex:0 0 100%;max-width:100%}.training-recorded .col-sm-bx{min-height:0}.training-recorded .img-bx{min-height:200px}.training-recorded .bx-link{font-size:14px;line-height:20px;padding:20px}.training-recorded .tabContent{padding:40px 20px}}
`;

const TrainingRecordedSession: React.FC<ITrainingRecordedSessionProps> = ({ onShowHome }) => {
  const [isLoading, setIsLoading] = React.useState<boolean>(true);

  React.useEffect(() => {
    const timer = window.setTimeout(() => setIsLoading(false), 2000);
    return () => window.clearTimeout(timer);
  }, []);

  return (
    <div className="training-recorded">
      <style>{recordedSessionStyles}</style>
      {isLoading && <div className="loading-container" aria-label="Loading"><div className="item" /><div className="item" /><div className="item" /><div className="item" /></div>}
      <div className="webPart">
        <div className="container-fluid nav-container">
          <div className="row nav-bar">
            <img className="EYlogo" src={`${imageRoot}EY_logo.png`} alt="EY logo" />
            <p className="logoTxt">MENA Tax Hub</p>
            <ul className="navbarMenu"><li><a data-interception="off" href="#home" onClick={(event) => { event.preventDefault(); onShowHome(); }}><img className="home" src={`${imageRoot}home.png`} alt="Home" /></a></li></ul>
          </div>
        </div>
        <div className="container-fluid">
          <div className="row">
            <div className="col-sm-12 bannerBackground">
              <div className="container-fluid cnt-fdr"><p className="cf6">Training recorded session</p></div>
            </div>
          </div>
        </div>
        <div className="container-fluid tabContent">
          <div className="row">
            <div className="col-sm-3 cl-3">
              <a data-interception="off" className="boxTag" href="https://sites.ey.com/:v:/r/sites/MENATaxHub/SiteAssets/MENATax/Videos/ELM_Introduction%20to%20Mercury%20and%20Engagement%20Economics_31%20Oct%2022-20221031_123624-Meeting%20Recording.mp4" target="_blank" rel="noreferrer">
                <div className="col-sm-bx"><div className="img-bx" style={{ backgroundImage: `url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/vd01.png)` }} /><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/play.png" className="playIcon" alt="Play" /><p className="bx-link">ELM_Introduction to Mercury and Engagement Economics_31 Oct 22</p></div>
              </a>
            </div>
            <div className="col-sm-3 cl-3">
              <a data-interception="off" className="boxTag" href="https://sites.ey.com/:v:/r/sites/MENATaxHub/SiteAssets/MENATax/Videos/ELM_Mercury%20and%20Reporting%20tool_01%20Nov%2022%20(Hands-on%20session)-20221101_120309-Meeting%20Recording.mp4" target="_blank" rel="noreferrer">
                <div className="col-sm-bx"><div className="img-bx" style={{ backgroundImage: `url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/vd04.png)` }} /><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/play.png" className="playIcon" alt="Play" /><p className="bx-link">ELM_Mercury and Reporting tool_01 Nov 22 (Hands-on session)</p></div>
              </a>
            </div>
            <div className="col-sm-3 cl-3">
              <a data-interception="off" className="boxTag" href="https://sites.ey.com/:v:/r/sites/MENATaxHub/SiteAssets/MENATax/Videos/Recording_Pricing%20for%20Value%20-%20Part%201.mp4" target="_blank" rel="noreferrer">
                <div className="col-sm-bx"><div className="img-bx" style={{ backgroundImage: `url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/pricing%20for%20value.png)` }} /><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/play.png" className="playIcon" alt="Play" /><p className="bx-link">Working Capital Management_Pricing for Value_Session 1_16 Jun 23</p></div>
              </a>
            </div>
          </div>
        </div>
        <div className="footer"><p>&#169; 2026 EYGM Limited. All rights reserved.</p></div>
      </div>
    </div>
  );
};

export default TrainingRecordedSession;
