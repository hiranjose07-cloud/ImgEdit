import * as React from 'react';

const engagementStyles = `
html, body { overflow-x: hidden !important; font-family: EYInterstate; }
.engagement-page { background: #2e2e38; color: #ffffff; min-height: 100vh; }
.engagement-page .container_wrapper { display: block; }
.engagement-page .bannerBackground { background: #2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/banner.jpg') center / 115% 115%; min-height: 20.6vw; padding: 3vw 11vw 0 0; }
.engagement-page .nav-bar { background: #2e2e38; min-height: 6vw; position: relative; }
.engagement-page .EYlogo { left: 5vw; position: absolute; top: 1.5vw; width: 3vw; }
.engagement-page .logoTxt { color: #ffffff; font-size: 2vw; left: 11vw; position: absolute; top: 2.2vw; }
.engagement-page .navbarMenu { list-style: none; margin: 0; padding: 0; position: absolute; right: 6vw; top: 2.4vw; }
.engagement-page .navbarMenu li { display: inline-block; }
.engagement-page .navbarMenu a { color: #ffffff; text-decoration: none; }
.engagement-page .home { width: 1.3vw; }
.engagement-page .hd1 { color: #ffe600; font-size: 3vw; line-height: 3.4vw; margin: 7vw 0 2vw 5vw; }
.engagement-page .hd1 span { color: #ffffff; display: block; }
.engagement-page .hd2 { color: #ffffff; font-size: 1vw; line-height: 1.5vw; margin: 0 0 3vw 5vw; }
.engagement-page .rgt_container { padding: 0; }
.engagement-page .rgt_c7 { height: 9.4vw; padding: 0; }
.engagement-page .rgt_c7 a { text-decoration: none; }
.r01{margin:0px !important;}
.c47{padding:0px !important;}
.engagement-page .rg_01, .engagement-page .rg_03, .engagement-page .rg_04, .engagement-page .rg_05 { background: #2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center / cover; height: 100%; position: relative; }
.rg_01{    background-color: rgb(255 255 255 / 19%) !important;}
.rg_03{    background-color: rgb(255 255 255 / 19%) !important;}
.engagement-page .s1 { color: #ffffff; font-size: 1vw; line-height: 1.2vw; left: 2vw; position: absolute; text-align: center; top: 50%; transform: translateY(-50%); width: 13vw; }
.engagement-page .fg1, .engagement-page .f1y { display: none; }
    
.engagement-page .footerTab { background: #1a1a24; padding: 5vw; }
.engagement-page .quicklinks { color: #ffffff; font-size: 1.3vw; margin-bottom: 2vw; }
.engagement-page .quickLinksGrid { display: flex; flex-wrap: wrap; }
.engagement-page .quickLink { flex: 0 0 25%; max-width: 25%; padding: .4vw; }
.engagement-page .col-sm-bx { background: #ffffff0f url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center / cover; box-shadow: 0 0 1.5vw rgba(0,0,0,.44); min-height: 7.5vw; position: relative; }
.engagement-page .img-bx { background-position: center; background-size: cover; bottom: 0; left: 0; position: absolute; top: 0; width: 37%; }
.engagement-page .bx-link { color: #ffffff; font-size: 1vw; left: 45%; line-height: 1.4vw; position: absolute; top: 50%; transform: translateY(-50%); width: 48%; }
.engagement-page .col-sm-bx span { bottom: .3vw; color: rgba(255,255,255,.52); font-size: 2vw; font-weight: bold; position: absolute; right: 1vw; }
.engagement-page .footer { background: #000000; }
.engagement-page .footer p { margin: 0; padding: 1vw 2vw; text-align: right; }
.engagement-page .engagementModal { align-items: center; background: rgba(0,0,0,.65); display: flex; inset: 0; justify-content: center; overflow-y: auto; padding: 2vw; position: fixed; z-index: 1000000; }
.engagement-page .engagementModalContent { background: #2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center / cover; box-sizing: border-box; max-height: 94vh; max-width: 90%; overflow-y: auto; padding: 3vw 4vw; position: relative; width: 90%; }
.engagement-page .closeButton { background: #ffe600; border: 0; color: #000000; cursor: pointer; font-size: 1.5vw; height: 2.2vw; line-height: 1.5vw; padding: 0; position: absolute; right: 1.5vw; top: 1.5vw; width: 2.2vw; z-index: 1; }
.engagement-page .modalTitle { color: #ffffff; font-size: 2.3vw; font-weight: normal; margin: 0 0 2.5vw; padding-top: .5vw; }
.engagement-page .keyLinks { float: left;
    width: 12vw;
    background: rgba(255, 255, 255, .07);
    min-height: 12vw;
    padding: 1.5vw 1.5vw;
    margin-right: 1.5vw;
    margin-bottom: 1vw;
    -webkit-transition: all .15s ease-in-out;
    -moz-transition: all .2s ease-in-out;
    -o-transition: all .2s ease-in-out;
    transition: all .2s ease-in-out;
    cursor: pointer;
    margin-right: 0vw !important; }
.engagement-page .keyLinks + .keyLinks { margin-left: 1.5vw; border:hidden; }
.engagement-page .keyLinks:hover { background: rgba(255,255,255,.2); }
.engagement-page .keyLinks img { display: block; height: 4vw; object-fit: contain; width: 4vw; }
.engagement-page .keyLinks p { color: #ffffff; font-size: 1vw; line-height: 1.3vw; margin: 1vw 0 0; }
.engagement-page .contactTable { border-collapse: collapse; color: #ffffff; margin-top: 2vw; width: 100%; }
.engagement-page .contactTable th, .engagement-page .contactTable td { border-top: 1px solid #5e5e5e !important; padding: 1vw 1.2vw; text-align: left; vertical-align: top; padding:1.7vw 0vw; }
.engagement-page .contactTable th { font-size: 1.1vw; font-weight: normal; }
.engagement-page .contactTable td { color: #b2b2b2; font-size: .9vw; }
.engagement-page .contactTable td p { margin: 0; }
.engagement-page .contactTable a { color: #ffe600; text-decoration: none; }
.engagement-page .mbaContactsModal { z-index: 1000001; }
.engagement-page .mbaTable { max-width: 55%; }

@media only screen and (max-width: 800px) { .engagement-page .engagementModal { padding: 20px; } .engagement-page .engagementModalContent { max-width: 100%; padding: 40px 25px 25px; width: 100%; } .engagement-page .closeButton { font-size: 24px; height: 32px; right: 15px; top: 15px; width: 32px; } .engagement-page .modalTitle { font-size: 30px; margin-bottom: 25px; } .engagement-page .keyLinks { min-height: 150px; padding: 15px 20px; width: 30%; } .engagement-page .keyLinks + .keyLinks { margin-left: 1.5%; } .engagement-page .keyLinks img { height: 50px; width: 50px; } .engagement-page .keyLinks p { font-size: 14px; line-height: 16px; margin-top: 15px; } .engagement-page .contactTable { margin-top: 25px; } .engagement-page .contactTable th, .engagement-page .contactTable td { font-size: 14px; padding: 12px; } .engagement-page .mbaContactsModal .engagementModalContent { width: 80%; } .engagement-page .mbaTable { max-width: 100%; } }
@media only screen and (max-width: 650px) { .engagement-page .keyLinks { display: block; margin: 0 0 10px !important; min-height: auto; width: 100%; } .engagement-page .keyLinks p { margin-bottom: 0; } .engagement-page .contactTable { display: block; overflow-x: auto; white-space: nowrap; } .engagement-page .mbaContactsModal .engagementModalContent { width: 100%; } }
@media only screen and (max-width: 800px) { .engagement-page .EYlogo { left: 60px; top: 20px; width: 40px; } .engagement-page .logoTxt { font-size: 25px; left: 130px; top: 30px; } .engagement-page .navbarMenu { right: 50px; top: 31px; } .engagement-page .home { width: 20px; } .engagement-page .hd1 { font-size: 40px; line-height: 36px; margin-top: 70px; } .engagement-page .hd2 { font-size: 15px; line-height: 24px; margin-left: 50px; } .engagement-page .quickLink { flex-basis: 50%; max-width: 50%; } }
@media only screen and (max-width: 500px) { .engagement-page .quickLink { flex-basis: 100%; max-width: 100%; } }
.engagement-page .footerTab .col-sm-3 {-ms-flex: 0 0 20% !important;
        flex: 0 0 20% !important;
        max-width: 20% !important;}
`;

interface IEngagementProps { onShowHome: () => void; onShowPolicies?: () => void; onShowTraining?: () => void; }

const quickLinks = [
  ['Mercury OneGate', 'https://mercury.ey.net/Pages/default.aspx', 'gettyimages-1334575820-2048x2048.jpg'],
  ['Engagement metrics', 'https://mybusiness.ey.net/', 'gettyimages-892701338-1024x1024.jpg'],
  ['Time utilization report', 'http://www.mybusiness.ey.net/myportal/reporttree.aspx', 'tx01.jpg'],
  ['MDM', 'https://www.mdm.ey.net/bp/search/', 'GettyImages-1255683032.jpg'],
  ['SORT', 'https://sort.ey.net/', 'GettyImages-1051617040.jpg'],
  ['GIS', 'https://gis.ey.net/home/dashboard/search', 'tx04.jpg'],
  ['Global Mercury', 'https://sites.ey.com/sites/GlobalMercurySupport/SitePages/MercuryHome.aspx', 'gettyimages-1332353096-1024x1024.jpg'],
  ['GEAR', 'https://gear.ey.net/GEAR/home/search/quick_actions', 'gettyimages-134887165.jpg'],
  ['GCO SharePoint', 'https://sites.ey.com/sites/MENAGCOSharePoint/SitePages/GCO_home.aspx', 'GettyImages-696570136.jpg'],
  ['EYI documentation', '#eyi', 'GettyImages-1091470486.jpg']
];

const supportContacts = [
  ['MENA Detect Control Support', 'Review planned fee and collect Engagement Agreements for central repository', 'menadetectcontrolsupport@gds.ey.com'],
  ['My Expense', 'Expense claims processing and related queries', 'myexpense@xe04.ey.com'],
  ['MENA Mass Transaction Support', 'Bulk Transfer of Time and Expenses', 'menamasstransaction.support@gds.ey.com'],
  ['MENA IFM Support', 'Accounting support and settlement of IFM invoices', 'mena.ifmsupport@xe04.ey.com'],
  ['Mercury transaction support team', 'Provides assistance to engagement managers', 'menamts@bh.ey.com'],
  ['MENA HRG Accounting Support', 'Accounting support on HRG invoices', 'mena.hrgaccountingsupport@om.ey.com']
];

const mbaContacts = [
  ['Saudi Arabia', 'Taha S Siddiqui'],
  ['Kuwait, Qatar, Oman', 'Shalini George'],
  ['Egypt, Lybia', 'Juli Ceasar'],
  ['Jordan, Saudi Arabia', 'Rand Zarour'],
  ['UAE', 'Sanketh Bhandary']
];

const EngagementLifecycleManagement: React.FC<IEngagementProps> = ({ onShowHome, onShowPolicies, onShowTraining }) => {
  const [showContacts, setShowContacts] = React.useState<boolean>(false);
  const [showMbaContacts, setShowMbaContacts] = React.useState<boolean>(false);
  const imageRoot = 'https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/';
  return (
    <div className="engagement-page">
      <style>{engagementStyles}</style>
      <div className="loading-container" style={{ display: 'none' }}><div className="item" /><div className="item" /><div className="item" /><div className="item" /></div>
      <div className="container_wrapper"><div className="webPart">
        <div className="container-fluid nav-container"><div className="row nav-bar"><img className="EYlogo" src={`${imageRoot}EY_logo.png`} alt="EY logo" /><p className="logoTxt">MENA Tax Hub</p><ul className="navbarMenu"><li><a data-interception="off" href="#" onClick={(event) => { event.preventDefault(); onShowHome(); }}><img className="home" src={`${imageRoot}home.png`} alt="Home" /></a></li></ul></div></div>
        <div className="container-fluid"><div className="row"><div className="col-sm-10 bannerBackground"><p className="hd1">Engagement Lifecycle <span>Management</span></p><p className="hd2">The opportunity and engagement lifecycle is a framework that describes how we sell, plan and deliver the work we do for our clients. It runs end-to-end, from managing contacts and pursuits, to creating, delivering and closing an engagement.<br /><br /><b>As part of this, the emphasis is on two main roles:</b><br /><br />1. Your accountability: With Mercury, you will remain accountable for managing the performance of your client engagements, from creating an opportunity through to completing the resulting engagement. You can also manage your engagements independently in Mercury, which gives you more autonomy, and better visibility of your opportunities and engagements.<br /><br />2. Partnership with Finance: You will have an enhanced partnership with the Finance team, who will provide guidance and advice on how best to manage your engagement and maximize margins.</p></div><div className="col-sm-2 c47"><div className="container-fluid rgt_container"><div className="row r01">
          <div className="col-sm-12 rgt_c7"><a data-interception="off" href="#policies" onClick={(event) => { event.preventDefault(); onShowPolicies?.(); }}><div className="rg_01"><p className="s1">Policies<br />and procedures</p></div></a></div>
          <div className="col-sm-12 rgt_c7"><a data-interception="off" href="#training" onClick={(event) => { event.preventDefault(); onShowTraining?.(); }}><div className="rg_05"><p className="s1">My Training</p></div></a></div>
          <div className="col-sm-12 rgt_c7" role="button" tabIndex={0} onClick={() => setShowContacts(true)} onKeyPress={(event) => { if (event.key === 'Enter' || event.key === ' ') setShowContacts(true); }}><div className="rg_03"><p className="s1">Connect with a Support<br />Advisor</p></div></div>
          <div className="col-sm-12 rgt_c7"><div className="rg_04"><p className="s1">Role of Market, Finance<br />and MBAs<br /><span style={{ fontSize: '0.7vw', opacity: .6 }}>(Coming soon)</span></p></div></div>
        </div></div></div></div></div>
        <div className="container-fluid footerTab"><div className="row"><p className="quicklinks">Quick links</p></div><div className="row">{quickLinks.map((link, index) => <div className="col-sm-3 cl-3" key={link[0]}><a data-interception="off" href={link[1]} target="_blank" rel="noreferrer"><div className="col-sm-bx"><div className="img-bx" style={{ backgroundImage: `url(${imageRoot}${link[2]})` }} /><p className="bx-link">{link[0]}</p><span>{index < 9 ? `0${index + 1}` : index + 1}</span></div></a></div>)}</div></div>
        <div className="footer"><p>&#169; 2026 EYGM Limited. All rights reserved.</p></div>
      </div></div>
      {showContacts && <div className="engagementModal" role="dialog" aria-modal="true" aria-labelledby="support-modal-title" onClick={() => setShowContacts(false)}><div className="engagementModalContent" onClick={(event) => event.stopPropagation()}><button type="button" className="closeButton" onClick={() => setShowContacts(false)} aria-label="Close">&times;</button><h2 className="modalTitle" id="support-modal-title">Key point of contacts</h2><div><a data-interception="off" className="keyLinks" href="https://eyt.service-now.com/" target="_blank" rel="noreferrer"><img src={`${imageRoot}service.png`} alt="" /><p>Raise a Service Now request from this website</p></a><a data-interception="off" className="keyLinks" href="tel:88888" target="_blank" rel="noreferrer"><img src={`${imageRoot}phone.png`} alt="" /><p>Call MBA via Teams by dialling 88888</p></a><button type="button" className="keyLinks" onClick={() => setShowMbaContacts(true)}><img src={`${imageRoot}contact.png`} alt="" /><p>Specific MBAs for respective locations and SSL</p></button></div><table className="contactTable"><thead><tr><th scope="col">Team name</th><th scope="col">Action</th><th scope="col">Email</th></tr></thead><tbody>{supportContacts.map((contact) => <tr key={contact[0]}><td><p>{contact[0]}</p></td><td><p>{contact[1]}</p></td><td><p><a data-interception="off" href={`mailto:${contact[2]}`}>{contact[2]}</a></p></td></tr>)}</tbody></table></div></div>}
      {showMbaContacts && <div className="engagementModal mbaContactsModal" role="dialog" aria-modal="true" aria-labelledby="mba-modal-title" onClick={() => setShowMbaContacts(false)}><div className="engagementModalContent" onClick={(event) => event.stopPropagation()}><button type="button" className="closeButton" onClick={() => setShowMbaContacts(false)} aria-label="Close">&times;</button><h2 className="modalTitle" id="mba-modal-title">Specific MBAs for respective locations and SSL</h2><table className="contactTable mbaTable"><thead><tr><th scope="col">Country</th><th scope="col">Name of MBA</th></tr></thead><tbody>{mbaContacts.map((contact) => <tr key={contact[0]}><td>{contact[0]}</td><td>{contact[1]}</td></tr>)}</tbody></table></div></div>}
    </div>
  );
};

export default EngagementLifecycleManagement;
