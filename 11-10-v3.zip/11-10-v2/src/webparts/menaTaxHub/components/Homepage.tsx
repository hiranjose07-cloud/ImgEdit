import * as React from 'react';

interface ISharePointResponse<T> {
  d: T;
}

interface ISharePointContextInfo {
  GetContextWebInformation: {
    FormDigestValue: string;
  };
}

interface ISharePointListItem {
  Id: number;
}

interface IEnsureUser {
  Id: number;
}

const requestAccessWebUrl = 'https://sites.ey.com/sites/MENATaxHub';

const homepageStyles = `
html,
body {
overflow-x: hidden !important;
font-family: EYInterstate;
}


/* .container_wrapper{display: none;} */

::-moz-selection {
color: #ffffff;
background: #27ACAA;
}

::selection {
color: #ffffff;
background: #27ACAA;
}


/* Hide scrollbar for Chrome, Safari and Opera */

body::-webkit-scrollbar {
display: none;
}


/*loading*/

.loading-container {
position: relative;
position: fixed;
z-index: 9999;
background: #1a1a24;
width: 100%;
height: 100vh;
margin: auto;
}

.loading-container .item {
position: absolute;
top: 50%;
left: 50%;
transform: translate(-50%, -50%);
border: .2vw solid #ffe600;
border-radius: 50%;
border-top-color: transparent;
border-bottom-color: transparent;
animation: spin 2s ease infinite;
}

.loading-container .item:nth-child(1) {
width: 30px;
height: 30px;
}

.loading-container .item:nth-child(2) {
width: 50px;
height: 50px;
animation-delay: 0.1s;
}

.loading-container .item:nth-child(3) {
width: 70px;
height: 70px;
animation-delay: 0.2s;
}

.loading-container .item:nth-child(4) {
width: 90px;
height: 90px;
animation-delay: 0.3s;
}

@keyframes spin {
50% {
transform: translate(-50%, -50%) rotate(180deg);
}
100% {
transform: translate(-50%, -50%) rotate(0deg);
}
}


/*loading*/

body {
-ms-overflow-style: none;
/* IE and Edge */
scrollbar-width: none;
position: relative;
/* Firefox */
}

.col-sm-8.bannerBackground {
-ms-flex: 0 0 80%;
flex: 0 0 80%;
max-width: 80%;
}

.col-sm-4.c47 {
-ms-flex: 0 0 20%;
flex: 0 0 20%;
max-width: 20%; padding:0px !important;
}

.bannerBackground {
background-color: #2e2e38e0;
background-size: 115% 115%;
background-position: center center;
position: relative;
background-attachment: fixed;
animation: shrink 20s infinite alternate;
padding: 0px;
}

.quote_div {
min-height: 27.6vw;
background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/quote.jpg);
background-size: cover;
background-position: center;
padding: 0vw 3vw 2vw 5vw;
}

img.qtIcon {
width: 2.5vw;
padding-top: 7.5vw;
margin-bottom: 1vw;
}

.quoteTxt {
font-family: none;
color: #ffffff;
font-size: 1.5vw;
line-height: 1.9vw;
width: 35vw;
}

@keyframes shrink {
0% {
background-size: 115% 115%;
}
100% {
background-size: 100% 100%;
}
}

.nav-bar {
position: relative;
z-index: 999;
background: #2e2e38;
min-height: 6vw;
width: 100%;
margin: 0;
}

.nav-container {
padding: 0px;
}
.c01 {padding:0px;}
.r01{margin:0px !important;}
.profileDes {
    float: left;
    width: 10vw;
    text-align: left;
    margin-left: 1vw;
    margin-top: 0.7vw;
}
    .pName {
    color: #ffffff;
    font-size: .9vw;
    font-family: EYInterstate;
    margin: 1vw 0vw 0vw 0vw;
}
    .pDes {
    color: #ffe600;
    font-size: .8vw;
    font-family: EYInterstate;
    margin: 0vw 0vw 0vw 0vw;
}
.EYlogo {
width: 3vw;
position: absolute;
left: 5vw;
top: 1.5vw;
}

p.logoTxt {
color: #ffffff;
font-size: 2vw;
position: absolute;
left: 11vw;
top: 2.2vw;
}

img.home {
width: 1.3vw;
}

ul.navbarMenu {
position: absolute;
right: 6vw;
top: 2.4vw;
font-family: EYInterstate;
}

ul.navbarMenu li {
display: inline-block;
font-size: 1vw;
color: #ffffff;
}

ul.navbarMenu li a {
color: #ffffff;
text-decoration: none;
padding: 0vw 2vw;
}

.hd1 {
color: #ffe600;
font-size: 2.5vw;
line-height: 2.4vw;
font-family: EYinterstate;
margin-top: 3vw;
margin-left: 4vw;
}

.hd1 span {
color: #ffffff;
}

.hd2 {
color: #ffffff;
font-size: 1vw;
width: 100%;
display: block;
margin-left: 4vw;
padding-right: 5vw;
margin-bottom: 3vw;
}

.bt-txt {
margin: 0;
background: #2e2e38e0;
padding: 2.4vw 3vw 1vw 5vw;
background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);
background-size: cover;
background-attachment: fixed;
}

.m-bg {
min-height: 25vw;
background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/qlty.jpg);
background-position: center;
background-size: cover;
}

.m-lft {
background-color: rgba(255, 255, 255, 0.1);
background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/wavebg.png);
background-size: cover;
background-position: center;
padding: 2vw 2vw;
min-height: 14.5vw;
height: 100%;
padding-right: 1vw;
}

.col-sm-12.m-6 {
min-height: 1vw;
padding: 1vw 1vw;
text-align: center;
margin-top: 0vw;
margin-bottom: 0;
height: auto;
padding-top: 0px;
}

.m3.col-sm-12.m-6 {
padding-top: 3vw;
}

.col-sm-12.m-6 .m-lft {
padding: 3vw 0vw;
min-height: 10vw;
height: auto;
padding-right: 0vw;
position: relative;
margin-top: 0vw;
}

.col-sm-12.m-6 .m-lft img {
width: 100%;
}

.m-6 {
overflow: hidden;
padding: 0vw 1vw;
}

.m-6.m0-6 {
padding-right: .5vw;
}

.m-6.m1-6 {
padding-left: .5vw;
}

.pr_hd {
color: #ffffff;
font-size: 1.3vw;
font-family: EYInterstate;
line-height: 1.6vw;
margin: 0;
margin-bottom: 1vw;
}

.col-sm-12.m-6 .m-lft .pr_hd {
margin-bottom: 0vw;
}

.pr_hd span {
color: #ffe600;
font-size: 2vw;
}

.col-sm-12.m-6 .m-lft .pr_hd span {
font-size: 1.3vw;
color: #ffe600;
}

.pr_txt {
color: #ffffff;
font-size: .9vw;
margin-bottom: .5vw;
margin-top: 1vw;
line-height: 1.2vw;
width: 100%;
}

.img-bg {
background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/img_0p.jpg);
background-size: cover;
}

.c4a7 {
color: #ffffff !important;
font-size: .9vw;
text-decoration: none !important;
margin-bottom: 0px;
}

p.m_btn {
background: #ffffff;
font-size: .9vw;
font-family: EYInterstate;
padding: 0.6vw 1vw;
margin-bottom: 0;
margin-top: 2vw;
width: 7vw;
text-align: center;
}

p.m_btn a {
color: #000000;
text-decoration: none;
}

.rgt_container {
padding: 0px;
}

.m-row {
padding: 0vw 0vw;
background: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/GettyImages-1327611460_edited.jpg);
background-position: center;
background-size: cover;
background-attachment: fixed;
}

.left-0 {
background: rgba(255, 255, 255, .10);
min-height: 20vw;
background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/wavebg.png);
background-size: cover;
background-position: center;
padding: 1vw 4vw .5vw 5vw;
-ms-flex: 0 0 40%;
flex: 0 0 40%;
max-width: 40%;
}

.left-0 img {
width: 100%;
}

.key-c7 {
color: #ffe600 !important;
font-size: .8vw;
display: block;
margin-bottom: -1vw;
margin-top: 0.5vw;
text-decoration: none !important;
}

.fy7 {
width: 8vw;
height: 84%;
position: absolute;
left: .8vw;
top: .8vw;
background-size: cover;
background-position: right;
opacity: 0.9;
}

.news_1 {
background: rgba(255, 255, 255, 0.1);
padding: 1.5vw 1.5vw;
margin-top: 0;
margin-bottom: 1vw;
-webkit-transition: all .2s ease-in-out;
-moz-transition: all .2s ease-in-out;
-o-transition: all .2s ease-in-out;
transition: all .2s ease-in-out;
padding-left: 10vw;
position: relative;
min-height: 8.4vw;
}

.news_1:hover {
background: rgba(255, 255, 255, 0.2);
}

.right-0 {
padding: 1vw .5vw 0vw .5vw;
-ms-flex: 0 0 60%;
flex: 0 0 60%;
max-width: 60%;
}

p.s1 {
color: #ffffff;
font-size: 1vw;
line-height: 1.3vw;
width: 11vw;
position: absolute;
left: 5vw;
margin-bottom: 0vw;
top: 50%;
transform: translate(0%, -50%);
text-align: center;
}


/* .rgt_c7 {
height: 5.89vw;
padding: 0vw;
} */

.rgt_c7 {
height: 4.58vw !important;
padding: 0vw;
}

.rgt_c7 a {
text-decoration: none !important;
}

.rg_01 {
background-color: rgb(255 255 255 / 13%);
background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);
background-size: cover;
background-position: center;
height: 100%;
width: 100%;
-webkit-transition: all .2s ease-in-out;
-moz-transition: all .2s ease-in-out;
-o-transition: all .2s ease-in-out;
transition: all .2s ease-in-out;
position: relative;
overflow: hidden;
}

.rg_02 {
background-color: #2e2e38;
background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);
background-size: cover;
background-position: center;
height: 100%;
width: 100%;
-webkit-transition: all .2s ease-in-out;
-moz-transition: all .2s ease-in-out;
-o-transition: all .2s ease-in-out;
transition: all .2s ease-in-out;
position: relative;
overflow: hidden;
}

.rg_03 {
background-color: rgb(255 255 255 / 13%);
background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);
background-size: cover;
;
background-position: center;
height: 100%;
width: 100%;
background-repeat: no-repeat;
-webkit-transition: all .2s ease-in-out;
-moz-transition: all .2s ease-in-out;
-o-transition: all .2s ease-in-out;
transition: all .2s ease-in-out;
position: relative;
overflow: hidden;
}

.rg_04 {
background-color: #2e2e38;
background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);
background-size: cover;
background-position: center;
height: 100%;
width: 100%;
-webkit-transition: all .2s ease-in-out;
-moz-transition: all .2s ease-in-out;
-o-transition: all .2s ease-in-out;
transition: all .2s ease-in-out;
position: relative;
overflow: hidden;
}

.rg_05 {
background-color: rgb(255 255 255 / 13%);
background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);
background-size: cover;
background-position: center;
height: 100%;
width: 100%;
background-repeat: no-repeat;
-webkit-transition: all .2s ease-in-out;
-moz-transition: all .2s ease-in-out;
-o-transition: all .2s ease-in-out;
transition: all .2s ease-in-out;
position: relative;
overflow: hidden;
}

.rg_06 {
background-color: #2e2e38;
background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);
background-size: cover;
background-position: center;
height: 100%;
width: 100%;
-webkit-transition: all .2s ease-in-out;
-moz-transition: all .2s ease-in-out;
-o-transition: all .2s ease-in-out;
transition: all .2s ease-in-out;
position: relative;
overflow: hidden;
}

.rg_07 {
background-color: rgb(255 255 255 / 13%);
background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);
background-size: cover;
background-position: center;
height: 100%;
width: 100%;
background-repeat: no-repeat;
-webkit-transition: all .2s ease-in-out;
-moz-transition: all .2s ease-in-out;
-o-transition: all .2s ease-in-out;
transition: all .2s ease-in-out;
position: relative;
overflow: hidden;
}

.rg_08 {
background-color: #2e2e38;
background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);
background-size: cover;
background-position: center;
height: 100%;
width: 100%;
-webkit-transition: all .2s ease-in-out;
-moz-transition: all .2s ease-in-out;
-o-transition: all .2s ease-in-out;
transition: all .2s ease-in-out;
position: relative;
overflow: hidden;
}


/* .rg_01:hover,
.rg_02:hover,
.rg_04:hover {
background-size: 190%;
}

.rg_03:hover {
background-size: 190%;
}
.rg_05:hover {
background-size: 190%;
}
.rg_06:hover {
background-size: 190%;
} */

.archived {
background: #ffe600;
color: #000000 !important;
font-size: 1vw;
padding: .5vw 1vw;
float: right;
margin-bottom: 0.5vw;
margin-top: 0vw;
text-decoration: none !important;
background: linear-gradient(to right, #ffe600 50%, #ffffff 50%);
background-size: 200% 100%;
background-position: left bottom;
-webkit-transition: all .6s ease-in-out;
-moz-transition: all .6s ease-in-out;
-o-transition: all .6s ease-in-out;
transition: all .6s ease-in-out;
}

.archived img {
width: 1.3vw;
margin-right: .5vw;
}

.archived:hover {
background-position: right bottom;
}

.rs-01:hover {
background-color: #000000 !important;
}

.f1y {
width: 100%;
position: absolute;
height: 180%;
transform: rotate(180deg);
top: -1px;
display: none;
}

.boxContent span {
color: #ffe600;
font-size: 1.2vw;
margin-right: .3vw;
font-weight: bold;
}

.boxContent p {
color: #ffffff;
font-size: .9vw;
line-height: 1.3vw;
font-family: EYInterstate;
font-weight: lighter;
}

.boxContent p b {
font-size: 1.2vw;
line-height: 2.5vw;
}

.desc {
background: #2e2e38e0;
padding: 9vw 9vw 6vw 9vw;
background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);
background-size: cover;
background-attachment: fixed;
display: none;
}

.boxContent img {
width: 3vw;
margin-bottom: .4vw;
}

img.fg1 {
width: 2vw;
position: absolute;
left: 2vw;
top: 50%;
transform: translate(0%, -50%);
display: none;
}

p.c4 {
color: #ffffff;
font-size: 1vw;
font-family: EYInterstate;
line-height: 1.3vw;
margin-bottom: 0.8vw;
}

ul.c5 {
color: #ffffff;
list-style: none;
padding: 0;
}

ul.c5 li {
position: relative;
padding-left: 1.3vw;
margin-bottom: 0.6vw;
font-size: 1vw;
}

ul.c5 li::before {
content: "";
background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/arrow_icon.png);
position: absolute;
width: .6vw;
height: .6vw;
background-size: contain;
background-repeat: no-repeat;
top: 0.5vw;
left: 0;
}

hr.c8 {
margin-top: 2vw;
margin-bottom: 3vw;
border: 0;
border-top: .01vw solid rgb(116 116 116);
}

.hotNews {
background: #ffe600;
width: 6vw;
margin-bottom: -.6vw;
z-index: 1;
}

.hotNews img {
width: 1.6vw;
padding: 0.2vw 0.1vw 0.3vw 0.5vw;
}

.hotNews span {
color: #000000;
font-size: .8vw;
padding: 0vw 0.3vw;
}

.footerTab {
background: #1a1a24;
padding: 5vw;
}

a.qLInk {
color: #ffffff;
font-family: EYInterstate;
font-size: 1vw;
font-weight: lighter;
border: .1vw dashed #9f9f9f;
padding: 0.5vw 1.6vw;
border-radius: .2vw;
margin-right: .7vw;
text-decoration: none;
float: left;
-webkit-transition: all .2s ease-in-out;
-moz-transition: all .2s ease-in-out;
-o-transition: all .2s ease-in-out;
transition: all .2s ease-in-out;
margin-bottom: .8vw;
width: 24%;
text-align: center;
margin-bottom: 1vw;
position: relative;
min-height: 3vw;
}

.sp_no {
position: absolute;
background: rgb(255 255 255 / 12%);
width: 1.7vw;
height: 1.7vw;
border-radius: 100vw;
line-height: 0;
padding-top: .8vw;
font-size: 0.7vw;
top: 50%;
transform: translate(0%, -50%);
left: 1vw;
}

a.qLInk:hover {
background: rgba(255, 255, 255, .2)
}

.quicklinks {
color: #ffffff;
font-size: 1.3vw;
margin-bottom: 2vw;
}

img.qklinks {
width: 1.4vw;
margin-top: -0.2vw;
margin-right: .4vw;
}

a.qLInk span {
position: absolute;
top: 50%;
left: 50%;
transform: translate(-50%, -50%);
width: 60%;
}


/*WEbAnimation*/

.footer {
background-color: #000000;
float: left;
width: 100%;
}

.footer p {
margin-bottom: 0px;
color: #ffffff;
font-size: 1vw;
padding: 1vw 2vw;
text-align: right;
}

.navToggle {
display: none;
}

.modal-dialog{max-width:50%;}
.modal-content{padding:0px !important;}
/**/

.footerTab {
background: #1a1a24;
padding: 5vw;
}

.quicklinks {
color: #ffffff;
font-size: 1.3vw;
margin-bottom: 2vw;
}

.col-sm-bx {
width: 100%;
background: #ffffff0f;
min-height: 7.5vw;
position: relative;
background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);
background-size: cover;
background-position: center;
box-shadow: 0vw 0vw 1.5vw rgba(0, 0, 0, .44);
}

.img-bx {
min-height: 100%;
position: absolute;
left: 0;
top: 0;
width: 37%;
background-position: center;
background-size: 160%;
-webkit-transition: all .2s ease-in-out;
-moz-transition: all .2s ease-in-out;
-o-transition: all .2s ease-in-out;
transition: all .2s ease-in-out;
}

.col-sm-bx:hover .img-bx {
background-size: 190%;
}

.col-sm-bx span {
color: rgba(255, 255, 255, 0.522);
position: absolute;
right: 1vw;
bottom: .3vw;
font-size: 2vw;
font-weight: bold;
opacity: 0.3;
}

p.bx-link {
color: #ffffff;
font-size: 1vw;
position: absolute;
left: 45%;
top: 2.6vw;
line-height: 1.4vw;
}

.cl-3 {
padding: .4vw;
}


/*contacts*/

.col-sm-12.sm-tm-5 {
-ms-flex: 0 0 16.6666%;
flex: 0 0 16.6666%;
max-width: 16.6666%;
padding: 0vw 0.8vw;
padding-bottom: 1.6vw;
text-align: center;
}

.cf {
background: rgb(255 255 255 / 6%);
min-height: 16vw;
}

.tmImg {
background: #ffe600;
width: 5.5vw;
height: 5.5vw;
border-radius: 100vw;
position: relative;
left: 50%;
transform: translate(-50%, 0);
top: 1.5vw;
overflow: hidden;
}

.tmImg img {
width: 100%;
}

.m1 {
float: left;
text-align: left;
font-size: 1.5vw;
line-height: 1.9vw;
margin: 0;
border-right: .1vw solid #000000;
padding: 1.9vw 1vw;
width: 31%;
color: #000000;
min-height: 8vw;
}

.m2 {
text-align: left;
font-size: 1vw;
line-height: 1.4vw;
padding: 0vw 0.4vw 1vw 1.4vw;
float: left;
width: 65%;
margin: 0;
color: #000000;
}

.m-lft.m0 {
background: #ffffff;
float: left;
padding-right: 1vw !important;
}
.menuButton{width: auto;
    height: auto;
    padding: 0.6vw;
    right: 1vw;
    top: 2vw}
.m-lft.m0 a {
color: #ffffff !important;
font-size: .9vw;
text-decoration: none !important;
background: #2e2e38;
padding: 0.5vw 1vw;
width: 11vw;
float: right;
margin-right: 1vw;
margin-top: .5vw;
}

.m-lft.m0 a.b1 {
top: 10vw;
right: 2vw;
cursor: pointer;
}

.m-lft.m0 a.b2 {
top: 7vw;
right: 2vw;
}

.n-b1 {
min-height: 0vw !important;
}


/**/

.tmShare {
float: left;
position: relative;
left: 50%;
transform: translate(-50%, 0%);
}

.Ic0 {
width: 1.4vw;
float: left;
}

.Ic2 {
width: 1.4vw;
float: left;
margin-left: 0.8vw;
}

.tmProfile {
font-size: 0.8vw;
text-align: center;
margin-top: -0.1vw;
margin-bottom: 1vw;
color: #ffffff;
}

.tmName {
font-size: 1vw;
font-family: EYInterstate;
text-align: center;
margin-top: 2.5vw;
margin-bottom: 0;
color: #ffe600;
}

.modal-dialog.modal-dialog-centered.carousel-dialog {
max-width: 80%;
}
#newsModalThree .modal-dialog.modal-dialog-centered.carousel-dialog {
max-width: 31vw;
}

.homepageModal {
display: flex !important;
position: fixed;
inset: 0;
z-index: 1000000;
background: rgba(0, 0, 0, .65);
align-items: center;
justify-content: center;
}

.homepageModal .modal-dialog {
margin: 1rem;
width: 100%;
}

.homepageModal .modal-content {
position: relative;
}

.homepageModalClose {
position: absolute;
right: .75rem;
top: .4rem;
z-index: 1;
border: 0;
background: transparent;
color: #000000;
font-size: 2rem;
line-height: 1;
cursor: pointer;
}

.videoModalContent {
background: #000000;
max-width: 900px;
padding: 2rem;
}

.videoModalContent video {
display: block;
width: 100%;
}

#newsModalThree .modal-dialog .modal-content {
border-radius: 0
}

#newsModalThree .modal-dialog .modal-content .modal-body {
padding: 2vw 2vw;
}

.form-group {
text-align: left;
}

.form-group label {
font-size: .9vw;
margin-bottom: 0.2vw;
}

.form-control {
min-height: 3vw;
border-radius: 0;
margin-bottom: .5vw;
font-size: .9vw;
}

.btn-primary {
background-color: #ffe600;
border-color: #ffe600;
color: #000000;
width: 100%;
border-radius: 0;
margin-top: 1vw;
padding: 0.6vw 1vw;
font-size: 1.1vw;
}

.form-control::placeholder {
/* Chrome, Firefox, Opera, Safari 10.1+ */
opacity: 0.3;
/* Firefox */
}

.form-control:-ms-input-placeholder {
/* Internet Explorer 10-11 */
opacity: 0.3;
}

.form-control::-ms-input-placeholder {
/* Microsoft Edge */
opacity: 0.3;
}


/**/

img.speakerIcon {
width: 5vw !important;
position: absolute;
left: 11vw;
top: 2vw;
}

p.subText {
font-size: .9vw;
position: absolute;
left: 1vw;
bottom: 1vw;
color: #155CB4;
}

.cf-7 {
position: relative;
display: block;
margin-bottom: 1vw;
}
.r02{margin:0px !important;}

/* .cf-7:nth-child(2):before */

.cf-7:nth-child(1):before {
content: "";
background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/latest-icon.png);
width: 6vw;
height: 1.8vw;
position: absolute;
top: -.8vw;
left: 0;
background-size: 5vw;
z-index: 1;
background-repeat: no-repeat;
background-color: #ffe600;
background-position: center;
}

#divNews {
margin-top: 2vw;
}

@media only screen and (max-width: 1200px) {
 .col-sm-8.bannerBackground {
-ms-flex: 0 0 100%;
flex: 0 0 100%;
max-width: 100%;
 }
 .cnt-fdr {
position: static;
 }
 .col-sm-4.c47 {
-ms-flex: 0 0 100%;
flex: 0 0 100%;
max-width: 100%;
 }
 .col-sm-6.rgt_c7 {
-ms-flex: 0 0 25%;
flex: 0 0 25%;
max-width: 25%;
 }
 .hd1 {
font-size: 30px;
line-height: 35px;
margin-top: 60px;
margin-left: 50px;
margin-bottom: 15px;
 }
 .hd2 {
font-size: 15px;
margin-bottom: 50px;
padding-left: 50px;
padding-right: 50px;
margin-left: auto;
 }
 .boxContent img {
width: 50px;
margin-bottom: 10px;
 }
 .boxContent p {
color: #ffffff;
font-size: 13px;
line-height: 19px;
 }
 .boxContent span {
font-size: 16px;
margin-right: 7px;
 }
 .boxContent p b {
font-size: 16px;
line-height: 25px;
 }
 .cnt-fdr {
padding: 35px 40px;
 }
 p.s1 {
font-size: 16px;
line-height: 20px;
left: 20px;
bottom: 20px;
width: auto;
 }
 .rg_01 {
background-size: cover;
 }
 .rg_02 {
background-size: cover;
 }
 .rg_03 {
background-size: cover;
 }
 .rg_04 {
background-size: cover;
 }
 .bt-txt {
padding: 50px 50px;
 }
 ul.c5 li {
padding-left: 20px;
margin-bottom: 12px;
font-size: 17px;
 }
 ul.c5 li::before {
width: 12px;
height: 12px;
top: 7px;
left: 0;
 }
 p.c4 {
font-size: 20px;
line-height: 26px;
margin-bottom: 15px;
 }
 .pg1 {
font-size: 25px;
margin-bottom: 10px;
padding-top: 50px;
 }
 .pg2 {
font-size: 18px;
margin-bottom: -40px;
 }
 .webAnimation {
min-height: 62vw;
 }
 .quicklinks {
font-size: 16px;
margin-bottom: 25px;
 }
 .pg1x {
font-size: 30px;
margin-bottom: 35px;
 }
 .keyLinks {
background: rgba(255, 255, 255, 0.07);
width: 30%;
min-height: 150px;
padding: 15px 20px;
margin-right: 15px;
margin-bottom: 10px;
 }
 .keyLinks img {
width: 50px;
 }
 .keyLinks p {
line-height: 16px;
font-size: 14px;
margin-top: 15px;
 }
 .table thead th {
font-size: 15px;
 }
 a.qLInk {
font-size: 15px;
padding: 7px 30px;
border-radius: 0.4vw;
margin-bottom: 10px;
margin-right: 10px;
width: 30%;
min-height: 60px;
 }
 .footerTab {
background: #1a1a24;
padding: 60px;
 }
 .EYlogo {
width: 40px;
left: 60px;
top: 20px;
 }
 p.logoTxt {
font-size: 25px;
left: 130px;
top: 30px;
 }
 ul.navbarMenu {
right: 50px;
top: 25px;
 }
 ul.navbarMenu li {
font-size: 15px;
 }
 ul.navbarMenu li a {
padding: 0vw 20px;
 }
 img.home {
width: 20px;
 }
 .nav-bar {
min-height: 90px;
 }
 ul.navbarMenu {
right: 50px;
top: 31px;
 }
 .footer p {
margin-bottom: 0px;
color: #ffffff;
font-size: 13px;
padding: 15px 20px;
text-align: right;
 }
 .col-sm-12.rgt_c7 {
-ms-flex: 0 0 33.333%;
flex: 0 0 33.333%;
max-width: 33.333%;
 }
 p.s1 span {
font-size: 12px !important;
 }
 .rgt_c7 {
height: auto !important;
padding: 0px 0px;
 }
 .rg_06 {
padding: 10px 10px;
 }
 p.s1 {
font-size: 16px;
line-height: 20px;
width: auto;
position: static;
transform: translate(0%, 0%);
 }
 .rs-01 {
padding: 30px 20px;
 }
 .m-row {
padding: 0px 20px 0px 0px;
 }
 .m-lft {
padding: 40px 40px;
 }
 .pr_hd {
font-size: 16px;
margin: 0;
line-height: 25px;
margin-bottom: 40px;
 }
 .hotNews {
width: 80px;
top: -27px;
z-index: 1;
 }
 .hotNews span {
color: #000000;
font-size: 13px;
padding: 0vw 0px;
 }
 .hotNews img {
width: 24px;
padding: 4px 5px;
 }
 .pr_hd span {
font-size: 25px;
 }
 .pr_txt {
font-size: 14px;
margin-bottom: 0;
margin-top: 13px;
line-height: 19px;
 }
 p.m_btn {
font-size: 13px;
padding: 10px 10px;
margin-top: 20px;
width: 120px;
 }
 .sp_no {
position: absolute;
background: rgba(255, 255, 255, 0.12);
width: 20px;
height: 20px;
border-radius: 100vw;
line-height: 0;
padding-top: 11px;
font-size: 12px;
left: 19px;
 }
 .c4a7 {
font-size: 11px;
margin-top: 11px;
 }
 .pr_txt {
margin-bottom: 10px;
 }
 .news_1 {
padding: 15px 15px;
margin-top: 15px;
padding-left: 10vw;
 }
 .left-0 {
padding: 20px 20px;
 }
 .archived {
font-size: 11px;
padding: 10px 12px;
margin-top: 5px;
 }
 .archived img {
width: 18px;
margin-right: 5px;
 }
 .key-c7 {
font-size: 11px;
margin-bottom: -1px;
margin-top: 7px;
 }
}

@media only screen and (max-width: 1000px) {
 .news_1 {
padding: 15px 15px;
margin-top: 15px;
padding-left: 15px;
float: left;
width: 100%;
 }
 .fy7 {
width: 120px;
height: 120px;
position: static;
float: left;
margin-right: 20px;
 }
 .hotNews {
top: -5px;
 }
 .col-sm-6.m-6 {
-ms-flex: 0 0 100%;
flex: 0 0 100%;
max-width: 100%;
 }
 .m-6 {
overflow: hidden;
padding: 0vw 10px !important;
margin-bottom: 12px;
 }
 .m-lft {
padding: 20px 40px;
 }
 .m1 {
font-size: 15px;
line-height: 17px;
border-right: 1px solid #000000;
padding: 11px 10px;
width: 35%;
min-height: 70px;
 }
 p.subText {
font-size: 10px;
left: 10px;
bottom: 0px;
 }
 img.speakerIcon {
width: 47px !important;
left: 110px;
top: 0vw;
 }
 .m2 {
font-size: 12px;
line-height: 15px;
padding: 6px 14px;
 }
 .m-lft.m0 a {
font-size: 11px;
padding: 6px 10px;
width: 115px;
margin-right: 10px;
margin-top: 5px;
 }
 .col-sm-12.m-6 {
margin-top: 15px;
 }
 .cf-7 {
float: left;
width: 100%;
 }
 .cf-7:nth-child(1):before,
 .cf-7:nth-child(2):before {
width: 70px;
height: 22px;
top: 4px;
left: 0;
background-size: 60px;
 }
}

@media only screen and (max-width: 992px) {
 .quoteTxt {
font-family: none;
color: #ffffff;
font-size: 18px;
line-height: 20px;
width: 40%;
 }
 p.bx-link {
font-size: 13px;
left: 45%;
top: 20px;
line-height: 14px;
padding-right: 30px;
 }

 .col-sm-bx span {
right: 10px;
bottom: 0px;
font-size: 15px;
opacity: 0.3;
 }
 .col-sm-3.cl-3 {
-ms-flex: 0 0 33.333%;
flex: 0 0 33.333%;
max-width: 33.333%;
 }
 .col-sm-bx {
min-height: 70px;
 }
 .cl-3 {
padding: 7px;
 }
}

@media only screen and (max-width: 950px) {
 a.qLInk {
width: 48%;
 }
}

@media only screen and (max-width: 850px) {
 .left-0 {
background: none;
padding: 0 20px !important;
min-height: auto;
 }
 .subCircle {
position: static;
display: none;
 }
 .Ctext {
position: static;
 }
 hr.hrLine {
display: none;
 }
 .circlesTab {
float: left;
padding: 0;
 }
 .Ctext {
width: 48%;
margin-right: 2%;
margin-left: 0px;
float: left;
background: #ffe600;
min-height: 60px;
color: #000000;
text-align: center;
font-size: 18px;
position: relative;
left: auto;
top: auto;
line-height: 21px;
padding: 8px 30px 0px 65px;
pointer-events: unset !important;
cursor: pointer;
 }
 .hrx {
display: none;
 }
 .Ctext img {
display: block;
background: #2e2e38;
width: 50px;
padding: 17px 10px;
position: absolute;
left: 0;
height: 100%;
top: 0;
 }
 .webAnimation {
min-height: auto;
min-height: 860px;
padding-left: 50px;
padding-right: 50px;
 }
 .pg2 {
margin-bottom: 0;
 }
 .left-0 {
-ms-flex: 0 0 100%;
flex: 0 0 100%;
max-width: 100%;
 }
 .right-0 {
-ms-flex: 0 0 100%;
flex: 0 0 100%;
max-width: 100%;
 }
 .left-0 {
padding: 20px 20px !important;
 }
 .m-row {
padding: 0px 10px 0px 10px;
 }
}

@media only screen and (max-width: 800px) {
 .col-sm-4.c57 {
-ms-flex: 0 0 100%;
flex: 0 0 100%;
max-width: 100%;
 }
 .col-sm-6.rgt_c7 {
-ms-flex: 0 0 50%;
flex: 0 0 50%;
max-width: 50%;
min-height: 100px;
 }
 p.s1 {
font-size: 18px;
line-height: 24px;
left: 40px;
bottom: 20px;
 }
 p.c4 {
font-size: 20px;
line-height: 27px;
margin-bottom: 20px;
 }
 .modal-dialog.md2 {
max-width: 80%;
 }
}

@media only screen and (max-width: 750px) {
 .Ctext {
width: 100%;
float: left;
min-height: 60px;
color: #000000;
text-align: center;
font-size: 18px;
position: relative;
left: auto;
top: auto;
line-height: 21px;
padding: 8px 30px 0px 65px;
 }
 .webAnimation {
float: left;
padding-bottom: 40px;
 }
 table#tableID {
border: 0;
 }
 table#tableID caption {
font-size: 1.3em;
 }
 table#tableID thead {
border: none;
clip: rect(0 0 0 0);
height: 1px;
margin: -1px;
overflow: hidden;
padding: 0;
position: absolute;
width: 1px;
 }
 table#tableID tr {
display: block;
background-color: rgb(255 255 255 / 16%) !important;
border: hidden;
padding: 5px 20px;
margin-bottom: 15px;
 }
 table#tableID td {
border-bottom: 1px solid #ddd;
display: block;
font-size: 0.8em;
text-align: right;
position: relative;
 }
 table#tableID td::before {
content: attr(data-label);
float: left;
font-weight: bold;
text-transform: uppercase;
position: absolute;
left: 0px;
top: 10px;
 }
 table#tableID td:last-child {
border-bottom: 0;
 }
 table#tableID td p {
margin-bottom: 0;
text-align: left;
margin-top: 21px;
 }
 button.close {
right: 30px;
top: 20px;
 }
 .footerTab {
float: left;
 }
 img.qklinks {
display: none;
 }
 .m-row .col-sm-2 {
display: none;
 }
 .m-lft {
-ms-flex: 0 0 100%;
flex: 0 0 100%;
max-width: 100%;
 }
 .col-sm-3.cl-3 {
-ms-flex: 0 0 50%;
flex: 0 0 50%;
max-width: 50%;
 }
 #VideoPlay .modal-dialog {
max-width: 90% !important;
 }
}

@media only screen and (max-width: 650px) {
 .keyLinks {
width: 100%;
min-height: auto;
padding-bottom: 25px;
 }
 .col-sm-12.rgt_c7 {
-ms-flex: 0 0 50%;
flex: 0 0 50%;
max-width: 50%;
 }
 a.qLInk {
width: 100%;
min-height: auto;
 }
 a.qLInk span {
position: static;
top: 50%;
left: 50%;
transform: translate(0%, 0%);
width: 60%;
 }
 .sp_no {
display: none;
 }
}

@media only screen and (max-width: 575px) {
 .col-sm-6.rgt_c7 {
-ms-flex: 0 0 100%;
flex: 0 0 100%;
max-width: 100%;
 }
 ul.navbarMenu {
top: 110px;
 }
 .hd1 {
margin-top: 70px;
 }
 .modal-dialog.md2 {
max-width: 100%;
 }
 .modal-dialog.ctabl {
max-width: 100%;
 }
 .m-6 {
margin-bottom: 30px;
 }
 .news_1 {
padding-left: 15px;
 }
 .fy7 {
width: 90px;
height: 90px;
 }
 .jp {
text-align: left !important;
font-size: 12px !important;
font-style: italic !important;
left: 10px !important;
top: 10px !important;
width: 100% !important;
float: left !important;
display: block !important;
position: relative !important;
 }
 .jp a {
font-size: 11px !important;
background: none !important;
color: #000000 !important;
padding: 0 !important;
margin: 0 !important;
font-style: italic !important;
text-decoration: underline !important;
text-align: left !important;
width: auto !important;
float: none !important;
margin-left: 3px !important;
 }
 .m2 {
min-height: 80px;
 }
 .col-sm-12.m-6 .m-lft img {
left: 30px !important;
top: 70px !important;
 }
}

@media only screen and (max-width: 500px) {
 .col-sm-3.cl-3 {
-ms-flex: 0 0 100%;
flex: 0 0 100%;
max-width: 100%;
 }
 .col-sm-12.m-6 .m-lft img {
width: 100%;
height: 46px;
 }
}

@media only screen and (max-width: 460px) {
 .quoteTxt {
width: 60%;
 }
 .col-sm-12.rgt_c7 {
-ms-flex: 0 0 100%;
flex: 0 0 100%;
max-width: 100%;
 }
}

@media only screen and (max-width: 400px) {
 .m1 {
width: 100%;
margin-bottom: 0 !important;
padding-right: 80px;
border: hidden;
 }
 .col-sm-12.m-6 .m-lft img {
position: static !important;
margin-top: -60px !important;
float: right !important;
margin-right: 20px !important;
 }
 .m2 {
min-height: auto;
width: 100%;
 }
 .m-lft.m0 a {
font-size: 11px;
padding: 6px 10px;
width: 95%;
margin-right: 2%;
margin-top: 5px;
 }
}
.c03{padding:0px !important;}
.r03{margin:0px !important;}
.m-lft.m0 a.OutlookLink{color:#000000 !important;}
#lineManagerName {
position: relative;
width: 100%;
min-height: 3vw;
margin-bottom: 1vw;
text-align: left;
display: block;
padding: 0.6vw 1vw;
font-size: 0.9vw;
border: 1px solid #ababab;
border-radius: 0;
background: rgba(255, 255, 255, 0.85);
color: #444;
}

#lineManagerName:focus {
outline: none;
border-color: #666;
}
`;

interface IHomepageProps {
  onShowSSL: () => void;
  onShowCST: () => void;
  onShowQuality: () => void;
  onShowFAQs: () => void;
  onShowLeadership: () => void;
  onShowMyDocs: () => void;
  onShowEYI: () => void;
  onShowResourcing: () => void;
  onShowOnshore: () => void;
  onShowNonGcc: () => void;
  onShowGDS: () => void;
  onShowTalent: () => void;
  onShowWebcast: () => void;
  onShowCommunications: () => void;
  onShowMarkets: () => void;
  onShowEngagement: () => void;
  onShowPolicies: () => void;
  userDisplayName: string;
  userEmail: string;
}

interface ITrendingNewsItem {
  Title: string;
  DisplayOrder?: number;
  ThumbNail?: { Url?: string };
  File?: { Name?: string };
}

interface ITrendingNewsResponse {
  d: { results: ITrendingNewsItem[] };
}

const trendingNewsUri = "https://sites.ey.com/sites/MENATaxHub/_api/web/lists/getByTitle('Newsletter')/items?$select=Title,DisplayOrder,ThumbNail,File/Name&$expand=File&$orderby=DisplayOrder desc";
const trendingNewsFileRoot = 'https://sites.ey.com/sites/MENATaxHub/Newsletter/';

const Homepage: React.FC<IHomepageProps> = ({ onShowSSL, onShowCST, onShowQuality, onShowFAQs, onShowLeadership, onShowMyDocs, onShowEYI, onShowResourcing, onShowOnshore, onShowNonGcc, onShowGDS, onShowTalent, onShowWebcast, onShowCommunications, onShowMarkets, onShowEngagement, onShowPolicies, userDisplayName, userEmail }) => {
  const [isAccessModalOpen, setIsAccessModalOpen] = React.useState<boolean>(false);
  const [isVideoModalOpen, setIsVideoModalOpen] = React.useState<boolean>(false);
  const [trendingNews, setTrendingNews] = React.useState<ITrendingNewsItem[]>([]);
  const [isSavingAccessRequest, setIsSavingAccessRequest] = React.useState<boolean>(false);

  const getRequestDigest = async (webUrl: string): Promise<string> => {
    const response = await fetch(`${webUrl}/_api/contextinfo`, {
      method: 'POST',
      headers: { Accept: 'application/json;odata=verbose' }
    });
    if (!response.ok) {
      throw new Error(`Unable to get SharePoint request digest (${response.status}).`);
    }
    const data = await response.json() as ISharePointResponse<ISharePointContextInfo>;
    return data.d.GetContextWebInformation.FormDigestValue;
  };

  const handleAccessRequestSubmit = async (): Promise<void> => {
    if (isSavingAccessRequest) {
      return;
    }

    const reasonInput = document.getElementById('Reason') as HTMLTextAreaElement | null;
    const fileInput = document.getElementById('fileUploader') as HTMLInputElement | null;
    const lineManagerInput = document.getElementById('lineManagerName') as HTMLInputElement | null;
    const lineManager = lineManagerInput?.value.trim() || '';
    const reason = reasonInput?.value.trim() || '';
    const file = fileInput?.files?.[0];

    if (!reason) {
      window.alert('Reason cannot be blank.');
      reasonInput?.focus();
      return;
    }
    if (!file) {
      window.alert('Upload the request approval mail.');
      fileInput?.focus();
      return;
    }

    setIsSavingAccessRequest(true);
    try {
      const listWebUrl = requestAccessWebUrl;
      const digest = await getRequestDigest(listWebUrl);
      const requestHeaders = {
        Accept: 'application/json;odata=verbose',
        'Content-Type': 'application/json;odata=verbose',
        'X-RequestDigest': digest
      };
      const requestBody: {
        __metadata: { type: string };
        Title: string;
        Email: string;
        Reason: string;
        LineManagerId?: number;
      } = {
        __metadata: { type: 'SP.Data.RequestAccessListItem' },
        Title: userDisplayName,
        Email: userEmail,
        Reason: reason
      };

      if (lineManager) {
        const ensureUserResponse = await fetch(`${listWebUrl}/_api/web/ensureuser`, {
          method: 'POST',
          headers: requestHeaders,
          body: JSON.stringify({ logonName: lineManager })
        });
        if (!ensureUserResponse.ok) {
          throw new Error(`Unable to resolve the line manager (${ensureUserResponse.status}).`);
        }
        const ensureUserData = await ensureUserResponse.json() as ISharePointResponse<IEnsureUser>;
        requestBody.LineManagerId = ensureUserData.d.Id;
      }

      const itemResponse = await fetch(`${listWebUrl}/_api/web/lists/getbytitle('RequestAccess')/items`, {
        method: 'POST',
        headers: requestHeaders,
        body: JSON.stringify(requestBody)
      });
      if (!itemResponse.ok) {
        throw new Error(`Unable to save the access request (${itemResponse.status}).`);
      }
      const itemData = await itemResponse.json() as ISharePointResponse<ISharePointListItem>;
      const attachmentResponse = await fetch(`${listWebUrl}/_api/web/lists/getbytitle('RequestAccess')/items(${itemData.d.Id})/AttachmentFiles/add(FileName='${encodeURIComponent(file.name)}')`, {
        method: 'POST',
        headers: {
          Accept: 'application/json;odata=verbose',
          'X-RequestDigest': digest,
          'Content-Type': 'application/octet-stream'
        },
        body: await file.arrayBuffer()
      });
      if (!attachmentResponse.ok) {
        throw new Error(`The request was saved, but the attachment failed (${attachmentResponse.status}).`);
      }

      window.alert('Request sent successfully.');
      setIsAccessModalOpen(false);
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      window.console.error('Unable to save the access request.', error);
      window.alert(message);
    } finally {
      setIsSavingAccessRequest(false);
    }
  };

  React.useEffect(() => {
    const getTrendingNews = async (): Promise<void> => {
      try {
        const response = await fetch(trendingNewsUri, {
          headers: { accept: 'application/json;odata=verbose' }
        });
        if (!response.ok) {
          throw new Error(`${response.status} ${response.statusText}`);
        }
        const data = await response.json() as ITrendingNewsResponse;
        setTrendingNews(data.d.results.slice(0, 3));
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        window.console.error(`Unable to load trending news: ${message}`);
      }
    };

    void getTrendingNews();
  }, []);

	return (
		<>
			<style>{homepageStyles}</style>
<div className="loading-container" style={{ display: 'none' }}>
<div className="item" />
<div className="item" />
<div className="item" />
<div className="item" />
</div>

<div className="container_wrapper" style={{ display: 'block' }}>
<div className="webPart">
<div className="container-fluid nav-container">
<div className="row nav-bar">
<img
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/EY_logo.png"
className="EYlogo"
alt="EY logo"
/>
<p className="logoTxt">MENA Tax Hub</p>
<img
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/toggle.png"
className="navToggle"
alt="Navigation toggle"
/>
</div>
</div>

<div className="container-fluid c01">
<div className="row r01">
<div className="col-sm-8 bannerBackground">
<div
className="quote_div"
style={{
backgroundImage:
'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/ey-ahmed-eldessouky-v1.jpg)'
}}
>
<img
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/Quoteicon.png"
className="qtIcon"
alt="Quote icon"
/>
<p className="quoteTxt">
In a region defined by transformation, our role as tax leaders is not just to interpret change - but to shape it with integrity, foresight and impact.
</p>

<div className="profileDes" style={{ marginTop: '5px', display: 'flex', flexDirection: 'column', alignItems: 'flex-end' }} />
<div className="profileDes" style={{ marginTop: '5px', display: 'flex', flexDirection: 'column', alignItems: 'flex-end' }} />

<div className="profileDes mt-3">
<p className="pName">Ahmed Eldessouky</p>
<p className="pDes">Tax Leader</p>
</div>
</div>

<div className="col-sm-12 bt-txt">
<p className="c4">
Our working world is rapidly evolving, and with that evolution, comes unprecedented opportunities for our Tax and Law practices, and all our businesses across sectors and geographies, to transform, expand and build a better working world.
</p>
<p className="c4">
Governments in the MENA region are taking active measures to maintain economic equilibrium. Tax authorities are also responding to demands for amendments to tax policies and processes.
</p>
<p className="c4">
At EY, our Tax subservice lines have been keeping pace with the situation, delivering appropriate solutions and helping clients stay on top of tax developments in a volatile and complex tax environment.
</p>
</div>
</div>

<div className="col-sm-4 c47">
<div className="container-fluid rgt_container">
<div className="row r02">
<div className="col-sm-12 rgt_c7" style={{ height: '59px' }}>
<div
  className="rg_01 rs-01"
  role="button"
  tabIndex={0}
  onClick={onShowSSL}
  onKeyPress={(event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      onShowSSL();
    }
  }}
  style={{ cursor: 'pointer' }}
>
<img
className="f1y"
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png"
alt="Overlay"
/>
<img
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Picture01.png"
className="fg1"
alt="MENA Tax SSLs"
/>
<p className="s1">MENA Tax SSLs</p>
</div>
</div>


<div className="col-sm-12 rgt_c7" style={{ height: '59px' }}>
<a data-interception="off" href="#" onClick={(event) => { event.preventDefault(); onShowEngagement(); }}>
<div className="rg_02 rs-01">
<img
className="f1y"
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png"
alt="Overlay"
/>
<img
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Picture02.png"
className="fg1"
alt="Engagement Lifecycle Management"
/>
<p className="s1">Engagement Lifecycle Management</p>
</div>
</a>
</div>

<div className="col-sm-12 rgt_c7" style={{ height: '59px' }}>
<div
  className="rg_03 rs-01"
  role="button"
  tabIndex={0}
  onClick={onShowCST}
  onKeyPress={(event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      onShowCST();
    }
  }}
  style={{ cursor: 'pointer' }}
>
<img
className="f1y"
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png"
alt="Overlay"
/>
<img
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Picture02.png"
className="fg1"
alt="Central Support Team"
/>
<p className="s1">Central Support Team</p>
</div>
</div>
<div className="col-sm-12 rgt_c7" style={{ height: '59px' }}>
<div
  className="rg_04 rs-01"
  role="button"
  tabIndex={0}
  onClick={onShowQuality}
  onKeyPress={(event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      onShowQuality();
    }
  }}
  style={{ cursor: 'pointer' }}
>
<img
className="f1y"
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png"
alt="Overlay"
/>
<img
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Picture03.png"
className="fg1"
alt="MENA Tax Quality"
/>
<p className="s1">MENA Tax Quality</p>
</div>
</div>
<div className="col-sm-12 rgt_c7" style={{ height: '59px' }}>
<div
  className="rg_05 rs-01"
  role="button"
  tabIndex={0}
  onClick={onShowLeadership}
  onKeyPress={(event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      onShowLeadership();
    }
  }}
  style={{ cursor: 'pointer' }}
>
<img
className="f1y"
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png"
alt="Overlay"
/>
<img
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Picture04.png"
className="fg1"
alt="MENA Tax Leadership"
/>
<p className="s1">MENA Tax Leadership</p>
</div>
</div>
<div className="col-sm-12 rgt_c7" style={{ height: '59px' }}>
<div
  className="rg_08 rs-01"
  role="button"
  tabIndex={0}
  onClick={onShowResourcing}
  onKeyPress={(event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      onShowResourcing();
    }
  }}
  style={{ cursor: 'pointer' }}
>
<img
className="f1y"
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png"
alt="Overlay"
/>
<img
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Picture04.png"
className="fg1"
alt="MENA Tax Resourcing Hub"
/>
<p className="s1">MENA Tax Resourcing Hub</p>
</div>
</div>
<div className="col-sm-12 rgt_c7" style={{ height: '59px' }}>
<div
  className="rg_07 rs-01"
  role="button"
  tabIndex={0}
  onClick={onShowTalent}
  onKeyPress={(event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      onShowTalent();
    }
  }}
  style={{ cursor: 'pointer' }}
>
<img
className="f1y"
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png"
alt="Overlay"
/>
<img
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Picture04.png"
className="fg1"
alt="MENA Tax Talent"
/>
<p className="s1">MENA Tax Talent</p>
</div>
</div>
<div className="col-sm-12 rgt_c7 cg4" style={{ height: '59px' }}>
<a data-interception="off" href="#" onClick={(event) => { event.preventDefault(); onShowMarkets(); }}>
<div className="rg_08 rs-01">
<img
className="f1y"
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png"
alt="Overlay"
/>
<img
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Picture05.png"
className="fg1"
alt="MENA Tax Markets"
/>
<p className="s1">MENA Tax Markets</p>
</div>
</a>
</div>
<div className="col-sm-12 rgt_c7" style={{ height: '53px' }}>
<a data-interception="off"
href="https://sites.ey.com/sites/MENALearningPortal/TaxLearning/SitePages/Homepage.aspx"
target="_blank"
rel="noreferrer"
>
<div className="rg_07 rs-01">
<img
className="f1y"
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png"
alt="Overlay"
/>
<img
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Picture04.png"
className="fg1"
alt="MENA Tax Learning"
/>
<p className="s1">MENA Tax Learning</p>
</div>
</a>
</div>
















<div className="col-sm-12 rgt_c7" style={{ height: '59px' }} hidden>
<div
  className="rg_08 rs-01"
  role="button"
  tabIndex={0}
  onClick={onShowCommunications}
  onKeyPress={(event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      onShowCommunications();
    }
  }}
  style={{ cursor: 'pointer' }}
>
<img
className="f1y"
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png"
alt="Overlay"
/>

<p className="s1">MENA Tax archived communications</p>
</div>
</div>

<div className="col-sm-12 rgt_c7" style={{ height: '59px' }} hidden>
<div
  className="rg_08 rs-01"
  role="button"
  tabIndex={0}
  onClick={onShowWebcast}
  onKeyPress={(event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      onShowWebcast();
    }
  }}
  style={{ cursor: 'pointer' }}
>
<img
className="f1y"
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png"
alt="Overlay"
/>

<p className="s1">MENA Tax all people webcast</p>
</div>
</div>

<div className="col-sm-12 rgt_c7" style={{ height: '59px' }} hidden>
<div
  className="rg_04 rs-01"
  role="button"
  tabIndex={0}
  onClick={onShowFAQs}
  onKeyPress={(event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      onShowFAQs();
    }
  }}
  style={{ cursor: 'pointer' }}
>
<img
className="f1y"
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png"
alt="Overlay"
/>
<img
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/faq.png?csf=1&web=1&e=ET46ax"
className="fg1"
alt="MENA Tax Quality FAQs"
/>
<p className="s1">MENA Tax Quality FAQs</p>
</div>
</div>

<div className="col-sm-12 rgt_c7" style={{ height: '59px' }} hidden>
<div className="rg_06 rs-01"
  role="button"
  tabIndex={0}
  onClick={onShowMyDocs}
  onKeyPress={(event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      onShowMyDocs();
    }
  }}
  style={{ cursor: 'pointer' }}
>
<img
className="f1y"
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png"
alt="Overlay"
/>
<img
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Picture05.png"
className="fg1"
alt="MyDocs Minutes"
/>
<p className="s1">MyDocs Minutes</p>
</div>
</div>

<div className="col-sm-12 rgt_c7" style={{ height: '59px' }} hidden>
<div
  className="rg_07 rs-01"
  role="button"
  tabIndex={0}
  onClick={onShowEYI}
  onKeyPress={(event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      onShowEYI();
    }
  }}
  style={{ cursor: 'pointer' }}
>
<img
className="f1y"
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png"
alt="Overlay"
/>
<img
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Picture06.png"
className="fg1"
alt="EYI Documentation"
/>
<p className="s1">EYI Documentation</p>
</div>
</div>



<div className="col-sm-12 rgt_c7" style={{ height: '59px' }} hidden>
<div
  className="rg_08 rs-01"
  role="button"
  tabIndex={0}
  onClick={onShowOnshore}
  onKeyPress={(event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      onShowOnshore();
    }
  }}
  style={{ cursor: 'pointer' }}
>
<img
className="f1y"
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png"
alt="Overlay"
/>
<img
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/onshore.jpg"
className="fg1"
alt="Onshore Resourcing"
/>
<p className="s1">Onshore Resourcing</p>
</div>
</div>

<div className="col-sm-12 rgt_c7" style={{ height: '59px' }} hidden>
<div
  className="rg_08 rs-01"
  role="button"
  tabIndex={0}
  onClick={onShowNonGcc}
  onKeyPress={(event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      onShowNonGcc();
    }
  }}
  style={{ cursor: 'pointer' }}
>
<img
className="f1y"
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png"
alt="Overlay"
/>
<img
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/thumbnail-203.png"
className="fg1"
alt="Non-GCC (Levant / Rapid Pakistan)"
/>
<p className="s1">Non-GCC (Levant / Rapid Pakistan)</p>
</div>
</div>

<div className="col-sm-12 rgt_c7" style={{ height: '59px' }} hidden>
<div
  className="rg_05 rs-01"
  role="button"
  tabIndex={0}
  onClick={onShowGDS}
  onKeyPress={(event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      onShowGDS();
    }
  }}
  style={{ cursor: 'pointer' }}
>
<img
className="f1y"
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png"
alt="Overlay"
/>
<img
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Picture02.png"
className="fg1"
alt="GDS"
/>
<p className="s1">GDS</p>
</div>
</div>






</div>
</div>
</div>
</div>
</div>

<div className="container-fluid c03">
<div className="row m-row r03">
<div className="col-sm-4 left-0">
<p className="pr_hd">Trending News</p>
<div id="divNews">
{trendingNews.map((item) => (
<a data-interception="off"
key={`${item.Title}-${item.File?.Name || ''}`}
href={`${trendingNewsFileRoot}${item.File?.Name || ''}`}
target="_blank"
rel="noreferrer"
style={{ textDecoration: 'none', position: 'relative' }}
className="cf-7"
>
<div className="news_1">
<div
className="fy7"
style={{
backgroundImage: item.ThumbNail?.Url ? `url(${item.ThumbNail.Url})` : undefined,
backgroundPosition: 'center'
}}
/>
<p className="pr_txt" style={{ marginTop: 0 }}>
{item.Title}
</p>
<p className="c4a7">READ MORE</p>
</div>
</a>
))}
</div>

<a data-interception="off"
 onClick={onShowCommunications}
className="archived"
target="_blank"
rel="noreferrer" style={{ cursor:'pointer' }}
>
<img
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/archived.png"
alt="Archived communications"
/>
Archived communications
</a>
</div>

<div className="col-sm-8 right-0">
<div className="container-fluid">
<div className="row">
<div className="col-sm-12 m-6 m3">
<div className="m-lft m0">
<p className="m1">MENA Tax<br />Reporting Dashboard</p>
<img
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/speaker.png"
className="speakerIcon"
alt="Speaker"
/>
<p className="m2">
Provides regular reporting of vital KPIs in a highly visual format combined with the ability to drill down to the detail.
</p>
<a data-interception="off" className="b1" href="#" onClick={(event) => { event.preventDefault(); setIsAccessModalOpen(true); }}>
Request Access
</a>
<a data-interception="off"
href="https://app.powerbi.com/groups/me/apps/88b138f5-216c-4ac6-b72a-a19e005bd381/reports/dc7969d8-2122-4804-8516-afe5d60de0a4/1ca454fa5a5c0e5d4d0a?ctid=5b973f99-77df-4beb-b27d-aa0c70b8482c&chromeless=1&experience=power-bi"
target="_blank"
rel="noreferrer"
className="b2"
>
Read Reports
</a>
<p
className="jp"
style={{
fontSize: '0.85vw',
fontStyle: 'italic',
position: 'absolute',
left: '20vw',
top: '11.2vw'
}}
>
Any queries related to reporting dashboard, please reach out to
<a data-interception="off" className='OutlookLink'
href="mailto:MENA.Tax.operations@ae.ey.com"
style={{
fontSize: '0.85vw',
background: 'none',
color: '#000000',
padding: 0,
margin: '0 0 0 -18px',
fontStyle: 'italic',
textDecoration: 'underline'
}}
>
MENA Tax Operations
</a>
</p>
</div>
</div>

<div className="col-sm-12 m-6">
<div className="m-lft n-b1" style={{ padding: '4vw 0.7vw', float: 'left' }}>
<a data-interception="off"
 onClick={onShowWebcast} rel="noreferrer"
style={{ float: 'left', width: '50%', cursor:'pointer' }}
>
<img
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/web-button-1.png"
alt="Webcast"
style={{ width: '96%' }}
/>
</a>
<a data-interception="off" href="#" onClick={(event) => { event.preventDefault(); setIsVideoModalOpen(true); }} style={{ cursor: 'pointer', float: 'left', width: '50%' }}>
<img
src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/web-button-2.png"
alt="Video play"
style={{ width: '96%' }}
/>
</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<div className="container-fluid footerTab">
<div className="row">
<div className="col-sm-12">
<p className="quicklinks">Quick links</p>
</div>

<div className="col-sm-3 cl-3">
<a data-interception="off" href="https://lmsme.ey.net/" target="_blank" rel="noreferrer">
<div className="col-sm-bx">
<div
className="img-bx"
style={{
backgroundImage:
'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/lms.jpg)'
}}
/>
<p className="bx-link">LMS</p>
<span>01</span>
</div>
</a>
</div>

<div className="col-sm-3 cl-3">
<a data-interception="off" href="https://sort.ey.net/" target="_blank" rel="noreferrer">
<div className="col-sm-bx">
<div
className="img-bx"
style={{
backgroundImage:
'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/gettyimages-1386672473-1024x1024.jpg)'
}}
/>
<p className="bx-link">SORT</p>
<span>02</span>
</div>
</a>
</div>

<div className="col-sm-3 cl-3">
<a data-interception="off" href="https://sf.ey.net" target="_blank" rel="noreferrer">
<div className="col-sm-bx">
<div
className="img-bx"
style={{
backgroundImage:
'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/tx03.jpg)'
}}
/>
<p className="bx-link">SuccessFactors</p>
<span>03</span>
</div>
</a>
</div>

<div className="col-sm-3 cl-3">
<a data-interception="off"
href="https://intranet.ey.com/sites/career-development/SitePageModern/342011/career-development"
target="_blank"
rel="noreferrer"
>
<div className="col-sm-bx">
<div
className="img-bx"
style={{
backgroundImage:
'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/tx04.jpg)'
}}
/>
<p className="bx-link">Career & development</p>
<span data-target="#newsModal" data-toggle="modal">04</span>
</div>
</a>
</div>

<div className="col-sm-3 cl-3">
<a data-interception="off"
href="https://sites.ey.com/sites/TaxLearning/TaxCopilot/SitePages/Homepage.aspx#/"
target="_blank"
rel="noreferrer"
>
<div className="col-sm-bx">
<div
className="img-bx"
style={{
backgroundImage:
'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/training.jpg)'
}}
/>
<p className="bx-link">EY Tax Copilot</p>
<span data-target="#newsModal" data-toggle="modal">05</span>
</div>
</a>
</div>

<div className="col-sm-3 cl-3">
<a data-interception="off"
href="https://apps.powerapps.com/play/e/a3c669f6-ac2e-4e77-ad43-beab3e15bee7/a/51ea11c3-8427-4e7f-91c0-1997fabd6c16?tenantId=5b973f99-77df-4beb-b27d-aa0c70b8482c&hint=c40b4e6c-c8f3-4c32-8df8-eb772d355b4e&sourcetime=1767618367761&hidenavbar=true"
target="_blank"
rel="noreferrer"
>
<div className="col-sm-bx">
<div
className="img-bx"
style={{
backgroundImage:
'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/tx04.jpg)'
}}
/>
<p className="bx-link">MENA Tax Industry Mapping Tool</p>
<span data-target="#newsModal" data-toggle="modal">06</span>
</div>
</a>
</div>

<div className="col-sm-3 cl-3">
<a data-interception="off"
href="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/excel/MENA_Skills_by_Role.xlsx"
target="_blank"
rel="noreferrer"
>
<div className="col-sm-bx">
<div
className="img-bx"
style={{
backgroundImage:
'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/GettyImages-691574503.jpg)'
}}
/>
<p className="bx-link">MENA Skills by Role</p>
<span data-target="#newsModal" data-toggle="modal">07</span>
</div>
</a>
</div>
</div>
</div>

<div className="footer">
<p>© 2026 EYGM Limited. All rights reserved.</p>
</div>
</div>

{isAccessModalOpen && <div className="homepageModal" id="newsModalThree" tabIndex={-1} aria-modal="true" role="dialog">
<div className="modal-dialog md2 modal-dialog-centered carousel-dialog" role="document">
<div className="modal-content">
<button type="button" className="homepageModalClose" onClick={() => setIsAccessModalOpen(false)} aria-label="Close request access dialog">&times;</button>
<div className="modal-body carousel-body" style={{ textAlign: 'center' }}>
<div className="modalBody bmodal">
<div className="form-group">
<label htmlFor="txtName">
Name <span>*</span>
</label>
<input
type="text"
className="form-control inputBox"
id="txtName"
readOnly
value={userDisplayName}
placeholder="Enter your Name"
required
/>

<label htmlFor="txtEmail">
Email <span>*</span>
</label>
<input
type="text"
className="form-control inputBox"
id="txtEmail"
readOnly
value={userEmail}
placeholder="Enter your email"
required
/>

<label htmlFor="lineManagerName">
Line Manager Name <span>*</span>
</label>
<input
type="text"
className="form-control"
id="lineManagerName"
placeholder="Enter line manager name or email"
autoComplete="off"
/>

<label htmlFor="Reason">
Reason for requesting access <span>*</span>
</label>
<textarea
className="form-control inputBox"
placeholder="Reason for requesting access"
required
id="Reason"
/>

<label htmlFor="fileUploader">
Please attach the approval mail <span>*</span>
</label>
<input
type="file"
style={{ width: '27vw', height: '2.2vw', fontSize: '10px' }}
id="fileUploader"
/>
<button type="button" className="btn btn-primary" onClick={() => { void handleAccessRequestSubmit(); }} disabled={isSavingAccessRequest}>
{isSavingAccessRequest ? 'Submitting...' : 'Submit'}
</button>
</div>
</div>
</div>
</div>
</div>
 </div>}
{isVideoModalOpen && <div className="homepageModal" id="VideoPlay" tabIndex={-1} aria-modal="true" role="dialog" onClick={() => setIsVideoModalOpen(false)}>
<div className="modal-dialog modal-dialog-centered" role="document" onClick={(event) => event.stopPropagation()}>
<div className="modal-content videoModalContent">
<button type="button" className="homepageModalClose" onClick={() => setIsVideoModalOpen(false)} aria-label="Close video dialog">&times;</button>
<video controls autoPlay title="MENA Tax video">
<source src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/Videos/MENA-Tax-All-People-Webcast-20260630_090205UTC-Meeting%20Recording.mp4" type="video/mp4" />
</video>
</div>
</div>
</div>}
</>
);
};

export default Homepage;

