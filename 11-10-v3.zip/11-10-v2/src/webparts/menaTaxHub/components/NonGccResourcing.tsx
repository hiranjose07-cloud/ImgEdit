import * as React from 'react';

const nonGccStyles = `
  .nonGccResourcing { background: #2e2e38; color: #ffffff; font-family: EYInterstate, Arial, sans-serif; overflow: hidden; }
  .nonGccResourcing__nav { background: #2e2e38; min-height: 6vw; position: relative; }
  .nonGccResourcing__nav .EYlogo { left: 5vw; position: absolute; top: 1.5vw; width: 3vw; }
  .nonGccResourcing__nav .logoTxt { color: #ffffff; font-size: 2vw; left: 11vw; margin: 0; position: absolute; top: 2.2vw; }
  .nonGccResourcing__nav .navLinks { display: flex; gap: 1vw; list-style: none; margin: 0; padding: 0; position: absolute; right: 6vw; top: 2.4vw; }
  .nonGccResourcing__nav .navLinks a { align-items: center; color: #ffffff; display: flex; font-size: 1vw; gap: .5vw; text-decoration: none; }
  .nonGccResourcing__nav .navLinks img { width: 1vw; }
  .nonGccResourcing__nav .navLinks img.home { width: 1.3vw; }
  .nonGccResourcing__nav .navToggle { display: none; }
  .nonGccResourcing__hero { background-color: #2e2e38; background-image: url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Rapid-Nearshore.jpg'); background-position: center; background-size: cover; min-height: 17vw; padding: 0 5vw; }
  .nonGccResourcing__hero h1 { border-bottom: 2px solid #ffffff; font-size: 1.9vw; margin: 0 0 1.3vw 1vw; padding-bottom: 3px; padding-top: 5vw; width: 34vw; }
  .nonGccResourcing__hero hr { border: 0; border-top: .2vw solid #ffe600; margin: 0 0 0 1.2vw; width: 3vw; }
  .nonGccResourcing__main { background-image: url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png'); background-position: center; background-size: cover; }
  .nonGccResourcing__intro { background: rgba(0, 0, 0, .09); border-bottom: .1vw solid #363636; padding: 2vw 6vw 1vw; }
  .nonGccResourcing__intro p, .nonGccResourcing__accordionBody li, .nonGccResourcing__table { font-family: Arial, sans-serif; font-size: 1vw; line-height: 1.5; }
  .nonGccResourcing__accordion { padding: 0 6vw 2vw; }
  .nonGccResourcing__item { border-bottom: 1px solid rgba(255, 255, 255, .25); }
  .nonGccResourcing__heading { color: #ffe600; font-size: 1.3vw; margin: 1.2vw 0 .6vw; }
  .nonGccResourcing__accordionBody { padding-bottom: .5vw; }
  .nonGccResourcing__accordionBody ul { list-style: none; margin: 0; padding: 0; }
  .nonGccResourcing__accordionBody li { margin-bottom: .6vw; padding-left: 1.5vw; position: relative; }
  .nonGccResourcing__accordionBody li::before { color: #ffe600; content: '>'; left: 0; position: absolute; }
  .nonGccResourcing__accordionBody a { color: #ffe600; font-weight: 700; }
  .nonGccResourcing__table { border: .1vw solid rgba(255, 255, 255, .14); border-collapse: collapse; margin: 3.5vw 2.5% 1vw; text-align: center; width: 95%; }
  .nonGccResourcing__table td { border-right: .1vw solid rgba(255, 255, 255, .12); height: 80px; padding: 1vw; }
  .nonGccResourcing__table tr:first-child { border-bottom: .1vw solid rgba(255, 255, 255, .12); }
  .nonGccResourcing__team { padding: 0 6vw 2vw; }
  .nonGccResourcing__sectionTitle { border-bottom: 1px solid rgba(255, 255, 255, .4); border-top: 1px solid rgba(255, 255, 255, .4); color: #ffffff; display: block; font-size: 1.4vw; margin: 0 0 2vw; padding: 1vw 0; }
  .nonGccResourcing__teamGrid { display: grid; gap: .8vw; grid-template-columns: repeat(5, 1fr); }
  .nonGccResourcing__person { background: rgba(255, 255, 255, .06); min-height: 13vw; padding: 1vw .4vw; text-align: center; }
  .nonGccResourcing__person img { border-radius: 50%; height: 5.5vw; object-fit: cover; width: 5.5vw; }
  .nonGccResourcing__person strong { color: #ffe600; display: block; font-size: .9vw; margin-top: 1vw; }
  .nonGccResourcing__person span { display: block; font-size: .8vw; margin-top: .4vw; }
  .nonGccResourcing__footer { background: #000000; color: #ffffff; font-size: 1vw; padding: 1vw 2vw; text-align: right; }
  .nonGccResourcing__back { align-items: center; background: #ffe600; border: 0; color: #000000; cursor: pointer; display: flex; font-weight: 700; gap: .5vw; margin: 1vw 0 0 2vw; padding: .6vw 1vw; }
  .nonGccResourcing__back img { width: 1vw; }
  @media only screen and (max-width: 1200px) {
    .nonGccResourcing__nav { min-height: 90px; }
    .nonGccResourcing__nav .EYlogo { left: 60px; top: 20px; width: 40px; }
    .nonGccResourcing__nav .logoTxt { font-size: 25px; left: 130px; top: 30px; }
    .nonGccResourcing__nav .navLinks { right: 50px; top: 31px; }
    .nonGccResourcing__nav .navLinks a { font-size: 13px; }
    .nonGccResourcing__nav .navLinks img { width: 13px; }
    .nonGccResourcing__nav .navLinks img.home { width: 20px; }
    .nonGccResourcing__hero { min-height: 220px; }
    .nonGccResourcing__hero h1 { font-size: 30px; padding-top: 70px; width: 420px; }
    .nonGccResourcing__intro p, .nonGccResourcing__accordionBody li, .nonGccResourcing__table { font-size: 14px; }
    .nonGccResourcing__heading, .nonGccResourcing__sectionTitle { font-size: 18px; }
    .nonGccResourcing__person strong { font-size: 13px; }
    .nonGccResourcing__person span, .nonGccResourcing__footer { font-size: 11px; }
  }
  @media only screen and (max-width: 800px) {
    .nonGccResourcing__hero { min-height: 190px; }
    .nonGccResourcing__teamGrid { grid-template-columns: repeat(3, 1fr); }
  }
  @media only screen and (max-width: 575px) {
    .nonGccResourcing__nav .navLinks { top: 110px; }
    .nonGccResourcing__hero { min-height: 170px; padding: 0 30px; }
    .nonGccResourcing__hero h1 { font-size: 20px; padding-top: 55px; width: 100%; }
    .nonGccResourcing__intro, .nonGccResourcing__accordion, .nonGccResourcing__team { padding-left: 30px; padding-right: 30px; }
    .nonGccResourcing__heading { font-size: 17px; line-height: 23px; }
    .nonGccResourcing__table { display: block; font-size: 12px; overflow-x: auto; white-space: nowrap; }
    .nonGccResourcing__teamGrid { grid-template-columns: repeat(2, 1fr); }
    .nonGccResourcing__person { min-height: 180px; }
    .nonGccResourcing__person img { height: 80px; width: 80px; }
    .nonGccResourcing__back { margin-left: 20px; }
  }
  @media only screen and (max-width: 400px) { .nonGccResourcing__teamGrid { grid-template-columns: 1fr; } }
`;

interface INonGccResourcingProps {
  onShowResourcing: () => void;
  onShowHome: () => void;
}

const NonGccResourcing: React.FC<INonGccResourcingProps> = ({ onShowResourcing, onShowHome }) => (
  <div className="nonGccResourcing">
    <style>{nonGccStyles}</style>
    <nav className="nonGccResourcing__nav">
      <img className="EYlogo" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/EY_logo.png" alt="EY logo" />
      <p className="logoTxt">MENA Tax Hub</p>
      <ul className="navLinks">
        <li><a data-interception="off" href="#resourcing"><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/back-button_resource-hub.png" alt="" />Back</a></li>
        <li><a data-interception="off" href="#" onClick={(event) => { event.preventDefault(); onShowHome(); }}><img className="home" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home.png" alt="Home" /></a></li>
      </ul>
      <img className="navToggle" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/toggle.png" alt="Navigation toggle" />
    </nav>
    <header className="nonGccResourcing__hero"><h1>Non-GCC (Levant / Rapid Pakistan)</h1><hr /></header>
    <main className="nonGccResourcing__main">
      <section className="nonGccResourcing__intro"><p>Rapid/Pakistan and the Levant region is scaling up to meet increasing demand.</p></section>
      <section className="nonGccResourcing__accordion">
        <div className="nonGccResourcing__item">
          <h2 className="nonGccResourcing__heading">Key Considerations:</h2>
          <div className="nonGccResourcing__accordionBody"><ul>
            <li>Is this request within your SSL Financial plan?</li>
            <li>Are the types of skills required available onshore or within the existing GDS FTE pool?</li>
            <li>Have you reviewed utilization of onshore resources against capacity and rank utilization expectations?</li>
            <li>Have you reviewed utilization of sponsored GDS FTE and Rapid pool against expectations?</li>
          </ul></div>
        </div>
        <div className="nonGccResourcing__item">
          <h2 className="nonGccResourcing__heading">What happens next?</h2>
          <div className="nonGccResourcing__accordionBody"><ul>
            <li>Carry out an assessment of your current state using the <a data-interception="off" href="https://app.powerbi.com/groups/me/apps/88b138f5-216c-4ac6-b72a-a19e005bd381/reports/224a0ea2-bd8c-4441-b136-31641b8a8103/ReportSectionbd6d72f0b28d653ff863?ctid=5b973f99-77df-4beb-b27d-aa0c70b8482c&amp;experience=power-bi" target="_blank" rel="noreferrer">Tax People Dashboard</a>, <a data-interception="off" href="https://app.powerbi.com/groups/me/apps/88b138f5-216c-4ac6-b72a-a19e005bd381/reports/db646e19-5e24-4e38-accc-9a8c2e8743e9/ReportSection?ctid=5b973f99-77df-4beb-b27d-aa0c70b8482c&amp;chromeless=1&amp;experience=power-bi" target="_blank" rel="noreferrer">Finance &amp; Engagement Dashboard</a></li>
            <li>If your request aligns with the considerations above and the Financial Plan, proceed with raising a resource request on the <a data-interception="off" href="https://apps.powerapps.com/play/e/a3c669f6-ac2e-4e77-ad43-beab3e15bee7/a/a422fad2-0a90-4117-b14b-3da399c77b75?tenantId=5b973f99-77df-4beb-b27d-aa0c70b8482c&amp;sourcetime=1721291017599&amp;hidenavbar=true" target="_blank" rel="noreferrer">MENA Tax Hiring Tool</a></li>
            <li>Your request would be routed through EXM (Experience Management), SSL leader and COO for approval</li>
            <li>Once fully approved, an automated email is generated and sent to the appropriate recruitment team for next steps</li>
            <li>Typical turnaround time for approval is between 2- 4 business days</li>
            <li>For requests that do not meet the requirements, please connect with your respective EXM contact for any additional information and guidance on the optimal approach to fulfil your requirement along with a business case.</li>
          </ul></div>
        </div>
        <div className="nonGccResourcing__item">
          <h2 className="nonGccResourcing__heading">Cost components:</h2>
          <div className="nonGccResourcing__accordionBody"><ul><li>Cost of the nearshore resources will be guided by the EY salary banding for that rank and location - <a data-interception="off" href="https://apps.powerapps.com/play/e/a3c669f6-ac2e-4e77-ad43-beab3e15bee7/a/3cfbfa9b-b76f-4eda-ac6d-4fca290223ed?tenantId=5b973f99-77df-4beb-b27d-aa0c70b8482c&amp;hint=44598ecd-53c9-437b-84db-7ad09753f59c&amp;sourcetime=1707913990980&amp;source=portal" target="_blank" rel="noreferrer">Mercury cost rates can be found using "MENA Tax Cost Comparison Tool"</a></li></ul></div>
        </div>
        <div className="nonGccResourcing__item">
          <h2 className="nonGccResourcing__heading">Out-of-pocket expenses (this will apply for onsite MENA deployments).</h2>
          <div className="nonGccResourcing__accordionBody"><ul><li>Travel OPE Cost Estimation - EXAMPLE</li></ul></div>
        </div>
      </section>
      <table className="nonGccResourcing__table"><tbody><tr><td>Country</td><td>Visa Type</td><td>Entry</td><td>Visa Cost</td><td>Flight Cost (Round trip)</td><td>Hotel Cost</td><td>Sim Card</td><td>Telephone Expenses (monthly)</td><td>Airport Transfers (both ways)</td><td>Additional Baggage</td><td>Taxi Expenses</td><td>Per Diem</td><td>Duration</td><td>Cost per resource (1st month)</td><td>Next Time Travel (per month)</td></tr><tr><td>KSA (Riyadh)</td><td>Work Permit</td><td>Multiple</td><td>$ 800</td><td>$ 600</td><td>$ 130</td><td>$ 50</td><td>$ 25</td><td>$ 100</td><td>$ 200</td><td>$ 40</td><td>$ 70</td><td>$ 30</td><td>$ 9,025</td><td>$ 8,175</td></tr></tbody></table>
      <section className="nonGccResourcing__team"><span className="nonGccResourcing__sectionTitle">Meet The Team</span><div className="nonGccResourcing__teamGrid">
        <div className="nonGccResourcing__person"><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Dania-Zalatimo.png" alt="Dania Zalatimo" /><strong>Dania Zalatimo</strong><span>Assistant Director</span><span>Tax Experience Hire Leader</span></div>
        <div className="nonGccResourcing__person"><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Farrah-Imran.png" alt="Farrah Imran" /><strong>Farrah Imran</strong><span>Assistant Director</span><span>MENA Campus Hire leader</span></div>
        <div className="nonGccResourcing__person"><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Dileep-Rajasekhar.png" alt="Dileep Rajasekhar" /><strong>Dileep Rajasekhar</strong><span>Assistant Director</span></div>
        <div className="nonGccResourcing__person"><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/ellen-M-Jose.png" alt="Jellen M Jose" /><strong>Jellen M Jose</strong><span>Assistant Director</span></div>
      </div></section>
    </main>
    <footer className="nonGccResourcing__footer">&#169; 2026 EYGM Limited. All rights reserved.</footer>
  </div>
);

export default NonGccResourcing;
