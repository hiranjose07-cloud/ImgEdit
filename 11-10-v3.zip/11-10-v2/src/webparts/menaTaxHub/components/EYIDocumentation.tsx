import * as React from 'react';

const eyiDocStyles = `
html,
body {
    overflow-x: hidden !important;
    font-family: EYInterstate;
}

::-moz-selection {
    color: #ffffff;
    background: #27ACAA;
}

::selection {
    color: #ffffff;
    background: #27ACAA;
}

body::-webkit-scrollbar {
    display: none;
}

body {
    -ms-overflow-style: none;
    scrollbar-width: none;
    position: relative;
}

.bannerBackground {
    background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/img_baner.jpg);
    background-color: #2e2e38;
    background-size: 100%;
    background-position-y: -9vw;
    height: 29vw;
    position: relative;
    background-attachment: fixed;
    padding: 0px;
}

.bn_left {
    -ms-flex: 0 0 71%;
    flex: 0 0 71%;
    max-width: 71%;
    padding-top: 3vw;
    padding-left: 6vw;
}

.bn_right {
    background: rgba(26, 26, 36, .5);
    height: 23vw;
    -ms-flex: 0 0 29%;
    flex: 0 0 29%;
    max-width: 29%;
    padding: 1vw 2vw;
}

img.topShade {
    position: absolute;
    top: -17vw;
    left: -10%;
    width: 120%;
}

img.cf-7 {
    width: 21vw;
}

.EYlogo {
    width: 3vw;
    position: absolute;
    left: 5vw;
    top: 1.5vw;
}

.bvx_1 {
    background: rgba(255, 255, 255, .12);
    width: 8vw;
    padding: 1vw 1vw;
    float: left;
    min-height: 5vw;
    margin-right: 1vw;
    text-align: center;
    position: relative;
    margin-top: 2vw;
    -webkit-transition: all .3s ease-in-out;
    -moz-transition: all .3s ease-in-out;
    -o-transition: all .3s ease-in-out;
    transition: all .3s ease-in-out;
}

.bvx_1:hover {
    background: rgba(255, 255, 255, .3);
}

.bvx_1 p {
    color: #ffffff;
    font-size: 1vw;
    margin: 0;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    line-height: 1.3vw;
}

.cd-3 {
    padding: 1vw 2vw;
    border-right: .01vw solid #595959;
}

.cd-4 {
    border: hidden;
}

.c7_fluid {
    min-height: 18vw;
    background: #2e2e38;
    padding: 3vw 5vw;
    background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);
    background-size: cover;
    background-position: center;
    background-attachment: fixed;
}

.cv-6 {
    width: 2.5vw;
}

.cv-7 {
    color: #ffffff;
    font-size: .9vw;
    line-height: 1.4vw;
    margin-bottom: 0;
    margin-top: 1vw;
}

p.logoTxt {
    color: #ffffff;
    font-size: 2vw;
    position: absolute;
    left: 11vw;
    top: 2.2vw;
}

.nav-bar {
    position: relative;
    z-index: 999;
    background: #2e2e38;
    min-height: 6vw;
    width: 100%;
    margin: 0;
}

ul.navbarMenu {
    position: absolute;
    right: 6vw;
    top: 2.4vw;
    font-family: EYInterstate;
}

ul.navbarMenu li {
    display: inline-block;
    font-size: 1vw;
    color: #ffffff;
}

ul.navbarMenu li a {
    color: #ffffff;
    text-decoration: none;
    padding: 0vw 2vw;
}

img.home {
    width: 1.3vw;
}

.hd1 {
    color: #ffffff;
    font-size: 1.5vw;
    width: 50%;
    line-height: 2.2vw;
    font-family: EYinterstate;
}

.hd2 {
    color: #ffffff;
    font-size: 1vw;
    width: 80%;
    display: block;
    margin: 0;
    line-height: 1.4vw;
}

.row-2 {
    margin-top: 23vw;
    padding-left: 5vw;
}

.footerTab {
    background: #1a1a24;
    padding: 5vw;
}

a.qLInk {
    color: #ffffff;
    font-family: EYInterstate;
    font-size: 1vw;
    font-weight: lighter;
    border: .1vw dashed #9f9f9f;
    padding: 0.5vw 1.6vw;
    border-radius: .2vw;
    margin-right: .7vw;
    text-decoration: none;
    float: left;
    -webkit-transition: all .2s ease-in-out;
    -moz-transition: all .2s ease-in-out;
    -o-transition: all .2s ease-in-out;
    transition: all .2s ease-in-out;
    margin-bottom: .8vw;
    width: 24%;
    text-align: center;
    margin-bottom: 1vw;
    position: relative;
    min-height: 4vw;
}

.sp_no {
    position: absolute;
    background: rgb(255 255 255 / 12%);
    width: 1.7vw;
    height: 1.7vw;
    border-radius: 100vw;
    line-height: 0;
    padding-top: .8vw;
    font-size: 0.7vw;
    top: 50%;
    transform: translate(0%, -50%);
    left: 1vw;
}

a.qLInk:hover {
    background: rgba(255, 255, 255, .2)
}

.quicklinks {
    color: #ffffff;
    font-size: 1.6vw;
    margin-bottom: 2vw;
}

a.qLInk span {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 60%;
}

.footer {
    background-color: #000000;
    float: left;
    width: 100%;
}

.footer p {
    margin-bottom: 0px;
    color: #ffffff;
    font-size: 1vw;
    padding: 1vw 2vw;
    text-align: right;
}

.navToggle {
    display: none;
}

.modal-dialog {
    width: 60%;
    max-width: 60%;
}

iframe {
    border: hidden;
}

.modal-content {
    background: transparent;
}

.col-sm-bx {
    width: 100%;
    background: #ffffff0f;
    min-height: 7.5vw;
    position: relative;
    background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);
    background-size: cover;
    background-position: center;
    box-shadow: 0vw 0vw 1.5vw rgba(0, 0, 0, .44);
}

.img-bx {
    min-height: 100%;
    position: absolute;
    left: 0;
    top: 0;
    width: 37%;
    background-position: center;
    background-size: 160%;
    -webkit-transition: all .2s ease-in-out;
    -moz-transition: all .2s ease-in-out;
    -o-transition: all .2s ease-in-out;
    transition: all .2s ease-in-out;
}

.col-sm-bx:hover .img-bx {
    background-size: 190%;
}

.col-sm-bx span {
    color: rgba(255, 255, 255, 0.522);
    position: absolute;
    right: 1vw;
    bottom: .3vw;
    font-size: 2vw;
    font-weight: bold;
    opacity: 0.3;
}

p.bx-link {
    color: #ffffff;
    font-size: 1vw;
    position: absolute;
    left: 45%;
    top: 2.6vw;
    line-height: 1.4vw;
    padding-right: 1vw;
}

.cl-3 {
    padding: .4vw;
}

@media only screen and (max-width: 1200px) {
    .cnt-fdr {
        position: static;
    }

    .cnt-fdr {
        padding: 35px 70px;
    }

    .quicklinks {
        font-size: 16px;
        margin-bottom: 25px;
    }

    a.qLInk {
        font-size: 15px;
        padding: 7px 25px;
        border-radius: .4vw;
        margin-bottom: 10px;
        margin-right: 10px;
    }

    .footerTab {
        background: #1a1a24;
        padding: 60px;
    }

    .EYlogo {
        width: 40px;
        left: 60px;
        top: 20px;
    }

    p.logoTxt {
        font-size: 25px;
        left: 130px;
        top: 30px;
    }

    ul.navbarMenu {
        right: 50px;
        top: 25px;
    }

    ul.navbarMenu li {
        font-size: 15px;
    }

    ul.navbarMenu li a {
        padding: 0vw 20px;
    }

    img.home {
        width: 20px;
    }

    .nav-bar {
        min-height: 90px;
    }

    ul.navbarMenu {
        right: 50px;
        top: 31px;
    }

    .footer p {
        margin-bottom: 0px;
        color: #ffffff;
        font-size: 13px;
        padding: 15px 20px;
        text-align: right;
    }

    .hd2 {
        font-size: 14px;
        width: 90%;
        margin: 0;
        line-height: 19px;
    }

    .bvx_1 {
        width: 120px;
        padding: 10px 10px;
        min-height: 60px;
        margin-right: 10px;
        margin-top: 25px;
    }

    .bvx_1 p {
        font-size: 15px;
        line-height: 17px;
    }

    .bannerBackground {
        height: auto;
        background-size: cover;
        background-position-y: unset;
        height: auto;
        background-position: center;
    }

    .bn_left {
        padding-bottom: 50px;
    }

    .bn_right {
        height: auto;
    }

    img.cf-7 {
        width: 21vw;
        position: absolute;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
    }

    .c7_fluid {
        min-height: 50px;
        padding: 46px 55px;
    }

    .cd-3 {
        padding: 20px 30px;
        border-right: 1px solid #595959;
    }

    .cv-6 {
        width: 35px;
    }

    .cv-7 {
        font-size: 14px;
        line-height: 21px;
        margin-bottom: 0;
        margin-top: 15px;
    }

    .quicklinks {
        font-size: 16px;
        margin-bottom: 25px;
    }

    a.qLInk {
        font-size: 15px;
        padding: 7px 30px;
        border-radius: .4vw;
        margin-bottom: 10px;
        margin-right: 10px;
        width: 30%;
        min-height: 60px;
    }

    .footerTab {
        background: #1a1a24;
        padding: 60px;
    }

    .sp_no {
        position: absolute;
        background: rgba(255, 255, 255, 0.12);
        width: 20px;
        height: 20px;
        border-radius: 100vw;
        line-height: 0;
        padding-top: 11px;
        font-size: 12px;
        left: 19px;
    }

    a.qLInk span {
        font-size: 12px;
    }
}

@media only screen and (max-width: 992px) {
    .bn_left {
        -ms-flex: 0 0 60%;
        flex: 0 0 60%;
        max-width: 60%;
    }

    .bn_right {
        -ms-flex: 0 0 40%;
        flex: 0 0 40%;
        max-width: 40%;
    }

    img.cf-7 {
        width: 30vw;
    }

    .col-sm-3.cd-3 {
        -ms-flex: 0 0 50%;
        flex: 0 0 50%;
        max-width: 50%;
    }

    .col-sm-3.cd-3:nth-child(even) {
        border: hidden;
    }

    p.bx-link {
        font-size: 13px;
        left: 45%;
        top: 20px;
        line-height: 14px;
        padding-right: 30px;
    }

    .col-sm-bx span {
        right: 10px;
        bottom: 0px;
        font-size: 15px;
        opacity: 0.3;
    }

    .col-sm-3.cl-3 {
        -ms-flex: 0 0 33.333%;
        flex: 0 0 33.333%;
        max-width: 33.333%;
    }

    .col-sm-bx {
        min-height: 70px;
    }

    .cl-3 {
        padding: 7px;
    }
}

@media only screen and (max-width: 950px) {
    a.qLInk {
        width: 48%;
    }
}

@media only screen and (max-width: 800px) {
    .col-sm-4.c57 {
        -ms-flex: 0 0 100%;
        flex: 0 0 100%;
        max-width: 100%;
    }
}

@media only screen and (max-width: 750px) {
    .footerTab {
        float: left;
    }

    img.qklinks {
        display: none;
    }

    .bn_left {
        -ms-flex: 0 0 100%;
        flex: 0 0 100%;
        max-width: 100%;
    }

    .bn_right {
        -ms-flex: 0 0 100%;
        flex: 0 0 100%;
        max-width: 100%;
    }

    img.cf-7 {
        width: 230px;
        position: static;
        left: auto;
        top: auto;
        transform: translate(0%, 0%);
    }

    .bn_right {
        padding: 40px 20px;
    }

    .hd1 {
        font-size: 24px;
        width: 80%;
        line-height: 30px;
    }

    .bn_left {
        padding: 50px 60px !important;
    }

    .bvx_1 p {
        font-size: 15px;
        line-height: 20px;
    }

    .col-sm-3.cd-3 {
        -ms-flex: 0 0 100%;
        flex: 0 0 100%;
        max-width: 100%;
        border: hidden;
    }

    .footerTab {
        float: left;
    }

    .col-sm-3.cl-3 {
        -ms-flex: 0 0 50%;
        flex: 0 0 50%;
        max-width: 50%;
    }
}

@media only screen and (max-width: 650px) {
    a.qLInk {
        width: 100%;
        min-height: auto;
    }

    a.qLInk span {
        position: static;
        top: 50%;
        left: 50%;
        transform: translate(0%, 0%);
        width: 60%;
    }

    .sp_no {
        display: none;
    }
}

@media only screen and (max-width: 575px) {
    ul.navbarMenu {
        top: 110px;
    }
}

@media only screen and (max-width: 500px) {
    .col-sm-3.cl-3 {
        -ms-flex: 0 0 100%;
        flex: 0 0 100%;
        max-width: 100%;
    }
}

@media only screen and (max-width: 400px) {
}
`;

interface IEYIDocumentationProps {
  onShowHome: () => void;
}

const EYIDocumentation: React.FC<IEYIDocumentationProps> = ({ onShowHome }) => {
  return (
    <>
      <style>{eyiDocStyles}</style>

      <div>
        <div className="webPart">
          <div className="container-fluid bannerBackground">
            <div className="row nav-bar">
              <img className="EYlogo" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/EY_logo.png" alt="EY logo" />
              <p className="logoTxt">MENA Tax Hub</p>
              <ul className="navbarMenu">
                <li>
                  <a data-interception="off" href="#" onClick={(event) => { event.preventDefault(); onShowHome(); }}>
                    <img className="home" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home.png" alt="Home" />
                  </a>
                  <span>|</span>
                </li>
                <li>
                  <a data-interception="off" href="#quality">Tax Quality</a>
                </li>
              </ul>
              <img className="navToggle" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/toggle.png" alt="Toggle" />
            </div>

            <div className="row">
              <div className="col-sm-9 bn_left">
                <p className="hd1">EYI documentation</p>
                <p className="hd2">
                  EYI MyDocs is the client engagement filing and document management system for Tax. Global Tax have set a target of 100% adoption
                  across our Global Tax practice - the benefits are clear and known as the 4C's:
                  <br />
                  <br /> It is also mandated in Global Tax Service Line policy that all tax engagements will use EYI MyDocs for client engagement
                  filing and documentation (other than for Law, which uses iManage).
                </p>
                <a data-interception="off" href="https://sites.ey.com/sites/mydocs-ey?env=Embedded" target="_blank" rel="noreferrer">
                  <div className="bvx_1">
                    <p>EYI site</p>
                  </div>
                </a>
                <a data-interception="off" href="#mydocs">
                  <div className="bvx_1">
                    <p>MyDocs Minutes</p>
                  </div>
                </a>
              </div>

              <div className="col-sm-3 bn_right">
                <img
                  className="cf-7"
                  src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/circle.png"
                  alt="Circle"
                />
              </div>
            </div>
          </div>

          <div className="container-fluid c7_fluid">
            <div className="row">
              <div className="col-sm-3 cd-3">
                <img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/cv1.png" className="cv-6" alt="Consistency" />
                <p className="cv-7">
                  <b>Consistency:</b> A single, central location to file engagement documents will improve productivity and document management
                  significantly.
                </p>
              </div>

              <div className="col-sm-3 cd-3">
                <img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/cv2.png" className="cv-6" alt="Collaboration" />
                <p className="cv-7">
                  <b>Collaboration:</b> Easy to share, edit, review and approve internal and external client documents. EYI MyDocs is being
                  integrated into the EY ecosystem of Tax tools and technologies, including the Global Tax Platform.
                </p>
              </div>

              <div className="col-sm-3 cd-3">
                <img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/cv3.png" className="cv-6" alt="Compliance" />
                <p className="cv-7">
                  <b>Compliance:</b> Document management and record retention that complies with EY policies, reduces overall document management
                  risk, including stringent access controls and an engagement close process enabling archiving and destruction of records.
                </p>
              </div>

              <div className="col-sm-3 cd-3 cd-4">
                <img
                  src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/cv4.png"
                  className="cv-6"
                  alt="Exceptional Client Service"
                />
                <p className="cv-7">
                  <b>Exceptional Client Service:</b> Maintaining a complete and coherent record of engagement documents is a foundational pillar
                  of exceptional client service, enabling teams to respond to client inquiries quickly.
                </p>
              </div>
            </div>
          </div>

          <div className="container-fluid footerTab">
            <div className="row">
              <div className="col-sm-12">
                <p className="quicklinks">Quick links</p>
              </div>

              <div className="col-sm-3 cl-3">
                <a data-interception="off"
                  href="https://eur01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fsites.ey.com%2Fsites%2Fmydocs-ey%2F%3Fenv%3DEmbedded&data=05%7C01%7CHiran.Jose%40gds.ey.com%7C340686f188cc4bb9665308da97bf29a2%7C5b973f9977df4bebb27daa0c70b8482c%7C0%7C0%7C637989144525267836%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C3000%7C%7C%7C&sdata=90zrXHfrmDlTdbUJA5fQghLz%2BJqP2OfFw%2BU6rcDrOHE%3D&reserved=0"
                  target="_blank"
                  rel="noreferrer"
                >
                  <div className="col-sm-bx">
                    <div
                      className="img-bx"
                      style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/tax.jpg)' }}
                    ></div>
                    <p className="bx-link">EYI MyDocs Landing Page</p>
                    <span>01</span>
                  </div>
                </a>
              </div>

              <div className="col-sm-3 cl-3">
                <a data-interception="off"
                  href="https://eur01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fsites.ey.com%2Fsites%2FDS_Tax%2FPages%2Fglobal-ey-interact-portal.aspx&data=05%7C01%7CHiran.Jose%40gds.ey.com%7C340686f188cc4bb9665308da97bf29a2%7C5b973f9977df4bebb27daa0c70b8482c%7C0%7C0%7C637989144525267836%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C3000%7C%7C%7C&sdata=Wv32spsX5xLKWu9pMFl7c5ZvhD5%2BSrXmdutO01sj6SM%3D&reserved=0"
                  target="_blank"
                  rel="noreferrer"
                >
                  <div className="col-sm-bx">
                    <div
                      className="img-bx"
                      style={{
                        backgroundImage:
                          'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/gettyimages-1386672473-1024x1024.jpg)'
                      }}
                    ></div>
                    <p className="bx-link">EYI MyDocs Discover Page</p>
                    <span>02</span>
                  </div>
                </a>
              </div>

              <div className="col-sm-3 cl-3">
                <a data-interception="off"
                  href="https://eur01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fgo.ey.com%2F3jI8FXY&data=05%7C01%7CHiran.Jose%40gds.ey.com%7C340686f188cc4bb9665308da97bf29a2%7C5b973f9977df4bebb27daa0c70b8482c%7C0%7C0%7C637989144525267836%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C3000%7C%7C%7C&sdata=2IeRADsTqm3MnbOktMfg4oanQXZYaqEvoT8cDdgbZyI%3D&reserved=0"
                  target="_blank"
                  rel="noreferrer"
                >
                  <div className="col-sm-bx">
                    <div
                      className="img-bx"
                      style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/tx03.jpg)' }}
                    ></div>
                    <p className="bx-link">Global EYI MyDocs Protocols</p>
                    <span>03</span>
                  </div>
                </a>
              </div>

              <div className="col-sm-3 cl-3">
                <a data-interception="off"
                  href="https://eur01.safelinks.protection.outlook.com/?url=https%3A%2F%2Feyus.sharepoint.com%2Fsites%2FEYInteract&data=05%7C01%7CHiran.Jose%40gds.ey.com%7C340686f188cc4bb9665308da97bf29a2%7C5b973f9977df4bebb27daa0c70b8482c%7C0%7C0%7C637989144525267836%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C3000%7C%7C%7C&sdata=tesdrOYFIByOLzhIL6k8s%2BDknK7%2B3VU8UgYNTAQRlcI%3D&reserved=0"
                  target="_blank"
                  rel="noreferrer"
                >
                  <div className="col-sm-bx">
                    <div
                      className="img-bx"
                      style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/tx04.jpg)' }}
                    ></div>
                    <p className="bx-link">EYI MyDocs Global Help Page</p>
                    <span>04</span>
                  </div>
                </a>
              </div>

              <div className="col-sm-3 cl-3">
                <a data-interception="off"
                  href="https://eur01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fey.service-now.com%2Fey%2F%3Fid%3Dsc_cat_item%26sys_id%3D5f968172dbd1bf488cfd890705961916&data=05%7C01%7CHiran.Jose%40gds.ey.com%7C340686f188cc4bb9665308da97bf29a2%7C5b973f9977df4bebb27daa0c70b8482c%7C0%7C0%7C637989144525267836%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C3000%7C%7C%7C&sdata=w5Y%2FMud6xfTCSFVJWr8uwKMqCnVxekC0zA8edk1rvo0%3D&reserved=0"
                  target="_blank"
                  rel="noreferrer"
                >
                  <div className="col-sm-bx">
                    <div
                      className="img-bx"
                      style={{
                        backgroundImage:
                          'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/gettyimages-1211353804-2048x2048.jpg)'
                      }}
                    ></div>
                    <p className="bx-link">EYI Support Form - assistance with IT issues</p>
                    <span>05</span>
                  </div>
                </a>
              </div>
            </div>
          </div>

          <div className="footer">
            <p>&#169; 2026 EYGM Limited. All rights reserved.</p>
          </div>
        </div>
      </div>

    </>
  );
};

export default EYIDocumentation;
