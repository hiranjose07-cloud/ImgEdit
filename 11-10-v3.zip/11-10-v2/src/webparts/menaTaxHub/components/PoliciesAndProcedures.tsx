import * as React from 'react';

const imageRoot = 'https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/';

const policyCards = [
  ['z1.png', 'Selling', 'an opportunity', 'is progressing the right opportunities and proposing the work we deliver to our clients. It is about focusing on and improving margin.'],
  ['z2.png', 'Planning', 'an engagement', 'is using our resources in a cost-effective way and providing valuable career opportunities, while enabling us to deliver quality solutions and services to our clients.'],
  ['z3.png', 'Delivering', 'an engagement', 'working on client deliverables, with a continuous focus on margin and managing the health of an engagement.']
];

const resources = [
  ['Engagement lifecycle management checklist', 'https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/Engagement%20lifecycle%20management%20key%20changes.pdf'],
  ['Lean and standard: process steps in Mercury', 'https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/Document%20in%20SOPs_01.pdf'],
  ['Lean vs. standard comparison', 'https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/Lean-vs-Standard.pdf'],
  ['High level budget calculator', 'https://apps.powerapps.com/play/e/c8ee9bdf-796c-e519-a5df-582e17394e4b/a/e5843273-4dd0-456f-bc51-a11b2a7b3b07'],
  ['Financial thresholds control framework', 'https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/MENA%20Tax%20-%20Financial%20Thresholds%20Control%20Framework%20v2.2.pdf'],
  ['RACI', 'https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/raci.pdf'],
  ['Exchange Rates', 'https://www.xe.com/currencyconverter'],
  ['Key Glossary', 'https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/Engagement%20Lifecycle%20Glossary%20%26%20Abbreviations%20V1.0.pdf'],
  ['FAQs', 'https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/Engagement%20Lifecycle%20FAQs%20V1.0.pdf']
];

const stepDetails = [
  ['Mercury Customer Relationship Management (CRM) acts as the single source for global client contact, account, and opportunity data.', 'CRM is standard terminology for creating and editing contact data to improve data accuracy, consistency and integrity.'],
  ['The Opportunity Management process creates, updates and sets the outcome of new opportunities while maintaining existing opportunities.', 'All opportunities need to be created in Mercury CRM and set to WON before an engagement can be created.'],
  ['A pricing plan is required for all opportunities and should reflect market and Service Line benchmarks for the type of work.', 'Pricing is done with a view of the fees required to deliver what the client has requested, with a primary focus on optimized margin.'],
  ['PACE remains the primary tool for risk assessments, while Mercury provides an easy entry point to the system.', 'Every opportunity requires a PACE form for Client Acceptance, Engagement Acceptance, Subcontract or a combination thereof.'],
  ['Pricing plans can be updated until the opportunity status is set to Won, representing the sold-at metric.', 'Keep the pricing plan updated to reflect client and deal review feedback and ensure you are optimizing the opportunity margin.'],
  ['In Mercury, capture the status of the signed Statement of Work (SOW) or Engagement Agreement (EA).', 'To set an opportunity to Won and release an engagement, a signed EA/SOW or exceptional or internal approval is needed.'],
  ['Updating opportunity information throughout the engagement lifecycle is critical because it supports engagement setup and downstream decision-making.', 'Keep opportunity details accurate and up to date, including information used for resourcing and future investment allocations.'],
  ['Every engagement must be linked to an opportunity. You cannot set up an engagement without an opportunity.', 'When setting up an engagement, provide opportunity and PACE details, engagement roles, engagement agreements and billing details.'],
  ['Standard engagements require detailed budgets, while Lean engagements require a high-level budget including the engagement value and margin threshold.', 'Complete the Engagement Budget to release the engagement and begin charging hours.'],
  ['Resourcing is the process of identifying and assigning individuals to an opportunity or engagement.', 'It ensures the right people are available to deliver on client needs on a timely basis.'],
  ['Resource scheduling ensures the right people are available to deliver on client needs on time.', 'Send the resource request and maintain the engagement schedule as requirements change.'],
  ['Timely and accurate recording and submission of time and expenses is crucial because every hour and expense charged is potential revenue or cost for the firm.'],
  ['Engagement Economics reviews and manages the financial aspects of an engagement, including forecasting against the Mercury budget.', 'Complete regular and timely reviews, optimize engagement margin and minimize write-offs by keeping data accurate and up to date.'],
  ['The billing process is crucial to mitigate risk and improve working capital management.', 'By billing correctly from the start and monitoring aged invoices, collection issues can be identified and resolved in a timely manner.'],
  ['Collections communicates with engagement teams and clients to ensure timely collection of Accounts Receivable.', 'Escalate issues or client disputes that prevent collection of Accounts Receivable.'],
  ['Closing an engagement is the final step of the Engagement Lifecycle and enables us to review financial performance.', 'This information helps us make informed decisions on how to approach or pursue similar engagements in the future.']
];

interface IPoliciesAndProceduresProps { onShowHome: () => void; }

const styles = `
.policies-page{background:#2e2e38;color:#fff;font-family:EYInterstate,Arial,sans-serif;min-height:100vh;overflow:hidden}.policies-page *{box-sizing:border-box}.loading-container{align-items:center;background:#1a1a24;display:flex;inset:0;justify-content:center;position:fixed;z-index:1000001}.loading-container .item{border:.2vw solid #ffe600;border-bottom-color:transparent;border-radius:50%;border-top-color:transparent;position:absolute;animation:spin 2s ease infinite}.loading-container .item:nth-child(1){height:30px;width:30px}.loading-container .item:nth-child(2){animation-delay:.1s;height:50px;width:50px}.loading-container .item:nth-child(3){animation-delay:.2s;height:70px;width:70px}.loading-container .item:nth-child(4){animation-delay:.3s;height:90px;width:90px}@keyframes spin{50%{transform:rotate(180deg)}100%{transform:rotate(0deg)}}.policy-nav{height:6vw;min-height:72px;background:#2e2e38;position:relative;z-index:3}.EYlogo{position:absolute;left:5vw;top:1.5vw;width:3vw}.logoTxt{position:absolute;left:11vw;top:2.2vw;margin:0;color:#fff;font-size:2vw}.navbarMenu{position:absolute;right:6vw;top:2.4vw;margin:0;padding:0;list-style:none}.navbarMenu li{display:inline-block;color:#fff;font-size:1vw}.navbarMenu a{color:#fff;padding:0 2vw;text-decoration:none}.home{width:1.3vw}.policy-hero{display:grid;grid-template-columns:minmax(0,3fr) minmax(230px,1fr);background:#2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/banner.jpg') center/cover;padding:0 0 0 5vw}.hero-copy{background:rgba(46,46,56,.54);padding:2vw 2vw 2.2vw 0}.policy-hero h1{color:#fff;font-size:1.5vw;font-weight:400;margin:0 0 2vw}.policy-card-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:2vw}.policy-card{min-height:10vw}.policy-card img{display:block;width:3vw;margin-bottom:.4vw}.policy-card p{font-size:.75vw;line-height:1.3;margin:0}.policy-card span{color:#ffe600;font-weight:700;font-size:.9vw;margin-right:.3vw}.policy-card b{font-size:.9vw}.hero-intro{margin-top:2vw;font-size:.75vw;line-height:1.4}.hero-intro ul{list-style:none;margin:1vw 0 0;padding:0}.hero-intro li{margin:.45vw 0;padding-left:1vw;position:relative}.hero-intro li:before{content:'>';color:#ffe600;position:absolute;left:0;font-weight:bold}.hero-resources{background:rgba(24,24,32,.7);padding:0}.hero-resources a{display:flex;align-items:center;justify-content:center;min-height:3.6vw;padding:.6vw 1.2vw;border-bottom:1px solid rgba(255,255,255,.08);color:#fff;text-align:center;font-size:.7vw;line-height:1.25;text-decoration:none;    font-size: 1vw;
    padding: 1vw 2vw;     min-height: 5.5vw;}
    .hero-resources a:nth-child(even){background:#ffffff12;}
    .hero-resources a:hover{background:rgba(255,255,255,.1)}.lifecycle{background:#2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/wecast.png') center/cover;padding:3.5vw 8vw 4vw;position:relative}.lifecycle h2{font-size:2.3vw;font-weight:400;margin:0 0 .3vw}.lifecycle>p{color:#ffe600;font-size:.75vw;margin:0}.phase-labels{display:grid;grid-template-columns:repeat(3,1fr);margin-top:1.7vw}.phase-label{border-bottom:3px solid;text-align:center;padding-bottom:.4vw;font-size:.7vw}.phase-label:nth-child(1){border-color:#2db757}.phase-label:nth-child(2){border-color:#27acaa}.phase-label:nth-child(3){border-color:#188ce5}.step-map{display:grid;grid-template-columns:repeat(8,1fr);grid-template-rows:repeat(2,8.5vw);margin-top:1.5vw;position:relative}.step-map:before{content:'';position:absolute;left:1.2vw;right:1.2vw;top:8.5vw;border-top:1px dashed rgba(255,255,255,.6)}.step-cell{position:relative;display:flex;align-items:center;justify-content:center}.step-cell:nth-child(4n+1),.step-cell:nth-child(4n+2){grid-row:2}.step-cell:nth-child(4n+3),.step-cell:nth-child(4n+4){grid-row:1}.step-cell:after{content:'';position:absolute;top:0;bottom:0;border-left:1px dashed rgba(255,255,255,.6);z-index:0}.step-cell:nth-child(4n+1):after,.step-cell:nth-child(4n+2):after{top:-3.5vw}.step-cell:nth-child(4n+3):after,.step-cell:nth-child(4n+4):after{bottom:-3.5vw}.step-cell:nth-child(4n+1) .step,.step-cell:nth-child(4n+2) .step{transform:translateY(2.4vw)}.step-cell:nth-child(4n+3) .step,.step-cell:nth-child(4n+4) .step{transform:translateY(-2.4vw)}.step{position:relative;z-index:1;background:transparent;border:0;color:#fff;cursor:pointer;padding:0;width:100%;text-align:center}.step:hover .step-number,.step:focus-visible .step-number{background:#fff;color:#000;outline:none}.step-number{display:flex;align-items:center;justify-content:center;background:#ffe600;border-radius:50%;color:#000;font-size:1vw;height:2.2vw;margin:auto;width:2.2vw}.step img{display:block;margin:.4vw auto;width:2vw;max-height:2vw;object-fit:contain}.step-label{display:block;font-size:.65vw;line-height:1.15;margin:auto;max-width:7vw}.lifecycle-links{display:flex;justify-content:flex-end;gap:.6vw;margin-top:1.2vw}.lifecycle-links a{background:rgba(255,255,255,.1);border-radius:2vw;color:#fff;font-size:.7vw;padding:.45vw 1.5vw;text-decoration:none}.lifecycle-links a:before{content:'';display:inline-block;background:#ffe600;border-radius:50%;height:.45vw;margin-right:.7vw;width:.45vw}.mercury{background:#2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center/cover;padding:4vw 5vw 3vw;min-height:18vw}.mercury h2{color:#ffe600;font-size:2.5vw;font-weight:400;margin:0 0 .8vw}.mercury p{font-size:.8vw;line-height:1.5;margin:0 0 1.5vw}.mercury-links{display:flex;gap:.8vw}.mercury-links a{background:rgba(255,255,255,.1);color:#fff;display:flex;flex-direction:column;font-size:.7vw;padding:1vw;text-decoration:none;width:9vw}.mercury-links img{height:2vw;margin-bottom:.5vw;object-fit:contain;width:2vw}.footer{background:#000;padding:.8vw 2vw;text-align:right}.footer p{font-size:.7vw;margin:0}.policy-panel{align-items:center;background:rgba(0,0,0,.72);display:flex;inset:0;justify-content:center;padding:2vw;position:fixed;z-index:1000000}.policy-panel-content{background:#2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center/cover;max-height:90vh;max-width:42vw;overflow-y:auto;padding:3vw;position:relative;width:100%}.policy-panel-content h3{color:#ffe600;font-size:2vw;font-weight:400;margin:0 0 1.5vw}.policy-panel-content ul{margin:0;padding-left:1.2vw}.policy-panel-content li{font-size:1vw;line-height:1.5;margin-bottom:1vw}.policy-panel-content a{color:#ffe600;display:block;font-size:1vw;margin-top:1.5vw}.close-panel{background:#ffe600;border:0;cursor:pointer;font-size:1.5vw;height:2.2vw;position:absolute;right:1.5vw;top:1.5vw;width:2.2vw}
@media(max-width:900px){.policy-nav{height:90px}.EYlogo{left:30px;top:20px;width:40px}.logoTxt{font-size:24px;left:90px;top:28px}.navbarMenu{right:25px;top:32px}.home{width:20px}.policy-hero{display:block;padding:0}.hero-copy{padding:35px 30px}.policy-hero h1{font-size:28px}.policy-card-grid{gap:25px}.policy-card img{width:45px}.policy-card p,.hero-intro{font-size:13px}.policy-card span,.policy-card b{font-size:16px}.hero-resources{display:grid;grid-template-columns:repeat(3,1fr)}.hero-resources a{font-size:11px;min-height:70px}.lifecycle{padding:40px 30px}.lifecycle h2{font-size:28px}.lifecycle>p{font-size:14px}.phase-label{font-size:11px}.step-map{grid-template-rows:repeat(2,110px);margin-top:20px}.step-number{font-size:14px;height:32px;width:32px}.step img{height:26px;width:30px}.step-label{font-size:10px}.lifecycle-links{justify-content:center}.lifecycle-links a{font-size:11px}.mercury{padding:40px 30px}.mercury h2{font-size:30px}.mercury p{font-size:14px}.mercury-links a{font-size:12px;width:130px}.footer p{font-size:11px}.policy-panel-content{max-width:90vw;padding:45px 25px 25px}.policy-panel-content h3{font-size:24px}.policy-panel-content li,.policy-panel-content a{font-size:14px}.close-panel{font-size:24px;height:32px;right:15px;top:15px;width:32px}}
@media(max-width:600px){.logoTxt{font-size:19px;left:85px}.navbarMenu{right:15px}.policy-card-grid{grid-template-columns:1fr}.hero-resources{grid-template-columns:1fr 1fr}.hero-resources a{min-height:58px}.phase-labels{grid-template-columns:1fr}.phase-label{margin-top:8px}.step-map{display:grid;grid-template-columns:repeat(2,1fr);grid-template-rows:none;gap:8px;margin-top:20px}.step-map:before,.step-cell:after{display:none}.step-cell,.step-cell:nth-child(4n+1),.step-cell:nth-child(4n+2),.step-cell:nth-child(4n+3),.step-cell:nth-child(4n+4){grid-row:auto}.step-cell .step,.step-cell:nth-child(4n+1) .step,.step-cell:nth-child(4n+2) .step,.step-cell:nth-child(4n+3) .step,.step-cell:nth-child(4n+4) .step{transform:none}.step{background:rgba(255,230,0,.95);color:#000;display:grid;grid-template-columns:45px 1fr;min-height:70px;padding:8px;text-align:left}.step-number{grid-row:span 2;margin:auto}.step img{grid-column:2;height:23px;margin:0;width:25px}.step-label{font-size:11px;max-width:none;width:100%}.lifecycle-links{flex-wrap:wrap}.mercury-links{flex-wrap:wrap}.mercury-links a{width:120px}}
.policies-page .logoTxt{font-size:2vw}.policies-page .navbarMenu li{font-size:1vw}.policies-page .policy-hero h1{color:#ffe600;font-size:3vw;line-height:3.4vw;margin:3vw 0 2vw}.policies-page .policy-card p{font-size:1vw;line-height:1.3vw}.policies-page .policy-card span,.policies-page .policy-card b{font-size:1.2vw}.policies-page .hero-intro{font-size:1vw;line-height:1.5vw}.policies-page .lifecycle h2,.policies-page .mercury h2{font-size:2.3vw}.policies-page .lifecycle>p{font-size:1vw}.policies-page .phase-label{font-size:1vw}.policies-page .step-label{font-size:1vw}.policies-page .mercury p{font-size:1vw}.policies-page .footer p{font-size:1vw}
@media only screen and (max-width:1200px){.policies-page .policy-hero h1{font-size:40px;line-height:35px}.policies-page .policy-card p,.policies-page .hero-intro{font-size:16px;line-height:24px}.policies-page .policy-card span,.policies-page .policy-card b{font-size:16px}.policies-page .lifecycle h2,.policies-page .mercury h2{font-size:30px}.policies-page .lifecycle>p,.policies-page .phase-label,.policies-page .step-label{font-size:15px}.policies-page .mercury p{font-size:16px}.policies-page .footer p{font-size:13px}}
@media only screen and (max-width:800px){.policies-page .EYlogo{left:60px;top:20px;width:40px}.policies-page .logoTxt{font-size:25px;left:130px;top:30px}.policies-page .navbarMenu{right:50px;top:31px}.policies-page .home{width:20px}.policies-page .policy-hero h1{font-size:40px;line-height:36px}.policies-page .policy-card p,.policies-page .hero-intro{font-size:15px;line-height:24px}.policies-page .policy-card span,.policies-page .policy-card b{font-size:18px}.policies-page .lifecycle h2,.policies-page .mercury h2{font-size:30px}.policies-page .lifecycle>p,.policies-page .phase-label,.policies-page .step-label{font-size:15px}.policies-page .mercury p{font-size:15px}.policies-page .footer p{font-size:13px}}
@media only screen and (max-width:500px){.policies-page .logoTxt{font-size:20px;left:115px}.policies-page .EYlogo{left:30px}.policies-page .policy-hero h1{font-size:30px}.policies-page .policy-card p,.policies-page .hero-intro{font-size:14px;line-height:21px}.policies-page .policy-card span,.policies-page .policy-card b{font-size:16px}.policies-page .lifecycle h2,.policies-page .mercury h2{font-size:30px}}
.policies-page .lifecycle{min-height:59vw;padding:4vw 8vw;overflow:hidden}.policies-page .step-map{display:block;height:45vw;margin-top:1vw;position:relative}.policies-page .step-map:before{display:none}.policies-page .step-cell{display:block;height:3vw;position:absolute;width:9vw}.policies-page .step-cell:nth-child(1){left:0;top:26vw}.policies-page .step-cell:nth-child(2){left:0;top:33vw}.policies-page .step-cell:nth-child(3){left:11vw;top:33vw}.policies-page .step-cell:nth-child(4){left:11vw;top:17vw}.policies-page .step-cell:nth-child(5){left:22vw;top:17vw}.policies-page .step-cell:nth-child(6){left:22vw;top:33vw}.policies-page .step-cell:nth-child(7){left:33vw;top:33vw}.policies-page .step-cell:nth-child(8){left:33vw;top:20vw}.policies-page .step-cell:nth-child(9){left:44vw;top:20vw}.policies-page .step-cell:nth-child(10){left:44vw;top:33vw}.policies-page .step-cell:nth-child(11){left:55vw;top:33vw}.policies-page .step-cell:nth-child(12){left:55vw;top:14vw}.policies-page .step-cell:nth-child(13){left:66vw;top:14vw}.policies-page .step-cell:nth-child(14){left:66vw;top:33vw}.policies-page .step-cell:nth-child(15){left:77vw;top:33vw}.policies-page .step-cell:nth-child(16){left:77vw;top:26vw}.policies-page .step-cell:after{display:none}.policies-page .step{height:3vw;position:static;width:3vw}.policies-page .step-number{font-size:1.5vw;height:3vw;padding-top:.3vw;width:3vw}.policies-page .step img{height:auto;margin:.5vw 0 0;width:3vw}.policies-page .step-label{font-size:1vw;left:0;line-height:1.2vw;max-width:9vw;position:absolute;text-align:left;top:4vw;width:9vw}.policies-page .step-cell:nth-child(odd) .step-label{top:-6vw}.policies-page .step-cell:nth-child(odd) .step img{position:absolute;top:-4vw}.policies-page .step-cell:nth-child(even) .step img{position:absolute;top:4vw}.policies-page .step-cell:nth-child(1) .step-label,.policies-page .step-cell:nth-child(3) .step-label,.policies-page .step-cell:nth-child(5) .step-label,.policies-page .step-cell:nth-child(7) .step-label,.policies-page .step-cell:nth-child(9) .step-label,.policies-page .step-cell:nth-child(11) .step-label,.policies-page .step-cell:nth-child(13) .step-label,.policies-page .step-cell:nth-child(15) .step-label{top:-6vw}.policies-page .connector{border-top:.15vw dashed #fff;position:absolute;transform-origin:left center}.policies-page .connector-0{left:1.5vw;top:34.5vw;width:9.5vw}.policies-page .connector-1{left:12.5vw;top:34.5vw;width:9.5vw}.policies-page .connector-2{left:23.5vw;top:34.5vw;width:9.5vw}.policies-page .connector-3{left:12.5vw;top:18.5vw;width:9.5vw}.policies-page .connector-4{left:23.5vw;top:18.5vw;width:9.5vw}.policies-page .connector-5{left:34.5vw;top:34.5vw;width:9.5vw}.policies-page .connector-6{left:34.5vw;top:21.5vw;width:9.5vw}.policies-page .connector-7{left:45.5vw;top:21.5vw;width:9.5vw}.policies-page .connector-8{left:45.5vw;top:34.5vw;width:9.5vw}.policies-page .connector-9{left:56.5vw;top:34.5vw;width:9.5vw}.policies-page .connector-10{left:56.5vw;top:15.5vw;width:9.5vw}.policies-page .connector-11{left:67.5vw;top:15.5vw;width:9.5vw}.policies-page .connector-12{left:67.5vw;top:34.5vw;width:9.5vw}.policies-page .connector-13{left:78.5vw;top:34.5vw;width:7vw}.policies-page .connector-14{left:79.5vw;top:29.5vw;height:7vw;width:0;transform:rotate(90deg)}.policies-page .lifecycle-links{margin-top:0}.policies-page .policy-panel{align-items:stretch;justify-content:flex-end;padding:0}.policies-page .policy-panel-content{height:100%;margin:0;max-height:none;max-width:35vw;padding:10vw 3vw 3vw;transform:translateX(0)}
.policies-page .step-cell:nth-child(odd) .step-label,.policies-page .step-cell:nth-child(even) .step-label{top:4vw}.policies-page .step-cell:nth-child(4) .step-label,.policies-page .step-cell:nth-child(5) .step-label,.policies-page .step-cell:nth-child(8) .step-label,.policies-page .step-cell:nth-child(9) .step-label,.policies-page .step-cell:nth-child(12) .step-label,.policies-page .step-cell:nth-child(13) .step-label,.policies-page .step-cell:nth-child(16) .step-label{top:-6vw}.policies-page .step-cell:nth-child(odd) .step img,.policies-page .step-cell:nth-child(even) .step img{top:4vw}.policies-page .step-cell:nth-child(4) .step img,.policies-page .step-cell:nth-child(5) .step img,.policies-page .step-cell:nth-child(8) .step img,.policies-page .step-cell:nth-child(9) .step img,.policies-page .step-cell:nth-child(12) .step img,.policies-page .step-cell:nth-child(13) .step img,.policies-page .step-cell:nth-child(16) .step img{top:-4vw}.policies-page .panel-left{justify-content:flex-end}.policies-page .panel-right{justify-content:flex-start}.policies-page .panel-left .policy-panel-content{transform:translateX(0)}.policies-page .panel-right .policy-panel-content{transform:translateX(0)}
@media only screen and (max-width:850px){.policies-page .step-map{display:flex;flex-wrap:wrap;gap:0;height:auto;margin-top:25px}.policies-page .step-map .connector{display:none}.policies-page .step-cell,.policies-page .step-cell:nth-child(n){height:auto;left:auto;top:auto;position:static;width:48%;margin:0 2% 10px 0}.policies-page .step-cell .step,.policies-page .step-cell:nth-child(n) .step{background:#ffe600;color:#000;display:grid;grid-template-columns:50px 1fr;height:auto;min-height:70px;padding:8px;text-align:left;transform:none;width:100%}.policies-page .step-cell .step-number{grid-row:span 2;margin:auto}.policies-page .step-cell .step img,.policies-page .step-cell:nth-child(n) .step img{grid-column:2;height:35px;margin:0;position:static;width:35px}.policies-page .step-cell .step-label,.policies-page .step-cell:nth-child(n) .step-label{font-size:18px;line-height:21px;max-width:none;position:static;width:auto}.policies-page .policy-panel-content{max-width:90vw;padding:40px 30px}.policies-page .policy-panel-content h3{font-size:19px}.policies-page .policy-panel-content li{font-size:12px}}
.policies-page .webAnimation{background:#2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/wecast.png') center/cover;min-height:59vw;overflow:hidden;padding:4vw 8vw;position:relative}.policies-page .pg1{color:#fff;font-size:2.3vw;margin:0 0 .3vw;padding-top:0}.policies-page .pg2{color:#ffe600;font-size:1vw;margin:0}.policies-page .hrx{border-bottom:.2vw solid;float:left;color:#fff;font-size:1vw;margin:2vw 0 0;padding-bottom:.5vw;text-align:center}.policies-page .br1{border-color:#2db757;width:34vw}.policies-page .br2{border-color:#27acaa;margin-left:.4vw;margin-right:.4vw;width:21.6vw}.policies-page .br3{border-color:#188ce5;width:22vw}.policies-page .circlesTab{height:43vw;list-style:none;margin:0;padding:0;position:relative}.policies-page .circlesTab .subCircle{background:#ffe600;border:0;border-radius:50%;color:#000;cursor:pointer;font-size:1.5vw;height:3vw;line-height:2.4vw;padding:0;position:absolute;text-align:center;width:3vw;z-index:2;padding-top: 0.25vw;}.policies-page .circlesTab .subCircle:before{animation:ripple 1.5s ease-out infinite;background:inherit;border-radius:50%;content:'';height:100%;left:0;position:absolute;top:0;width:100%;z-index:-1}.policies-page .circlesTab .subCircle:hover{border:.4vw solid #fff;line-height:1.7vw}.policies-page .circle-c0{left:0;top:26vw}.policies-page .circle-c1{left:0;top:33vw}.policies-page .circle-c2{left:11vw;top:33vw}.policies-page .circle-c3{left:11vw;top:17vw}.policies-page .circle-c4{left:22vw;top:17vw}.policies-page .circle-c5{left:22vw;top:33vw}.policies-page .circle-c6{left:33vw;top:33vw}.policies-page .circle-c7{left:33vw;top:20vw}.policies-page .circle-c8{left:44vw;top:20vw}.policies-page .circle-c9{left:44vw;top:33vw}.policies-page .circle-c10{left:55vw;top:33vw}.policies-page .circle-c11{left:55vw;top:14vw}.policies-page .circle-c12{left:66vw;top:14vw}.policies-page .circle-c13{left:66vw;top:33vw}.policies-page .circle-c14{left:77vw;top:33vw}.policies-page .circle-c15{left:77vw;top:26vw}.policies-page .hrLine{border-top:.15vw dashed #fff;position:absolute;z-index:1}.policies-page .hr0{left:-2vw;top:30vw;transform:rotate(90deg);width:7vw}.policies-page .hr1{left:1.5vw;top:33.5vw;width:9vw}.policies-page .hr2{left:4.5vw;top:26vw;transform:rotate(90deg);width:16vw}.policies-page .hr3{left:12vw;top:17.5vw;width:12vw}.policies-page .hr4{left:15.5vw;top:26vw;transform:rotate(90deg);width:16vw}.policies-page .hr5{left:25vw;top:33.5vw;width:11vw}.policies-page .hr6{left:28.5vw;top:26vw;transform:rotate(90deg);width:12vw}.policies-page .hr7{left:34vw;top:20.5vw;width:11vw}.policies-page .hr8{left:39.5vw;top:27vw;transform:rotate(90deg);width:12vw}.policies-page .hr9{left:46vw;top:33.5vw;width:11vw}.policies-page .hr10{left:48vw;top:24vw;transform:rotate(90deg);width:17vw}.policies-page .hr11{left:57vw;top:14.5vw;width:11vw}.policies-page .hr12{left:59vw;top:24vw;transform:rotate(90deg);width:17vw}.policies-page .hr13{left:68vw;top:33.5vw;width:11vw}.policies-page .hr14{left:75vw;top:30vw;transform:rotate(90deg);width:7vw}.policies-page .Ctext{color:#fff;cursor:pointer;font-size:1vw;line-height:1.2vw;pointer-events:auto;position:absolute;text-align:left;width:9vw;z-index:1}.policies-page .Ctext img{display:block;padding-bottom:.5vw;width:3vw}.policies-page .p1{left:0;top:20vw}.policies-page .p2{left:0;top:37vw}.policies-page .p3{left:11vw;top:37vw}.policies-page .p4{left:11vw;top:11.5vw}.policies-page .p5{left:22vw;top:10.7vw}.policies-page .p6{left:22vw;top:37.2vw}.policies-page .p7{left:33vw;top:37vw}.policies-page .p8{left:33vw;top:14vw}.policies-page .p9{left:44vw;top:14vw;width:10vw}.policies-page .p10{left:44vw;top:37vw}.policies-page .p11{left:55vw;top:37.3vw}.policies-page .p12{left:55vw;top:9.3vw}.policies-page .p13{left:66vw;top:8.3vw;width:10vw}.policies-page .p14{left:66vw;top:37.1vw;width:8vw}.policies-page .p15{left:77vw;top:37.1vw;width:8vw}.policies-page .p16{left:77vw;top:20.5vw;width:8vw}.policies-page .overlayLeft,.policies-page .overlayRight{height:100%;position:absolute;top:0;transition:all 1s ease-in-out;width:35vw;z-index:5}.policies-page .overlayLeft{background:rgba(46,46,56,.9);right:-36vw}.policies-page .overlayRight{background:rgba(46,46,56,.9);left:-36vw}.policies-page .overlayLeft.active{right:0}.policies-page .overlayRight.active{left:0}.policies-page .inside{height:100%;left:0;opacity:0;overflow-y:auto;padding:10vw 3vw 3vw;position:absolute;top:0;transition:opacity 1s;visibility:hidden;width:100%;z-index:0}.policies-page .inside.active{opacity:1;visibility:visible;z-index:1}.policies-page .def-head{color:#ffe600;font-size:2vw;margin:0 0 1.4vw}.policies-page .definition{color:#fff;font-size:1vw;list-style:none;margin:0;padding:0}.policies-page .definition li{margin-bottom:1vw;padding-left:1vw;position:relative}.policies-page .definition li:before{color:#ffe600;content:'>';left:0;position:absolute}.policies-page .close_slide{background:#ffe600;cursor:pointer;font-size:1vw;font-weight:bold;height:2vw;left:-1vw;padding-top:.2vw;position:absolute;text-align:center;top:8vw;width:2vw;z-index:3}.policies-page .close_slide.c70{border-radius:0 .5vw 0 0;left:auto;right:-1vw}.policies-page .inside .minfo{color:#ffe600;display:block;font-size:.9vw;margin:1vw 0;text-decoration:underline}.policies-page .rows{bottom:2vw;left:0;padding:1vw 5vw;position:absolute;width:95%}.policies-page .bx-01{background:rgba(255,255,255,.09);border:1px solid rgba(255,255,255,.2);border-radius:5vw;float:right;margin:0 .4vw;position:relative;width:12vw}.policies-page .bx-01:before{background:#ffe600;border-radius:50%;content:'';height:.8vw;left:1.3vw;position:absolute;top:50%;transform:translate(-50%,-50%);width:.8vw}.policies-page .bx-01 .cb-box{min-height:auto;    padding: 0.6vw 1.5vw;}.policies-page .bx-01 p{color:#fff;font-size:1vw;line-height:1.3vw;margin:0;text-align:center}
@keyframes ripple{from{opacity:1;transform:scale(0)}to{opacity:0;transform:scale(1.8)}}
@media only screen and (max-width:850px){.policies-page .webAnimation{min-height:860px;padding:50px}.policies-page .pg1{font-size:25px}.policies-page .pg2{font-size:18px}.policies-page .hrx{display:none}.policies-page .circlesTab{height:auto}.policies-page .circlesTab .subCircle,.policies-page .hrLine{display:none}.policies-page .Ctext{background:#ffe600;color:#000;display:block;float:left;font-size:18px;line-height:21px;margin:0 2% 10px 0;min-height:60px;padding:8px 30px 0 65px;position:relative;top:auto!important;left:auto!important;width:48%}.policies-page .Ctext img{background:#2e2e38;height:100%;left:0;padding:17px 10px;position:absolute;top:0;width:50px}.policies-page .overlayLeft,.policies-page .overlayRight{height:100%;width:90%}.policies-page .overlayLeft{right:-110%}.policies-page .overlayRight{left:-110%}.policies-page .inside{padding:40px 30px}.policies-page .def-head{font-size:19px;line-height:20px}.policies-page .definition{font-size:12px}.policies-page .definition li{margin-bottom:10px;padding-left:15px}.policies-page .inside .minfo{font-size:12px}.policies-page .rows{bottom:auto;padding:10px;position:static;width:100%}.policies-page .bx-01{float:none;margin:10px;width:calc(100% - 20px)}.policies-page .bx-01 p{font-size:13px}}
`;

const PoliciesAndProcedures: React.FC<IPoliciesAndProceduresProps> = ({ onShowHome }) => {
  const [selectedStep, setSelectedStep] = React.useState<number | null>(null);
  const [isLoading, setIsLoading] = React.useState<boolean>(true);

  React.useEffect(() => {
    const closeOnEscape = (event: KeyboardEvent): void => {
      if (event.key === 'Escape') setSelectedStep(null);
    };
    document.addEventListener('keydown', closeOnEscape);
    const loadingTimer = window.setTimeout(() => setIsLoading(false), 2000);
    return () => {
      document.removeEventListener('keydown', closeOnEscape);
      window.clearTimeout(loadingTimer);
    };
  }, []);

  const renderPanel = (index: number, title: string): React.ReactNode => (
    <div className={`inside ins${index}${selectedStep === index ? ' active' : ''}`} key={title}>
      <p className="def-head">{title}</p>
      <ul className="definition">
        {stepDetails[index].map((detail) => <li key={detail}>{detail}</li>)}
      </ul>
      <a data-interception="off" className="minfo in-c4" href={resources[index % resources.length][1]} target="_blank" rel="noreferrer">
        View process guide
      </a>
    </div>
  );

  return (
    <div className="policies-page">
      <style>{styles}</style>

      {isLoading && (
        <div className="loading-container" aria-label="Loading">
          <div className="item" />
          <div className="item" />
          <div className="item" />
          <div className="item" />
        </div>
      )}

      <header className="policy-nav">
        <img className="EYlogo" src={`${imageRoot}EY_logo.png`} alt="EY logo" />
        <p className="logoTxt">MENA Tax Hub</p>
        <ul className="navbarMenu">
          <li>
            <a data-interception="off" href="#home" onClick={(event) => { event.preventDefault(); onShowHome(); }}>
              <img className="home" src={`${imageRoot}home.png`} alt="Home" />
            </a>
          </li>
          <li><span>|</span></li>
          <li><a data-interception="off" href="#lifecycle">Engagement Lifecycle</a></li>
        </ul>
      </header>

      <main>
        <section className="policy-hero">
          <div className="hero-copy">
            <h1>Policies and procedures</h1>
            <div className="policy-card-grid">
              {policyCards.map((card) => (
                <article className="policy-card" key={card[1]}>
                  <img src={`${imageRoot}${card[0]}`} alt="" />
                  <p>
                    <span>{card[1]}</span>
                    <b>{card[2]}</b>
                    <br />
                    {card[3]}
                  </p>
                </article>
              ))}
            </div>
            <div className="hero-intro">
              Depending on the value and the characteristics of your engagement, the journey through the engagement lifecycle may differ:
              <ul>
                <li>Opportunities with a total higher opportunity value (TOV) are called &quot;standard&quot; and will pass through most steps.</li>
                <li>Smaller opportunities are called &quot;Lean&quot; and will not require as much information as the standard opportunity.</li>
                <li>Thresholds are determined locally.</li>
              </ul>
            </div>
          </div>
          <nav className="hero-resources">
            {resources.slice(0, 6).map((resource) => (
              <a data-interception="off" href={resource[1]} key={resource[0]} target="_blank" rel="noreferrer">{resource[0]}</a>
            ))}
          </nav>
        </section>

        <section className="webAnimation" id="lifecycle">
          <p className="pg1">Engagement Lifecycle Management - Policy Guidance</p>
          <p className="pg2">Click on each step to view more</p>
          <p className="br1 hrx">Selling an opportunity (0-6)</p>
          <p className="br2 hrx">Planning an engagement (7-10)</p>
          <p className="br3 hrx">Delivering an engagement (11-15)</p>

          <ul className="circlesTab">
            <a data-interception="off" href="#step-0" onClick={(event) => event.preventDefault()}><li className="circle-c0 subCircle onClickShow vf1" onClick={() => setSelectedStep(0)}>0</li><p className="p1 Ctext onClickShow1" onClick={() => setSelectedStep(0)}><img src={`${imageRoot}Picture00.png`} alt="" />Create or maintain contacts</p></a>
            <hr className="hr0 hrLine" />
            <a data-interception="off" href="#step-1" onClick={(event) => event.preventDefault()}><li className="circle-c1 subCircle onClickShow vf1" onClick={() => setSelectedStep(1)}>1</li><p className="p2 Ctext onClickShow1" onClick={() => setSelectedStep(1)}><img src={`${imageRoot}Picture01.png`} alt="" />Create opportunity</p></a>
            <hr className="hr1 hrLine" />
            <a data-interception="off" href="#step-2" onClick={(event) => event.preventDefault()}><li className="circle-c2 subCircle onClickShow vf1" onClick={() => setSelectedStep(2)}>2</li><p className="p3 Ctext onClickShow1" onClick={() => setSelectedStep(2)}><img src={`${imageRoot}Picture02.png`} alt="" />Create Pricing Plan</p></a>
            <hr className="hr2 hrLine" />
            <a data-interception="off" href="#step-3" onClick={(event) => event.preventDefault()}><li className="circle-c3 subCircle onClickShow vf1" onClick={() => setSelectedStep(3)}>3</li><p className="p4 Ctext onClickShow1" onClick={() => setSelectedStep(3)}><img src={`${imageRoot}Picture03.png`} alt="" />Perform Acceptance</p></a>
            <hr className="hr3 hrLine" />
            <a data-interception="off" href="#step-4" onClick={(event) => event.preventDefault()}><li className="circle-c4 subCircle onClickShow vf1" onClick={() => setSelectedStep(4)}>4</li><p className="p5 Ctext onClickShow1" onClick={() => setSelectedStep(4)}><img src={`${imageRoot}Picture04.png`} alt="" />Update Pricing Plan</p></a>
            <hr className="hr4 hrLine" />
            <a data-interception="off" href="#step-5" onClick={(event) => event.preventDefault()}><li className="circle-c5 subCircle onClickShow vf1" onClick={() => setSelectedStep(5)}>5</li><p className="p6 Ctext onClickShow1" onClick={() => setSelectedStep(5)}><img src={`${imageRoot}Picture05.png`} alt="" />Statement of Work (SOW) sign off and contract</p></a>
            <hr className="hr5 hrLine" />
            <a data-interception="off" href="#step-6" onClick={(event) => event.preventDefault()}><li className="circle-c6 subCircle onClickShow vf1" onClick={() => setSelectedStep(6)}>6</li><p className="p7 Ctext onClickShow1" onClick={() => setSelectedStep(6)}><img src={`${imageRoot}Picture06.png`} alt="" />Update Opportunity details</p></a>
            <hr className="hr6 hrLine" />
            <a data-interception="off" href="#step-7" onClick={(event) => event.preventDefault()}><li className="circle-c7 subCircle onClickShow vf1" onClick={() => setSelectedStep(7)}>7</li><p className="p8 Ctext onClickShow1" onClick={() => setSelectedStep(7)}><img src={`${imageRoot}Picture07.png`} alt="" />Create Engagement</p></a>
            <hr className="hr7 hrLine" />
            <a data-interception="off" href="#step-8" onClick={(event) => event.preventDefault()}><li className="circle-c8 subCircle onClickShow vf1 c70" onClick={() => setSelectedStep(8)}>8</li><p className="p9 Ctext onClickShow1 c70" onClick={() => setSelectedStep(8)}><img src={`${imageRoot}Picture08.png`} alt="" />Create Engagement Budget</p></a>
            <hr className="hr8 hrLine" />
            <a data-interception="off" href="#step-9" onClick={(event) => event.preventDefault()}><li className="circle-c9 subCircle onClickShow vf1 c70" onClick={() => setSelectedStep(9)}>9</li><p className="p10 Ctext onClickShow1 c70" onClick={() => setSelectedStep(9)}><img src={`${imageRoot}Picture09.png`} alt="" />Send Resource Request</p></a>
            <hr className="hr9 hrLine" />
            <a data-interception="off" href="#step-10" onClick={(event) => event.preventDefault()}><li className="circle-c10 subCircle onClickShow vf1 c70" onClick={() => setSelectedStep(10)}>10</li><p className="p11 Ctext onClickShow1 c70" onClick={() => setSelectedStep(10)}><img src={`${imageRoot}Picture10.png`} alt="" />Schedule resources</p></a>
            <hr className="hr10 hrLine" />
            <a data-interception="off" href="#step-11" onClick={(event) => event.preventDefault()}><li className="circle-c11 subCircle onClickShow vf1 c70" onClick={() => setSelectedStep(11)}>11</li><p className="p12 Ctext onClickShow1 c70" onClick={() => setSelectedStep(11)}><img src={`${imageRoot}Picture11.png`} alt="" />Charge T&amp;E</p></a>
            <hr className="hr11 hrLine" />
            <a data-interception="off" href="#step-12" onClick={(event) => event.preventDefault()}><li className="circle-c12 subCircle onClickShow vf1 c70" onClick={() => setSelectedStep(12)}>12</li><p className="p13 Ctext onClickShow1 c70" onClick={() => setSelectedStep(12)}><img src={`${imageRoot}Picture12.png`} alt="" />Perform Engagement economics</p></a>
            <hr className="hr12 hrLine" />
            <a data-interception="off" href="#step-13" onClick={(event) => event.preventDefault()}><li className="circle-c13 subCircle onClickShow vf1 c70" onClick={() => setSelectedStep(13)}>13</li><p className="p14 Ctext onClickShow1 c70" onClick={() => setSelectedStep(13)}><img src={`${imageRoot}Picture13.png`} alt="" />Initiate or Perform billing</p></a>
            <hr className="hr13 hrLine" />
            <a data-interception="off" href="#step-14" onClick={(event) => event.preventDefault()}><li className="circle-c14 subCircle onClickShow vf1 c70" onClick={() => setSelectedStep(14)}>14</li><p className="p15 Ctext onClickShow1 c70" onClick={() => setSelectedStep(14)}><img src={`${imageRoot}Picture14.png`} alt="" />Dunning and Collection</p></a>
            <hr className="hr14 hrLine" />
            <a data-interception="off" href="#step-15" onClick={(event) => event.preventDefault()}><li className="circle-c15 subCircle onClickShow vf1 c70" onClick={() => setSelectedStep(15)}>15</li><p className="p16 Ctext onClickShow1 c70" onClick={() => setSelectedStep(15)}><img src={`${imageRoot}Picture15.png`} alt="" />Close Engagement</p></a>
          </ul>

          <div className={`overlayLeft${selectedStep !== null && selectedStep < 8 ? ' active' : ''}`}>
            <div className="close_slide" onClick={() => setSelectedStep(null)}>X</div>
            {renderPanel(0, 'Create or maintain contacts')}
            {renderPanel(1, 'Create Opportunity')}
            {renderPanel(2, 'Create Pricing Plan')}
            {renderPanel(3, 'Perform Acceptance')}
            {renderPanel(4, 'Update pricing plan')}
            {renderPanel(5, 'Statement of Work (SOW) sign off and contract')}
            {renderPanel(6, 'Update opportunity details')}
            {renderPanel(7, 'Create Engagement')}
          </div>

          <div className={`overlayRight${selectedStep !== null && selectedStep >= 8 ? ' active' : ''}`}>
            <div className="close_slide c70" onClick={() => setSelectedStep(null)}>X</div>
            {renderPanel(8, 'Create Engagement Budget')}
            {renderPanel(9, 'Send and schedule resource')}
            {renderPanel(10, 'Send and schedule resource')}
            {renderPanel(11, 'Charge T&E')}
            {renderPanel(12, 'Perform Engagement Economics')}
            {renderPanel(13, 'Initiate or perform billing')}
            {renderPanel(14, 'Collections')}
            {renderPanel(15, 'Close engagement')}
          </div>

          <div className="rows">
            {resources.slice(6, 9).map((resource) => (
              <div className="bx-01" key={resource[0]}>
                <a data-interception="off" href={resource[1]} target="_blank" rel="noreferrer">
                  <div className="cb-box"><p>{resource[0]}</p></div>
                </a>
              </div>
            ))}
          </div>
        </section>

        <section className="mercury">
          <h2>What is Mercury?</h2>
          <p>Mercury is an integrated SAP system, which enables us to become an even better connected and globally integrated organization. Mercury has already been deployed in 148 EY offices, capturing more than 75% of our global revenues.</p>
          <div className="mercury-links">
            <a data-interception="off" href="https://web.microsoftstream.com/embed/video/28ad8a48-6df2-46af-b718-746434a4d2be?autoplay=false&showinfo=true" target="_blank" rel="noreferrer">
              <img src={`${imageRoot}m1.png`} alt="" />
              Mercury Video
            </a>
            <a data-interception="off" href="https://sites.ey.com/sites/MercuryLearningCatalogue/SitePages/TypeProceduralGuides.aspx" target="_blank" rel="noreferrer">
              <img src={`${imageRoot}m2.png`} alt="" />
              Procedural Guides
            </a>
          </div>
        </section>
      </main>

      <footer className="footer"><p>&#169; 2026 EYGM Limited. All rights reserved.</p></footer>
    </div>
  );
};

export default PoliciesAndProcedures;
