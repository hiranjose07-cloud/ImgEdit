import * as React from 'react';

const leadershipStyles = `
html,
body {
    overflow-x: hidden !important;
    font-family: EYInterstate;
}

::-moz-selection {
    color: #ffffff;
    background: #27ACAA;
}

::selection {
    color: #ffffff;
    background: #27ACAA;
}

body::-webkit-scrollbar {
    display: none;
}

body {
    -ms-overflow-style: none;
    scrollbar-width: none;
    position: relative;
}

.bannerBackground {
    background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/banner.jpg);
    background-color: #2e2e38;
    background-size: 115% 115%;
    background-position: center center;
    position: relative;
    background-attachment: fixed;
    animation: shrink 20s infinite alternate;
    padding: 0px;
}

.cf6 {
    color: #ffffff;
    width: 100%;
    font-size: 1.5vw;
    padding: 1vw 1vw;
    margin-bottom: 0;
}

@keyframes shrink {
    0% {
        background-size: 115% 115%;
    }
    100% {
        background-size: 100% 100%;
    }
}

.nav-bar {
    position: relative;
    z-index: 999;
    background: #2e2e38;
    min-height: 6vw;
    width: 100%;
    margin: 0;
}

.nav-container {
    padding: 0px;
}

.EYlogo {
    width: 3vw;
    position: absolute;
    left: 5vw;
    top: 1.5vw;
}

p.logoTxt {
    color: #ffffff;
    font-size: 2vw;
    position: absolute;
    left: 11vw;
    top: 2.2vw;
}

img.home {
    width: 1.3vw;
}

ul.navbarMenu {
    position: absolute;
    right: 6vw;
    top: 2.4vw;
    font-family: EYInterstate;
}

ul.navbarMenu li {
    display: inline-block;
    font-size: 1vw;
    color: #ffffff;
}

ul.navbarMenu li a {
    color: #ffffff;
    text-decoration: none;
    padding: 0vw 2vw;
}

.boxContent span {
    color: #ffe600;
    font-size: 1.2vw;
    margin-right: .3vw;
    font-weight: bold;
}

.cnt-fdr {
    padding: 2vw 5vw 2vw 5vw;
    background: rgba(46, 46, 56, .5);
    bottom: 0;
    width: 100%;
}

.vh3 {
    margin-top: 1.3vw;
}

.boxContent p {
    color: #ffffff;
    font-size: .9vw;
    line-height: 1.3vw;
    font-family: EYInterstate;
    font-weight: lighter;
}

.boxContent p b {
    font-size: 1.2vw;
    line-height: 2.5vw;
}

.boxContent img {
    width: 3vw;
    margin-bottom: .4vw;
}

p.c4 {
    color: #ffffff;
    font-size: 1.1vw;
    font-family: EYInterstate;
    line-height: 1.5vw;
    margin-bottom: 1.3vw;
}

ul.c5 {
    color: #ffffff;
    list-style: none;
    padding: 0;
}

ul.c5 li {
    position: relative;
    padding-left: 1.3vw;
    margin-bottom: 0.6vw;
    font-size: 1vw;
}

ul.c5 li::before {
    content: "";
    background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/arrow_icon.png);
    position: absolute;
    width: .6vw;
    height: .6vw;
    background-size: contain;
    background-repeat: no-repeat;
    top: 0.5vw;
    left: 0;
}

.footerTab {
    background: #1a1a24;
    padding: 5vw;
}

a.qLInk {
    color: #ffffff;
    font-family: EYInterstate;
    font-size: 1vw;
    font-weight: lighter;
    border: .1vw solid #9f9f9f;
    padding: 0.5vw 1.6vw;
    border-radius: .4vw;
    margin-right: .7vw;
    text-decoration: none;
    float: left;
    -webkit-transition: all .2s ease-in-out;
    -moz-transition: all .2s ease-in-out;
    -o-transition: all .2s ease-in-out;
    transition: all .2s ease-in-out;
    margin-bottom: .8vw;
}

a.qLInk:hover {
    background: rgba(255, 255, 255, .2)
}

.quicklinks {
    color: #ffffff;
    font-size: 2vw;
    margin-bottom: 2vw;
}

img.qklinks {
    width: 1.4vw;
    margin-top: -0.2vw;
    margin-right: .4vw;
}

.tabContent {
    background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);
    background-position: center;
    background-size: cover;
    background-attachment: fixed;
    background-color: #2e2e38;
    min-height: 10vw;
}

p.hder {
    color: #ffffff;
    padding-left: 1vw;
    font-size: 1vw;
    line-height: 1.5vw;
    margin-bottom: 1vw;
}

.card_08 {
    margin-left: 4vw !important;
    margin-right: 6.5vw !important;
}

hr.cf7 {
    margin-top: 1rem;
    margin-bottom: 1rem;
    border: 0;
    border-top: .1vw dashed rgb(255 255 255 / 77%);
    width: 20vw;
    position: absolute;
    left: 10vw;
    transform: rotate(90deg);
    top: 8.5vw;
}

.cvg-1 p {
    text-align: left !important;
    padding-left: 20vw !important;
}

.pro-12 {
    padding: 2vw 0vw 2vw 0vw;
    max-width: max-content !important;
}

.pro-13 {
    padding: 3vw 5.1vw;
    position: relative;
    overflow: hidden;
}

.bg_m {
    background: #ffffff0a;
    position: absolute;
    width: 20vw;
    height: 20vw;
    top: 0;
    left: 0;
}

.bg {
    background: rgba(102, 102, 127, .34) !important
}

.profileCard {
    background: rgba(255, 255, 255, .04);
    width: 19.8vw;
    float: left;
    padding: 1vw 1vw;
    border-bottom: .1vw solid #4a4a4a;
    -webkit-transition: all .2s ease-in-out;
    -moz-transition: all .2s ease-in-out;
    -o-transition: all .2s ease-in-out;
    transition: all .2s ease-in-out;
}

.profileCard:hover {
    background: rgba(255, 255, 255, .08);
}

.profileCard.c2 {
    margin: 0vw 1vw;
}

.profileCard.c3 {
    margin-right: 1vw;
}

.cg-6 .pro-13 .profileCard:nth-child(3n) {
    margin: 0;
}

.cg-7 .pro-13 .profileCard:nth-child(3n) {
    margin: 0;
}

.imgCircle {
    background: #2e2e38;
    width: 6vw;
    height: 6vw;
    border-radius: 100vw;
    float: left;
    background-size: cover;
    background-position: center;    margin: 0 auto !important;
}

.pName {
    color: #ffffff;
    font-size: .9vw;
    font-family: EYInterstate;
    margin: 1vw 0vw 0vw 0vw;
}

.pDes {
    color: #ffe600;
    font-size: .8vw;
    font-family: EYInterstate;
    margin: 0vw 0vw 0vw 0vw;
}

.profileDes {
    float: left;
    width: 10vw;
    text-align: left;
    margin-left: 1vw;
    margin-top: 0.7vw;
}

.pro-hd-1 {
    background-color: rgba(26, 26, 36, .37);
}

.pro-hd-1 p {
    margin: 0;
    padding: 1vw 0vw;
    color: #ffffff;
    text-align: center;
    font-family: EYInterstate;
    font-size: 1.2vw;
}

.profileCard.v1 {
    width: 11.9vw;
    float: left;
    margin-right: 1.5vw;
    padding-top: 2vw;
    min-height: 14vw;
    position: relative;
    z-index: 1;
    margin-bottom: 1.5vw !important;
}

.cg-6 {
    border-right: .1vw solid #ffffff17;
}

.cg-6,
.cg-7 {
    padding: 0px;
}

.col-flex {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
}

.imgCircle.v1 {
    float: none;
    width: 5vw;
    height: 5vw;
}

.profileDes.v1 {
    float: none;
    text-align: center;
    margin-left: 0px;
}

.footer {
    background-color: #000000;
    float: left;
    width: 100%;
}

.footer p {
    margin-bottom: 0px;
    color: #ffffff;
    font-size: 1vw;
    padding: 1vw 2vw;
    text-align: right;
}

.navToggle {
    display: none;
}

@media only screen and (max-width: 1200px) {
    .cnt-fdr {
        position: static;
    }
    .cnt-fdr {
        padding: 35px 70px;
    }
    .quicklinks {
        font-size: 30px;
        margin-bottom: 25px;
    }
    a.qLInk {
        font-size: 15px;
        border: 1px solid #9f9f9f;
        padding: 7px 25px;
        border-radius: .4vw;
        margin-bottom: 10px;
        margin-right: 10px;
    }
    .footerTab {
        background: #1a1a24;
        padding: 60px;
    }
    .EYlogo {
        width: 40px;
        left: 60px;
        top: 20px;
    }
    p.logoTxt {
        font-size: 25px;
        left: 130px;
        top: 30px;
    }
    ul.navbarMenu {
        right: 50px;
        top: 25px;
    }
    ul.navbarMenu li {
        font-size: 15px;
    }
    ul.navbarMenu li a {
        padding: 0vw 20px;
    }
    img.home {
        width: 20px;
    }
    .nav-bar {
        min-height: 90px;
    }
    ul.navbarMenu {
        right: 50px;
        top: 31px;
    }
    .footer p {
        margin-bottom: 0px;
        color: #ffffff;
        font-size: 13px;
        padding: 15px 20px;
        text-align: right;
    }
    .cf6 {
        font-size: 30px;
        margin-bottom: 0;
    }
}

@media only screen and (max-width: 1100px) {
    .pName {
        font-size: 14px;
        margin: 10px 0vw 0vw 0vw;
        line-height: 18px;
    }
    .pDes {
        font-size: 12px;
        line-height: 14px;
        margin: 7px 0vw 0vw 0vw;
    }
    .profileCard.v1 {
        width: 25%;
        float: left;
        margin-right: 2%;
        padding-top: 30px;
    }
    .profileDes {
        width: 85%;
    }
    .profileCard.v1 {
        min-height: 175px;
    }
    .imgCircle.v1 {
        width: 70px;
        height: 70px;
    }
    .profileCard.v1.x1 {
        margin-left: 0px;
    }
    .pro-13 {
        padding: 30px 0%;
        margin-left: 10%;
    }
    .profileCard.v1 {
        min-height: 175px;
        margin-bottom: 15px;
    }
    .pro-hd-1 p {
        padding: 15px 0vw;
        font-size: 17px;
    }
    .profileCard {
        min-height: 200px;
        background: rgba(255, 255, 255, .04);
        width: 24%;
        padding: 20px 20px;
    }
    .pro-12 {
        padding: 30px 8%;
    }
    .imgCircle {
        width: 80px;
        height: 80px;
    }
    .profileCard.v1 {
        min-height: 190px;
    }
    .col-sm-3.pro-hd-1 {
        -ms-flex: 0 0 40%;
        flex: 0 0 40%;
        max-width: 40%;
    }
    .col-sm-9.pro-hd-1 {
        -ms-flex: 0 0 60%;
        flex: 0 0 60%;
        max-width: 60%;
    }
    .profileCard.card_08 {
        min-height: 191px !important;
        margin-bottom: 220px !important;
    }
    .bg_m {
        background-color: transparent;
    }
    .cf7 {
        display: none;
    }
    .card_08 {
        margin-left: 0vw !important;
        margin-right: 6.5vw !important;
    }
}

@media only screen and (max-width: 800px) {
    .col-sm-4.c57 {
        -ms-flex: 0 0 100%;
        flex: 0 0 100%;
        max-width: 100%;
    }
    .profileCard {
        min-height: 190px;
    }
    .sm-07 {
        display: block !important;
    }
    .card_08 {
        display: none !important;
    }
    .col-sm-3.pro-hd-1 {
        display: none;
    }
    .col-sm-9.pro-hd-1 {
        -ms-flex: 0 0 100%;
        flex: 0 0 100%;
        max-width: 100%;
    }
}

@media only screen and (max-width: 769px) {
    .footerTab {
        float: left;
    }
    img.qklinks {
        display: none;
    }
    .profileCard.v1 {
        min-height: 225px;
    }
    .profileCard {
        width: 48%;
        margin-bottom: 1vw !important;
    }
}

@media only screen and (max-width: 650px) {
    .profileCard.v1 {
        width: 45%;
    }
    .pro-13 {
        padding: 30px 0%;
        margin-left: 4%;
    }
    .profileCard.card_08 {
        min-height: 190px !important;
        margin-bottom: 15px !important;
    }
}

@media only screen and (max-width: 575px) {
    ul.navbarMenu {
        top: 110px;
    }
    .profileCard.v1 {
        width: 100%;
    }
    .pro-13 {
        padding: 30px 5%;
        margin-left: 0%;
    }
    .profileCard {
        min-height: 150px;
        width: 100%;
        margin-left: 0 !important;
        margin-bottom: 25px !important;
        padding: 20px 20px;
    }
}
`;

interface IMenaTaxLeadershipProps {
  onShowHome: () => void;
}

const MenaTaxLeadership: React.FC<IMenaTaxLeadershipProps> = ({ onShowHome }) => {
  return (
    <>
      <style>{leadershipStyles}</style>

      <div className="container_wrapper">
        <div className="webPart">
          <div className="container-fluid nav-container">
            <div className="row nav-bar">
              <img className="EYlogo" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/EY_logo.png" alt="EY logo" />
              <p className="logoTxt">MENA Tax Hub</p>
              <ul className="navbarMenu">
                <li>
                  <a data-interception="off" href="#" onClick={(event) => { event.preventDefault(); onShowHome(); }}>
                    <img className="home" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home.png" alt="Home" />
                  </a>
                </li>
              </ul>
              <img className="navToggle" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/toggle.png" alt="Toggle" />
            </div>
          </div>

          <div className="container-fluid">
            <div className="row">
              <div className="col-sm-12 bannerBackground">
                <div className="container-fluid cnt-fdr">
                  <div className="row">
                    <p className="cf6">MENA Tax Leadership Structure</p>
                    <div className="col-sm-4 c57"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="container-fluid tabContent">
            <div className="row">
              <div className="container-fluid tabContent">
                <div className="row justify-content-center">
                  <div className="col-sm-12 pro-12" style={{ maxWidth: '600px' }}>
                    <div className="profileCard text-center">
                      <div className="imgCircle" style={{
                        backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Ahmed%20Eldessouky-v2.jpg)',
                        width: '80px',
                        height: '80px',
                        backgroundSize: 'cover',
                        backgroundPosition: 'center',
                        borderRadius: '50%',
                        margin: '0 auto'
                      }} />
                      <div className="profileDes" style={{ marginTop: '12px' }}>
                        <p className="pName">Ahmed Eldessouky</p>
                        <p className="pDes">Tax Leader </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="container-fluid tabContent">
                <div className="row justify-content-center">
                  <div className="col-sm-12 pro-12" style={{ maxWidth: '600px' }}>
                    <div className="profileCard text-center">
                      <div className="imgCircle" style={{
                        backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/asim%20sheikh.jpg)',
                        width: '80px',
                        height: '80px',
                        backgroundSize: 'cover',
                        backgroundPosition: 'center',
                        borderRadius: '50%',
                        margin: '0 auto'
                      }} />
                      <div className="profileDes" style={{ marginTop: '12px' }}>
                        <p className="pName">Asim Sheikh</p>
                        <p className="pDes">Tax COO</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-sm-12 pro-hd-1">
                <p>Sub Service Line & Tax Quality Leaders</p>
              </div>
              <div className="col-sm-12 pro-13">
                <div className="profileCard v1 x1" style={{ textAlign: 'center' }}>
                  <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Ahmed%20Aboelfotouh.jpg)' }} />
                  <div className="profileDes v1">
                    <p className="pName">Ahmed Aboelfotouh</p>
                    <p className="pDes">Global Compliance & Reporting (GCR)</p>
                  </div>
                </div>

                <div className="profileCard v1" style={{ textAlign: 'center' }}>
                  <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Mohammed%20Bilal%20Akram.jpg)' }} />
                  <div className="profileDes v1">
                    <p className="pName">Mohammed Bilal Akram</p>
                    <p className="pDes">Indirect Tax (IDT)</p>
                  </div>
                </div>

                <div className="profileCard v1" style={{ textAlign: 'center' }}>
                  <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Rajan%20Parmar.png)' }} />
                  <div className="profileDes v1">
                    <p className="pName">Rajan Parmar</p>
                    <p className="pDes">International Tax & Transaction Services (ITTS)</p>
                  </div>
                </div>

                <div className="profileCard v1" style={{ textAlign: 'center' }}>
                  <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/n8.png)' }} />
                  <div className="profileDes v1">
                    <p className="pName">Chris P. Sioufi</p>
                    <p className="pDes">Law</p>
                  </div>
                </div>

                <div className="profileCard v1" style={{ textAlign: 'center' }}>
                  <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Xavier%20Delaunay.jpg)' }} />
                  <div className="profileDes v1">
                    <p className="pName">Xavier Delaunay</p>
                    <p className="pDes">People Advisory Services (PAS)</p>
                  </div>
                </div>

                <div className="profileCard v1" style={{ textAlign: 'center' }}>
                  <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Barry%20Magill.jpg)' }} />
                  <div className="profileDes v1">
                    <p className="pName">Barry Magill</p>
                    <p className="pDes">Tax Quality Leader</p>
                  </div>
                </div>
              </div>

              <div className="col-sm-12 pro-hd-1">
                <p>Competency Leaders</p>
              </div>
              <div className="col-sm-12 pro-13">
                <div className="profileCard v1 x1" style={{ textAlign: 'center' }}>
                  <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Aamer%20Bhatti.jpg)' }} />
                  <div className="profileDes v1">
                    <p className="pName">Aamer Bhatti</p>
                    <p className="pDes">E - Invoicing</p>
                  </div>
                </div>

                <div className="profileCard v1" style={{ textAlign: 'center' }}>
                  <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Jeanine%20Daou.jpg)' }} />
                  <div className="profileDes v1">
                    <p className="pName">Jeanine Daou</p>
                    <p className="pDes">Tax Policy</p>
                  </div>
                </div>

                <div className="profileCard v1" style={{ textAlign: 'center' }}>
                  <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Sohail%20Nini.jpg)' }} />
                  <div className="profileDes v1">
                    <p className="pName">Sohail Nini</p>
                    <p className="pDes">Accounting Compliance & Reporting (ACR)</p>
                  </div>
                </div>

                <div className="profileCard v1 x1" style={{ textAlign: 'center' }}>
                  <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Adil%20Rao.jpg)' }} />
                  <div className="profileDes v1">
                    <p className="pName">Adil Rao</p>
                    <p className="pDes">Transfer Pricing</p>
                  </div>
                </div>

                <div className="profileCard v1" style={{ textAlign: 'center' }}>
                  <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Ramy%20Rass.jpg)' }} />
                  <div className="profileDes v1">
                    <p className="pName">Ramy Rass</p>
                    <p className="pDes">Global Trade</p>
                  </div>
                </div>
              </div>

              <div className="col-sm-6 cg-6">
                <div className="col-sm-12 pro-hd-1">
                  <p>MENA Industry Group Leaders</p>
                </div>
                <div className="col-sm-12 pro-13">
                  <div className="profileCard v1 x1" style={{ textAlign: 'center' }}>
                    <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/ahmad.png)' }} />
                    <div className="profileDes v1">
                      <p className="pName">Ahmad Ahmad</p>
                      <p className="pDes">Government & Infrastructure Industry</p>
                    </div>
                  </div>

                  <div className="profileCard v1" style={{ textAlign: 'center' }}>
                    <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Mayur%20Pau.jpg)' }} />
                    <div className="profileDes v1">
                      <p className="pName">Mayur Pau</p>
                      <p className="pDes">Financial Services Industry</p>
                    </div>
                  </div>

                  <div className="profileCard v1" style={{ textAlign: 'center' }}>
                    <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Mobin%20Khan.jpg)' }} />
                    <div className="profileDes v1">
                      <p className="pName">Mobin Khan</p>
                      <p className="pDes">Industrials & Energy Industry</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-sm-6 cg-7">
                <div className="col-sm-12 pro-hd-1">
                  <p>Tax Industry Group Leaders</p>
                </div>
                <div className="col-sm-12 pro-13">
                  <div className="profileCard v1" style={{ textAlign: 'center' }}>
                    <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/ey-stuart-halstead.jpg)' }} />
                    <div className="profileDes v1">
                      <p className="pName">Stuart Halstead</p>
                      <p className="pDes">Government & Infrastructure Industry</p>
                    </div>
                  </div>

                  <div className="profileCard v1 x1" style={{ textAlign: 'center' }}>
                    <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/ey-ahmed-akeel.jpg)' }} />
                    <div className="profileDes v1">
                      <p className="pName">Ahmed Akeel</p>
                      <p className="pDes">Financial Services Industry</p>
                    </div>
                  </div>

                  <div className="profileCard v1" style={{ textAlign: 'center' }}>
                    <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/ey-blake-langridge.jpg)' }} />
                    <div className="profileDes v1">
                      <p className="pName">Blake Langridge</p>
                      <p className="pDes">Industrial & Energy Industry</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-sm-6 cg-6">
                <div className="col-sm-12 pro-hd-1">
                  <p>MENA Growth Accounts Leader</p>
                </div>
                <div className="col-sm-12 pro-13 col-flex">
                  <div className="profileCard v1 x1" style={{ textAlign: 'center' }}>
                    <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Fahad%20Altoaimi.jpg)' }} />
                    <div className="profileDes v1">
                      <p className="pName">Fahad Altoaimi</p>
                      <p className="pDes">Growth Accounts</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-sm-6 cg-7">
                <div className="col-sm-12 pro-hd-1">
                  <p>Tax Growth Accounts Leader</p>
                </div>
                <div className="col-sm-12 pro-13 col-flex">
                  <div className="profileCard v1 x1" style={{ textAlign: 'center' }}>
                    <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Miranda%20Baas.jpg)' }} />
                    <div className="profileDes v1">
                      <p className="pName">Miranda Baas</p>
                      <p className="pDes">Growth Accounts (GA)</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-sm-6 cg-6">
                <div className="col-sm-12 pro-hd-1">
                  <p>MENA Big Bets Leaders</p>
                </div>
                <div className="col-sm-12 pro-13">
                  <div className="profileCard v1 x1 b1" style={{ textAlign: 'center' }}>
                    <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Marco%20Biaggi.jpg)' }} />
                    <div className="profileDes v1">
                      <p className="pName">Marco Biaggi</p>
                      <p className="pDes">MENA AI Leader</p>
                    </div>
                  </div>

                  <div className="profileCard v1 b1" style={{ textAlign: 'center' }}>
                    <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Michael%20Hasbani.jpg)' }} />
                    <div className="profileDes v1">
                      <p className="pName">Michael Hasbani</p>
                      <p className="pDes">MENA Alliances Leader</p>
                    </div>
                  </div>

                  <div className="profileCard v1 b1" style={{ textAlign: 'center' }}>
                    <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Omar%20Odeh.jpg)' }} />
                    <div className="profileDes v1">
                      <p className="pName">Omar Odeh</p>
                      <p className="pDes">MENA Finance Leader</p>
                    </div>
                  </div>

                  <div className="profileCard v1 b1" style={{ textAlign: 'center' }}>
                    <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Bhuvana%20Krishnamoorthy.jpg)' }} />
                    <div className="profileDes v1">
                      <p className="pName">Bhuvana Krishnamoorthy</p>
                      <p className="pDes">MENA Managed Services Leader</p>
                    </div>
                  </div>

                  <div className="profileCard v1 b1" style={{ textAlign: 'center' }}>
                    <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Yasir%20Ahmad.jpg)' }} />
                    <div className="profileDes v1">
                      <p className="pName">Yasir Ahmad</p>
                      <p className="pDes"> MENA Sustainability Leader</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-sm-6 cg-7">
                <div className="col-sm-12 pro-hd-1">
                  <p>Tax Big Bets Leaders</p>
                </div>
                <div className="col-sm-12 pro-13">
                  <div className="profileCard v1 x1 b1" style={{ textAlign: 'center' }}>
                    <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Satish%20Karnam.jpg)' }} />
                    <div className="profileDes v1">
                      <p className="pName">Satish Karnam</p>
                      <p className="pDes">Tax Technology and AI Leader</p>
                    </div>
                  </div>

                  <div className="profileCard v1 b1" style={{ textAlign: 'center' }}>
                    <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/ey-lucy-satiyan.jpg)' }} />
                    <div className="profileDes v1">
                      <p className="pName">Lucy Satiyan</p>
                      <p className="pDes">Tax Alliances Leader</p>
                    </div>
                  </div>

                  <div className="profileCard v1 b1" style={{ textAlign: 'center' }}>
                    <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/ey-sohail-nini.jpg)' }} />
                    <div className="profileDes v1">
                      <p className="pName">Sohail Nini</p>
                      <p className="pDes">Tax Finance Leader</p>
                    </div>
                  </div>

                  <div className="profileCard v1 b1" style={{ textAlign: 'center' }}>
                    <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/ey-annabelle-hosatte.jpg)' }} />
                    <div className="profileDes v1">
                      <p className="pName">Annabelle Hosatte</p>
                      <p className="pDes">Tax Managed Services Leader</p>
                    </div>
                  </div>

                  <div className="profileCard v1 b1" style={{ textAlign: 'center' }}>
                    <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/ey-stefan-majerowski.jpg)' }} />
                    <div className="profileDes v1">
                      <p className="pName">Stefan Majerowski</p>
                      <p className="pDes"> Tax Sustainability Leader</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-sm-12 pro-hd-1">
                <p>MENA GEO Leaders</p>
              </div>
              <div className="col-sm-12 pro-13">
                <div className="profileCard v1 x1 b1" style={{ textAlign: 'center' }}>
                  <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Essa%20Al-Jowder.png)' }} />
                  <div className="profileDes v1">
                    <p className="pName">Essa Al-Jowder</p>
                    <p className="pDes">Gulf Coast will include Kuwait, Qatar, Oman and Bahrain</p>
                  </div>
                </div>

                <div className="profileCard v1 b1" style={{ textAlign: 'center' }}>
                  <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Fahad%20Altoaimi.png)' }} />
                  <div className="profileDes v1">
                    <p className="pName">Fahad Altoaimi</p>
                    <p className="pDes">KSA</p>
                  </div>
                </div>

                <div className="profileCard v1 b1" style={{ textAlign: 'center' }}>
                  <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Raed%20Ahmad.png)' }} />
                  <div className="profileDes v1">
                    <p className="pName">Raed Ahmad</p>
                    <p className="pDes">Levant + will include Iraq, Jordan, Libya, Lebanon, Palestine, Syria and Egypt</p>
                  </div>
                </div>

                <div className="profileCard v1 b1" style={{ textAlign: 'center' }}>
                  <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Anthony%20O%27Sullivan.png)' }} />
                  <div className="profileDes v1">
                    <p className="pName">Anthony O'Sullivan</p>
                    <p className="pDes">UAE + will include UAE and Pakistan</p>
                  </div>
                </div>
              </div>

              <div className="col-sm-12 pro-hd-1">
                <p>MENA TAX Country Leaders</p>
              </div>
              <div className="col-sm-12 pro-13">
                <div className="profileCard v1 x1 b1" style={{ textAlign: 'center' }}>
                  <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Ali_Almahroos.png)' }} />
                  <div className="profileDes v1">
                    <p className="pName">Ali Almahroos</p>
                    <p className="pDes">Bahrain</p>
                  </div>
                </div>

                <div className="profileCard v1 b1" style={{ textAlign: 'center' }}>
                  <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Amit%20Arora.jpg)' }} />
                  <div className="profileDes v1">
                    <p className="pName">Amit Arora</p>
                    <p className="pDes">Kuwait</p>
                  </div>
                </div>

                <div className="profileCard v1 b1" style={{ textAlign: 'center' }}>
                  <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Sana%20Azam.jpg)' }} />
                  <div className="profileDes v1">
                    <p className="pName">Sana Azam</p>
                    <p className="pDes">United Arab Emirates</p>
                  </div>
                </div>

                <div className="profileCard v1 b1" style={{ textAlign: 'center' }}>
                  <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Ahmed%20El%20Sayed.jpg)' }} />
                  <div className="profileDes v1">
                    <p className="pName">Ahmed El Sayed</p>
                    <p className="pDes">Egypt</p>
                  </div>
                </div>

                <div className="profileCard v1 b1" style={{ textAlign: 'center' }}>
                  <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Alkesh%20Joshi.jpg)' }} />
                  <div className="profileDes v1">
                    <p className="pName">Alkesh Joshi</p>
                    <p className="pDes">Oman</p>
                  </div>
                </div>

                <div className="profileCard v1 b1" style={{ textAlign: 'center' }}>
                  <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Kevin_Mcmanus.png)' }} />
                  <div className="profileDes v1">
                    <p className="pName">Kevin McManus</p>
                    <p className="pDes">Qatar</p>
                  </div>
                </div>

                <div className="profileCard v1 b1" style={{ textAlign: 'center' }}>
                  <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Haider%20Patel.jpg)' }} />
                  <div className="profileDes v1">
                    <p className="pName">Haider Patel</p>
                    <p className="pDes">Pakistan</p>
                  </div>
                </div>

                <div className="profileCard v1 b1" style={{ textAlign: 'center' }}>
                  <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Jacob%20Rabie.jpg)' }} />
                  <div className="profileDes v1">
                    <p className="pName">Jacob Rabie</p>
                    <p className="pDes">Levant (Jordan, Iraq, Palestine, Lebanon, Syria) + Libya</p>
                  </div>
                </div>

                <div className="profileCard v1 b1" style={{ textAlign: 'center' }}>
                  <div className="imgCircle v1" style={{ backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/asim%20sheikh.jpg)' }} />
                  <div className="profileDes v1">
                    <p className="pName">Asim Sheikh</p>
                    <p className="pDes">Saudi Arabia</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="footer">
            <p>&#169; 2026 EYGM Limited. All rights reserved.</p>
          </div>
        </div>
      </div>

    </>
  );
};

export default MenaTaxLeadership;
