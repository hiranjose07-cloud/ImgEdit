import * as React from 'react';

const qualityStyles = `
html,
body {
    overflow-x: hidden !important;
    font-family: EYInterstate;
}

::-moz-selection {
    color: #ffffff;
    background: #27ACAA;
}

::selection {
    color: #ffffff;
    background: #27ACAA;
}

body::-webkit-scrollbar {
    display: none;
}

body {
    -ms-overflow-style: none;
    scrollbar-width: none;
    position: relative;
}

form {
    margin: 0px !important;
}
.row{margin:0px !important;}
.bannerBackground {
    background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/banner_2.jpg);
    background-color: #2e2e38;
    background-size: cover;
    background-position: center;
    min-height: 85h;
    position: relative;
    background-attachment: fixed;
}

img.topShade {
    position: absolute;
    top: -17vw;
    left: -10%;
    width: 120%;
}

.EYlogo {
    width: 4vw;
    position: absolute;
    left: 5vw;
    top: 3vw;
}

p.logoTxt {
    color: #ffffff;
    font-size: 2vw;
    position: absolute;
    left: 11vw;
    top: 4.6vw;
}

img.home {
    width: 1.3vw;
}

ul.navbarMenu {
    position: absolute;
    right: 6vw;
    top: 5vw;
    font-family: EYInterstate;
}

ul.navbarMenu li {
    display: inline-block;
    font-size: 1vw;
    color: #ffffff;
}

ul.navbarMenu li a {
    color: #ffffff;
    text-decoration: none;
    padding: 0vw 2vw;
}

img.scrollDown {
    width: 3vw;
    position: absolute;
    left: 50%;
    bottom: 2vw;
    background: rgb(255 255 255 / 17%);
    padding: .7vw .7vw;
    border-radius: 100vw;
    transform: translate(-50%, 0%);
    cursor: pointer;
}

.hd1 {
    color: #ffe600;
    font-size: 3vw;
    width: 50%;
    line-height: 3.4vw;
    font-family: EYinterstate;
}

.hd1 span {
    color: #ffffff;
}

.hd2 {
    color: #ffffff;
    font-size: 1vw;
    width: 51%;
    display: block;
}

.row-2 {
    margin-top: 12vw !important;
    padding-left: 5vw;
}

.boxMenu {
    width: 60vw;
    height: 11vw;
    float: left;
    margin-top: 2vw;
}

.subMenu {
    width: 50%;
    height: 11vw;
    float: left;
    -webkit-transition: all .2s ease-in-out;
    -moz-transition: all .2s ease-in-out;
    -o-transition: all .2s ease-in-out;
    transition: all .2s ease-in-out;
    cursor: pointer;
}

.subMenu:hover {
    background-color: rgba(255, 255, 255, .2)
}

.bx1 {
    padding: 1.5vw;
    width: auto;
    height: auto;
    background-color: rgba(255, 255, 255, .12);
    margin-right: 1vw;
    float: left;
    width: 18vw;
    min-height: 13vw;
    position: relative;
}

.bxinr1 img {
    width: 3vw;
}

.boxInner p {
    color: #ffffff;
    line-height: 1.1vw;
    margin-bottom: 0;
    margin-top: .7vw;
}

.boxInner p.q3 {
    text-align: right;
    font-size: .9vw;
    right: 2vw;
    bottom: 1.5vw;
    position: absolute;
}

.q2 {
    font-size: .9vw;
}

.boxInner p.q1 {
    font-size: 1.2vw;
}

.boxContent span {
    color: #ffe600;
    font-size: 1.5vw;
    margin-right: .3vw;
    font-weight: bold;
}

.boxContent p {
    color: #ffffff;
    font-size: 1.1vw;
    line-height: 1.8vw;
    font-family: EYInterstate;
    font-weight: lighter;
}

.boxContent p b {
    font-size: 1.5vw;
    line-height: 2.5vw;
}

.desc {
    background: #2e2e38;
    padding: 9vw 9vw 6vw 9vw;
    background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);
    background-size: cover;
    background-attachment: fixed;
}

.boxContent img {
    width: 4.4vw;
    margin-bottom: 1.3vw;
}

p.c4 {
    color: #ffffff;
    font-size: 1.2vw;
    font-family: EYInterstate;
    line-height: 1.7vw;
    margin-bottom: 1.5vw;
}

ul.c5 {
    color: #ffffff;
    list-style: none;
    padding: 0;
}

ul.c5 li {
    position: relative;
    padding-left: 1.3vw;
    margin-bottom: 0.6vw;
    font-size: 1vw;
}

ul.c5 li::before {
    content: "";
    background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/arrow_icon.png);
    position: absolute;
    width: .6vw;
    height: .6vw;
    background-size: contain;
    background-repeat: no-repeat;
    top: 0.5vw;
    left: 0;
}

hr.c8 {
    margin-top: 2vw;
    margin-bottom: 3vw;
    border: 0;
    border-top: .01vw solid rgb(116 116 116);
}

.footerTab {
    background: #1a1a24;
    padding: 5vw;
}

a.qLInk {
    color: #ffffff;
    font-family: EYInterstate;
    font-size: 1vw;
    font-weight: lighter;
    border: .1vw solid #9f9f9f;
    padding: 0.5vw 1.6vw;
    border-radius: .4vw;
    margin-right: .7vw;
    text-decoration: none;
    float: left;
    -webkit-transition: all .2s ease-in-out;
    -moz-transition: all .2s ease-in-out;
    -o-transition: all .2s ease-in-out;
    transition: all .2s ease-in-out;
}

a.qLInk:hover {
    background: rgba(255, 255, 255, .2)
}

.quicklinks {
    color: #ffffff;
    font-size: 2vw;
    margin-bottom: 2vw;
}

img.qklinks {
    width: 1.4vw;
    margin-top: -0.2vw;
    margin-right: .4vw;
}

a.minfo {
    color: #000000;
    text-decoration: none;
    background: #ffffff;
    font-size: 1vw;
    font-family: EYinterstate;
    padding: 0.5vw 1vw;
    margin-left: 1.1vw;
    margin-bottom: 1vw;
    display: block;
    float: left;
    cursor: pointer;
}

.footer {
    background-color: #000000;
    float: left;
    width: 100%;
}

.footer p {
    margin-bottom: 0px;
    color: #ffffff;
    font-size: 1vw;
    padding: 1vw 2vw;
    text-align: right;
}

.navToggle {
    display: none;
}

.modal-dialog {
    width: 60%;
    max-width: 60%;
}

iframe {
    border: hidden;
}

.modal-content {
    background: transparent;
}

.blurbSec {
    float: left;
    width: 30vw;
    color: #ffffff;
    font-size: .9vw;
    line-height: 1.3vw;
    margin-top: -11.6vw;
    padding: 2vw 2vw;
    background: rgba(255, 255, 255, 0.078);
    height: 25vw;
}

a.lnk {
    background: #ffe600;
    color: #000000;
    padding: 1vw 1vw;
    margin-left: 60vw;
    margin-top: 1vw;
    margin-bottom: 2vw;
    width: 30vw;
    text-align: center;
    font-size: 1.2vw;
    text-decoration: none;
    -webkit-transition: all .2s ease-in-out;
    -moz-transition: all .2s ease-in-out;
    -o-transition: all .2s ease-in-out;
    transition: all .2s ease-in-out;
}

a.lnk:hover {
    background: #ffffff
}

img.proImg {
    width: 5vw;
    border-radius: 100vw;
    float: left;
    margin-right: 1vw;
}

.tmp2 {
    font-size: 0.9vw;
    text-align: center;
    margin-top: -0.1vw;
    color: #ffffff;
    font-weight: bold;
    margin-bottom: 0.5vw;
}

p.proName {
    color: #ffffff;
    font-size: 1vw;
    margin-bottom: 0vw;
    padding-top: 1.3vw;
}

p.proDes {
    color: #ffe600;
    font-size: .9vw;
    margin-bottom: 0;
    margin-top: -.2vw;
}

.profileDetails {
    float: left;
    width: 100%;
    margin-bottom: 1.2vw;
}

.tabContent {
    background-image: url(../images/bgc.png);
    background-position: center;
    background-size: cover;
    background-attachment: fixed;
    background-color: #2e2e38;
}

.tabCol {
    min-height: 10vw;
    padding: 2vw 6vw;
}

.m-Title {
    color: #ffffff;
    width: 100%;
    font-size: 1.5vw;
    padding: 1vw 1vw;
    margin-bottom: 2vw;
}

.col-sm-12.sm-tm-5 {
    -ms-flex: 0 0 16.6666%;
    flex: 0 0 16.6666%;
    max-width: 16.6666%;
    padding: 0vw 0.4vw;
    padding-bottom: 1.6vw;
}

.cf {
    background: rgb(255 255 255 / 6%);
    min-height: 15vw;
}

.tmImg {
    background: #ffffff;
    width: 5.5vw;
    height: 5.5vw;
    border-radius: 100vw;
    position: relative;
    left: 50%;
    transform: translate(-50%, 0);
    top: 1.5vw;
    overflow: hidden;
}

.tmImg img {
    width: 101%;
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
}

.tmShare {
    float: left;
    position: relative;
    left: 50%;
    transform: translate(-50%, 0%);
}

.Ic0 {
    width: 1.4vw;
    float: left;
}

.Ic2 {
    width: 1.4vw;
    float: left;
    margin-left: 0.8vw;
}

.tmProfile {
    font-size: 0.8vw;
    text-align: center;
    margin-top: -0.1vw;
    margin-bottom: 0.5vw;
    color: #ffffff;
    padding: 0vw 1vw;
    padding-bottom: 1vw;
}

.tmName {
    font-size: 1vw;
    font-family: EYInterstate;
    text-align: center;
    margin-top: 2.5vw;
    margin-bottom: 0;
    color: #ffe600;
}

.faqBtn img,
button.faqBtn img {
    width: 1.5vw;
    margin-left: 0.5vw;
    margin-top: -.2vw;
}

.faqBtn {
  background: transparent;
  border: 0;
  cursor: pointer;
  font: inherit;
  text-align: left;
    background: #ffe600;
    color: #000000;
    font-size: 1vw;
    text-decoration: none;
    outline: none;
    padding: 0.7vw 1vw;
    margin-top: 1vw;
    display: inline-block;
}

.contactIcons {
    text-align: center;
    margin-top: 1vw;
    margin-bottom: 1vw;
}

a.profile_icons img {
    width: 1.6vw;
}

a.profile_icons:nth-child(2) img {
    margin: 0vw 0.5vw;
}

@media only screen and (max-width: 1200px) {
    a.qLInk {
        font-size: 15px;
        border: 1px solid #9f9f9f;
        padding: 7px 25px;
        border-radius: .4vw;
        margin-bottom: 10px;
        margin-right: 10px;
    }

    .footerTab {
        background: #1a1a24;
        padding: 60px;
    }

    .EYlogo {
        width: 40px;
        left: 60px;
        top: 20px;
    }

    p.logoTxt {
        font-size: 25px;
        left: 130px;
        top: 30px;
    }

    ul.navbarMenu {
        right: 50px;
        top: 37px;
    }

    ul.navbarMenu li {
        font-size: 15px;
    }

    ul.navbarMenu li a {
        padding: 0vw 20px;
    }

    img.home {
        width: 20px;
    }

    .nav-bar {
        min-height: 90px;
    }

    .row-2 {
        margin-top: 170px;
        padding-left: 50px;
    }

    .hd1 {
        font-size: 37px;
        width: 50%;
        line-height: 40px;
    }

    .hd2 {
        color: #ffffff;
        font-size: 16px;
        width: 80%;
        display: block;
    }

    .bannerBackground {
        min-height: auto;
    }

    .boxMenu {
        width: 100%;
        height: auto;
        position: static;
        bottom: 0;
        left: 40px;
        margin-bottom: 15px;
    }

    .bxinr1 img {
        width: 40px;
    }

    .boxInner p {
        color: #ffffff;
        line-height: 18px;
        margin-bottom: 0;
        margin-top: 18px;
        font-size: 14px;
    }

    .bx1 {
        padding: 20px;
        margin-right: 10px;
        margin-bottom: 15px;
        width: 31%;
        min-height: 190px;
    }

    .blurbSec {
        width: 95%;
        font-size: 14px;
        line-height: 23px;
        margin-top: -19px;
        padding: 20px 20px;
        height: auto;
    }

    img.proImg {
        width: 80px;
        margin-right: 15px;
    }

    p.proName {
        font-size: 19px;
        margin-bottom: 0vw;
        padding-top: 15px;
    }

    .profileDetails {
        margin-bottom: 20px;
    }

    p.proDes {
        font-size: 16px;
        margin-bottom: 0;
        margin-top: 0px;
    }

    .quicklinks {
        font-size: 30px;
        margin-bottom: 25px;
    }

    .qklinks {
        display: none;
    }

    .footer p {
        margin-bottom: 0px;
        color: #ffffff;
        font-size: 13px;
        padding: 15px 20px;
        text-align: right;
    }

    .boxInner p.q1 {
        font-size: 17px;
    }

    .boxInner p.q3 {
        text-align: right;
        font-size: 11px;
    }

    a.lnk {
        padding: 10px 20px;
        margin-top: 1vw;
        font-size: 14px;
        width: auto;
        min-width: 35vw;
        float: right;
        margin-left: auto;
        margin-right: 5%;
    }

    .m-Title {
        font-size: 17px;
        padding: 8px 7px;
        margin-bottom: 10px;
    }

    .tmImg {
        width: 50px;
        height: 50px;
        border-radius: 100vw;
        top: 10px;
    }

    .tmName {
        font-size: 12px;
        margin-top: 14px;
    }

    .tmp2 {
        font-size: 11px;
        margin-top: -1px;
        margin-bottom: 6px;
    }

    .tmProfile {
        font-size: 11px;
        margin-top: 0px;
        margin-bottom: 10px;
        padding: 0vw 10px;
        padding-bottom: 10px;
    }

    .col-sm-12.sm-tm-5 {
        -ms-flex: 0 0 16.6666%;
        flex: 0 0 33.333%;
        max-width: 33.333%;
        padding: 5px 5px;
        padding-bottom: 5px;
    }

    .cf {
        height: 100%;
    }
}

@media only screen and (max-width: 992px) {
    .boxMenu {
        width: 100%;
    }
}

@media only screen and (max-width: 768px) {
    .boxInner p.q3 {
        position: static;
    }

    .bx1 {
        min-height: 140px;
        width: 93%;
    }

    .blurbSec {
        width: 93%;
    }

    a.lnk {
        margin-right: 7%;
    }
}

@media only screen and (max-width: 750px) {
    .bx1 {
        min-height: 210px;
    }
}

@media only screen and (max-width: 650px) {
    ul.navbarMenu {
        top: 90px;
    }

    .modal-dialog {
        width: 100%;
        max-width: 95% !important;
    }
}

@media only screen and (max-width: 575px) {
    .bx1 {
        min-height: auto;
    }

    .col-sm-12.sm-tm-5 {
        -ms-flex: 0 0 50%;
        flex: 0 0 50%;
        max-width: 50%;
        padding: 5px 5px;
        padding-bottom: 5px;
    }

    a.lnk {
        width: 100%;
    }
}
`;

interface IMenaTaxQualityProps {
  onShowHome: () => void;
  onShowFAQs: () => void;
}

const MenaTaxQuality: React.FC<IMenaTaxQualityProps> = ({ onShowHome, onShowFAQs }) => {
  React.useEffect(() => {
    const $ = (window as any).jQuery;
    if (!$) {
      return;
    }

    $(document).ready(() => {
      $('.subCircle').hover(
        function () {
          $('.overlayRight').removeClass('active');
          $('.overlayLeft').addClass('active');
        }
      );

      $('.subCircle.c70').hover(
        function () {
          $('.overlayLeft').removeClass('active');
          $('.overlayRight').addClass('active');
        }
      );

      $('.onClickShow').hover(
        function (this: HTMLElement) {
          $('.inside').removeClass('active');
          const target = $(this).attr('target') || '';
          $('.ins' + target).addClass('active');
        }
      );

      $('.close_slide').click(
        function () {
          $('.overlayLeft, .overlayRight').removeClass('active');
        }
      );

      $('.scrollDown').click(function () {
        $('html, body').animate({
          scrollTop: $('.webAnimation').offset().top
        }, 2000);
      });

      $('#newsModal').on('hidden.bs.modal', function () {
        $('#newsModal iframe').attr('src', $('#newsModal iframe').attr('src'));
      });
    });
  }, []);

  return (
    <>
      <style>{qualityStyles}</style>

      <div className="container_wrapper">
        <div className="webPart">
          <div className="container-fluid bannerBackground">
            
            <div className="row">
              <img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/EY_logo.png" className="EYlogo" alt="EY logo" />
              <p className="logoTxt">MENA Tax Hub</p>
              <ul className="navbarMenu">
                <li>
                  <a data-interception="off" href="#" onClick={(event) => { event.preventDefault(); onShowHome(); }}><img className="home" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home.png" alt="Home" /></a>
                  <span>|</span>
                </li>
                <li>
                  <a data-interception="off" href="#engagement">Engagement Lifecycle</a>
                </li>
              </ul>
              <img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/toggle.png" className="navToggle" alt="Toggle" />
            </div>

            <div className="row row-2">
              <p className="hd1">Tax Quality</p>
              <p className="hd2">
                Tax Quality's goal is to improve your ability to serve clients and achieve success in the marketplace by supporting all Tax Service Line professionals with practical advice on quality and risk management.
              </p>

              <div className="boxMenu">
                <a data-interception="off" href="https://sites.ey.com/sites/MENATaxQualityKnowledge/SitePages/MENA_Tax_Quality.aspx" target="_blank" rel="noreferrer">
                  <div className="bx1 subMenu">
                    <div className="boxInner bxinr1">
                      <p className="q1">MENA Tax Quality</p>
                      <p className="q2">Provide insights on MENA TQ, Global policy documents, current news trends and many more.</p>
                      <p className="q3">READ MORE</p>
                    </div>
                  </div>
                </a>

                <a data-interception="off" href="#eyi">
                  <div className="bx1 subMenu">
                    <div className="boxInner bxinr1">
                      <p className="q1">EYI Documentation</p>
                      <p className="q2">EYI MyDocs is the client engagement filing and document management system for Tax.</p>
                      <p className="q3">READ MORE</p>
                    </div>
                  </div>
                </a>

                <a data-interception="off" href="https://portalone.ey.net/app/home?i=mena" target="_blank" rel="noreferrer">
                  <div className="bx1 subMenu">
                    <div className="boxInner bxinr1">
                      <p className="q1">Knowledge Database</p>
                      <p className="q2">Provides information such as relevant tax laws, regulations, policies including guides, tax alerts and other thought leadership materials.</p>
                      <p className="q3">READ MORE</p>
                    </div>
                  </div>
                </a>

                <button type="button" className="faqBtn" onClick={onShowFAQs}>
                  MENA Tax Quality FAQs <img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/faq.png?csf=1&web=1&e=ET46ax" alt="FAQ" />
                </button>
              </div>

              <div className="blurbSec">
                <div className="profileDetails">
                  <img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Barry%20Magill.jpg" className="proImg" alt="Barry Magill" />
                  <p className="proName">Barry Magill</p>
                  <p className="proDes">MENA Tax Quality Leader</p>
                </div>
                <p className="blurbTxt">
                  Barry, based in Abu Dhabi, is the MENA Tax Quality Leader and also leads EY's M&A Tax practice for the MENA region. He has over 17 years of experience across the UK, MENA and APAC regions, having worked in Saudi Arabia, the UAE and China. Barry specializes in transactions and international tax advisory, focusing on complex transactions and capital markets. He holds an LL.B from Queens University, Belfast, and is a member of the Institute of Chartered Accountants Ireland.
                </p>
              </div>
              <a data-interception="off" className="lnk" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/MENA%20Tax%20Quality%20and%20Knowledge%20FY23%20Q1%20newsletter.pdf" target="_blank" rel="noreferrer">
                Consultation and escalation approval process
              </a>
            </div>
          </div>

          <div className="container-fluid tabContent">
            <div className="row tabCol">
              <p className="m-Title">MENA Tax Quality team</p>

              <div className="col-sm-12 sm-tm-5">
                <div className="cf">
                  <div className="TmBox">
                    <div className="tmImg"><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Elis_Ademova.jpg" alt="Elis Rallien" style={{ width: '100% !important' }} /></div>
                    <p className="tmName">Elis Rallien</p>
                    <p className="tmp2">Director</p>
                    <div className="contactIcons">
                      <a data-interception="off" href="mailto:elis.rallien@qa.ey.com" target="_blank" className="profile_icons" rel="noreferrer"><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/mail-icon01.png" alt="mail" /></a>
                      <a data-interception="off" href="tel:+971563811888" target="_blank" className="profile_icons" rel="noreferrer"><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/call-icon01.png" alt="call" /></a>
                      <a data-interception="off" href="https://people.ey.com/PersonImmersive.aspx?accountname=i:0%23.f%7cmembership%7celis.ademova@uk.ey.com" target="_blank" className="profile_icons" rel="noreferrer"><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/profile-icon01.png" alt="profile" /></a>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-sm-12 sm-tm-5">
                <div className="cf">
                  <div className="TmBox">
                    <div className="tmImg"><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Keshnee.png" alt="Keshnee Pillay" /></div>
                    <p className="tmName">Keshnee Pillay</p>
                    <p className="tmp2">Senior Manager</p>
                    <div className="contactIcons">
                      <a data-interception="off" href="mailto:keshnee.pillay@ae.ey.com" target="_blank" className="profile_icons" rel="noreferrer"><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/mail-icon01.png" alt="mail" /></a>
                      <a data-interception="off" href="tel:+97147010568" target="_blank" className="profile_icons" rel="noreferrer"><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/call-icon01.png" alt="call" /></a>
                      <a data-interception="off" href="https://people.ey.com/PersonImmersive.aspx?accountname=i:0%23.f%7cmembership%7ckeshnee.pillay@ae.ey.com" target="_blank" className="profile_icons" rel="noreferrer"><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/profile-icon01.png" alt="profile" /></a>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-sm-12 sm-tm-5">
                <div className="cf">
                  <div className="TmBox">
                    <div className="tmImg"><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Sarah%20N%20Hussein.jpg" alt="Sarah Hussein" /></div>
                    <p className="tmName">Sarah Hussein</p>
                    <p className="tmp2">Senior Manager</p>
                    <div className="contactIcons">
                      <a data-interception="off" href="mailto:sarah.hussein@iq.ey.com" target="_blank" className="profile_icons" rel="noreferrer"><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/mail-icon01.png" alt="mail" /></a>
                      <a data-interception="off" href="tel:+9647835415011" target="_blank" className="profile_icons" rel="noreferrer"><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/call-icon01.png" alt="call" /></a>
                      <a data-interception="off" href="https://people.ey.com/PersonImmersive.aspx?accountname=i:0%23.f%7cmembership%7csarah.hussein@iq.ey.com" target="_blank" className="profile_icons" rel="noreferrer"><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/profile-icon01.png" alt="profile" /></a>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-sm-12 sm-tm-5">
                <div className="cf">
                  <div className="TmBox">
                    <div className="tmImg"><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Amisha%20Khambhaita2.jpg" alt="Amisha Khambhaita" /></div>
                    <p className="tmName">Amisha Khambhaita</p>
                    <p className="tmp2">Senior Manager</p>
                    <div className="contactIcons">
                      <a data-interception="off" href="mailto:amisha.khambhaita@ae.ey.com" target="_blank" className="profile_icons" rel="noreferrer"><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/mail-icon01.png" alt="mail" /></a>
                      <a data-interception="off" href="tel:+97147010703" target="_blank" className="profile_icons" rel="noreferrer"><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/call-icon01.png" alt="call" /></a>
                      <a data-interception="off" href="https://people.ey.com/PersonImmersive.aspx?accountname=i:0%23.f%7cmembership%7camisha.khambhaita@ae.ey.com" target="_blank" className="profile_icons" rel="noreferrer"><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/profile-icon01.png" alt="profile" /></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="container-fluid footerTab" hidden>
            <div className="row">
              <div className="col-sm-12">
                <p className="quicklinks">Quick links</p>
                <a data-interception="off" href="https://mercury.ey.net/Pages/default.aspx" className="qLInk" target="_blank" rel="noreferrer"><img className="qklinks" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png" alt="Mercury OneGate" />Mercury OneGate</a>
                <a data-interception="off" href="https://mybusiness.ey.net/" className="qLInk" target="_blank" rel="noreferrer"><img className="qklinks" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png" alt="Engagement metrics" />Engagement metrics</a>
                <a data-interception="off" href="http://www.mybusiness.ey.net/myportal/reporttree.aspx" className="qLInk" target="_blank" rel="noreferrer"><img className="qklinks" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png" alt="Time utilization report" />Time utilization report</a>
                <a data-interception="off" href="https://www.mdm.ey.net/bp/search/" className="qLInk" target="_blank" rel="noreferrer"><img className="qklinks" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png" alt="MDM" />MDM</a>
                <a data-interception="off" href="https://sort.ey.net/" className="qLInk" target="_blank" rel="noreferrer"><img className="qklinks" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png" alt="SORT" />SORT</a>
                <a data-interception="off" href="https://gis.ey.net/home/dashboard/search" className="qLInk" target="_blank" rel="noreferrer"><img className="qklinks" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png" alt="GIS" />GIS</a>
                <a data-interception="off" href="https://sites.ey.com/sites/GlobalMercurySupport/SitePages/MercuryHome.aspx" className="qLInk" target="_blank" rel="noreferrer"><img className="qklinks" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png" alt="Global Mercury" />Global Mercury</a>
              </div>
            </div>
          </div>

          <div className="footer">
            <p>&#169; 2026 EYGM Limited. All rights reserved.</p>
          </div>
        </div>
      </div>

      <div className="modal fade show" id="newsModal" tabIndex={-1} role="dialog" aria-modal="true">
        <div className="modal-dialog modal-dialog-centered carousel-dialog" role="document">
          <div className="modal-content" ng-repeat="abc in selectedvalues">
            <div className="modal-body carousel-body" style={{ textAlign: 'center' }}>
              <button type="button" className="close carousel-close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">x</span>
              </button>
              <div className="Hdimgz">
                <iframe width="100%" height="500" src="https://web.microsoftstream.com/embed/video/28ad8a48-6df2-46af-b718-746434a4d2be?autoplay=false&showinfo=true" allowFullScreen title="stream video" />
              </div>
              <div className="modalBody" />
            </div>
          </div>
        </div>
      </div>

    </>
  );
};

export default MenaTaxQuality;
