import * as React from 'react';

const imageRoot = 'https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/';

const trainingStyles = `
html,body{overflow-x:hidden!important;font-family:EYInterstate}.my-training{background:#2e2e38;color:#fff;min-height:100vh}.my-training .loading-container{align-items:center;background:#1a1a24;display:flex;inset:0;justify-content:center;position:fixed;z-index:9999}.my-training .loading-container .item{border:.2vw solid #ffe600;border-bottom-color:transparent;border-radius:50%;border-top-color:transparent;position:absolute;animation:training-spin 2s ease infinite}.my-training .loading-container .item:nth-child(1){height:30px;width:30px}.my-training .loading-container .item:nth-child(2){animation-delay:.1s;height:50px;width:50px}.my-training .loading-container .item:nth-child(3){animation-delay:.2s;height:70px;width:70px}.my-training .loading-container .item:nth-child(4){animation-delay:.3s;height:90px;width:90px}@keyframes training-spin{50%{transform:rotate(180deg)}100%{transform:rotate(0)}}.my-training .nav-bar{background:#2e2e38;min-height:6vw;position:relative}.my-training .EYlogo{left:5vw;position:absolute;top:1.5vw;width:3vw}.my-training .logoTxt{color:#fff;font-size:2vw;left:11vw;position:absolute;top:2.2vw}.my-training .navbarMenu{list-style:none;margin:0;padding:0;position:absolute;right:6vw;top:2.4vw}.my-training .navbarMenu li{display:inline-block;font-size:1vw}.my-training .navbarMenu a{color:#fff;padding:0 2vw;text-decoration:none}.my-training .home{width:1.3vw}.my-training .bannerBackground{background:#2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/banner.jpg') center/cover;min-height:auto}.my-training .cnt-fdr{background:rgba(46,46,56,.5);min-height:auto;padding:2vw 3.5vw}.my-training .cf6{color:#fff;font-size:1.5vw;margin:0 0 1vw}.my-training .hder{color:#fff;font-size:1vw;line-height:1.5vw;margin:0 0 1vw}.my-training .ul-s4{font-size:1vw;line-height:1.3vw;list-style:none;margin:0 0 1.5vw;padding:0;width:100%}.my-training .ul-s4 li{margin-bottom:.6vw;padding-left:1.3vw;position:relative}.my-training .ul-s4 li:before{background:url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/arrow_icon.png') center/contain no-repeat;content:'';height:.6vw;left:0;position:absolute;top:.4vw;width:.6vw}.my-training .htr{width:100%}.my-training .cf7{background:#ffe600;color:#000;cursor:pointer;font-size:1vw;margin:0 0 1vw;padding:1vw;text-align:center;width:20vw}.my-training .c09{display:flex;flex-wrap:wrap;gap:1vw}.my-training .boxTag{color:#fff;text-decoration:none}.my-training .box_page{background:rgba(255,255,255,.09);height:10vw;padding:1.5vw 2vw;text-align:center;transition:background .2s;width:15vw}.my-training .box_page:hover{background:rgba(255,255,255,.2)}.my-training .iconBox{width:3vw}.my-training .txtBox{font-size:1vw;line-height:1.3vw;margin:1vw 0 0;width:10vw}.my-training .main-Content{background:#2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center/cover;padding:2vw 5vw 4vw}.my-training .cnt_header{color:#fff;font-size:1.5vw;margin:1vw 0}.my-training .table{color:#fff;font-size:.9vw;line-height:1.3vw;margin:2vw 0;width:100%}.my-training .table th{background:#1f2027;color:#ffe600;font-size:1.1vw;padding:1vw 1.5vw;border: 1px solid #474747;}.my-training .table td{border:1px solid #474747;padding:.7vw 1.5vw}.my-training .table tbody tr:nth-child(even){background:#1f2027}.my-training .table .mandatory{color:#27acaa}.my-training .cv7{background:rgba(255,255,255,.07);float:left;margin-bottom:1vw;padding:1vw;width:100%}.my-training .vb1,.my-training .vb2{float:right;font-size:.9vw;margin:0 0 0 1vw;padding-left:2vw;position:relative}.my-training .vb1:before,.my-training .vb2:before{content:'';height:1.3vw;left:0;position:absolute;top:0;width:1.3vw}.my-training .vb1:before{background:#27acaa}.my-training .vb2:before{background:#fff}.my-training .hder a{color:#ffe600;text-decoration:none}.my-training .footer{background:#000;float:left;width:100%}.my-training .footer p{font-size:1vw;margin:0;padding:1vw 2vw;text-align:right}
@media(max-width:1200px){.my-training .EYlogo{left:60px;top:20px;width:40px}.my-training .logoTxt{font-size:25px;left:130px;top:30px}.my-training .navbarMenu{right:50px;top:31px}.my-training .home{width:20px}.my-training .nav-bar{min-height:90px}.my-training .cf6{font-size:23px}.my-training .hder{font-size:16px;line-height:23px}.my-training .ul-s4{font-size:14px;line-height:21px;padding:0 25px}.my-training .cnt-fdr{padding:35px 70px}.my-training .main-Content{padding:60px 70px}.my-training .cnt_header{font-size:23px}.my-training .table th{font-size:15px}.my-training .table td{font-size:13px}.my-training .box_page{height:130px;padding:25px 20px;width:160px}.my-training .iconBox{width:35px}.my-training .txtBox{font-size:14px;line-height:16px;width:95%}.my-training .footer p{font-size:13px;padding:15px 20px}}
+@media(max-width:850px){.my-training .c09{gap:10px}.my-training .boxTag{width:48%}.my-training .box_page{width:100%}}
+@media(max-width:750px){.my-training .table thead{display:none}.my-training .table,.my-training .table tbody,.my-training .table tr,.my-training .table td{display:block}.my-training .table tr{margin-bottom:15px}.my-training .table td{border:1px solid #646464!important;padding:36px 20px 12px;position:relative;text-align:left}.my-training .table td:before{color:#ffe600;content:attr(data-label);font-size:12px;left:20px;position:absolute;text-transform:uppercase;top:12px}.my-training .vb1,.my-training .vb2{font-size:13px}}
+@media(max-width:575px){.my-training .logoTxt{font-size:20px;left:115px}.my-training .EYlogo{left:30px}.my-training .navbarMenu{top:110px}.my-training .cnt-fdr{padding:35px 30px}.my-training .cf7{width:100%}.my-training .boxTag{width:100%}.my-training .main-Content{padding:50px 40px}.my-training .hder{font-size:14px;line-height:21px}.my-training .cnt_header{font-size:23px}.my-training .vb1,.my-training .vb2{float:none;display:inline-block}}
`;

interface IMyTrainingProps { onShowHome: () => void; onShowTrainingPack?: () => void; onShowRecordedSession?: () => void; onShowVirtualClinics?: () => void; }

const MyTraining: React.FC<IMyTrainingProps> = ({ onShowHome, onShowTrainingPack, onShowRecordedSession, onShowVirtualClinics }) => {
  const [isLoading, setIsLoading] = React.useState<boolean>(true);
  const [showMaterials, setShowMaterials] = React.useState<boolean>(false);

  React.useEffect(() => {
    const timer = window.setTimeout(() => setIsLoading(false), 2000);
    return () => window.clearTimeout(timer);
  }, []);

  return (
    <div className="my-training">
      <style>{trainingStyles}</style>
      {isLoading && <div className="loading-container" aria-label="Loading"><div className="item" /><div className="item" /><div className="item" /><div className="item" /></div>}
      <div className="webPart">
        <div className="container-fluid nav-container">
          <div className="row nav-bar">
            <img className="EYlogo" src={`${imageRoot}EY_logo.png`} alt="EY logo" />
            <p className="logoTxt">MENA Tax Hub</p>
            <ul className="navbarMenu"><li><a data-interception="off" href="#home" onClick={(event) => { event.preventDefault(); onShowHome(); }}><img className="home" src={`${imageRoot}home.png`} alt="Home" /></a></li></ul>
          </div>
        </div>
        <div className="container-fluid">
          <div className="row">
            <div className="col-sm-12 bannerBackground">
              <div className="container-fluid cnt-fdr">
                <p className="cf6">My Training</p>
                <p className="hder">Engagement Lifecycle Management is critical to our business, hence it is important that you fully understand Mercury concepts. To help you make the most of Mercury&apos;s capabilities, there is an array of training resources available, including:</p>
                <ul className="ul-s4"><li><b>Web Based Learnings (WBL)</b>: A series of conceptual WBLs are available. No matter your role or function, the WBLs are the best place to get started.</li><li><b>Instructor led trainings</b>: Additionally, there are a number of trainings available if you need to be an expert in a certain area.</li></ul>
                <div className="htr"><p className="cf7" onClick={() => setShowMaterials((visible) => !visible)}>Instructor led training materials</p></div>
                {showMaterials && <div className="c09">
                  <a data-interception="off" className="boxTag" href="#training-pack" onClick={(event) => { event.preventDefault(); onShowTrainingPack?.(); }}><div className="box_page"><img src={`${imageRoot}docIcon.png`} className="iconBox" alt="" /><p className="txtBox">Training pack and documents</p></div></a>
                  <a data-interception="off" className="boxTag" href="#training-recorded" onClick={(event) => { event.preventDefault(); onShowRecordedSession?.(); }}><div className="box_page"><img src={`${imageRoot}videoIcon.png`} className="iconBox" alt="" /><p className="txtBox">Training recorded sessions</p></div></a>
                  <a data-interception="off" className="boxTag" href="#virtual-clinics" onClick={(event) => { event.preventDefault(); onShowVirtualClinics?.(); }}><div className="box_page"><img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/iconvideo.png" className="iconBox" alt="" /><p className="txtBox">Virtual clinics training sessions</p></div></a>
                  <a data-interception="off" className="boxTag" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/FAQs%20%20ELM%20%20Introduction%20to%20Mercury%20and%20Engagement%20economics_Rev%2001.pdf" target="_blank" rel="noreferrer"><div className="box_page"><img src={`${imageRoot}faqIcon.png`} className="iconBox" alt="" /><p className="txtBox">FAQs</p></div></a>
                </div>}
              </div>
            </div>
          </div>
        </div>
        <div className="main-Content">
          <p className="cnt_header">Web Based Learnings (WBL)</p>
          <p className="hder">Below mentioned WBLs are mandatory for all new joiners in MENA Tax SSLs (i.e. Staff to PPED).<br /><br />Learnings must be completed within 90 days from the date of assignment.</p>
          <table className="table table-bordered tx_7"><thead><tr><th>Description</th><th>SuccessFactors Course Code</th></tr></thead><tbody>
            <tr><td data-label="Description">The Essentials of Time</td><td data-label="SuccessFactors Course Code">GLOBALALLHRC6061526</td></tr>
            <tr><td className="mandatory" data-label="Description">Opportunity Management and Pricing - Detailed Knowledge Check</td><td className="mandatory" data-label="SuccessFactors Course Code">GLOBALALLHRC4210972</td></tr>
            <tr><td data-label="Description">Creating a pricing plan</td><td data-label="SuccessFactors Course Code">GLOBALALLHRC5834126</td></tr>
            <tr><td data-label="Description">Mercury ETC - Getting Started and Scenarios</td><td data-label="SuccessFactors Course Code">GLOBALALLHRC7889055</td></tr>
            <tr><td className="mandatory" data-label="Description">Advanced Mercury Economics - Detailed</td><td className="mandatory" data-label="SuccessFactors Course Code">GLOBALCBSHRC4691515</td></tr>
          </tbody></table>
          <div className="cv7"><p className="vb1">Optional trainings</p><p className="vb2">Mandatory trainings</p></div>
          <p className="hder">For existing personnel, use the table above to access courses in <a data-interception="off" href="http://sf.ey.net/" target="_blank" rel="noreferrer">SuccessFactors</a> by entering the course code in the Find Learning search field.</p>
          <p className="cnt_header">Instructor Led Trainings</p>
          <p className="hder">Multiple sessions led jointly by MBAs and PFA ensure practical in-system walk-throughs, case studies, FAQ, best practices and Q&amp;A.</p>
          <p className="hder">Virtual sessions in the year 2024:</p>
          <table className="table table-bordered ty_7"><thead><tr><th>Training sessions</th><th>Instructors</th><th>Tentative Date</th></tr></thead><tbody>
            <tr><td data-label="Training sessions">Opportunity &amp; Pricing Plan</td><td data-label="Instructors">Juli Ceasar; Shalini George</td><td data-label="Tentative Date">19-Nov-24</td></tr>
            <tr><td data-label="Training sessions">Engagement Budget and Release (Lean &amp; Standard Path)</td><td data-label="Instructors">Rand Zarour; Juli Ceasar</td><td data-label="Tentative Date">20-Nov-24</td></tr>
            <tr><td data-label="Training sessions">Estimate to Complete</td><td data-label="Instructors">Rand Zarour; Shalini George</td><td data-label="Tentative Date">21-Nov-24</td></tr>
            <tr><td data-label="Training sessions">Billing process</td><td data-label="Instructors">Juli Ceasar; Shalini George</td><td data-label="Tentative Date">26-Nov-24</td></tr>
            <tr><td data-label="Training sessions">Engagement Economics</td><td data-label="Instructors">Rand Zarour; Shalini George</td><td data-label="Tentative Date">27-Nov-24</td></tr>
          </tbody></table>
          <p className="hder">If you wish to register for these trainings please contact <a data-interception="off" href="mailto:ghazanfar.iqbal@sa.ey.com">Ghazanfar Iqbal</a>.</p>
          <p className="hder">Please click on <a data-interception="off" className="topClass" style={{ cursor: 'pointer'}}>“Instructor led training materials”</a> to find the training materials and recordings for each session type.</p>

        
          
        </div>
        <div className="footer"><p>&#169; 2026 EYGM Limited. All rights reserved.</p></div>
      </div>
    </div>
  );
};

export default MyTraining;
