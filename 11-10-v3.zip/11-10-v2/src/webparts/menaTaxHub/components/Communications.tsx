import * as React from 'react';

const communicationsStyles = `
html, body { overflow-x: hidden !important; font-family: EYInterstate; }
.communications-page { background: #2e2e38; color: #ffffff; font-family: EYInterstate, Arial, sans-serif; overflow: hidden; }
.communications-page .loading-container { align-items: center; background: #1a1a24; display: flex; inset: 0; justify-content: center; position: fixed; z-index: 9999; }
.communications-page .loading-container .item { border: .2vw solid #ffe600; border-bottom-color: transparent; border-radius: 50%; border-top-color: transparent; height: 30px; position: absolute; width: 30px; animation: communicationsSpin 2s ease infinite; }
.communications-page .loading-container .item:nth-child(2) { height: 50px; width: 50px; animation-delay: .1s; }
.communications-page .loading-container .item:nth-child(3) { height: 70px; width: 70px; animation-delay: .2s; }
.communications-page .loading-container .item:nth-child(4) { height: 90px; width: 90px; animation-delay: .3s; }
@keyframes communicationsSpin { 50% { transform: rotate(180deg); } 100% { transform: rotate(0deg); } }
.communications-page .container-wrapper { display: block; }
.communications-page .nav-bar { background: #2e2e38; min-height: 6vw; position: relative; }
.communications-page .nav-container { padding: 0; }
.communications-page .EYlogo { left: 5vw; position: absolute; top: 1.5vw; width: 3vw; }
.communications-page .logoTxt { color: #ffffff; font-size: 2vw; left: 11vw; margin: 0; position: absolute; top: 2.2vw; }
.communications-page .navbarMenu { list-style: none; margin: 0; padding: 0; position: absolute; right: 6vw; top: 2.4vw; }
.communications-page .navbarMenu li { display: inline-block; font-size: 1vw; }
.communications-page .navbarMenu a { color: #ffffff; padding: 0 2vw; text-decoration: none; }
.communications-page .navbarMenu img { width: 1.3vw; }
.communications-page .bannerBackground { background: #2e2e38 url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/banner.jpg);
    animation: communicationsShrink 20s infinite alternate;
    padding: 0;
    background-size: cover !important;
    background-position: 0% 21%;}
.communications-page .cnt-fdr { background: rgba(46, 46, 56, .5); padding: 2vw 5vw; width: 100%; }
.communications-page .cf6 { color: #ffffff; font-size: 1.5vw; margin: 0; padding: 1vw; width: 100%; }
@keyframes communicationsShrink { 0% { background-size: 115% 115%; } 100% { background-size: 100% 100%; } }
.communications-page .tabContent { background: #2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center / cover; min-height: 31vw; padding: 4vw 7vw; }
.communications-page .col-sm-bx { padding:0px 10px; align-items: center; background: #ffffff0f url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') left / contain; box-shadow: 0 0 1.5vw rgba(0, 0, 0, .44); display: flex; min-height: 4vw; position: relative; width: 100%; }
.communications-page .img-bx { background-position: left; background-size: 50%; min-height: 2vw; transition: all .2s ease-in-out; width: 30px;     width: 30px;
    background-size: cover !important;
    background-position: center !important;}
.communications-page .col-sm-bx:hover .img-bx { background-size: 50%; }
.communications-page .communications-list { list-style: none; margin: 0; padding: 0; width: 100%; }
.communications-page .communications-list li { margin-bottom: .7vw; }
.communications-page .col-sm-bx a { color: #ffffff; margin-right: 10px; }
.communications-page .col-sm-bx a.pName { color: #ffe600; font-size: 9px; }
.communications-page .footer { background: #000000; float: left; width: 100%; }
.communications-page .footer p { color: #ffffff; font-size: 1vw; margin: 0; padding: 1vw 2vw; text-align: right; }
@media only screen and (max-width: 1200px) {
  .communications-page .cnt-fdr { padding: 35px 70px; }
  .communications-page .EYlogo { left: 60px; top: 20px; width: 40px; }
  .communications-page .logoTxt { font-size: 25px; left: 130px; top: 30px; }
  .communications-page .navbarMenu { right: 50px; top: 31px; }
  .communications-page .navbarMenu li { font-size: 15px; }
  .communications-page .navbarMenu img { width: 20px; }
  .communications-page .nav-bar { min-height: 90px; }
  .communications-page .cf6 { font-size: 30px; }
  .communications-page .footer p { font-size: 13px; padding: 15px 20px; }
}
@media only screen and (max-width: 800px) { .communications-page .col-sm-4.c57 { flex: 0 0 100%; max-width: 100%; } }
`;

interface ICommunicationsItem {
  Title: string;
  ThumbNail?: { Url?: string };
  File?: { Name?: string };
}

interface ICommunicationsResponse {
  d: { results: ICommunicationsItem[] };
}

const requestUri = "https://sites.ey.com/sites/MENATaxHub/_api/web/lists/getByTitle('Newsletter')/items?$select=Title,DisplayOrder,ThumbNail,File/Name&$expand=File&$orderby=DisplayOrder desc";
const requestHeaders = { accept: 'application/json;odata=verbose' };
const fileRoot = 'https://sites.ey.com/sites/MENATaxHub/Newsletter/';

interface ICommunicationsProps {
  onShowHome: () => void;
}

const Communications: React.FC<ICommunicationsProps> = ({ onShowHome }) => {
  const [loading, setLoading] = React.useState<boolean>(true);
  const [items, setItems] = React.useState<ICommunicationsItem[]>([]);

  React.useEffect(() => {
    window.scrollTo(0, 0);
    const loadingTimer = window.setTimeout(() => setLoading(false), 2000);
    const getDoclib = async (): Promise<void> => {
      try {
        const response = await fetch(requestUri, { headers: requestHeaders });
        if (!response.ok) {
          throw new Error(`${response.status} ${response.statusText}`);
        }
        const data = await response.json() as ICommunicationsResponse;
        if (data.d.results.length > 0) {
          setItems(data.d.results);
        }
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        window.console.error('Unable to load archived communications:', message);
      }
    };
    void getDoclib();
    return () => window.clearTimeout(loadingTimer);
  }, []);

  return (
    <div className="communications-page">
      <style>{communicationsStyles}</style>
      {loading && <div className="loading-container"><div className="item" /><div className="item" /><div className="item" /><div className="item" /></div>}
      <div className="container-wrapper">
        <div className="webPart">
          <div className="container-fluid nav-container"><div className="row nav-bar"><img className="EYlogo" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/EY_logo.png" alt="EY logo" /><p className="logoTxt">MENA Tax Hub</p><ul className="navbarMenu"><li><a data-interception="off" href="#" onClick={(event) => { event.preventDefault(); onShowHome(); }}><img className="home" src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home.png" alt="Home" /></a></li></ul></div></div>
          <div className="container-fluid"><div className="row"><div className="col-sm-12 bannerBackground"><div className="container-fluid cnt-fdr"><div className="row"><p className="cf6">MENA Tax archived communications</p><div className="col-sm-4 c57" /></div></div></div></div></div>
          <div className="container-fluid tabContent"><div id="divParent" className="row"><ul className="communications-list">{items.map((value, index) => index > 2 && <li key={`${value.Title}-${index}`}><div className="col-sm-bx"><div className="img-bx" style={{ backgroundImage: `url(${value.ThumbNail?.Url})`, marginRight: '10px' }} /><a data-interception="off" href={`${fileRoot}${value.File?.Name || ''}`} target="_blank" rel="noreferrer">{value.Title}</a><a data-interception="off" href={`${fileRoot}${value.File?.Name || ''}`} target="_blank" rel="noreferrer" className="pName">READ MORE</a></div></li>)}</ul></div></div>
        </div>
        <div className="footer"><p>&#169; 2026 EYGM Limited. All rights reserved.</p></div>
      </div>
    </div>
  );
};

export default Communications;