import * as React from 'react';

const imageRoot = 'https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/';

interface ITrainingPackAndDocumentsProps {
  onShowHome: () => void;
}

const trainingPackStyles = `
html,body{overflow-x:hidden!important;font-family:EYInterstate}.training-pack{background:#2e2e38;color:#fff;min-height:100vh}.training-pack .loading-container{align-items:center;background:#1a1a24;display:flex;inset:0;justify-content:center;position:fixed;z-index:9999}.training-pack .loading-container .item{border:.2vw solid #ffe600;border-bottom-color:transparent;border-radius:50%;border-top-color:transparent;position:absolute;animation:pack-spin 2s ease infinite}.training-pack .loading-container .item:nth-child(1){height:30px;width:30px}.training-pack .loading-container .item:nth-child(2){animation-delay:.1s;height:50px;width:50px}.training-pack .loading-container .item:nth-child(3){animation-delay:.2s;height:70px;width:70px}.training-pack .loading-container .item:nth-child(4){animation-delay:.3s;height:90px;width:90px}@keyframes pack-spin{50%{transform:rotate(180deg)}100%{transform:rotate(0)}}.training-pack .nav-bar{background:#2e2e38;min-height:6vw;position:relative}.training-pack .EYlogo{left:5vw;position:absolute;top:1.5vw;width:3vw}.training-pack .logoTxt{color:#fff;font-size:2vw;left:11vw;position:absolute;top:2.2vw}.training-pack .navbarMenu{list-style:none;margin:0;padding:0;position:absolute;right:6vw;top:2.4vw}.training-pack .navbarMenu li{display:inline-block;font-size:1vw}.training-pack .navbarMenu a{color:#fff;padding:0 2vw;text-decoration:none}.training-pack .home{width:1.3vw}.training-pack .bannerBackground{background:#2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/banner.jpg') center/cover;min-height:8vw}.training-pack .cnt-fdr{background:rgba(46,46,56,.5);min-height:8vw;padding:2vw 3.5vw}.training-pack .cf6{color:#fff;font-size:1.5vw;margin:0}.training-pack .tabContent{background:#2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center/cover;min-height:35vw;padding:4vw 7vw}.training-pack .cl-3{padding:.7vw}.training-pack .col-sm-bx{background:#ffffff0f url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center/cover;box-shadow:0 0 1.5vw rgba(0,0,0,.44);min-height:19vw;overflow:hidden;position:relative;width:100%}.training-pack .boxTag{display:block;text-decoration:none}.training-pack .img-bx{background-position:right;background-size:100%;min-height:9vw;transition:all .2s ease-in-out;width:100%}.training-pack .col-sm-bx:hover .img-bx{background-size:110%}.training-pack .count{background:#fff;border-radius:100vw;float:right;margin-right:2vw;margin-top:-1.7vw;padding:.3vw;width:2.5vw}.training-pack .bx-link{color:#fff;font-size:.9vw;line-height:1.3vw;margin:0;padding:2vw 1vw 0 1.5vw}.training-pack .footer{background:#000;float:left;width:100%}.training-pack .footer p{font-size:1vw;margin:0;padding:1vw 2vw;text-align:right}
@media(max-width:1200px){.training-pack .EYlogo{left:60px;top:20px;width:40px}.training-pack .logoTxt{font-size:25px;left:130px;top:30px}.training-pack .navbarMenu{right:50px;top:31px}.training-pack .home{width:20px}.training-pack .nav-bar{min-height:90px}.training-pack .cf6{font-size:30px}.training-pack .cnt-fdr{padding:35px 70px}.training-pack .tabContent{padding:50px 70px}.training-pack .col-sm-bx{min-height:70px}.training-pack .bx-link{font-size:13px;line-height:17px;padding:30px 30px}.training-pack .count{margin-right:20px;margin-top:-17px;width:35px;padding:6px}.training-pack .footer p{font-size:13px;padding:15px 20px}}
    .col-sm-3 {
        -ms-flex: 0 0 20%;
        flex: 0 0 20%;
        max-width: 20%;
    }
@media(max-width:992px){.training-pack .col-sm-3.cl-3{flex:0 0 33.333%;max-width:33.333%}}
@media(max-width:750px){.training-pack .tabContent{padding:40px 30px}.training-pack .col-sm-3.cl-3{flex:0 0 50%;max-width:50%}.training-pack .img-bx{min-height:140px}}
@media(max-width:575px){.training-pack .logoTxt{font-size:20px;left:115px}.training-pack .EYlogo{left:30px}.training-pack .navbarMenu{top:110px}.training-pack .col-sm-3.cl-3{flex:0 0 100%;max-width:100%}.training-pack .col-sm-bx{min-height:0}.training-pack .img-bx{min-height:200px}.training-pack .bx-link{font-size:14px;line-height:20px;padding:20px}.training-pack .tabContent{padding:40px 20px}}
`;

const TrainingPackAndDocuments: React.FC<ITrainingPackAndDocumentsProps> = ({ onShowHome }) => {
  const [isLoading, setIsLoading] = React.useState<boolean>(true);

  React.useEffect(() => {
    const timer = window.setTimeout(() => setIsLoading(false), 2000);
    return () => window.clearTimeout(timer);
  }, []);

  return (
    <div className="training-pack">
      <style>{trainingPackStyles}</style>
      {isLoading && <div className="loading-container" aria-label="Loading"><div className="item" /><div className="item" /><div className="item" /><div className="item" /></div>}
      <div className="webPart">
        <div className="container-fluid nav-container">
          <div className="row nav-bar">
            <img className="EYlogo" src={`${imageRoot}EY_logo.png`} alt="EY logo" />
            <p className="logoTxt">MENA Tax Hub</p>
            <ul className="navbarMenu"><li><a data-interception="off" href="#home" onClick={(event) => { event.preventDefault(); onShowHome(); }}><img className="home" src={`${imageRoot}home.png`} alt="Home" /></a></li></ul>
          </div>
        </div>
        <div className="container-fluid">
          <div className="row">
            <div className="col-sm-12 bannerBackground">
              <div className="container-fluid cnt-fdr"><p className="cf6">Training pack and documents</p></div>
            </div>
          </div>
        </div>
        <div className="container-fluid tabContent">
          <div className="row">
            <div className="col-sm-3 cl-3">
              <a data-interception="off" className="boxTag" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/Introduction%20to%20Mercury%20Training%20Deck%20v5_V1.pdf" target="_blank" rel="noreferrer">
                <div className="col-sm-bx">
                  <div className="img-bx" style={{ backgroundImage: `url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Screenshot.png)` }} />
                  <img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/pdf_icon.png" className="count" alt="PDF" />
                  <p className="bx-link">Instructor led training October / November 2022 - Introduction to Mercury and Engagement Economics</p>
                </div>
              </a>
            </div>
            <div className="col-sm-3 cl-3">
              <a data-interception="off" className="boxTag" href="https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/PfV%20Session%201%20-%20MENA.pdf" target="_blank" rel="noreferrer">
                <div className="col-sm-bx">
                  <div className="img-bx" style={{ backgroundImage: `url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/pricing%20for%20value.png)` }} />
                  <img src="https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/pdf_icon.png" className="count" alt="PDF" />
                  <p className="bx-link">Working Capital Management_Pricing for Value_Session 1_16 Jun 23</p>
                </div>
              </a>
            </div>
          </div>
        </div>
        <div className="footer"><p>&#169; 2026 EYGM Limited. All rights reserved.</p></div>
      </div>
    </div>
  );
};

export default TrainingPackAndDocuments;
