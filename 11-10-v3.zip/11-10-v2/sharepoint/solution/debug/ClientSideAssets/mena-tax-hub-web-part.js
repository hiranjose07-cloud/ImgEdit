define("4579f40f-d111-46fc-8634-0d1fe9af05fc_0.0.1", ["react","react-dom","@microsoft/sp-core-library","@microsoft/sp-property-pane","@microsoft/sp-webpart-base","MenaTaxHubWebPartStrings"], (__WEBPACK_EXTERNAL_MODULE__959__, __WEBPACK_EXTERNAL_MODULE__398__, __WEBPACK_EXTERNAL_MODULE__676__, __WEBPACK_EXTERNAL_MODULE__877__, __WEBPACK_EXTERNAL_MODULE__642__, __WEBPACK_EXTERNAL_MODULE__76__) => { return /******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 11:
/*!******************************************************************!*\
  !*** ./lib/webparts/menaTaxHub/components/MenaTaxHub.module.css ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_microsoft_sp_css_loader_node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/@microsoft/sp-css-loader/node_modules/@microsoft/load-themed-styles/lib-es6/index.js */ 323);
// Imports


_node_modules_microsoft_sp_css_loader_node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__.loadStyles(".fui-DialogSurface,.fui-DialogSurface__backdrop{display:none!important}.menaTaxHub_befce39d{background:#2e2e38;color:\"[theme:bodyText, default: #323130]\";color:var(--bodyText);height:100vh;left:0;overflow:hidden;overflow:auto;padding:0;position:fixed;top:0;width:100%;z-index:999999}.menaTaxHub_befce39d,.menaTaxHub_befce39d *{font-family:EYInterstate!important}.menaTaxHub_befce39d .nav-bar,.menaTaxHub_befce39d .nonGccResourcing__nav,.menaTaxHub_befce39d .onshoreResourcing__nav,.menaTaxHub_befce39d .resourcingHub__nav,.menaTaxHub_befce39d .talent-nav{min-height:6vw!important;position:relative!important}.menaTaxHub_befce39d .EYlogo{left:5vw!important;position:absolute!important;top:1.5vw!important;width:3vw!important}.menaTaxHub_befce39d .logoTxt{color:#fff!important;font-size:2vw!important;left:11vw!important;margin:0!important;position:absolute!important;top:2.2vw!important}.menaTaxHub_befce39d .homeLink,.menaTaxHub_befce39d .navLinks,.menaTaxHub_befce39d .navbarMenu{position:absolute!important;right:6vw!important;top:2.4vw!important}.menaTaxHub_befce39d .navbarMenu{list-style:none;margin:0!important;padding:0!important}.menaTaxHub_befce39d .homeLink .home,.menaTaxHub_befce39d .homeLink img,.menaTaxHub_befce39d .navLinks .home,.menaTaxHub_befce39d .navLinks img,.menaTaxHub_befce39d .navbarMenu .home{width:1.3vw!important}.menaTaxHub_befce39d .cf6{font-size:1.5vw!important;line-height:1.3!important}.menaTaxHub_befce39d .hder,.menaTaxHub_befce39d p.hder{font-size:1vw!important;line-height:1.5vw!important}@media only screen and (max-width:800px){.menaTaxHub_befce39d .nav-bar,.menaTaxHub_befce39d .nonGccResourcing__nav,.menaTaxHub_befce39d .onshoreResourcing__nav,.menaTaxHub_befce39d .resourcingHub__nav,.menaTaxHub_befce39d .talent-nav{min-height:90px!important}.menaTaxHub_befce39d .EYlogo{left:60px!important;top:20px!important;width:40px!important}.menaTaxHub_befce39d .logoTxt{font-size:25px!important;left:130px!important;top:30px!important}.menaTaxHub_befce39d .homeLink,.menaTaxHub_befce39d .navLinks,.menaTaxHub_befce39d .navbarMenu{right:50px!important;top:31px!important}.menaTaxHub_befce39d .homeLink .home,.menaTaxHub_befce39d .homeLink img,.menaTaxHub_befce39d .navLinks .home,.menaTaxHub_befce39d .navLinks img,.menaTaxHub_befce39d .navbarMenu .home{width:20px!important}.menaTaxHub_befce39d .cf6{font-size:30px!important;line-height:1.2!important}.menaTaxHub_befce39d .hder,.menaTaxHub_befce39d p.hder{font-size:16px!important;line-height:23px!important}}.menaTaxHub_befce39d.teams_befce39d{font-family:Segoe UI,-apple-system,BlinkMacSystemFont,Roboto,Helvetica Neue,sans-serif}.menaTaxHub_befce39d .menuButton_befce39d{align-items:center;background:#ffe600;border:0;cursor:pointer;display:flex;height:48px;justify-content:center;padding:0;position:fixed;right:24px;top:24px;width:48px;z-index:1000002}.menaTaxHub_befce39d .menuButton_befce39d img{height:24px;width:24px}.menaTaxHub_befce39d .menuOverlay_befce39d{background:rgba(0,0,0,.45);inset:0;opacity:0;pointer-events:none;position:fixed;transition:opacity .2s ease-in-out;z-index:1000003}.menaTaxHub_befce39d .menuOverlayOpen_befce39d{opacity:1;pointer-events:auto}.menaTaxHub_befce39d .routeLoading_befce39d{align-items:center;background:#1a1a24;display:flex;inset:0;justify-content:center;position:fixed;z-index:1000005}.menaTaxHub_befce39d .loadingRing_befce39d{animation:routeSpin_befce39d 2s ease infinite;border-color:transparent #ffe600;border-radius:50%;border-style:solid;border-width:.2vw;height:30px;position:absolute;width:30px}.menaTaxHub_befce39d .loadingRing_befce39d:nth-child(2){animation-delay:.1s;height:50px;width:50px}.menaTaxHub_befce39d .loadingRing_befce39d:nth-child(3){animation-delay:.2s;height:70px;width:70px}.menaTaxHub_befce39d .loadingRing_befce39d:nth-child(4){animation-delay:.3s;height:90px;width:90px}@keyframes routeSpin_befce39d{50%{transform:rotate(180deg)}to{transform:rotate(0)}}.menaTaxHub_befce39d .menuPanel_befce39d{background:#2e2e38;bottom:0;box-shadow:-8px 0 24px rgba(0,0,0,.3);max-width:360px;overflow-y:auto;padding:24px;position:fixed;right:0;top:0;transform:translateX(100%);transition:transform .2s ease-in-out;width:min(86vw,360px);z-index:1000004}.menaTaxHub_befce39d .menuPanel_befce39d ul{list-style:none;margin:0;padding:0}.menaTaxHub_befce39d .menuPanel_befce39d li{border-bottom:1px solid hsla(0,0%,100%,.14)}.menaTaxHub_befce39d .menuPanel_befce39d li button{background:0 0;border:0;color:#fff;cursor:pointer;display:block;font:16px EYInterstate,Arial,sans-serif;padding:14px 8px;text-align:left;width:100%}.menaTaxHub_befce39d .menuPanel_befce39d li button:focus-visible,.menaTaxHub_befce39d .menuPanel_befce39d li button:hover{background:hsla(0,0%,100%,.1);color:#ffe600}.menaTaxHub_befce39d .menuPanel_befce39d .menuLink_befce39d{color:#fff;display:block;font:16px EYInterstate,Arial,sans-serif;padding:14px 8px;text-decoration:none}.menaTaxHub_befce39d .menuPanel_befce39d .menuLink_befce39d:focus-visible,.menaTaxHub_befce39d .menuPanel_befce39d .menuLink_befce39d:hover{background:hsla(0,0%,100%,.1);color:#ffe600}.menaTaxHub_befce39d .menuPanelOpen_befce39d{transform:translateX(0)}.menaTaxHub_befce39d .menuHeader_befce39d{align-items:center;border-bottom:2px solid #ffe600;color:#ffe600;display:flex;font:22px EYInterstate,Arial,sans-serif;justify-content:space-between;margin-bottom:12px;padding-bottom:14px}.menaTaxHub_befce39d .menuClose_befce39d{background:0 0;border:0;color:#fff;cursor:pointer;font-size:30px;line-height:1;padding:0 4px}.menaTaxHub_befce39d .menuItemActive_befce39d{color:#ffe600!important}.menaTaxHub_befce39d .footerTab{background:#1a1a24!important;padding:5vw!important}.menaTaxHub_befce39d .footerTab .quicklinks{color:#fff!important;display:block;font-size:1.3vw!important;margin:0 0 2vw!important;width:100%}.menaTaxHub_befce39d .footerTab .row{display:flex;flex-wrap:wrap}.menaTaxHub_befce39d .footerTab .cl-3{flex:0 0 25%!important;max-width:25%!important;padding:.4vw!important}.menaTaxHub_befce39d .footerTab .cl-3>a{display:block;height:100%;text-decoration:none}.menaTaxHub_befce39d .quickLinksGrid{display:flex;flex-wrap:wrap;margin:0 -.4vw}.menaTaxHub_befce39d .quickLink{flex:0 0 25%!important;max-width:25%!important;padding:.4vw!important}.menaTaxHub_befce39d .quickLink>a{display:block;height:100%;text-decoration:none}.menaTaxHub_befce39d .engagement-page .quickLinksGrid,.menaTaxHub_befce39d .markets-page .quickLinksGrid{display:flex!important;flex-wrap:wrap!important;margin:0 -.4vw!important}.menaTaxHub_befce39d .engagement-page .quickLink,.menaTaxHub_befce39d .markets-page .quickLink{flex:0 0 25%!important;max-width:25%!important;padding:.4vw!important}.menaTaxHub_befce39d .engagement-page .quickLink>a,.menaTaxHub_befce39d .markets-page .quickLink>a{display:block!important;height:100%}.menaTaxHub_befce39d .footerTab .col-sm-bx{background:#ffffff0f url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png) 50%/cover!important;box-shadow:0 0 1.5vw rgba(0,0,0,.44);min-height:7.5vw!important;overflow:hidden;position:relative;width:100%}.menaTaxHub_befce39d .footerTab .img-bx{background-position:50%!important;background-size:cover!important;bottom:0;left:0;min-height:0!important;position:absolute;top:0;width:37%!important}.menaTaxHub_befce39d .footerTab p.bx-link{color:#fff!important;font-size:1vw!important;left:42%!important;line-height:1.3vw!important;margin:0!important;max-height:3.9vw;overflow:hidden;padding:0!important;position:absolute;top:50%!important;transform:translateY(-50%);width:48%!important}.menaTaxHub_befce39d .footerTab .col-sm-bx>span{bottom:.3vw!important;color:hsla(0,0%,100%,.52)!important;font-size:2vw!important;font-weight:700;position:absolute;right:1vw!important}@media only screen and (max-width:992px){.menaTaxHub_befce39d .footerTab .cl-3{flex-basis:33.3333%!important;max-width:33.3333%!important}.menaTaxHub_befce39d .footerTab p.bx-link{font-size:13px!important;line-height:16px!important;max-height:48px}.menaTaxHub_befce39d .engagement-page .quickLink,.menaTaxHub_befce39d .markets-page .quickLink,.menaTaxHub_befce39d .quickLink{flex-basis:33.3333%!important;max-width:33.3333%!important}}@media only screen and (max-width:650px){.menaTaxHub_befce39d .engagement-page .quickLink,.menaTaxHub_befce39d .footerTab .cl-3,.menaTaxHub_befce39d .markets-page .quickLink,.menaTaxHub_befce39d .quickLink{flex-basis:50%!important;max-width:50%!important}}@media only screen and (max-width:500px){.menaTaxHub_befce39d .engagement-page .quickLink,.menaTaxHub_befce39d .footerTab .cl-3,.menaTaxHub_befce39d .markets-page .quickLink,.menaTaxHub_befce39d .quickLink{flex-basis:100%!important;max-width:100%!important}}@media only screen and (min-width:641px) and (max-width:1000px){.menaTaxHub_befce39d *{box-sizing:border-box}.menaTaxHub_befce39d iframe,.menaTaxHub_befce39d img,.menaTaxHub_befce39d video{max-width:100%!important}.menaTaxHub_befce39d a,.menaTaxHub_befce39d button,.menaTaxHub_befce39d input,.menaTaxHub_befce39d label,.menaTaxHub_befce39d li,.menaTaxHub_befce39d p,.menaTaxHub_befce39d select,.menaTaxHub_befce39d span,.menaTaxHub_befce39d td,.menaTaxHub_befce39d textarea,.menaTaxHub_befce39d th{font-size:15px!important;line-height:1.4!important}.menaTaxHub_befce39d h1{font-size:34px!important;line-height:1.15!important}.menaTaxHub_befce39d h2{font-size:28px!important;line-height:1.2!important}.menaTaxHub_befce39d h3,.menaTaxHub_befce39d h4,.menaTaxHub_befce39d h5,.menaTaxHub_befce39d h6{font-size:22px!important;line-height:1.25!important}.menaTaxHub_befce39d .cf6{font-size:30px!important;line-height:1.2!important}.menaTaxHub_befce39d .hder,.menaTaxHub_befce39d p.hder{font-size:16px!important;line-height:23px!important}.menaTaxHub_befce39d table{max-width:100%!important;overflow-x:auto!important}.menaTaxHub_befce39d .row{margin-left:0!important;margin-right:0!important}.menaTaxHub_befce39d .col-sm-3,.menaTaxHub_befce39d .col-sm-4,.menaTaxHub_befce39d .col-sm-6{flex-basis:50%!important;max-width:50%!important}.menaTaxHub_befce39d .col-sm-12{flex-basis:100%!important;max-width:100%!important}.menaTaxHub_befce39d [style*=width],.menaTaxHub_befce39d [width]{max-width:100%!important}}@media only screen and (max-width:640px){.menaTaxHub_befce39d *{box-sizing:border-box}.menaTaxHub_befce39d iframe,.menaTaxHub_befce39d img,.menaTaxHub_befce39d video{max-width:100%!important}.menaTaxHub_befce39d a,.menaTaxHub_befce39d button,.menaTaxHub_befce39d input,.menaTaxHub_befce39d label,.menaTaxHub_befce39d li,.menaTaxHub_befce39d p,.menaTaxHub_befce39d select,.menaTaxHub_befce39d span,.menaTaxHub_befce39d td,.menaTaxHub_befce39d textarea,.menaTaxHub_befce39d th{font-size:max(14px,1vw)!important;line-height:1.35!important}.menaTaxHub_befce39d h1{font-size:clamp(24px,7vw,34px)!important;line-height:1.15!important}.menaTaxHub_befce39d h2{font-size:clamp(20px,5.5vw,28px)!important;line-height:1.2!important}.menaTaxHub_befce39d h3,.menaTaxHub_befce39d h4,.menaTaxHub_befce39d h5,.menaTaxHub_befce39d h6{font-size:clamp(17px,4.5vw,24px)!important;line-height:1.25!important}.menaTaxHub_befce39d .cf6{font-size:clamp(22px,6vw,30px)!important;line-height:1.2!important}.menaTaxHub_befce39d .hder,.menaTaxHub_befce39d p.hder{font-size:14px!important;line-height:21px!important}.menaTaxHub_befce39d table{display:block!important;max-width:100%!important;overflow-x:auto!important;white-space:normal}.menaTaxHub_befce39d .row{margin-left:0!important;margin-right:0!important}.menaTaxHub_befce39d [style*=width],.menaTaxHub_befce39d [width]{max-width:100%!important}}.welcome_befce39d{text-align:center}.welcomeImage_befce39d{max-width:420px;width:100%}.links_befce39d a{color:\"[theme:link, default:#03787c]\";color:var(--link);text-decoration:none}.links_befce39d a:hover{color:\"[theme:linkHovered, default: #014446]\";color:var(--linkHovered);text-decoration:underline}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvaGlyYW4vc3BmeC1wcm9qZWN0LTIvTUVOQSUyMFRheCUyMEh1Yi12Ny0xL3NyYy93ZWJwYXJ0cy9tZW5hVGF4SHViL2NvbXBvbmVudHMvTWVuYVRheEh1Yi5tb2R1bGUuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFQSxnREFFRSxzQkFBQSxDQUdGLHFCQW1CSSxrQkFBQSxDQVZGLDBDQUFBLENBQ0EscUJBQUEsQ0FJRSxZQUFBLENBRUEsTUFBQSxDQVRGLGVBQUEsQ0FRRSxhQUFBLENBS0EsU0FBQSxDQVJFLGNBQUEsQ0FLRixLQUFBLENBSkEsVUFBQSxDQUtBLGNBRUEsQ0FqQkYsNENBRkEsa0NBR0UsQ0FrQkYsaU1BS0Usd0JBQUEsQ0FDQSwyQkFBQSxDQUdGLDZCQUNFLGtCQUFBLENBQ0EsMkJBQUEsQ0FDQSxtQkFBQSxDQUNBLG1CQUFBLENBR0YsOEJBQ0Usb0JBQUEsQ0FDQSx1QkFBQSxDQUNBLG1CQUFBLENBQ0Esa0JBQUEsQ0FDQSwyQkFBQSxDQUNBLG1CQUFBLENBR0YsK0ZBR0UsMkJBQUEsQ0FDQSxtQkFBQSxDQUNBLG1CQUFBLENBR0YsaUNBQ0UsZUFBQSxDQUNBLGtCQUFBLENBQ0EsbUJBQUEsQ0FTRix1TEFFRSxxQkFBQSxDQUdGLDBCQUNFLHlCQUFBLENBQ0EseUJBQUEsQ0FHRix1REFFRSx1QkFBQSxDQUNBLDJCQUFBLENBR0YseUNBQ0UsaU1BS0UseUJBQUEsQ0FHRiw2QkFDRSxtQkFBQSxDQUNBLGtCQUFBLENBQ0Esb0JBQUEsQ0FHRiw4QkFDRSx3QkFBQSxDQUNBLG9CQUFBLENBQ0Esa0JBQUEsQ0FHRiwrRkFHRSxvQkFBQSxDQUNBLGtCQUFBLENBU0YsdUxBRUUsb0JBQUEsQ0FHRiwwQkFDRSx3QkFBQSxDQUNBLHlCQUFBLENBR0YsdURBRUUsd0JBQUEsQ0FDQSwwQkFBQSxDQUFBLENBS0osb0NBQ0Usc0ZBQUEsQ0FHRiwwQ0FDRSxrQkFBQSxDQUNBLGtCQUFBLENBQ0EsUUFBQSxDQUNBLGNBQUEsQ0FDQSxZQUFBLENBQ0EsV0FBQSxDQUNBLHNCQUFBLENBQ0EsU0FBQSxDQUNBLGNBQUEsQ0FDQSxVQUFBLENBQ0EsUUFBQSxDQUNBLFVBQUEsQ0FDQSxlQUFBLENBRUEsOENBQ0UsV0FBQSxDQUNBLFVBQUEsQ0FJSiwyQ0FDRSwwQkFBQSxDQUNBLE9BQUEsQ0FDQSxTQUFBLENBQ0EsbUJBQUEsQ0FDQSxjQUFBLENBQ0Esa0NBQUEsQ0FDQSxlQUFBLENBR0YsK0NBQ0UsU0FBQSxDQUNBLG1CQUFBLENBR0YsNENBQ0Usa0JBQUEsQ0FDQSxrQkFBQSxDQUNBLFlBQUEsQ0FDQSxPQUFBLENBQ0Esc0JBQUEsQ0FDQSxjQUFBLENBQ0EsZUFBQSxDQUdGLDJDQVFFLDZDQUFBLENBSkEsZ0NBQUEsQ0FEQSxpQkFBQSxDQUNBLGtCQUFBLENBQUEsaUJBQUEsQ0FDQSxXQUFBLENBQ0EsaUJBQUEsQ0FDQSxVQUNBLENBRUEsd0RBQ0UsbUJBQUEsQ0FDQSxXQUFBLENBQ0EsVUFBQSxDQUdGLHdEQUNFLG1CQUFBLENBQ0EsV0FBQSxDQUNBLFVBQUEsQ0FHRix3REFDRSxtQkFBQSxDQUNBLFdBQUEsQ0FDQSxVQUFBLENBSUosOEJBQ0UsSUFBTSx3QkFBQSxDQUNOLEdBQU8sbUJBQUEsQ0FBQSxDQUdULHlDQUNFLGtCQUFBLENBQ0EsUUFBQSxDQUNBLHFDQUFBLENBQ0EsZUFBQSxDQUNBLGVBQUEsQ0FDQSxZQUFBLENBQ0EsY0FBQSxDQUNBLE9BQUEsQ0FDQSxLQUFBLENBQ0EsMEJBQUEsQ0FDQSxvQ0FBQSxDQUNBLHFCQUFBLENBQ0EsZUFBQSxDQUVBLDRDQUNFLGVBQUEsQ0FDQSxRQUFBLENBQ0EsU0FBQSxDQUdGLDRDQUNFLDJDQUFBLENBR0YsbURBQ0UsY0FBQSxDQUNBLFFBQUEsQ0FDQSxVQUFBLENBQ0EsY0FBQSxDQUNBLGFBQUEsQ0FDQSx1Q0FBQSxDQUNBLGdCQUFBLENBQ0EsZUFBQSxDQUNBLFVBQUEsQ0FFQSwwSEFFRSw2QkFBQSxDQUNBLGFBQUEsQ0FJSiw0REFDRSxVQUFBLENBQ0EsYUFBQSxDQUNBLHVDQUFBLENBQ0EsZ0JBQUEsQ0FDQSxvQkFBQSxDQUVBLDRJQUVFLDZCQUFBLENBQ0EsYUFBQSxDQUtOLDZDQUNFLHVCQUFBLENBR0YsMENBQ0Usa0JBQUEsQ0FDQSwrQkFBQSxDQUNBLGFBQUEsQ0FDQSxZQUFBLENBQ0EsdUNBQUEsQ0FDQSw2QkFBQSxDQUNBLGtCQUFBLENBQ0EsbUJBQUEsQ0FHRix5Q0FDRSxjQUFBLENBQ0EsUUFBQSxDQUNBLFVBQUEsQ0FDQSxjQUFBLENBQ0EsY0FBQSxDQUNBLGFBQUEsQ0FDQSxhQUFBLENBR0YsOENBQ0UsdUJBQUEsQ0FHRixnQ0FDRSw0QkFBQSxDQUNBLHFCQUFBLENBR0YsNENBQ0Usb0JBQUEsQ0FDQSxhQUFBLENBQ0EseUJBQUEsQ0FDQSx3QkFBQSxDQUNBLFVBQUEsQ0FHRixxQ0FDRSxZQUFBLENBQ0EsY0FBQSxDQUdGLHNDQUNFLHNCQUFBLENBQ0EsdUJBQUEsQ0FDQSxzQkFBQSxDQUdGLHdDQUNFLGFBQUEsQ0FDQSxXQUFBLENBQ0Esb0JBQUEsQ0FHRixxQ0FDRSxZQUFBLENBQ0EsY0FBQSxDQUNBLGNBQUEsQ0FHRixnQ0FDRSxzQkFBQSxDQUNBLHVCQUFBLENBQ0Esc0JBQUEsQ0FHRixrQ0FDRSxhQUFBLENBQ0EsV0FBQSxDQUNBLG9CQUFBLENBR0YseUdBRUUsc0JBQUEsQ0FDQSx3QkFBQSxDQUNBLHdCQUFBLENBR0YsK0ZBRUUsc0JBQUEsQ0FDQSx1QkFBQSxDQUNBLHNCQUFBLENBR0YsbUdBRUUsdUJBQUEsQ0FDQSxXQUFBLENBR0YsMkNBQ0UscUhBQUEsQ0FDQSxvQ0FBQSxDQUNBLDBCQUFBLENBQ0EsZUFBQSxDQUNBLGlCQUFBLENBQ0EsVUFBQSxDQUdGLHdDQUNFLGlDQUFBLENBQ0EsK0JBQUEsQ0FDQSxRQUFBLENBQ0EsTUFBQSxDQUNBLHNCQUFBLENBQ0EsaUJBQUEsQ0FDQSxLQUFBLENBQ0EsbUJBQUEsQ0FHRiwwQ0FDRSxvQkFBQSxDQUNBLHVCQUFBLENBQ0Esa0JBQUEsQ0FDQSwyQkFBQSxDQUNBLGtCQUFBLENBQ0EsZ0JBQUEsQ0FDQSxlQUFBLENBQ0EsbUJBQUEsQ0FDQSxpQkFBQSxDQUNBLGlCQUFBLENBQ0EsMEJBQUEsQ0FDQSxtQkFBQSxDQUdGLGdEQUNFLHFCQUFBLENBQ0EsbUNBQUEsQ0FDQSx1QkFBQSxDQUNBLGVBQUEsQ0FDQSxpQkFBQSxDQUNBLG1CQUFBLENBR0YseUNBQ0Usc0NBQ0UsNkJBQUEsQ0FDQSw0QkFBQSxDQUdGLDBDQUNFLHdCQUFBLENBQ0EsMEJBQUEsQ0FDQSxlQUFBLENBUUYsK0hBRUUsNkJBQUEsQ0FDQSw0QkFBQSxDQUFBLENBSUoseUNBV0UscUtBRUUsd0JBQUEsQ0FDQSx1QkFBQSxDQUFBLENBSUoseUNBV0UscUtBRUUseUJBQUEsQ0FDQSx3QkFBQSxDQUFBLENBSUosZ0VBQ0UsdUJBQ0UscUJBQUEsQ0FHRixnRkFHRSx3QkFBQSxDQUdGLDRSQVdFLHdCQUFBLENBQ0EseUJBQUEsQ0FHRix3QkFDRSx3QkFBQSxDQUNBLDBCQUFBLENBR0Ysd0JBQ0Usd0JBQUEsQ0FDQSx5QkFBQSxDQUdGLGdHQUlFLHdCQUFBLENBQ0EsMEJBQUEsQ0FHRiwwQkFDRSx3QkFBQSxDQUNBLHlCQUFBLENBR0YsdURBRUUsd0JBQUEsQ0FDQSwwQkFBQSxDQUdGLDJCQUNFLHdCQUFBLENBQ0EseUJBQUEsQ0FHRiwwQkFDRSx1QkFBQSxDQUNBLHdCQUFBLENBR0YsNkZBR0Usd0JBQUEsQ0FDQSx1QkFBQSxDQUdGLGdDQUNFLHlCQUFBLENBQ0Esd0JBQUEsQ0FHRixpRUFFRSx3QkFBQSxDQUFBLENBSUoseUNBQ0UsdUJBQ0UscUJBQUEsQ0FHRixnRkFHRSx3QkFBQSxDQUdGLDRSQVdFLGlDQUFBLENBQ0EsMEJBQUEsQ0FHRix3QkFDRSx3Q0FBQSxDQUNBLDBCQUFBLENBR0Ysd0JBQ0UsMENBQUEsQ0FDQSx5QkFBQSxDQUdGLGdHQUlFLDBDQUFBLENBQ0EsMEJBQUEsQ0FHRiwwQkFDRSx3Q0FBQSxDQUNBLHlCQUFBLENBR0YsdURBRUUsd0JBQUEsQ0FDQSwwQkFBQSxDQUdGLDJCQUNFLHVCQUFBLENBQ0Esd0JBQUEsQ0FDQSx5QkFBQSxDQUNBLGtCQUFBLENBR0YsMEJBQ0UsdUJBQUEsQ0FDQSx3QkFBQSxDQUdGLGlFQUVFLHdCQUFBLENBQUEsQ0FNTixrQkFDRSxpQkFBQSxDQUdGLHVCQUVFLGVBQUEsQ0FEQSxVQUNBLENBSUEsa0JBRUUscUNBQUEsQ0FDQSxpQkFBQSxDQUZBLG9CQUVBLENBRUEsd0JBRUUsNkNBQUEsQ0FDQSx3QkFBQSxDQUZBLHlCQUVBIiwiZmlsZSI6Ik1lbmFUYXhIdWIubW9kdWxlLmNzcyJ9 */", true);

// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  "fui-DialogSurface": "fui-DialogSurface",
  "fui-DialogSurface__backdrop": "fui-DialogSurface__backdrop",
  menaTaxHub_befce39d: "menaTaxHub_befce39d",
  "nav-bar": "nav-bar",
  nonGccResourcing__nav: "nonGccResourcing__nav",
  onshoreResourcing__nav: "onshoreResourcing__nav",
  resourcingHub__nav: "resourcingHub__nav",
  "talent-nav": "talent-nav",
  EYlogo: "EYlogo",
  logoTxt: "logoTxt",
  homeLink: "homeLink",
  navLinks: "navLinks",
  navbarMenu: "navbarMenu",
  home: "home",
  cf6: "cf6",
  hder: "hder",
  teams_befce39d: "teams_befce39d",
  menuButton_befce39d: "menuButton_befce39d",
  menuOverlay_befce39d: "menuOverlay_befce39d",
  menuOverlayOpen_befce39d: "menuOverlayOpen_befce39d",
  routeLoading_befce39d: "routeLoading_befce39d",
  loadingRing_befce39d: "loadingRing_befce39d",
  routeSpin_befce39d: "routeSpin_befce39d",
  menuPanel_befce39d: "menuPanel_befce39d",
  menuLink_befce39d: "menuLink_befce39d",
  menuPanelOpen_befce39d: "menuPanelOpen_befce39d",
  menuHeader_befce39d: "menuHeader_befce39d",
  menuClose_befce39d: "menuClose_befce39d",
  menuItemActive_befce39d: "menuItemActive_befce39d",
  footerTab: "footerTab",
  quicklinks: "quicklinks",
  row: "row",
  "cl-3": "cl-3",
  quickLinksGrid: "quickLinksGrid",
  quickLink: "quickLink",
  "engagement-page": "engagement-page",
  "markets-page": "markets-page",
  "col-sm-bx": "col-sm-bx",
  "img-bx": "img-bx",
  "bx-link": "bx-link",
  "col-sm-3": "col-sm-3",
  "col-sm-4": "col-sm-4",
  "col-sm-6": "col-sm-6",
  "col-sm-12": "col-sm-12",
  welcome_befce39d: "welcome_befce39d",
  welcomeImage_befce39d: "welcomeImage_befce39d",
  links_befce39d: "links_befce39d"
});


/***/ }),

/***/ 420:
/*!***************************************************!*\
  !*** ./lib/webparts/menaTaxHub/components/CST.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

var cstStyles = "\nhtml,\nbody {\n  overflow-x: hidden !important;\n  font-family: EYInterstate;\n}\n\n.container_wrapper {\n  display: none;\n}\n\n::-moz-selection {\n  color: #ffffff;\n  background: #27ACAA;\n}\n\n::selection {\n  color: #ffffff;\n  background: #27ACAA;\n}\n\nbody::-webkit-scrollbar {\n  display: none;\n}\n\n.loading-container {\n  position: relative;\n  position: fixed;\n  z-index: 9999;\n  background: #1a1a24;\n  width: 100%;\n  height: 100vh;\n  margin: auto;\n}\n\n.loading-container .item {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  border: .2vw solid #ffe600;\n  border-radius: 50%;\n  border-top-color: transparent;\n  border-bottom-color: transparent;\n  animation: spin 2s ease infinite;\n}\n\n.loading-container .item:nth-child(1) {\n  width: 30px;\n  height: 30px;\n}\n\n.loading-container .item:nth-child(2) {\n  width: 50px;\n  height: 50px;\n  animation-delay: 0.1s;\n}\n\n.loading-container .item:nth-child(3) {\n  width: 70px;\n  height: 70px;\n  animation-delay: 0.2s;\n}\n\n.loading-container .item:nth-child(4) {\n  width: 90px;\n  height: 90px;\n  animation-delay: 0.3s;\n}\n\n@keyframes spin {\n  50% {\n    transform: translate(-50%, -50%) rotate(180deg);\n  }\n  100% {\n    transform: translate(-50%, -50%) rotate(0deg);\n  }\n}\n\nbody {\n  -ms-overflow-style: none;\n  scrollbar-width: none;\n  position: relative;\n}\n\n.bannerBackground {\n  background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/banner.jpg);\n  background-color: #2e2e38;\n  background-size: 115% 115%;\n  background-position: center center;\n  position: relative;\n  background-attachment: fixed;\n  animation: shrink 20s infinite alternate;\n  padding: 0px;\n}\n\n.cf6 {\n  color: #ffffff;\n  width: 100%;\n  font-size: 1.9vw;\n  padding: 0;\n  margin-bottom: 0;\n  float: left;\n  border-bottom: .1vw solid #ffffff;\n  padding-bottom: 3px;\n  margin-left: 1vw;\n  width: 34vw;\n  margin-bottom: 1.3vw;\n}\n\n@keyframes shrink {\n  0% {\n    background-size: 115% 115%;\n  }\n  100% {\n    background-size: 100% 100%;\n  }\n}\n\n.nav-bar {\n  position: relative;\n  z-index: 999;\n  background: #2e2e38;\n  min-height: 6vw;\n  width: 100%;\n  margin: 0;\n}\n\n.nav-container {\n  padding: 0px;\n}\n\n.EYlogo {\n  width: 3vw;\n  position: absolute;\n  left: 5vw;\n  top: 1.5vw;\n}\n\np.logoTxt {\n  color: #ffffff;\n  font-size: 2vw;\n  position: absolute;\n  left: 11vw;\n  top: 2.2vw;\n}\n\nimg.home {\n  width: 1.3vw;\n}\n\nul.navbarMenu {\n  position: absolute;\n  right: 6vw;\n  top: 2.4vw;\n  font-family: EYInterstate;\n}\n\nul.navbarMenu li {\n  display: inline-block;\n  font-size: 1vw;\n  color: #ffffff;\n}\n\nul.navbarMenu li a {\n  color: #ffffff;\n  text-decoration: none;\n  padding: 0vw 2vw;\n}\n\n.boxContent span {\n  color: #ffe600;\n  font-size: 1.2vw;\n  margin-right: .3vw;\n  font-weight: bold;\n}\n\n.cnt-fdr {\n  padding: 2vw 5vw 2vw 5vw;\n  background: rgba(46, 46, 56, .5);\n  bottom: 0;\n  width: 100%;\n}\n\n.vh3 {\n  margin-top: 1.3vw;\n}\n\n.boxContent p {\n  color: #ffffff;\n  font-size: .9vw;\n  line-height: 1.3vw;\n  font-family: EYInterstate;\n  font-weight: lighter;\n}\n\n.boxContent p b {\n  font-size: 1.2vw;\n  line-height: 2.5vw;\n}\n\n.boxContent img {\n  width: 3vw;\n  margin-bottom: .4vw;\n}\n\np.c4 {\n  color: #ffffff;\n  font-size: 1.1vw;\n  font-family: EYInterstate;\n  line-height: 1.5vw;\n  margin-bottom: 1.3vw;\n}\n\nul.c5 {\n  color: #ffffff;\n  list-style: none;\n  padding: 0;\n}\n\nul.c5 li {\n  position: relative;\n  padding-left: 1.3vw;\n  margin-bottom: 0.6vw;\n  font-size: 1vw;\n}\n\nul.c5 li::before {\n  content: \"\";\n  background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/arrow_icon.png);\n  position: absolute;\n  width: .6vw;\n  height: .6vw;\n  background-size: contain;\n  background-repeat: no-repeat;\n  top: 0.5vw;\n  left: 0;\n}\n\n.footerTab {\n  background: #1a1a24;\n  padding: 5vw;\n}\n\na.qLInk {\n  color: #ffffff;\n  font-family: EYInterstate;\n  font-size: 1vw;\n  font-weight: lighter;\n  border: .1vw solid #9f9f9f;\n  padding: 0.5vw 1.6vw;\n  border-radius: .4vw;\n  margin-right: .7vw;\n  text-decoration: none;\n  float: left;\n  -webkit-transition: all .2s ease-in-out;\n  -moz-transition: all .2s ease-in-out;\n  -o-transition: all .2s ease-in-out;\n  transition: all .2s ease-in-out;\n  margin-bottom: .8vw;\n}\n\na.qLInk:hover {\n  background: rgba(255, 255, 255, .2)\n}\n\n.quicklinks {\n  color: #ffffff;\n  font-size: 2vw;\n  margin-bottom: 2vw;\n}\n\nimg.qklinks {\n  width: 1.4vw;\n  margin-top: -0.2vw;\n  margin-right: .4vw;\n}\n\n.tabContent {\n  background-image: url(../images/bgc.png);\n  background-position: center;\n  background-size: cover;\n  background-attachment: fixed;\n  background-color: #2e2e38;\n}\n\n.tabCol {\n  min-height: 10vw;\n}\n\n.nav-tabs .nav-link {\n  margin-bottom: 0vw;\n  border: hidden;\n  border-radius: 0px;\n  color: #ffffff !important;\n  font-size: 1.1vw;\n  font-family: EYInterstate;\n  font-weight: lighter;\n  border-right: .1vw solid #9e9e9e !important;\n  padding: 0.2vw 2.5vw\n}\n\n.nav-tabs .nav-item.show .nav-link,\n.nav-tabs .nav-link.active {\n  color: #ffe600 !important;\n  background-color: transparent;\n}\n\n#myTab {\n  border-bottom: .1vw solid #7e7e7e;\n  padding-bottom: 1vw;\n  margin-bottom: 0px;\n}\n\n.tabCol {\n  min-height: 10vw;\n  padding: 2vw 6vw;\n}\n\np.tabTxt {\n  color: #ffffff;\n  font-size: 1vw;\n  line-height: 1.5vw;\n  margin-bottom: 0;\n  min-height: 5vw;\n}\n\na.cgt7 {\n  position: absolute;\n  right: 0vw;\n  bottom: 1vw;\n  color: #000000;\n  background: #ffe600;\n  width: 17vw;\n  padding: 0.5vw 0vw;\n  text-align: center;\n  text-decoration: none;\n}\n\na.cgt7 img {\n  width: 1.5vw;\n  margin-right: 0.5vw;\n}\n\n.cl-tx {\n  border-bottom: .01vw solid #ffffff61;\n  padding-bottom: 2vw;\n  margin-bottom: 2vw !important;\n}\n\np.tabTxt a {\n  color: #ffe600;\n  text-decoration: none;\n  font-weight: bold;\n}\n\nul.ul_01 li a {\n  color: #ffe600;\n  text-decoration: none;\n  font-weight: bold;\n}\n\n.tab-pane {\n  padding: 3vw 4vw !important;\n}\n\n.tabCol ul.ul_01 {\n  color: #ffffff;\n  font-size: 1vw;\n  list-style: none;\n  padding: 0;\n  margin: 0;\n  font-family: EYInterstate;\n  font-weight: lighter;\n}\n\n.tabCol ul.ul_02 {\n  color: #ffffff;\n  font-size: 1vw;\n  list-style: none;\n  padding: 0;\n  margin: 0;\n  font-family: EYInterstate;\n  font-weight: lighter;\n}\n\np.bt_7 {\n  color: #ffffff;\n  font-size: 2vw;\n  margin-bottom: 1vw;\n  margin-top: -1vw;\n}\n\n.tabCol ul.ul_01 li {\n  position: relative;\n  padding-left: 1.5vw;\n  margin-bottom: 1.7vw;\n}\n\n.tabCol ul.ul_02 li {\n  position: relative;\n  padding-left: 1.5vw;\n  margin-bottom: .7vw;\n}\n\n.tabCol ul.ul_01 li::before {\n  content: \"\";\n  background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/arrow_png.png);\n  position: absolute;\n  width: 0.7vw;\n  height: 0.6vw;\n  background-size: contain;\n  background-repeat: no-repeat;\n  margin-top: 0.4vw;\n  left: 0;\n}\n\n.tabCol ul.ul_02 li::before {\n  content: \"\";\n  background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/tick.png);\n  position: absolute;\n  width: 0.7vw;\n  height: 0.6vw;\n  background-size: contain;\n  background-repeat: no-repeat;\n  margin-top: 0.4vw;\n  left: 0;\n}\n\n.col_1 {\n  width: 20%;\n  background: rgba(255, 255, 255, .08);\n  color: #ffffff;\n  font-size: .9vw;\n  line-height: 1.3vw;\n  float: left;\n  border-right: .1vw solid #616161;\n}\n\n.col_1:last-child {\n  border-right: hidden\n}\n\n.Hdline {\n  background: #1a1a24;\n  padding: 1.5vw;\n  min-height: 7vw;\n}\n\n.p-text {\n  padding: 1.5vw;\n  margin: 0;\n  min-height: 17vw;\n}\n\np.c8 {\n  color: #ffe600;\n  padding: 0vw 1.5vw;\n}\n\nul.c9 {\n  padding: 0vw 1.5vw 1.5vw 1.5vw;\n  list-style: none;\n  margin-bottom: 0;\n  min-height: 20vw;\n}\n\nul.c9 li {\n  position: relative;\n  padding-left: 1vw;\n  margin-bottom: 1vw;\n}\n\nul.c9 li::before {\n  content: \"\";\n  background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/arrow_png.png);\n  position: absolute;\n  width: 0.7vw;\n  height: 0.6vw;\n  background-size: contain;\n  background-repeat: no-repeat;\n  margin-top: 0.4vw;\n  left: 0;\n}\n\nimg.cf_img {\n  width: 100%;\n  height: 8vw;\n}\n\n.cf_head {\n  background: #747480;\n  padding: 0.6vw 0vw;\n  text-align: center;\n  color: #ffffff;\n  font-size: 1.2vw;\n  float: left;\n  width: 100%;\n}\n\nimg.proImg {\n  width: 5vw;\n  border-radius: 100vw;\n  float: left;\n  margin-right: 1vw;\n}\n\np.proName {\n  color: #ffffff;\n  font-size: 1vw;\n  margin-bottom: 0vw;\n  padding-top: 1.3vw;\n}\n\np.proDes {\n  color: #ffe600;\n  font-size: .9vw;\n  margin-bottom: 0;\n  margin-top: -.2vw;\n}\n\n.profileDetails {\n  float: left;\n  width: 100%;\n  margin-bottom: 2vw;\n}\n\nli.subList {\n  margin: 2vw 0vw !important;\n  font-size: 1.5vw !important;\n}\n\nli.subList::before {\n  display: none !important;\n}\n\n#Six-tab {\n  border-right: hidden !important;\n}\n\np.hder {\n  color: #ffffff;\n  padding-left: 1vw;\n  font-size: 1vw;\n  line-height: 1.5vw;\n  margin-bottom: 1vw;\n}\n\n.news_box {\n  float: left;\n  margin-right: 1.5vw;\n  background: rgba(255, 255, 255, .08);\n  width: 28%;\n  border: .01vw solid #444343;\n  border-radius: .2vw;\n  overflow: hidden;\n}\n\n.nws02.nsw a .news_box {\n  width: 60%;\n}\n\n.imgTile {\n  width: 100%;\n  height: 7vw;\n  background-size: cover;\n  background-position: center;\n}\n\n.newsHd {\n  color: #ffffff;\n  font-size: 2vw;\n  margin-bottom: 0.5vw;\n  margin-top: 3vw;\n}\n\nhr.newsHr {\n  margin-top: 0;\n  margin-bottom: 2vw;\n  border: 0;\n  border-top: 1px solid rgba(255, 255, 255, .64);\n  width: 4vw;\n}\n\n.Ntitle {\n  color: #ffe600;\n  margin-bottom: .5vw;\n  font-size: .9vw\n}\n\n.Nsubtitle {\n  color: #ffe600;\n  font-size: 1vw;\n  margin-bottom: 0.6vw;\n  margin-top: -0.4vw;\n}\n\n.Ndes {\n  color: #ffffff;\n  font-size: .8vw;\n  line-height: 1.1vw;\n  margin-bottom: 0;\n}\n\n.Nread {\n  color: #ffffff;\n  font-size: .8vw;\n  font-style: italic;\n  margin: 0;\n  text-align: right;\n  margin-top: 0.4vw;\n  position: absolute;\n  right: 1vw;\n  bottom: 1vw;\n}\n\n.newsDes {\n  padding: 2vw 1vw;\n  position: relative;\n  min-height: 10vw;\n}\n\n.footer {\n  background-color: #000000;\n  float: left;\n  width: 100%;\n}\n\n.footer p {\n  margin-bottom: 0px;\n  color: #ffffff;\n  font-size: 1vw;\n  padding: 1vw 2vw;\n  text-align: right;\n}\n\n.txtTwo {\n  margin-bottom: 1vw !important;\n}\n\n.navToggle {\n  display: none;\n}\n\n.cl-v1 {\n  background: #ffe600;\n  color: #000000 !important;\n  font-family: EYInterstate;\n  padding: 0.7vw 2vw;\n  float: right;\n  text-decoration: none !important;\n  font-size: .9vw;\n  position: relative;\n  z-index: 1;\n  margin-top: 5px;\n}\n\n.cl-v1 img {\n  width: 2vw;\n  margin-right: .6vw;\n}\n\n.u0 {\n  color: #ffe600 !important;\n}\n\n.u1 {\n  margin: 1vw 0vw !important;\n}\n\n.u2 li {\n  margin-bottom: .5vw !important;\n}\n\n.hotNews {\n  background: #ffe600;\n  width: 6vw;\n  margin-bottom: -1vw;\n  position: relative;\n  z-index: 1;\n  margin-left: 1vw;\n}\n\n.hotNews img {\n  width: 1.6vw;\n  padding: 0.2vw 0.1vw 0.3vw 0.5vw;\n}\n\n.hotNews span {\n  color: #000000;\n  font-size: .8vw;\n  padding: 0vw 0.3vw;\n}\n\n.table.table-bordered {\n  color: #ffffff;\n  margin-top: 2vw;\n}\n\n.table-bordered thead th {\n  color: #ffe600;\n  padding: 1vw 1.5vw;\n  font-size: 1.1vw;\n  line-height: 1.4vw;\n}\n\n.table-bordered.ty_7 thead th {\n  padding: 1vw 0vw;\n}\n\n.table-bordered tbody td {\n  padding: 0.7vw 1.5vw;\n  font-size: .9vw;\n}\n\n.table-bordered td,\n.table-bordered th,\n.table-bordered {\n  border: .01vw solid #474747 !important;\n}\n\ntable.table-bordered thead tr {\n  background-color: #1f2027;\n}\n\n.col_20 {\n  background-color: #1f2027;\n}\n\n.col_10 td ul {\n  list-style: none;\n  padding: 0px;\n  margin-top: 1vw;\n}\n\n.col_10 td ul li {\n  margin-bottom: .7vw !important;\n}\n\n.nws01 {\n  float: left;\n  width: 65%;\n  border-right: .1vw solid #8e8e8e;\n  padding-bottom: 2vw;\n}\n\n.nws02 {\n  float: left;\n  width: 35%;\n  padding-left: 4vw;\n}\n\na.cr7 {\n  text-decoration: none;\n  position: relative;\n}\n\n.news_1 {\n  background: rgba(255, 255, 255, 0.1);\n  padding: 1.5vw 1.5vw;\n  margin-top: 0;\n  margin-bottom: 1vw;\n  -webkit-transition: all .2s ease-in-out;\n  -moz-transition: all .2s ease-in-out;\n  -o-transition: all .2s ease-in-out;\n  transition: all .2s ease-in-out;\n  padding-left: 10vw;\n  position: relative;\n  min-height: 8.4vw;\n}\n\n.fy7 {\n  background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/FSleader.png?csf=1&web=1&e=t2oWU0);\n  width: 8vw;\n  height: 84%;\n  position: absolute;\n  left: .8vw;\n  top: .8vw;\n  background-size: cover;\n  background-position: right;\n  opacity: 0.9;\n}\n\n.pr_txt {\n  color: #ffffff;\n  font-size: .9vw;\n  margin-bottom: .5vw;\n  margin-top: 1vw;\n  line-height: 1.2vw;\n  width: 100%;\n}\n\n.c4a7 {\n  color: #ffffff !important;\n  font-size: .9vw;\n  text-decoration: none !important;\n  margin-bottom: 0px;\n}\n\na.btn-yellow {\n  background: #ffe600;\n  text-align: center;\n  color: #000000;\n  font-size: 1vw;\n  text-decoration: none;\n  padding: 0.8vw 2vw;\n  width: 40%;\n  display: inline-block;\n}\n\np.cf7 {\n  text-align: center;\n  margin: 0;\n  padding: 2vw 0vw;\n}\n\n.ifrme {\n  width: 100%;\n  padding: 0vw;\n  margin-bottom: 3vw;\n  margin-top: 2vw;\n}\n\n.videoTab {\n  float: left;\n  width: 100%;\n  margin-bottom: .2vw;\n}\n\n.videoTab a {\n  float: left;\n  width: 100%;\n  padding: 1vw 0vw;\n  padding-top: 0px;\n}\n\n.vidThumb {\n  width: 18vw;\n  float: left;\n}\n\n.hder.vid-hdr {\n  float: left;\n  margin-top: 2.5vw;\n}\n\n.textPhace {\n  float: left;\n}\n\nspan.s-span {\n  color: #ffe600;\n}\n\nspan.c-span {\n  font-size: .85vw;\n}\n\n.tmp2 {\n  font-size: 0.9vw;\n  text-align: center;\n  margin-top: -0.1vw;\n  color: #ffffff;\n  font-weight: bold;\n  margin-bottom: 0.5vw;\n}\n\n.tabCol {\n  min-height: 10vw;\n}\n\n.tabCol {\n  min-height: 10vw;\n  padding: 2vw 6vw;\n}\n\n.m-Title {\n  color: #ffffff;\n  width: 100%;\n  font-size: 1.5vw;\n  padding: 1vw 1vw;\n  margin-bottom: 2vw;\n}\n\n.col-sm-12.sm-tm-5 {\n  -ms-flex: 0 0 16.6666%;\n  flex: 0 0 16.6666%;\n  max-width: 16.6666%;\n  padding: 0vw 0.4vw;\n  padding-bottom: 0.8vw;\n  margin-top: 2vw;\n}\n\n.cf {\n  background: rgb(255 255 255 / 6%);\n  min-height: 13vw;\n}\n\n.tmImg {\n  background: #000000;\n  width: 5.5vw;\n  height: 5.5vw;\n  border-radius: 100vw;\n  position: relative;\n  left: 50%;\n  transform: translate(-50%, 0);\n  top: 1.5vw;\n  overflow: hidden;\n}\n\n.tmImg img {\n  width: 105%;\n  position: absolute;\n  left: 50%;\n  top: 50%;\n  transform: translate(-50%, -50%);\n}\n\n.tmProfile {\n  font-size: 0.8vw;\n  text-align: center;\n  margin-top: -0.1vw;\n  margin-bottom: 0.5vw;\n  color: #ffffff;\n  padding: 0vw 1vw;\n  padding-bottom: 1vw;\n}\n\n.tmName {\n  font-size: .9vw;\n  font-family: EYInterstate;\n  text-align: center;\n  margin-top: 2.5vw;\n  margin-bottom: 0;\n  color: #ffe600;\n}\n\niframe#cst {\n  width: 60vw;\n  height: 35.4vw;\n  margin-top: 1.5vw;\n}\n\niframe#csts {\n  width: 65vw;\n  height: 28.5vw;\n}\n\n.trs-padding {\n  padding-top: 0px !important;\n}\n\nspan.s1-cf {\n  font-size: 1.4vw;\n  color: #ffe600;\n  display: block;\n  width: 100%;\n  border-top: .1vw solid #ffffff63;\n  border-bottom: .1vw solid #ffffff63;\n  padding: 1vw 0vw;\n}\n\n.cg-6 {\n  font-size: 1.2vw;\n}\n\nimg.vid {\n  position: absolute;\n  top: 2px;\n  right: 0;\n  width: 460px;\n  border: 1px solid #474747;\n}\n\n.vid-parent {\n  position: relative;\n  padding-right: 500px;\n}\n\n.cst-back-btn {\n  position: absolute;\n  right: 2vw;\n  top: 1.2vw;\n  color: #ffe600 !important;\n  border: 1px solid #ffe600;\n  padding: 0.35rem 0.8rem;\n  font-size: 0.9rem;\n}\n\n@media only screen and (max-width: 1200px) {\n  .cnt-fdr {\n    position: static;\n  }\n  .cnt-fdr {\n    padding: 35px 70px;\n  }\n  .EYlogo {\n    width: 40px;\n    left: 60px;\n    top: 20px;\n  }\n  p.logoTxt {\n    font-size: 25px;\n    left: 130px;\n    top: 30px;\n  }\n  ul.navbarMenu {\n    right: 50px;\n    top: 25px;\n  }\n  ul.navbarMenu li {\n    font-size: 15px;\n  }\n  ul.navbarMenu li a {\n    padding: 0vw 20px;\n  }\n  img.home {\n    width: 20px;\n  }\n  .nav-bar {\n    min-height: 90px;\n  }\n  ul.navbarMenu {\n    right: 50px;\n    top: 31px;\n  }\n  .footer p {\n    margin-bottom: 0px;\n    color: #ffffff;\n    font-size: 13px;\n    padding: 15px 20px;\n    text-align: right;\n  }\n  .cf6 {\n    font-size: 30px;\n    margin-bottom: 0;\n  }\n  p.hder {\n    color: #ffffff;\n    font-size: 16px;\n    line-height: 23px;\n    margin-bottom: 10px;\n  }\n  .tabCol {\n    padding: 50px 70px;\n  }\n  .profileDetails {\n    margin-bottom: 25px;\n  }\n  img.proImg {\n    width: 65px;\n    margin-right: 15px;\n  }\n  p.proName {\n    font-size: 15px;\n    padding-top: 12px;\n  }\n  p.proDes {\n    font-size: 13px;\n    margin-top: -1px;\n  }\n  p.tabTxt {\n    font-size: 14px;\n    line-height: 20px;\n    margin-bottom: 0;\n  }\n  .tabCol ul.ul_01 {\n    font-size: 14px;\n  }\n  .tabCol ul.ul_01 li::before {\n    width: 15px;\n    height: 8px;\n    margin-top: 6px;\n    left: 0;\n  }\n  .tabCol ul.ul_01 li {\n    position: relative;\n    padding-left: 17px;\n    margin-bottom: 10px;\n  }\n  span.s1-cf {\n    font-size: 18px;\n    border-top: 1px solid #ffffff63;\n    border-bottom: 1px solid #ffffff63;\n    padding: 11px 15px;\n  }\n  .col-sm-12.sm-tm-5 {\n    padding: 0vw 4px;\n    margin-top: 8px;\n    padding-bottom: 0;\n    -ms-flex: 0 0 160px;\n    flex: 0 0 160px;\n    max-width: 160px;\n  }\n  .tmImg {\n    width: 56px;\n    height: 56px;\n    top: 24px;\n    overflow: hidden;\n  }\n  .tmName {\n    font-size: 13px;\n    margin-top: 28px;\n    line-height: 13px;\n    margin-bottom: 3px;\n  }\n  .tmp2 {\n    font-size: 11px;\n    margin-top: 0px;\n    margin-bottom: 5px;\n  }\n  .cf {\n    min-height: 160px;\n    max-height: 160px;\n  }\n  .cg-6 {\n    font-size: 16px;\n  }\n  a.btn-yellow {\n    background: #ffe600;\n    text-align: center;\n    color: #000000;\n    font-size: 13px;\n    text-decoration: none;\n    padding: 5px 10px;\n    width: 65%;\n    display: inline-block;\n  }\n  .vidThumb {\n    width: 205px;\n    float: left;\n    margin-right: 10px;\n  }\n}\n\n@media only screen and (max-width: 800px) {\n  .col-sm-4.c57 {\n    -ms-flex: 0 0 100%;\n    flex: 0 0 100%;\n    max-width: 100%;\n  }\n  .tabCol {\n    padding: 50px 30px;\n  }\n}\n\n@media only screen and (max-width: 760px) {\n  img.vid {\n    position: static;\n    width: 380px;\n    border: 1px solid #474747;\n    transform: translate(0%, 0%);\n  }\n  .vid-parent {\n    position: relative;\n    padding-right: 0px;\n  }\n}\n\n@media only screen and (max-width: 600px) {\n  img.vid {\n    width: 100%;\n  }\n}\n\n@media only screen and (max-width: 575px) {\n  ul.navbarMenu {\n    top: 110px;\n  }\n  .col-sm-12.sm-tm-5 {\n    -ms-flex: 0 0 50%;\n    flex: 0 0 50%;\n    max-width: 50%;\n  }\n}\n\n@media only screen and (max-width: 400px) {\n  .col-sm-12.sm-tm-5 {\n    -ms-flex: 0 0 100%;\n    flex: 0 0 100%;\n    max-width: 100%;\n  }\n}\n";
var CST = function (_a) {
    var onShowHome = _a.onShowHome;
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
        var loader = document.querySelector('.loading-container');
        var wrapper = document.querySelector('.container_wrapper');
        if (loader) {
            setTimeout(function () {
                loader.style.display = 'none';
            }, 2000);
        }
        window.scrollTo(0, 0);
        setTimeout(function () {
            if (wrapper) {
                wrapper.style.display = 'block';
            }
        }, 1999);
    }, []);
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("style", null, cstStyles),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "loading-container", style: { display: 'none' } },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container_wrapper", style: { display: 'block' } },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "webPart" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid nav-container" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row nav-bar" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "EYlogo", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/EY_logo.png", alt: "EY logo" }),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "logoTxt" }, "MENA Tax Hub"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "navbarMenu" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#", onClick: function (event) { event.preventDefault(); onShowHome(); } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "home", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home.png", alt: "Home" })))))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 bannerBackground" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid cnt-fdr" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "cf6" }, "MENA Tax CST (Central Support Team)"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "hder" },
                                        "Our aim is to reduce the time you spend on routine tasks and to improve governance of the MENA Tax engagement portfolio.",
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        " The MENA Tax CST, based in the Philippines, forms part of Global Delivery Services (GDS). The team supports MENA Tax service line (SL) engagements to enhance service delivery, by ensuring proactive coordination, timely communication and efficient engagement management."),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-4 c57" })))))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid tabContent" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 tabCol" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "vid-parent" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt txtTwo" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "cg-6" }, "Our activities include:")),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "ul_01 u2" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "New and existing entity onboarding in MDM and GIS (Create Prospect Process)"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Creating new opportunity in CRM/EY Dynamics"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Initiating new PACE"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Setting up detailed pricing plans"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Creating new engagement codes"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Setting up engagement budgets"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Setting up and maintaining engagement activities"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Performing estimate to complete (ETC)"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Performing invoice billing & invoice adjustment"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Updating client details (i.e., client address, client VAT ID) via MDM for invoice billing"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Monitoring and following up on collections (when required)"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Closing an engagement")),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt txtTwo" },
                                        "This helps our Engagement team spend less time on routine Mercury processes and focus more on serving clients and winning in the market.",
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null)),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/Videos/CST%20Training%20_2-20230302_110511-Meeting%20Recording.mp4", target: "_blank", rel: "noreferrer" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/VideoThumbnail.jpg", className: "vid", alt: "CST training" })),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/CST%20Training%20FAQs%20V1.1.pdf", target: "_blank", className: "cgt7", rel: "noreferrer" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/question.png", alt: "FAQs" }),
                                        "Click here to view FAQs")),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "s1-cf" }, "So, how does it work?"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt txtTwo" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                    "Engagement teams will send the request using the form below. When selecting the service required, simply input all the necessary information requested."),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "cf7" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: "btn-yellow", href: "https://apps.powerapps.com/play/e/a3c669f6-ac2e-4e77-ad43-beab3e15bee7/a/716780f0-e2a9-49e5-9fbb-d7437adc6298?tenantId=5b973f99-77df-4beb-b27d-aa0c70b8482c", target: "_blank", rel: "noreferrer" }, "Central Support Team - Request Form (Click here)")),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "ifrme", style: { textAlign: 'center' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("iframe", { id: "csts", src: "https://apps.powerapps.com/play/e/a3c669f6-ac2e-4e77-ad43-beab3e15bee7/a/716780f0-e2a9-49e5-9fbb-d7437adc6298?tenantId=5b973f99-77df-4beb-b27d-aa0c70b8482c", scrolling: "no", allow: "geolocation *; microphone *; camera *; fullscreen *;", allowFullScreen: true, sandbox: "allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts allow-forms allow-orientation-lock allow-downloads", width: "100%", height: "100%", title: "Power Apps", name: "webPlayer-iFrame-1", style: { boxSizing: 'border-box', border: 'none' } })),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt txtTwo" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "s1-cf" }, "What details do I need to provide?"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "cg-6" }, "A. Prospect Creation")),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt txtTwo cgh", style: { paddingLeft: '25px' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { style: { marginLeft: '-12px' } }, "1."),
                                    " Client details must be provided completely as per the request form as well as any of the available listed legal documents below which has national ID, entity name & business location address given in it:",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "ul_01 u2", style: { padding: '0 25px' } },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Any official letter/doc from the company representative (with registration, new name/address)"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Company website of current year copyright"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Email from company representative with company registered number/Commercial register with new entity name and address"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Letter of incorporation (new name/address)"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Any Government registered proof having registration ID"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Company structure for entity onboarding process in GIS"))),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt txtTwo", style: { minHeight: 'auto' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "cg-6" }, " B. Opportunity Creation")),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt txtTwo cgh", style: { paddingLeft: '25px' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { style: { marginLeft: '-12px' } }, "1."),
                                    " Essential details must be provided as per the request form",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                    " ",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { style: { marginLeft: '-12px' } }, "2."),
                                    " Entity must be in \u201CData Validation Completed\u201D status and must be linked ",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/Tax_CST/PACE%20submissions%20for%20Clients%20which%20are%20not%20on%20GIS.pdf", target: "_blank", rel: "noreferrer" }, "to Global Independence system"),
                                    " (except for individual and private households). Prospect creation must be requested if the entity is not properly onboarded in MDM and GIS"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt txtTwo", style: { minHeight: 'auto' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "cg-6" }, "C. Engagement set up (Lean and Standard)")),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt txtTwo cgh", style: { paddingLeft: '25px' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { style: { marginLeft: '-12px' } }, "1."),
                                    " Opportunity must be in \u201CWon\u201D status and PACE should be in \u201CApproved\u201D status to proceed with the engagement creation",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                    " ",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { style: { marginLeft: '-12px' } }, "2."),
                                    " For lean engagements (TOV <25K USD), the essential metrics have to be provided as per the request form (In order for the Engagement Team to provide an appropriate data in high-level budget, download the ",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/MENATaxHub/SitePages/Policies_and_procedures.aspx", target: "_blank", rel: "noreferrer" }, "high-level budget calculator"),
                                    " and input the necessary information to come up with the metrics. This will help the Engagement Team to predict the outcome of Margin% and EAF% prior to submitting a request)",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                    " ",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { style: { marginLeft: '-12px' } }, "3."),
                                    " For Standard Engagements (TOV>25K USD), the financial metrics, resource details (Named, Unnamed & GDS) and external engagement details must be provided.",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                    " ",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { style: { marginLeft: '-12px' } }, "4."),
                                    " EL/EA/SOW must be provided (If EL/EA/SOW is not yet signed, approval from Tax Quality Leader is required by filling out the ",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/MENATaxQualityKnowledge/_layouts/15/AccessDenied.aspx?Source=https%3A%2F%2Fsites%2Eey%2Ecom%2Fsites%2FMENATaxQualityKnowledge%2FSitePages%2Fform%2Easpx&correlation=8793dea0%2D806c%2D7000%2D6063%2Dce5f631be70c&Type=item&name=49016cbf%2D9d9f%2D44f3%2D80f2%2Db636a258df94&listItemId=6&listItemUniqueId=7a254ba3%2D166e%2D4372%2D8d66%2D127f91de24b6", target: "_blank", rel: "noreferrer" }, "Tax Exception: the 30-day rule monitoring form"),
                                    ")"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt txtTwo", style: { minHeight: 'auto' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "cg-6", style: { minHeight: 'auto' } }, "D. ETC (Engagement Economics)")),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt txtTwo cgh", style: { minHeight: 'auto', paddingLeft: '25px' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { style: { marginLeft: '-12px' } }, "1."),
                                    " Engagement must be in \u201CReleased\u201D status to proceed with the ETC request",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                    " ",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { style: { marginLeft: '-12px' } }, "2."),
                                    " Engagement team is expected to review the latest E2E report before providing instruction in the ETC Template",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                    " ",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { style: { marginLeft: '-12px' } }, "3."),
                                    " Provide the ETC specifics using the ",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/MENATaxHub/_layouts/15/download.aspx?UniqueId=d2239996%2D13af%2D452e%2Dbec2%2Df98dcc1f2fb9", target: "_blank", rel: "noreferrer", download: true }, "ETC Template"),
                                    " which can be filled for both single and bulk requests. For guidance on how to use the ETC Template, please check out the video below"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "videoTab", style: { paddingLeft: '25px' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/:v:/r/sites/MENATaxHub/SiteAssets/MENATax/Videos/MENA%20Tax%20-%20ETC%20template%20guided%20video.webm", target: "_blank", rel: "noreferrer" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/vid-thumb.png", className: "vidThumb", alt: "ETC video" }),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "hder vid-hdr" },
                                            "MENA Tax - ETC template guided video",
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "sites.ey.com")))),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt txtTwo", style: { minHeight: 'auto' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "cg-6" }, "E. Billing and Collections")),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt txtTwo cgh", style: { paddingLeft: '25px' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { style: { marginLeft: '-12px' } }, "1."),
                                    " Engagement must be in \u201CReleased\u201D status and Engagement Code must be a MENA code to proceed with the Billing Request",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                    " ",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { style: { marginLeft: '-12px' } }, "2."),
                                    " All mandatory details to be updated",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                    " ",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { style: { marginLeft: '-12px' } }, "3."),
                                    " For PSM Invoicing, EY Office/EY Entity code should be provided in the Client Name field; If it's a direct billed to the client, local entity should be provided in the Client Name Field",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                    " ",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { style: { marginLeft: '-12px' } }, "4."),
                                    " If technology fee is already known, update field as '0%' and provide the amount in the comments section",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                    " ",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { style: { marginLeft: '-12px' } }, "5."),
                                    " For Invoice Reversal above 30 days, approval from Ghazanfar Iqbal/Paul Cooper (via email) is required",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                    " ",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { style: { marginLeft: '-12px' } }, "6."),
                                    " EL/EA/SOW/PSM must be provided"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt txtTwo", style: { minHeight: 'auto' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "cg-6" }, "F. Engagement Code Closure")),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt txtTwo cgh", style: { paddingLeft: '25px' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { style: { marginLeft: '-12px' } }, "1."),
                                    " Essential details must be provided as per the Global process request form"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt txtTwo", style: { minHeight: 'auto' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "cg-6" }, "*NOTE*")),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "ul_01 u2", style: { padding: '0 25px 25px' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Please ensure ALL time and expense have been charged and ALL billing issued prior to submitting this closing form"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Once the engagement close process is initiated NO time, expense or billing may be processed"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "You can block time OR expense by accessing the \u2018My Engagement: Maintenance and Billing\u2019 page in Mercury and click the engagement number hyperlink")),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "textPhace" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt txtTwo" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "s1-cf" }, " What happens next?"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        "Upon submission, you will receive a notification letting you know the CST have successfully received your request. Your request will be automatically added to the workflow queue (prioritizing oldest task first) to be reviewed & performed.",
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        " We'll update you throughout the process and if any additional/missing information is required, we will reach out via email and occasionally on Teams. ",
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "s-span" }, "In order to complete your request as soon as possible and avoid any changes on ETC metrics - please aim to respond on the same working day"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        "Once the request is completed, the requestor will get an automated notification confirming the case has been successfully closed.",
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        " ",
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "s1-cf" }, "How long will it take to complete my request?"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "c-span" }, "*SLA's are based on same day response & no rework required")),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "framesTwo", style: { textAlign: 'center' } },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("iframe", { id: "cst", src: "https://sites.ey.com/sites/MENATaxHub/_layouts/15/Doc.aspx?sourcedoc={618c6ce9-288c-4b20-9bbf-82900442b414}&action=embedview&wdAr=1.7777777777777777", frameBorder: "0", title: "MENA Tax CST SLA Dashboard" },
                                            "This is an embedded ",
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", target: "_blank", href: "https://office.com", rel: "noreferrer" }, "Microsoft Office"),
                                            " presentation, powered by ",
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", target: "_blank", href: "https://office.com/webapps", rel: "noreferrer" }, "Office"),
                                            ".")))))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row tabCol trs-padding" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "s1-cf" }, "Meet The Team"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 sm-tm-5 " },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "cf " },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "TmBox " },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "tmImg " },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Nomah%20Nasir.jpg", alt: "Nomah Nasir" })),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmName " }, "Nomah Nasir"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmp2 " }, "Supervising Associate")))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 sm-tm-5 " },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "cf " },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "TmBox " },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "tmImg " },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Nida%20Rasool.jpg", alt: "Nida Rasool" })),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmName " }, "Nida Rasool"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmp2 " }, "Senior Associate")))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 sm-tm-5 " },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "cf " },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "TmBox " },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "tmImg " },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Ahmed%20Raza%20Aftab.jpg", alt: "Ahmed Raza Aftab" })),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmName " }, "Ahmed Raza Aftab"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmp2 " }, "Associate")))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 sm-tm-5 " },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "cf " },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "TmBox " },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "tmImg " },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Ayan%20Rashid.jpg", alt: "Ayan Rashid" })),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmName " }, "Ayan Rashid"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmp2 " }, "Associate")))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 sm-tm-5 " },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "cf " },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "TmBox " },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "tmImg " },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Faiza%20Daood%20Shah.jpg", alt: "Faiza Daood Shah" })),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmName " }, "Faiza Daood Shah"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmp2 " }, "Associate")))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 sm-tm-5 " },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "cf " },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "TmBox " },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "tmImg " },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Hazique%20Abdul%20Rehman.jpg", alt: "Hazique Abdul Rehman" })),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmName " }, "Hazique Abdul Rehman"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmp2 " }, "Associate")))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 sm-tm-5 " },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "cf " },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "TmBox " },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "tmImg " },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Iqra%20Qabool.jpg", alt: "Iqra Qabool" })),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmName " }, "Iqra Qabool"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmp2 " }, "Associate")))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 sm-tm-5 " },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "cf " },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "TmBox " },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "tmImg " },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Kashan%20Qamar.jpg", alt: "Kashan Qamar" })),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmName " }, "Kashan Qamar"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmp2 " }, "Associate")))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 sm-tm-5 " },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "cf " },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "TmBox " },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "tmImg " },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Muhammad%20A%20Hasan.jpg", alt: "Muhammad A Hasan" })),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmName " }, "Muhammad A Hasan"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmp2 " }, "Associate")))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 sm-tm-5 " },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "cf " },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "TmBox " },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "tmImg " },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Muhammad%20Muhaiudin.jpg", alt: "Muhammad Muhaidin" })),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmName " }, "Muhammad Muhaidin"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmp2 " }, "Associate")))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 sm-tm-5 " },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "cf " },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "TmBox " },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "tmImg " },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Ayan%20Rashid.jpg", alt: "Fazal Abbas" })),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmName " }, "Fazal Abbas"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmp2 " }, "Associate")))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 sm-tm-5 " },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "cf " },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "TmBox " },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "tmImg " },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Safiya%20Yameen.jpg", alt: "Safiya Yameen" })),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmName " }, "Safiya Yameen"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmp2 " }, "Associate")))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 sm-tm-5 " },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "cf " },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "TmBox " },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "tmImg " },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Sania%20Sami.jpg", alt: "Maria Arif" })),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmName " }, "Maria Arif"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmp2 " }, "Associate")))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 sm-tm-5 " },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "cf " },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "TmBox " },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "tmImg " },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Sehrish%20Akhtar.jpg", alt: "Sehrish Akhtar" })),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmName " }, "Sehrish Akhtar"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmp2 " }, "Associate")))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 sm-tm-5 " },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "cf " },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "TmBox " },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "tmImg " },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Shayan%20Imran.jpg", alt: "Bhadur Khan" })),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmName " }, "Bhadur Khan"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmp2 " }, "Associate")))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 sm-tm-5 " },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "cf " },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "TmBox " },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "tmImg " },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Syed%20M%20Ukasha.jpg", alt: "Syed M Ukasha" })),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmName " }, "Syed M Ukasha"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmp2 " }, "Associate")))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 sm-tm-5 " },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "cf " },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "TmBox " },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "tmImg " },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Teams/Zoha%20Humayun.jpg", alt: "Zoha Humayun" })),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmName " }, "Zoha Humayun"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmp2 " }, "Associate"))))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row " },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "footer " },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "\u00A9 2026 EYGM Limited. All rights reserved."))))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CST);


/***/ }),

/***/ 621:
/*!**************************************************************!*\
  !*** ./lib/webparts/menaTaxHub/components/Communications.js ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};

var communicationsStyles = "\nhtml, body { overflow-x: hidden !important; font-family: EYInterstate; }\n.communications-page { background: #2e2e38; color: #ffffff; font-family: EYInterstate, Arial, sans-serif; overflow: hidden; }\n.communications-page .loading-container { align-items: center; background: #1a1a24; display: flex; inset: 0; justify-content: center; position: fixed; z-index: 9999; }\n.communications-page .loading-container .item { border: .2vw solid #ffe600; border-bottom-color: transparent; border-radius: 50%; border-top-color: transparent; height: 30px; position: absolute; width: 30px; animation: communicationsSpin 2s ease infinite; }\n.communications-page .loading-container .item:nth-child(2) { height: 50px; width: 50px; animation-delay: .1s; }\n.communications-page .loading-container .item:nth-child(3) { height: 70px; width: 70px; animation-delay: .2s; }\n.communications-page .loading-container .item:nth-child(4) { height: 90px; width: 90px; animation-delay: .3s; }\n@keyframes communicationsSpin { 50% { transform: rotate(180deg); } 100% { transform: rotate(0deg); } }\n.communications-page .container-wrapper { display: block; }\n.communications-page .nav-bar { background: #2e2e38; min-height: 6vw; position: relative; }\n.communications-page .nav-container { padding: 0; }\n.communications-page .EYlogo { left: 5vw; position: absolute; top: 1.5vw; width: 3vw; }\n.communications-page .logoTxt { color: #ffffff; font-size: 2vw; left: 11vw; margin: 0; position: absolute; top: 2.2vw; }\n.communications-page .navbarMenu { list-style: none; margin: 0; padding: 0; position: absolute; right: 6vw; top: 2.4vw; }\n.communications-page .navbarMenu li { display: inline-block; font-size: 1vw; }\n.communications-page .navbarMenu a { color: #ffffff; padding: 0 2vw; text-decoration: none; }\n.communications-page .navbarMenu img { width: 1.3vw; }\n.communications-page .bannerBackground { background: #2e2e38 url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/banner.jpg);\n    animation: communicationsShrink 20s infinite alternate;\n    padding: 0;\n    background-size: cover !important;\n    background-position: 0% 21%;}\n.communications-page .cnt-fdr { background: rgba(46, 46, 56, .5); padding: 2vw 5vw; width: 100%; }\n.communications-page .cf6 { color: #ffffff; font-size: 1.5vw; margin: 0; padding: 1vw; width: 100%; }\n@keyframes communicationsShrink { 0% { background-size: 115% 115%; } 100% { background-size: 100% 100%; } }\n.communications-page .tabContent { background: #2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center / cover; min-height: 31vw; padding: 4vw 7vw; }\n.communications-page .col-sm-bx { padding:0px 10px; align-items: center; background: #ffffff0f url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') left / contain; box-shadow: 0 0 1.5vw rgba(0, 0, 0, .44); display: flex; min-height: 4vw; position: relative; width: 100%; }\n.communications-page .img-bx { background-position: left; background-size: 50%; min-height: 2vw; transition: all .2s ease-in-out; width: 30px;     width: 30px;\n    background-size: cover !important;\n    background-position: center !important;}\n.communications-page .col-sm-bx:hover .img-bx { background-size: 50%; }\n.communications-page .communications-list { list-style: none; margin: 0; padding: 0; width: 100%; }\n.communications-page .communications-list li { margin-bottom: .7vw; }\n.communications-page .col-sm-bx a { color: #ffffff; margin-right: 10px; }\n.communications-page .col-sm-bx a.pName { color: #ffe600; font-size: 9px; }\n.communications-page .footer { background: #000000; float: left; width: 100%; }\n.communications-page .footer p { color: #ffffff; font-size: 1vw; margin: 0; padding: 1vw 2vw; text-align: right; }\n@media only screen and (max-width: 1200px) {\n  .communications-page .cnt-fdr { padding: 35px 70px; }\n  .communications-page .EYlogo { left: 60px; top: 20px; width: 40px; }\n  .communications-page .logoTxt { font-size: 25px; left: 130px; top: 30px; }\n  .communications-page .navbarMenu { right: 50px; top: 31px; }\n  .communications-page .navbarMenu li { font-size: 15px; }\n  .communications-page .navbarMenu img { width: 20px; }\n  .communications-page .nav-bar { min-height: 90px; }\n  .communications-page .cf6 { font-size: 30px; }\n  .communications-page .footer p { font-size: 13px; padding: 15px 20px; }\n}\n@media only screen and (max-width: 800px) { .communications-page .col-sm-4.c57 { flex: 0 0 100%; max-width: 100%; } }\n";
var requestUri = "https://sites.ey.com/sites/MENATaxHub/_api/web/lists/getByTitle('Newsletter')/items?$select=Title,DisplayOrder,ThumbNail,File/Name&$expand=File&$orderby=DisplayOrder desc";
var requestHeaders = { accept: 'application/json;odata=verbose' };
var fileRoot = 'https://sites.ey.com/sites/MENATaxHub/Newsletter/';
var Communications = function (_a) {
    var onShowHome = _a.onShowHome;
    var _b = react__WEBPACK_IMPORTED_MODULE_0__.useState(true), loading = _b[0], setLoading = _b[1];
    var _c = react__WEBPACK_IMPORTED_MODULE_0__.useState([]), items = _c[0], setItems = _c[1];
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
        window.scrollTo(0, 0);
        var loadingTimer = window.setTimeout(function () { return setLoading(false); }, 2000);
        var getDoclib = function () { return __awaiter(void 0, void 0, void 0, function () {
            var response, data, error_1, message;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 3, , 4]);
                        return [4 /*yield*/, fetch(requestUri, { headers: requestHeaders })];
                    case 1:
                        response = _a.sent();
                        if (!response.ok) {
                            throw new Error("".concat(response.status, " ").concat(response.statusText));
                        }
                        return [4 /*yield*/, response.json()];
                    case 2:
                        data = _a.sent();
                        if (data.d.results.length > 0) {
                            setItems(data.d.results);
                        }
                        return [3 /*break*/, 4];
                    case 3:
                        error_1 = _a.sent();
                        message = error_1 instanceof Error ? error_1.message : String(error_1);
                        window.console.error('Unable to load archived communications:', message);
                        return [3 /*break*/, 4];
                    case 4: return [2 /*return*/];
                }
            });
        }); };
        void getDoclib();
        return function () { return window.clearTimeout(loadingTimer); };
    }, []);
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "communications-page" },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("style", null, communicationsStyles),
        loading && react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "loading-container" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-wrapper" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "webPart" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid nav-container" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row nav-bar" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "EYlogo", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/EY_logo.png", alt: "EY logo" }),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "logoTxt" }, "MENA Tax Hub"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "navbarMenu" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#", onClick: function (event) { event.preventDefault(); onShowHome(); } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "home", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home.png", alt: "Home" })))))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 bannerBackground" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid cnt-fdr" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "cf6" }, "MENA Tax archived communications"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-4 c57" })))))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid tabContent" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { id: "divParent", className: "row" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "communications-list" }, items.map(function (value, index) { var _a, _b, _c; return index > 2 && react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", { key: "".concat(value.Title, "-").concat(index) },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: { backgroundImage: "url(".concat((_a = value.ThumbNail) === null || _a === void 0 ? void 0 : _a.Url, ")"), marginRight: '10px' } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "".concat(fileRoot).concat(((_b = value.File) === null || _b === void 0 ? void 0 : _b.Name) || ''), target: "_blank", rel: "noreferrer" }, value.Title),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "".concat(fileRoot).concat(((_c = value.File) === null || _c === void 0 ? void 0 : _c.Name) || ''), target: "_blank", rel: "noreferrer", className: "pName" }, "READ MORE"))); }))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "footer" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "\u00A9 2026 EYGM Limited. All rights reserved.")))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Communications);


/***/ }),

/***/ 21:
/*!****************************************************************!*\
  !*** ./lib/webparts/menaTaxHub/components/EYIDocumentation.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

var eyiDocStyles = "\nhtml,\nbody {\n    overflow-x: hidden !important;\n    font-family: EYInterstate;\n}\n\n::-moz-selection {\n    color: #ffffff;\n    background: #27ACAA;\n}\n\n::selection {\n    color: #ffffff;\n    background: #27ACAA;\n}\n\nbody::-webkit-scrollbar {\n    display: none;\n}\n\nbody {\n    -ms-overflow-style: none;\n    scrollbar-width: none;\n    position: relative;\n}\n\n.bannerBackground {\n    background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/img_baner.jpg);\n    background-color: #2e2e38;\n    background-size: 100%;\n    background-position-y: -9vw;\n    height: 29vw;\n    position: relative;\n    background-attachment: fixed;\n    padding: 0px;\n}\n\n.bn_left {\n    -ms-flex: 0 0 71%;\n    flex: 0 0 71%;\n    max-width: 71%;\n    padding-top: 3vw;\n    padding-left: 6vw;\n}\n\n.bn_right {\n    background: rgba(26, 26, 36, .5);\n    height: 23vw;\n    -ms-flex: 0 0 29%;\n    flex: 0 0 29%;\n    max-width: 29%;\n    padding: 1vw 2vw;\n}\n\nimg.topShade {\n    position: absolute;\n    top: -17vw;\n    left: -10%;\n    width: 120%;\n}\n\nimg.cf-7 {\n    width: 21vw;\n}\n\n.EYlogo {\n    width: 3vw;\n    position: absolute;\n    left: 5vw;\n    top: 1.5vw;\n}\n\n.bvx_1 {\n    background: rgba(255, 255, 255, .12);\n    width: 8vw;\n    padding: 1vw 1vw;\n    float: left;\n    min-height: 5vw;\n    margin-right: 1vw;\n    text-align: center;\n    position: relative;\n    margin-top: 2vw;\n    -webkit-transition: all .3s ease-in-out;\n    -moz-transition: all .3s ease-in-out;\n    -o-transition: all .3s ease-in-out;\n    transition: all .3s ease-in-out;\n}\n\n.bvx_1:hover {\n    background: rgba(255, 255, 255, .3);\n}\n\n.bvx_1 p {\n    color: #ffffff;\n    font-size: 1vw;\n    margin: 0;\n    position: absolute;\n    top: 50%;\n    left: 50%;\n    transform: translate(-50%, -50%);\n    line-height: 1.3vw;\n}\n\n.cd-3 {\n    padding: 1vw 2vw;\n    border-right: .01vw solid #595959;\n}\n\n.cd-4 {\n    border: hidden;\n}\n\n.c7_fluid {\n    min-height: 18vw;\n    background: #2e2e38;\n    padding: 3vw 5vw;\n    background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);\n    background-size: cover;\n    background-position: center;\n    background-attachment: fixed;\n}\n\n.cv-6 {\n    width: 2.5vw;\n}\n\n.cv-7 {\n    color: #ffffff;\n    font-size: .9vw;\n    line-height: 1.4vw;\n    margin-bottom: 0;\n    margin-top: 1vw;\n}\n\np.logoTxt {\n    color: #ffffff;\n    font-size: 2vw;\n    position: absolute;\n    left: 11vw;\n    top: 2.2vw;\n}\n\n.nav-bar {\n    position: relative;\n    z-index: 999;\n    background: #2e2e38;\n    min-height: 6vw;\n    width: 100%;\n    margin: 0;\n}\n\nul.navbarMenu {\n    position: absolute;\n    right: 6vw;\n    top: 2.4vw;\n    font-family: EYInterstate;\n}\n\nul.navbarMenu li {\n    display: inline-block;\n    font-size: 1vw;\n    color: #ffffff;\n}\n\nul.navbarMenu li a {\n    color: #ffffff;\n    text-decoration: none;\n    padding: 0vw 2vw;\n}\n\nimg.home {\n    width: 1.3vw;\n}\n\n.hd1 {\n    color: #ffffff;\n    font-size: 1.5vw;\n    width: 50%;\n    line-height: 2.2vw;\n    font-family: EYinterstate;\n}\n\n.hd2 {\n    color: #ffffff;\n    font-size: 1vw;\n    width: 80%;\n    display: block;\n    margin: 0;\n    line-height: 1.4vw;\n}\n\n.row-2 {\n    margin-top: 23vw;\n    padding-left: 5vw;\n}\n\n.footerTab {\n    background: #1a1a24;\n    padding: 5vw;\n}\n\na.qLInk {\n    color: #ffffff;\n    font-family: EYInterstate;\n    font-size: 1vw;\n    font-weight: lighter;\n    border: .1vw dashed #9f9f9f;\n    padding: 0.5vw 1.6vw;\n    border-radius: .2vw;\n    margin-right: .7vw;\n    text-decoration: none;\n    float: left;\n    -webkit-transition: all .2s ease-in-out;\n    -moz-transition: all .2s ease-in-out;\n    -o-transition: all .2s ease-in-out;\n    transition: all .2s ease-in-out;\n    margin-bottom: .8vw;\n    width: 24%;\n    text-align: center;\n    margin-bottom: 1vw;\n    position: relative;\n    min-height: 4vw;\n}\n\n.sp_no {\n    position: absolute;\n    background: rgb(255 255 255 / 12%);\n    width: 1.7vw;\n    height: 1.7vw;\n    border-radius: 100vw;\n    line-height: 0;\n    padding-top: .8vw;\n    font-size: 0.7vw;\n    top: 50%;\n    transform: translate(0%, -50%);\n    left: 1vw;\n}\n\na.qLInk:hover {\n    background: rgba(255, 255, 255, .2)\n}\n\n.quicklinks {\n    color: #ffffff;\n    font-size: 1.6vw;\n    margin-bottom: 2vw;\n}\n\na.qLInk span {\n    position: absolute;\n    top: 50%;\n    left: 50%;\n    transform: translate(-50%, -50%);\n    width: 60%;\n}\n\n.footer {\n    background-color: #000000;\n    float: left;\n    width: 100%;\n}\n\n.footer p {\n    margin-bottom: 0px;\n    color: #ffffff;\n    font-size: 1vw;\n    padding: 1vw 2vw;\n    text-align: right;\n}\n\n.navToggle {\n    display: none;\n}\n\n.modal-dialog {\n    width: 60%;\n    max-width: 60%;\n}\n\niframe {\n    border: hidden;\n}\n\n.modal-content {\n    background: transparent;\n}\n\n.col-sm-bx {\n    width: 100%;\n    background: #ffffff0f;\n    min-height: 7.5vw;\n    position: relative;\n    background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);\n    background-size: cover;\n    background-position: center;\n    box-shadow: 0vw 0vw 1.5vw rgba(0, 0, 0, .44);\n}\n\n.img-bx {\n    min-height: 100%;\n    position: absolute;\n    left: 0;\n    top: 0;\n    width: 37%;\n    background-position: center;\n    background-size: 160%;\n    -webkit-transition: all .2s ease-in-out;\n    -moz-transition: all .2s ease-in-out;\n    -o-transition: all .2s ease-in-out;\n    transition: all .2s ease-in-out;\n}\n\n.col-sm-bx:hover .img-bx {\n    background-size: 190%;\n}\n\n.col-sm-bx span {\n    color: rgba(255, 255, 255, 0.522);\n    position: absolute;\n    right: 1vw;\n    bottom: .3vw;\n    font-size: 2vw;\n    font-weight: bold;\n    opacity: 0.3;\n}\n\np.bx-link {\n    color: #ffffff;\n    font-size: 1vw;\n    position: absolute;\n    left: 45%;\n    top: 2.6vw;\n    line-height: 1.4vw;\n    padding-right: 1vw;\n}\n\n.cl-3 {\n    padding: .4vw;\n}\n\n@media only screen and (max-width: 1200px) {\n    .cnt-fdr {\n        position: static;\n    }\n\n    .cnt-fdr {\n        padding: 35px 70px;\n    }\n\n    .quicklinks {\n        font-size: 16px;\n        margin-bottom: 25px;\n    }\n\n    a.qLInk {\n        font-size: 15px;\n        padding: 7px 25px;\n        border-radius: .4vw;\n        margin-bottom: 10px;\n        margin-right: 10px;\n    }\n\n    .footerTab {\n        background: #1a1a24;\n        padding: 60px;\n    }\n\n    .EYlogo {\n        width: 40px;\n        left: 60px;\n        top: 20px;\n    }\n\n    p.logoTxt {\n        font-size: 25px;\n        left: 130px;\n        top: 30px;\n    }\n\n    ul.navbarMenu {\n        right: 50px;\n        top: 25px;\n    }\n\n    ul.navbarMenu li {\n        font-size: 15px;\n    }\n\n    ul.navbarMenu li a {\n        padding: 0vw 20px;\n    }\n\n    img.home {\n        width: 20px;\n    }\n\n    .nav-bar {\n        min-height: 90px;\n    }\n\n    ul.navbarMenu {\n        right: 50px;\n        top: 31px;\n    }\n\n    .footer p {\n        margin-bottom: 0px;\n        color: #ffffff;\n        font-size: 13px;\n        padding: 15px 20px;\n        text-align: right;\n    }\n\n    .hd2 {\n        font-size: 14px;\n        width: 90%;\n        margin: 0;\n        line-height: 19px;\n    }\n\n    .bvx_1 {\n        width: 120px;\n        padding: 10px 10px;\n        min-height: 60px;\n        margin-right: 10px;\n        margin-top: 25px;\n    }\n\n    .bvx_1 p {\n        font-size: 15px;\n        line-height: 17px;\n    }\n\n    .bannerBackground {\n        height: auto;\n        background-size: cover;\n        background-position-y: unset;\n        height: auto;\n        background-position: center;\n    }\n\n    .bn_left {\n        padding-bottom: 50px;\n    }\n\n    .bn_right {\n        height: auto;\n    }\n\n    img.cf-7 {\n        width: 21vw;\n        position: absolute;\n        left: 50%;\n        top: 50%;\n        transform: translate(-50%, -50%);\n    }\n\n    .c7_fluid {\n        min-height: 50px;\n        padding: 46px 55px;\n    }\n\n    .cd-3 {\n        padding: 20px 30px;\n        border-right: 1px solid #595959;\n    }\n\n    .cv-6 {\n        width: 35px;\n    }\n\n    .cv-7 {\n        font-size: 14px;\n        line-height: 21px;\n        margin-bottom: 0;\n        margin-top: 15px;\n    }\n\n    .quicklinks {\n        font-size: 16px;\n        margin-bottom: 25px;\n    }\n\n    a.qLInk {\n        font-size: 15px;\n        padding: 7px 30px;\n        border-radius: .4vw;\n        margin-bottom: 10px;\n        margin-right: 10px;\n        width: 30%;\n        min-height: 60px;\n    }\n\n    .footerTab {\n        background: #1a1a24;\n        padding: 60px;\n    }\n\n    .sp_no {\n        position: absolute;\n        background: rgba(255, 255, 255, 0.12);\n        width: 20px;\n        height: 20px;\n        border-radius: 100vw;\n        line-height: 0;\n        padding-top: 11px;\n        font-size: 12px;\n        left: 19px;\n    }\n\n    a.qLInk span {\n        font-size: 12px;\n    }\n}\n\n@media only screen and (max-width: 992px) {\n    .bn_left {\n        -ms-flex: 0 0 60%;\n        flex: 0 0 60%;\n        max-width: 60%;\n    }\n\n    .bn_right {\n        -ms-flex: 0 0 40%;\n        flex: 0 0 40%;\n        max-width: 40%;\n    }\n\n    img.cf-7 {\n        width: 30vw;\n    }\n\n    .col-sm-3.cd-3 {\n        -ms-flex: 0 0 50%;\n        flex: 0 0 50%;\n        max-width: 50%;\n    }\n\n    .col-sm-3.cd-3:nth-child(even) {\n        border: hidden;\n    }\n\n    p.bx-link {\n        font-size: 13px;\n        left: 45%;\n        top: 20px;\n        line-height: 14px;\n        padding-right: 30px;\n    }\n\n    .col-sm-bx span {\n        right: 10px;\n        bottom: 0px;\n        font-size: 15px;\n        opacity: 0.3;\n    }\n\n    .col-sm-3.cl-3 {\n        -ms-flex: 0 0 33.333%;\n        flex: 0 0 33.333%;\n        max-width: 33.333%;\n    }\n\n    .col-sm-bx {\n        min-height: 70px;\n    }\n\n    .cl-3 {\n        padding: 7px;\n    }\n}\n\n@media only screen and (max-width: 950px) {\n    a.qLInk {\n        width: 48%;\n    }\n}\n\n@media only screen and (max-width: 800px) {\n    .col-sm-4.c57 {\n        -ms-flex: 0 0 100%;\n        flex: 0 0 100%;\n        max-width: 100%;\n    }\n}\n\n@media only screen and (max-width: 750px) {\n    .footerTab {\n        float: left;\n    }\n\n    img.qklinks {\n        display: none;\n    }\n\n    .bn_left {\n        -ms-flex: 0 0 100%;\n        flex: 0 0 100%;\n        max-width: 100%;\n    }\n\n    .bn_right {\n        -ms-flex: 0 0 100%;\n        flex: 0 0 100%;\n        max-width: 100%;\n    }\n\n    img.cf-7 {\n        width: 230px;\n        position: static;\n        left: auto;\n        top: auto;\n        transform: translate(0%, 0%);\n    }\n\n    .bn_right {\n        padding: 40px 20px;\n    }\n\n    .hd1 {\n        font-size: 24px;\n        width: 80%;\n        line-height: 30px;\n    }\n\n    .bn_left {\n        padding: 50px 60px !important;\n    }\n\n    .bvx_1 p {\n        font-size: 15px;\n        line-height: 20px;\n    }\n\n    .col-sm-3.cd-3 {\n        -ms-flex: 0 0 100%;\n        flex: 0 0 100%;\n        max-width: 100%;\n        border: hidden;\n    }\n\n    .footerTab {\n        float: left;\n    }\n\n    .col-sm-3.cl-3 {\n        -ms-flex: 0 0 50%;\n        flex: 0 0 50%;\n        max-width: 50%;\n    }\n}\n\n@media only screen and (max-width: 650px) {\n    a.qLInk {\n        width: 100%;\n        min-height: auto;\n    }\n\n    a.qLInk span {\n        position: static;\n        top: 50%;\n        left: 50%;\n        transform: translate(0%, 0%);\n        width: 60%;\n    }\n\n    .sp_no {\n        display: none;\n    }\n}\n\n@media only screen and (max-width: 575px) {\n    ul.navbarMenu {\n        top: 110px;\n    }\n}\n\n@media only screen and (max-width: 500px) {\n    .col-sm-3.cl-3 {\n        -ms-flex: 0 0 100%;\n        flex: 0 0 100%;\n        max-width: 100%;\n    }\n}\n\n@media only screen and (max-width: 400px) {\n}\n";
var EYIDocumentation = function (_a) {
    var onShowHome = _a.onShowHome;
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("style", null, eyiDocStyles),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "webPart" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid bannerBackground" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row nav-bar" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "EYlogo", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/EY_logo.png", alt: "EY logo" }),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "logoTxt" }, "MENA Tax Hub"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "navbarMenu" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#", onClick: function (event) { event.preventDefault(); onShowHome(); } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "home", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home.png", alt: "Home" })),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "|")),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#quality" }, "Tax Quality"))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "navToggle", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/toggle.png", alt: "Toggle" })),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-9 bn_left" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "hd1" }, "EYI documentation"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "hd2" },
                                "EYI MyDocs is the client engagement filing and document management system for Tax. Global Tax have set a target of 100% adoption across our Global Tax practice - the benefits are clear and known as the 4C's:",
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                " It is also mandated in Global Tax Service Line policy that all tax engagements will use EYI MyDocs for client engagement filing and documentation (other than for Law, which uses iManage)."),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/mydocs-ey?env=Embedded", target: "_blank", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "bvx_1" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "EYI site"))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#mydocs" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "bvx_1" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "MyDocs Minutes")))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 bn_right" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "cf-7", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/circle.png", alt: "Circle" })))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid c7_fluid" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cd-3" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/cv1.png", className: "cv-6", alt: "Consistency" }),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "cv-7" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("b", null, "Consistency:"),
                                " A single, central location to file engagement documents will improve productivity and document management significantly.")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cd-3" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/cv2.png", className: "cv-6", alt: "Collaboration" }),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "cv-7" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("b", null, "Collaboration:"),
                                " Easy to share, edit, review and approve internal and external client documents. EYI MyDocs is being integrated into the EY ecosystem of Tax tools and technologies, including the Global Tax Platform.")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cd-3" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/cv3.png", className: "cv-6", alt: "Compliance" }),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "cv-7" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("b", null, "Compliance:"),
                                " Document management and record retention that complies with EY policies, reduces overall document management risk, including stringent access controls and an engagement close process enabling archiving and destruction of records.")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cd-3 cd-4" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/cv4.png", className: "cv-6", alt: "Exceptional Client Service" }),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "cv-7" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("b", null, "Exceptional Client Service:"),
                                " Maintaining a complete and coherent record of engagement documents is a foundational pillar of exceptional client service, enabling teams to respond to client inquiries quickly.")))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid footerTab" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "quicklinks" }, "Quick links")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cl-3" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://eur01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fsites.ey.com%2Fsites%2Fmydocs-ey%2F%3Fenv%3DEmbedded&data=05%7C01%7CHiran.Jose%40gds.ey.com%7C340686f188cc4bb9665308da97bf29a2%7C5b973f9977df4bebb27daa0c70b8482c%7C0%7C0%7C637989144525267836%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C3000%7C%7C%7C&sdata=90zrXHfrmDlTdbUJA5fQghLz%2BJqP2OfFw%2BU6rcDrOHE%3D&reserved=0", target: "_blank", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/tax.jpg)' } }),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bx-link" }, "EYI MyDocs Landing Page"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "01")))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cl-3" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://eur01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fsites.ey.com%2Fsites%2FDS_Tax%2FPages%2Fglobal-ey-interact-portal.aspx&data=05%7C01%7CHiran.Jose%40gds.ey.com%7C340686f188cc4bb9665308da97bf29a2%7C5b973f9977df4bebb27daa0c70b8482c%7C0%7C0%7C637989144525267836%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C3000%7C%7C%7C&sdata=Wv32spsX5xLKWu9pMFl7c5ZvhD5%2BSrXmdutO01sj6SM%3D&reserved=0", target: "_blank", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: {
                                            backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/gettyimages-1386672473-1024x1024.jpg)'
                                        } }),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bx-link" }, "EYI MyDocs Discover Page"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "02")))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cl-3" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://eur01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fgo.ey.com%2F3jI8FXY&data=05%7C01%7CHiran.Jose%40gds.ey.com%7C340686f188cc4bb9665308da97bf29a2%7C5b973f9977df4bebb27daa0c70b8482c%7C0%7C0%7C637989144525267836%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C3000%7C%7C%7C&sdata=2IeRADsTqm3MnbOktMfg4oanQXZYaqEvoT8cDdgbZyI%3D&reserved=0", target: "_blank", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/tx03.jpg)' } }),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bx-link" }, "Global EYI MyDocs Protocols"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "03")))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cl-3" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://eur01.safelinks.protection.outlook.com/?url=https%3A%2F%2Feyus.sharepoint.com%2Fsites%2FEYInteract&data=05%7C01%7CHiran.Jose%40gds.ey.com%7C340686f188cc4bb9665308da97bf29a2%7C5b973f9977df4bebb27daa0c70b8482c%7C0%7C0%7C637989144525267836%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C3000%7C%7C%7C&sdata=tesdrOYFIByOLzhIL6k8s%2BDknK7%2B3VU8UgYNTAQRlcI%3D&reserved=0", target: "_blank", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/tx04.jpg)' } }),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bx-link" }, "EYI MyDocs Global Help Page"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "04")))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cl-3" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://eur01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fey.service-now.com%2Fey%2F%3Fid%3Dsc_cat_item%26sys_id%3D5f968172dbd1bf488cfd890705961916&data=05%7C01%7CHiran.Jose%40gds.ey.com%7C340686f188cc4bb9665308da97bf29a2%7C5b973f9977df4bebb27daa0c70b8482c%7C0%7C0%7C637989144525267836%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C3000%7C%7C%7C&sdata=w5Y%2FMud6xfTCSFVJWr8uwKMqCnVxekC0zA8edk1rvo0%3D&reserved=0", target: "_blank", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: {
                                            backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/gettyimages-1211353804-2048x2048.jpg)'
                                        } }),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bx-link" }, "EYI Support Form - assistance with IT issues"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "05")))))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "footer" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "\u00A9 2026 EYGM Limited. All rights reserved."))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EYIDocumentation);


/***/ }),

/***/ 936:
/*!*****************************************************************************!*\
  !*** ./lib/webparts/menaTaxHub/components/EngagementLifecycleManagement.js ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

var engagementStyles = "\nhtml, body { overflow-x: hidden !important; font-family: EYInterstate; }\n.engagement-page { background: #2e2e38; color: #ffffff; min-height: 100vh; }\n.engagement-page .container_wrapper { display: block; }\n.engagement-page .bannerBackground { background: #2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/banner.jpg') center / 115% 115%; min-height: 20.6vw; padding: 3vw 11vw 0 0; }\n.engagement-page .nav-bar { background: #2e2e38; min-height: 6vw; position: relative; }\n.engagement-page .EYlogo { left: 5vw; position: absolute; top: 1.5vw; width: 3vw; }\n.engagement-page .logoTxt { color: #ffffff; font-size: 2vw; left: 11vw; position: absolute; top: 2.2vw; }\n.engagement-page .navbarMenu { list-style: none; margin: 0; padding: 0; position: absolute; right: 6vw; top: 2.4vw; }\n.engagement-page .navbarMenu li { display: inline-block; }\n.engagement-page .navbarMenu a { color: #ffffff; text-decoration: none; }\n.engagement-page .home { width: 1.3vw; }\n.engagement-page .hd1 { color: #ffe600; font-size: 3vw; line-height: 3.4vw; margin: 7vw 0 2vw 5vw; }\n.engagement-page .hd1 span { color: #ffffff; display: block; }\n.engagement-page .hd2 { color: #ffffff; font-size: 1vw; line-height: 1.5vw; margin: 0 0 3vw 5vw; }\n.engagement-page .rgt_container { padding: 0; }\n.engagement-page .rgt_c7 { height: 9.4vw; padding: 0; }\n.engagement-page .rgt_c7 a { text-decoration: none; }\n.r01{margin:0px !important;}\n.c47{padding:0px !important;}\n.engagement-page .rg_01, .engagement-page .rg_03, .engagement-page .rg_04, .engagement-page .rg_05 { background: #2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center / cover; height: 100%; position: relative; }\n.rg_01{    background-color: rgb(255 255 255 / 19%) !important;}\n.rg_03{    background-color: rgb(255 255 255 / 19%) !important;}\n.engagement-page .s1 { color: #ffffff; font-size: 1vw; line-height: 1.2vw; left: 2vw; position: absolute; text-align: center; top: 50%; transform: translateY(-50%); width: 13vw; }\n.engagement-page .fg1, .engagement-page .f1y { display: none; }\n    \n.engagement-page .footerTab { background: #1a1a24; padding: 5vw; }\n.engagement-page .quicklinks { color: #ffffff; font-size: 1.3vw; margin-bottom: 2vw; }\n.engagement-page .quickLinksGrid { display: flex; flex-wrap: wrap; }\n.engagement-page .quickLink { flex: 0 0 25%; max-width: 25%; padding: .4vw; }\n.engagement-page .col-sm-bx { background: #ffffff0f url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center / cover; box-shadow: 0 0 1.5vw rgba(0,0,0,.44); min-height: 7.5vw; position: relative; }\n.engagement-page .img-bx { background-position: center; background-size: cover; bottom: 0; left: 0; position: absolute; top: 0; width: 37%; }\n.engagement-page .bx-link { color: #ffffff; font-size: 1vw; left: 45%; line-height: 1.4vw; position: absolute; top: 50%; transform: translateY(-50%); width: 48%; }\n.engagement-page .col-sm-bx span { bottom: .3vw; color: rgba(255,255,255,.52); font-size: 2vw; font-weight: bold; position: absolute; right: 1vw; }\n.engagement-page .footer { background: #000000; }\n.engagement-page .footer p { margin: 0; padding: 1vw 2vw; text-align: right; }\n.engagement-page .engagementModal { align-items: center; background: rgba(0,0,0,.65); display: flex; inset: 0; justify-content: center; overflow-y: auto; padding: 2vw; position: fixed; z-index: 1000000; }\n.engagement-page .engagementModalContent { background: #2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center / cover; box-sizing: border-box; max-height: 94vh; max-width: 90%; overflow-y: auto; padding: 3vw 4vw; position: relative; width: 90%; }\n.engagement-page .closeButton { background: #ffe600; border: 0; color: #000000; cursor: pointer; font-size: 1.5vw; height: 2.2vw; line-height: 1.5vw; padding: 0; position: absolute; right: 1.5vw; top: 1.5vw; width: 2.2vw; z-index: 1; }\n.engagement-page .modalTitle { color: #ffffff; font-size: 2.3vw; font-weight: normal; margin: 0 0 2.5vw; padding-top: .5vw; }\n.engagement-page .keyLinks { float: left;\n    width: 12vw;\n    background: rgba(255, 255, 255, .07);\n    min-height: 12vw;\n    padding: 1.5vw 1.5vw;\n    margin-right: 1.5vw;\n    margin-bottom: 1vw;\n    -webkit-transition: all .15s ease-in-out;\n    -moz-transition: all .2s ease-in-out;\n    -o-transition: all .2s ease-in-out;\n    transition: all .2s ease-in-out;\n    cursor: pointer;\n    margin-right: 0vw !important; }\n.engagement-page .keyLinks + .keyLinks { margin-left: 1.5vw; border:hidden; }\n.engagement-page .keyLinks:hover { background: rgba(255,255,255,.2); }\n.engagement-page .keyLinks img { display: block; height: 4vw; object-fit: contain; width: 4vw; }\n.engagement-page .keyLinks p { color: #ffffff; font-size: 1vw; line-height: 1.3vw; margin: 1vw 0 0; }\n.engagement-page .contactTable { border-collapse: collapse; color: #ffffff; margin-top: 2vw; width: 100%; }\n.engagement-page .contactTable th, .engagement-page .contactTable td { border-top: 1px solid #5e5e5e !important; padding: 1vw 1.2vw; text-align: left; vertical-align: top; padding:1.7vw 0vw; }\n.engagement-page .contactTable th { font-size: 1.1vw; font-weight: normal; }\n.engagement-page .contactTable td { color: #b2b2b2; font-size: .9vw; }\n.engagement-page .contactTable td p { margin: 0; }\n.engagement-page .contactTable a { color: #ffe600; text-decoration: none; }\n.engagement-page .mbaContactsModal { z-index: 1000001; }\n.engagement-page .mbaTable { max-width: 55%; }\n\n@media only screen and (max-width: 800px) { .engagement-page .engagementModal { padding: 20px; } .engagement-page .engagementModalContent { max-width: 100%; padding: 40px 25px 25px; width: 100%; } .engagement-page .closeButton { font-size: 24px; height: 32px; right: 15px; top: 15px; width: 32px; } .engagement-page .modalTitle { font-size: 30px; margin-bottom: 25px; } .engagement-page .keyLinks { min-height: 150px; padding: 15px 20px; width: 30%; } .engagement-page .keyLinks + .keyLinks { margin-left: 1.5%; } .engagement-page .keyLinks img { height: 50px; width: 50px; } .engagement-page .keyLinks p { font-size: 14px; line-height: 16px; margin-top: 15px; } .engagement-page .contactTable { margin-top: 25px; } .engagement-page .contactTable th, .engagement-page .contactTable td { font-size: 14px; padding: 12px; } .engagement-page .mbaContactsModal .engagementModalContent { width: 80%; } .engagement-page .mbaTable { max-width: 100%; } }\n@media only screen and (max-width: 650px) { .engagement-page .keyLinks { display: block; margin: 0 0 10px !important; min-height: auto; width: 100%; } .engagement-page .keyLinks p { margin-bottom: 0; } .engagement-page .contactTable { display: block; overflow-x: auto; white-space: nowrap; } .engagement-page .mbaContactsModal .engagementModalContent { width: 100%; } }\n@media only screen and (max-width: 800px) { .engagement-page .EYlogo { left: 60px; top: 20px; width: 40px; } .engagement-page .logoTxt { font-size: 25px; left: 130px; top: 30px; } .engagement-page .navbarMenu { right: 50px; top: 31px; } .engagement-page .home { width: 20px; } .engagement-page .hd1 { font-size: 40px; line-height: 36px; margin-top: 70px; } .engagement-page .hd2 { font-size: 15px; line-height: 24px; margin-left: 50px; } .engagement-page .quickLink { flex-basis: 50%; max-width: 50%; } }\n@media only screen and (max-width: 500px) { .engagement-page .quickLink { flex-basis: 100%; max-width: 100%; } }\n.engagement-page .footerTab .col-sm-3 {-ms-flex: 0 0 20% !important;\n        flex: 0 0 20% !important;\n        max-width: 20% !important;}\n";
var quickLinks = [
    ['Mercury OneGate', 'https://mercury.ey.net/Pages/default.aspx', 'gettyimages-1334575820-2048x2048.jpg'],
    ['Engagement metrics', 'https://mybusiness.ey.net/', 'gettyimages-892701338-1024x1024.jpg'],
    ['Time utilization report', 'http://www.mybusiness.ey.net/myportal/reporttree.aspx', 'tx01.jpg'],
    ['MDM', 'https://www.mdm.ey.net/bp/search/', 'GettyImages-1255683032.jpg'],
    ['SORT', 'https://sort.ey.net/', 'GettyImages-1051617040.jpg'],
    ['GIS', 'https://gis.ey.net/home/dashboard/search', 'tx04.jpg'],
    ['Global Mercury', 'https://sites.ey.com/sites/GlobalMercurySupport/SitePages/MercuryHome.aspx', 'gettyimages-1332353096-1024x1024.jpg'],
    ['GEAR', 'https://gear.ey.net/GEAR/home/search/quick_actions', 'gettyimages-134887165.jpg'],
    ['GCO SharePoint', 'https://sites.ey.com/sites/MENAGCOSharePoint/SitePages/GCO_home.aspx', 'GettyImages-696570136.jpg'],
    ['EYI documentation', '#eyi', 'GettyImages-1091470486.jpg']
];
var supportContacts = [
    ['MENA Detect Control Support', 'Review planned fee and collect Engagement Agreements for central repository', 'menadetectcontrolsupport@gds.ey.com'],
    ['My Expense', 'Expense claims processing and related queries', 'myexpense@xe04.ey.com'],
    ['MENA Mass Transaction Support', 'Bulk Transfer of Time and Expenses', 'menamasstransaction.support@gds.ey.com'],
    ['MENA IFM Support', 'Accounting support and settlement of IFM invoices', 'mena.ifmsupport@xe04.ey.com'],
    ['Mercury transaction support team', 'Provides assistance to engagement managers', 'menamts@bh.ey.com'],
    ['MENA HRG Accounting Support', 'Accounting support on HRG invoices', 'mena.hrgaccountingsupport@om.ey.com']
];
var mbaContacts = [
    ['Saudi Arabia', 'Taha S Siddiqui'],
    ['Kuwait, Qatar, Oman', 'Shalini George'],
    ['Egypt, Lybia', 'Juli Ceasar'],
    ['Jordan, Saudi Arabia', 'Rand Zarour'],
    ['UAE', 'Sanketh Bhandary']
];
var EngagementLifecycleManagement = function (_a) {
    var onShowHome = _a.onShowHome, onShowPolicies = _a.onShowPolicies, onShowTraining = _a.onShowTraining;
    var _b = react__WEBPACK_IMPORTED_MODULE_0__.useState(false), showContacts = _b[0], setShowContacts = _b[1];
    var _c = react__WEBPACK_IMPORTED_MODULE_0__.useState(false), showMbaContacts = _c[0], setShowMbaContacts = _c[1];
    var imageRoot = 'https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/';
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "engagement-page" },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("style", null, engagementStyles),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "loading-container", style: { display: 'none' } },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container_wrapper" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "webPart" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid nav-container" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row nav-bar" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "EYlogo", src: "".concat(imageRoot, "EY_logo.png"), alt: "EY logo" }),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "logoTxt" }, "MENA Tax Hub"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "navbarMenu" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#", onClick: function (event) { event.preventDefault(); onShowHome(); } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "home", src: "".concat(imageRoot, "home.png"), alt: "Home" })))))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-10 bannerBackground" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "hd1" },
                                "Engagement Lifecycle ",
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "Management")),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "hd2" },
                                "The opportunity and engagement lifecycle is a framework that describes how we sell, plan and deliver the work we do for our clients. It runs end-to-end, from managing contacts and pursuits, to creating, delivering and closing an engagement.",
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("b", null, "As part of this, the emphasis is on two main roles:"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                "1. Your accountability: With Mercury, you will remain accountable for managing the performance of your client engagements, from creating an opportunity through to completing the resulting engagement. You can also manage your engagements independently in Mercury, which gives you more autonomy, and better visibility of your opportunities and engagements.",
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                "2. Partnership with Finance: You will have an enhanced partnership with the Finance team, who will provide guidance and advice on how best to manage your engagement and maximize margins.")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-2 c47" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid rgt_container" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row r01" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 rgt_c7" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#policies", onClick: function (event) { event.preventDefault(); onShowPolicies === null || onShowPolicies === void 0 ? void 0 : onShowPolicies(); } },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "rg_01" },
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "s1" },
                                                    "Policies",
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                                    "and procedures")))),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 rgt_c7" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#training", onClick: function (event) { event.preventDefault(); onShowTraining === null || onShowTraining === void 0 ? void 0 : onShowTraining(); } },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "rg_05" },
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "s1" }, "My Training")))),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 rgt_c7", role: "button", tabIndex: 0, onClick: function () { return setShowContacts(true); }, onKeyPress: function (event) { if (event.key === 'Enter' || event.key === ' ')
                                            setShowContacts(true); } },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "rg_03" },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "s1" },
                                                "Connect with a Support",
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                                "Advisor"))),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 rgt_c7" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "rg_04" },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "s1" },
                                                "Role of Market, Finance",
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                                "and MBAs",
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { style: { fontSize: '0.7vw', opacity: .6 } }, "(Coming soon)"))))))))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid footerTab" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "quicklinks" }, "Quick links")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" }, quickLinks.map(function (link, index) { return react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cl-3", key: link[0] },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: link[1], target: "_blank", rel: "noreferrer" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: { backgroundImage: "url(".concat(imageRoot).concat(link[2], ")") } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bx-link" }, link[0]),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, index < 9 ? "0".concat(index + 1) : index + 1)))); }))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "footer" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "\u00A9 2026 EYGM Limited. All rights reserved.")))),
        showContacts && react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "engagementModal", role: "dialog", "aria-modal": "true", "aria-labelledby": "support-modal-title", onClick: function () { return setShowContacts(false); } },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "engagementModalContent", onClick: function (event) { return event.stopPropagation(); } },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { type: "button", className: "closeButton", onClick: function () { return setShowContacts(false); }, "aria-label": "Close" }, "\u00D7"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("h2", { className: "modalTitle", id: "support-modal-title" }, "Key point of contacts"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: "keyLinks", href: "https://eyt.service-now.com/", target: "_blank", rel: "noreferrer" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(imageRoot, "service.png"), alt: "" }),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "Raise a Service Now request from this website")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: "keyLinks", href: "tel:88888", target: "_blank", rel: "noreferrer" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(imageRoot, "phone.png"), alt: "" }),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "Call MBA via Teams by dialling 88888")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { type: "button", className: "keyLinks", onClick: function () { return setShowMbaContacts(true); } },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(imageRoot, "contact.png"), alt: "" }),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "Specific MBAs for respective locations and SSL"))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("table", { className: "contactTable" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("thead", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", { scope: "col" }, "Team name"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", { scope: "col" }, "Action"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", { scope: "col" }, "Email"))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("tbody", null, supportContacts.map(function (contact) { return react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", { key: contact[0] },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, contact[0])),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, contact[1])),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "mailto:".concat(contact[2]) }, contact[2])))); }))))),
        showMbaContacts && react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "engagementModal mbaContactsModal", role: "dialog", "aria-modal": "true", "aria-labelledby": "mba-modal-title", onClick: function () { return setShowMbaContacts(false); } },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "engagementModalContent", onClick: function (event) { return event.stopPropagation(); } },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { type: "button", className: "closeButton", onClick: function () { return setShowMbaContacts(false); }, "aria-label": "Close" }, "\u00D7"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("h2", { className: "modalTitle", id: "mba-modal-title" }, "Specific MBAs for respective locations and SSL"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("table", { className: "contactTable mbaTable" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("thead", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", { scope: "col" }, "Country"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", { scope: "col" }, "Name of MBA"))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("tbody", null, mbaContacts.map(function (contact) { return react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", { key: contact[0] },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, contact[0]),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, contact[1])); })))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EngagementLifecycleManagement);


/***/ }),

/***/ 522:
/*!***************************************************!*\
  !*** ./lib/webparts/menaTaxHub/components/GDS.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

var gdsStyles = "\n  html,\n  body {\n      overflow-x: hidden !important;\n      font-family: EYInterstate;\n  }\n\n  .container_wrapper {\n      display: none;\n  }\n\n  ::-moz-selection {\n      color: #ffffff;\n      background: #27ACAA;\n  }\n\n  ::selection {\n      color: #ffffff;\n      background: #27ACAA;\n  }\n\n  body::-webkit-scrollbar {\n      display: none;\n  }\n\n  .loading-container {\n      position: relative;\n      position: fixed;\n      z-index: 9999;\n      background: #1a1a24;\n      width: 100%;\n      height: 100vh;\n      margin: auto;\n  }\n\n  .loading-container .item {\n      position: absolute;\n      top: 50%;\n      left: 50%;\n      transform: translate(-50%, -50%);\n      border: .2vw solid #ffe600;\n      border-radius: 50%;\n      border-top-color: transparent;\n      border-bottom-color: transparent;\n      animation: spin 2s ease infinite;\n  }\n\n  .loading-container .item:nth-child(1) {\n      width: 30px;\n      height: 30px;\n  }\n\n  .loading-container .item:nth-child(2) {\n      width: 50px;\n      height: 50px;\n      animation-delay: 0.1s;\n  }\n\n  .loading-container .item:nth-child(3) {\n      width: 70px;\n      height: 70px;\n      animation-delay: 0.2s;\n  }\n\n  .loading-container .item:nth-child(4) {\n      width: 90px;\n      height: 90px;\n      animation-delay: 0.3s;\n  }\n\n  @keyframes spin {\n      50% {\n          transform: translate(-50%, -50%) rotate(180deg);\n      }\n      100% {\n          transform: translate(-50%, -50%) rotate(0deg);\n      }\n  }\n\n  body {\n      -ms-overflow-style: none;\n      scrollbar-width: none;\n      position: relative;\n  }\n\n  .bannerBackground {\n      background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Offshore-GDS.png);\n      background-color: #2e2e38;\n      background-size: cover !important;\n      background-position: center;\n      position: relative;\n      background-attachment: unset !important;\n      animation: none !important;\n      padding: 0px;\n  }\n\n  .cnt-fdr {\n      min-height: 17vw;\n  }\n\n  .tabCol {\n      padding: 2vw 2vw 1vw 6vw;\n  }\n\n  span.s1-cg {\n      font-size: 1.4vw;\n      color: #ffffff;\n      display: block;\n      width: 100%;\n      padding: 1vw 0vw 0.6vw 0vw;\n      margin-top: 2vw;\n      margin-bottom: 0.5vw;\n      border: hidden;\n      line-height: 1.9vw;\n  }\n\n  .vid-parent {\n      padding-right: 0px;\n  }\n\n  hr.hr {\n      margin-top: 0vw;\n      margin-bottom: 0vw;\n      border: 0;\n      border-top: .11vw solid #ffe600;\n      width: 3vw;\n      display: block;\n  }\n\n  hr.hr1 {\n      margin-left: .1vw;\n  }\n\n  .tab-left {\n      background-color: #2e2e38;\n      background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/gettyimages-607638780-1024x102.png);\n      background-position: center;\n      background-size: cover;\n      overflow: hidden;\n      position: relative;\n      padding: 0px;\n  }\n\n  .left-1 {\n      position: absolute;\n      right: -1vw;\n      top: -2vw;\n      width: 22vw;\n      transform: rotate(90deg);\n  }\n\n  .left-2 {\n      position: absolute;\n      left: -1vw;\n      bottom: -2vw;\n      width: 22vw;\n      transform: rotate(0deg);\n  }\n\n  .quicklink-Head {\n      color: #ffffff;\n      font-size: 2vw;\n      font-family: arial;\n  }\n\n  .quicklink-Head img {\n      width: 2.5vw;\n      margin-right: 0.4vw;\n  }\n\n  ul.ul-links {\n      list-style: none;\n      padding-left: 0;\n      color: #ffffff;\n      font-size: 1.2vw;\n      font-family: arial;\n  }\n\n  ul.ul-links li {\n      width: 50%;\n      float: left;\n      margin: 0;\n      padding: .5vw .5vw;\n  }\n\n  ul.ul-links li a {\n      color: #ffffff !important;\n      text-decoration: none !important;\n  }\n\n  ul.ul-links li span {\n      background: #ffffff17;\n      padding: 2vw 4vw;\n      height: 9vw;\n      text-align: center;\n      font-size: 1vw;\n      line-height: 1.2vw;\n      display: block;\n      transition: all .6s ease-in-out;\n  }\n\n  ul.ul-links li span img {\n      width: 2.3vw;\n      display: block;\n      position: relative;\n      left: 50%;\n      transform: translate(-50%, -20%);\n      margin-bottom: 0.2vw;\n      transition: all .6s ease-in-out;\n  }\n\n  .box-quicklinks {\n      position: absolute;\n      top: 50%;\n      left: 50%;\n      transform: translate(-50%, -50%);\n      width: 85%;\n  }\n\n  ul.ul-links li:hover span img {\n      transform: translate(-50%, -20%) rotateY(180deg);\n  }\n\n  ul.ul-links li:hover span {\n      background: #ffffff47;\n  }\n\n  .col-06 {\n      background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/GettyImages-1460853312-1.png);\n      background-position: center;\n      background-size: cover;\n      background-color: #2e2e38;\n  }\n\n  span.s1-cf {\n      font-size: 1.4vw;\n      color: #ffffff;\n      display: block;\n      width: 100%;\n      padding: 0vw 0vw;\n      margin-top: 2vw;\n      margin-bottom: 0.7vw;\n      border: hidden;\n  }\n\n  .s1-cf-1 {\n      text-align: center;\n      font-size: 2vw !important;\n      margin-bottom: 0vw !important;\n      font-family: arial;\n  }\n\n  .tab-col {\n      padding: 1vw 2vw 0vw 6vw;\n  }\n\n  .tmp3 {\n      color: #ffffff;\n      font-size: .8vw;\n      text-align: center;\n      width: 100%;\n      padding: 0vw 10% 1vw 10%;\n  }\n\n  .TmBox {\n      height: 15vw;\n  }\n\n  .col-sm-12.sm-tm-5 {\n      margin-top: 0px;\n  }\n\n  .cf6 {\n      color: #ffffff;\n      width: 100%;\n      font-size: 2vw;\n      padding: 0;\n      margin-bottom: 0;\n      float: left;\n      border-bottom: hidden;\n      padding-bottom: 3px;\n      margin-left: 1vw;\n      width: 100%;\n      margin-bottom: 0.3vw;\n      margin-top: 5vw;\n  }\n\n  hr.hrt {\n      margin-top: 0vw;\n      margin-bottom: 0vw;\n      border: 0;\n      border-top: .2vw solid #ffe600;\n      width: 3vw;\n      display: block;\n      margin-left: 1.2vw;\n  }\n\n  .accordion {\n      color: #ffffff;\n      width: 100%;\n  }\n\n  .accordion .card {\n      border: none;\n      margin-bottom: 0px;\n      background: transparent;\n  }\n\n  .accordion .card h2 {\n      background-size: 1.5vw;\n      cursor: pointer;\n      font-size: 1.3vw;\n      margin-bottom: .6vw !important;\n      background-position: 95% 0.3vw;\n      color: #ffe600;\n  }\n\n  .accordion .card-body {\n      padding-left: 0;\n      padding-right: 0;\n  }\n\n  .CollapsibleText {\n      font-size: 1vw;\n      font-family: arial;\n      line-height: 1.5vw;\n      color: #ffffff;\n  }\n\n  .tc-col {\n      background: #00000017;\n      min-height: auto;\n      border-bottom: .1vw solid #363636;\n  }\n\n  li strong {\n      color: #ffe600;\n  }\n\n  ul.cf-u li {\n      margin-bottom: .6vw !important\n  }\n\n  ul.cf-u1 li {\n      margin-top: 1.1vw !important;\n  }\n\n  .tabCol ul.ul_01 {\n      padding-left: 2vw;\n  }\n\n  col:nth-child(odd) {\n      background: #ffffff12;\n  }\n\n  col:nth-child(even) {\n      background: #ffffff2b;\n  }\n\n  td {\n      height: 80px;\n      padding: 2vw 1vw;\n  }\n\n  table {\n      color: #ffffff;\n      font-size: .9vw;\n      text-align: center;\n      line-height: 1.1vw;\n      margin-left: 2.5%;\n      width: 95%;\n      border: .1vw solid #ffffff24;\n      margin-top: 1vw;\n      margin-top: 3.5vw;\n      position: relative;\n      overflow: hidden;\n  }\n\n  tr.rowOne {\n      border-bottom: .1vw solid #ffffff1c;\n  }\n\n  td {\n      border-right: .1vw solid #ffffff1c;\n  }\n\n  tr.rowOne td {\n      padding: 1vw 1vw;\n  }\n\n  td {\n      padding: 1vw 1vw;\n      position: relative;\n      overflow: visible;\n  }\n\n  td::after {\n      background: rgba(255, 255, 255, 0) !important;\n      content: \"\";\n      height: 500%;\n      left: 0;\n      position: absolute;\n      top: -200%;\n      width: 100%;\n      z-index: 1;\n      transition: all .6s ease-in-out;\n  }\n\n  td:hover::after {\n      background: rgb(255 255 255 / 32%) !important;\n      content: \"\";\n      height: 500%;\n      left: 0;\n      position: absolute;\n      top: -200%;\n      width: 100%;\n      z-index: 1;\n  }\n\n  li i {\n      color: #ffe600;\n      font-size: .9vw;\n  }\n\n  iframe.vg-1 {\n      width: 100%;\n      height: 30vw;\n  }\n\n  .cv-g {\n      padding: 3vw 7vw;\n  }\n\n  .ft-g {\n      color: #ffffff;\n      font-size: 1.3vw;\n      text-align: center;\n      margin-bottom: 2vw;\n  }\n\n  .ft-g span {\n      font-size: 1vw;\n      color: #ffe600;\n  }\n\n  ul.navbarMenu li {\n      font-size: .9vw;\n  }\n\n  ul.navbarMenu li img {\n      width: 1vw;\n      margin-right: .5vw;\n  }\n\n  ul.navbarMenu li a {\n      padding: 0vw .5vw;\n  }\n\n  strong.strong {\n      font-size: 1vw;\n      display: block;\n      line-height: 1vw;\n      margin-bottom: -1.5vw;\n      font-weight: 100 !important;\n  }\n\n  .EYlogo {\n      width: 3vw;\n      position: absolute;\n      left: 5vw;\n      top: 1.5vw;\n  }\n\n  p.logoTxt {\n      color: #ffffff;\n      font-size: 2vw;\n      position: absolute;\n      left: 11vw;\n      top: 2.2vw;\n  }\n\n  img.home {\n      width: 1.3vw;\n  }\n\n  ul.navbarMenu {\n      position: absolute;\n      right: 6vw;\n      top: 2.4vw;\n      font-family: EYInterstate;\n  }\n\n  ul.navbarMenu li {\n      display: inline-block;\n      font-size: 1vw;\n      color: #ffffff;\n  }\n\n  ul.navbarMenu li a {\n      color: #ffffff;\n      text-decoration: none;\n      padding: 0vw 2vw;\n  }\n\n  .nav-bar {\n      position: relative;\n      z-index: 999;\n      background: #2e2e38;\n      min-height: 6vw;\n      width: 100%;\n      margin: 0;\n  }\n\n  .nav-container {\n      padding: 0px;\n  }\n\n  .footer {\n      background-color: #000000;\n      float: left;\n      width: 100%;\n  }\n\n  .footer p {\n      margin-bottom: 0px;\n      color: #ffffff;\n      font-size: 1vw;\n      padding: 1vw 2vw;\n      text-align: right;\n  }\n\n  .container-fluid {\n      max-width: 100%;\n  }\n\n  .webPart {\n      background: #2e2e38;\n      color: #ffffff;\n  }\n\n  .tabContent {\n      background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);\n      background-position: center;\n      background-size: cover;\n      background-attachment: fixed;\n      background-color: #2e2e38;\n  }\n\n  .tabCol ul.ul_01 {\n      color: #ffffff;\n      font-size: 1vw;\n      list-style: none;\n      padding: 0;\n      margin: 0;\n      font-family: EYInterstate;\n      font-weight: lighter;\n  }\n\n  .tabCol ul.ul_01 li {\n      position: relative;\n      padding-left: 1.5vw;\n      margin-bottom: 1.7vw;\n  }\n\n  .tabCol ul.ul_01 li::before {\n      content: \"\";\n      background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/arrow_png.png);\n      position: absolute;\n      width: 0.7vw;\n      height: 0.6vw;\n      background-size: contain;\n      background-repeat: no-repeat;\n      margin-top: 0.4vw;\n      left: 0;\n  }\n\n  .accordion .card h2 {\n      background-size: 1.5vw;\n      cursor: pointer;\n      font-size: 1.3vw;\n      margin-bottom: .6vw !important;\n      background-position: 95% 0.3vw;\n      color: #ffe600;\n  }\n\n  .card {\n      border: none;\n      margin-bottom: 0px;\n      background: transparent;\n  }\n\n  .card-body {\n      padding-left: 0;\n      padding-right: 0;\n  }\n\n  .tmImg {\n      background: #000000;\n      width: 5.5vw;\n      height: 5.5vw;\n      border-radius: 100vw;\n      position: relative;\n      left: 50%;\n      transform: translate(-50%, 0);\n      top: 1.5vw;\n      overflow: hidden;\n  }\n\n  .tmImg img {\n      width: 105%;\n      position: absolute;\n      left: 50%;\n      top: 50%;\n      transform: translate(-50%, -50%);\n  }\n\n  .tmName {\n      font-size: .9vw;\n      font-family: EYInterstate;\n      text-align: center;\n      margin-top: 2.5vw;\n      margin-bottom: 0;\n      color: #ffe600;\n  }\n\n  .tmp2 {\n      font-size: 0.9vw;\n      text-align: center;\n      margin-top: -0.1vw;\n      color: #ffffff;\n      font-weight: bold;\n      margin-bottom: 0.5vw;\n  }\n\n  .cf {\n      background: rgb(255 255 255 / 6%);\n      min-height: 13vw;\n  }\n\n  .col-sm-12.sm-tm-5 {\n      -ms-flex: 0 0 16.6666%;\n      flex: 0 0 16.6666%;\n      max-width: 16.6666%;\n      padding: 0vw 0.4vw;\n      padding-bottom: 0.8vw;\n      margin-top: 2vw;\n  }\n\n  @media only screen and (max-width: 1200px) {\n      .cf6 {\n          font-size: 30px;\n          margin-bottom: 0;\n      }\n      .tabCol {\n          padding: 50px 70px;\n      }\n      .tabCol ul.ul_01 {\n          font-size: 14px;\n      }\n      .tabCol ul.ul_01 li::before {\n          width: 15px;\n          height: 8px;\n          margin-top: 6px;\n          left: 0;\n      }\n      .tabCol ul.ul_01 li {\n          position: relative;\n          padding-left: 17px;\n          margin-bottom: 10px;\n      }\n      span.s1-cf {\n          font-size: 18px;\n          border-top: 1px solid #ffffff63;\n          border-bottom: 1px solid #ffffff63;\n          padding: 11px 15px;\n      }\n      .col-sm-12.sm-tm-5 {\n          padding: 0vw 4px;\n          margin-top: 8px;\n          padding-bottom: 0;\n          -ms-flex: 0 0 160px;\n          flex: 0 0 160px;\n          max-width: 160px;\n      }\n      .tmImg {\n          width: 56px;\n          height: 56px;\n          top: 24px;\n          overflow: hidden;\n      }\n      .tmName {\n          font-size: 13px;\n          margin-top: 28px;\n          line-height: 13px;\n          margin-bottom: 3px;\n      }\n      .tmp2 {\n          font-size: 11px;\n          margin-top: 0px;\n          margin-bottom: 5px;\n      }\n      .cf {\n          min-height: 160px;\n          max-height: 160px;\n      }\n  }\n\n  @media only screen and (max-width: 800px) {\n      .tabCol {\n          padding: 50px 30px;\n      }\n  }\n";
var GDS = function (_a) {
    var onShowHome = _a.onShowHome;
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("style", null, gdsStyles),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "webPart" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid nav-container" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row nav-bar" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "EYlogo", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/EY_logo.png", alt: "EY Logo" }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "logoTxt" }, "MENA Tax Hub"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "navbarMenu" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#", onClick: function (e) { e.preventDefault(); if (onShowHome)
                                    onShowHome(); }, style: { cursor: 'pointer' } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home.png", alt: "Home", className: "home" })))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 bannerBackground" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid cnt-fdr" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "cf6" }, "GDS"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("hr", { className: "hrt" }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-4 c57" })))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid tabContent" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row tabCol tc-col" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "CollapsibleText" }, "GDS continues to be a strategic enabler for MENA. Global KPIs are driving increasing consumption of hours."),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "accordion", id: "accordionExample" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "card" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("h2", { className: "mb-0" }, "Key Considerations:"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { id: "collapseOne", className: "collapse show", "aria-labelledby": "headingOne", "data-parent": "#accordionExample" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "card-body" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "vid-parent" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "ul_01 u2 cf-u" },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Utilization of onshore resources against capacity and rank utilization expectations "),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Utilization of sponsored GDS FTE and Rapid pool against expectations "),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Is this within your SSL financial plan for GDS hours? "),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Internal promotion/ progression opportunities "),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Is a type of skills needed available onshore or within the existing GDS FTE pool "),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "GDS T&M to be considered on a case-by-case basis after factoring in the current capacity and Skill set of the GDS FTE sponsored pool ")))))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "card" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("h2", { className: "mb-0" }, "What happens next?"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { id: "collapseOne", className: "collapse show", "aria-labelledby": "headingOne", "data-parent": "#accordionExample" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "card-body" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "vid-parent" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "ul_01 u2 cf-u" },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                                "Carry out an assessment of your current state using the ",
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://app.powerbi.com/groups/me/apps/88b138f5-216c-4ac6-b72a-a19e005bd381/reports/224a0ea2-bd8c-4441-b136-31641b8a8103/ReportSectionbd6d72f0b28d653ff863?ctid=5b973f99-77df-4beb-b27d-aa0c70b8482c&experience=power-bi", target: "_blank", rel: "noreferrer" }, " Tax People Dashboard"),
                                                ", ",
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://app.powerbi.com/groups/me/apps/88b138f5-216c-4ac6-b72a-a19e005bd381/reports/db646e19-5e24-4e38-accc-9a8c2e8743e9/ReportSection?ctid=5b973f99-77df-4beb-b27d-aa0c70b8482c&chromeless=1&experience=power-bi", target: "_blank", rel: "noreferrer" }, " Finance & Engagement Dashboard "),
                                                " and the FTE demand plan for the current FY "),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                                "If your request aligns with the FY FTE plan and the considerations above, you may proceed with raising a resource request on the ",
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://apps.powerapps.com/play/e/a3c669f6-ac2e-4e77-ad43-beab3e15bee7/a/a422fad2-0a90-4117-b14b-3da399c77b75?tenantId=5b973f99-77df-4beb-b27d-aa0c70b8482c&sourcetime=1721291017599&hidenavbar=true", target: "_blank", rel: "noreferrer" }, " MENA Tax Hiring Tool")),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Your request would be routed through EXM (Experience Management), SSL leader and COO for approval "),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Once fully approved, the EXM team will raise the request through the GDS Gateway tool."),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Typical turnaround time for approval is between 2- 4 business days "),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "For requests that do not meet the requirements, please connect with your respective EXM contact for any additional information and guidance on the optimal approach to fulfil your requirement ")))))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "card" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("h2", { className: "mb-0" }, "Cost components:"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { id: "collapseOne", className: "collapse show", "aria-labelledby": "headingOne", "data-parent": "#accordionExample" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "card-body" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "vid-parent" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "ul_01 u2 cf-u" },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                                " Cost of the offshore resources will be guided by the GDS rate cards for both FTE and T&M resources available ",
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/GlobalPlanningOperations/GDS%20FY25%20Rate%20Cards/Forms/AllItems.aspx", target: "_blank", rel: "noreferrer" }, " here")),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                                "FTE yearly cost (GDS rate card) Note:",
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("i", null, " *For GDS FTE resources, it is the responsibility of the hiring manager to ensure target utilization is achievable for the entire duration of the agreement.")),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "T&M hourly cost (GDS rate card)"),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Out of pocket expenses- this will apply for onsite MENA deployments. An example is illustrated below:")))))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "card" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("h2", { className: "mb-0" }, "Out-of-pocket expenses (this will apply for onsite MENA deployments)."),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { id: "collapseOne", className: "collapse show", "aria-labelledby": "headingOne", "data-parent": "#accordionExample" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "card-body" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "vid-parent" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "ul_01 u2 cf-u" },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Travel OPE Cost Estimation - EXAMPLE ")))))))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("table", { className: "ck-table-resized" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("colgroup", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("col", { style: { width: '5%' } }),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("col", { style: { width: '5%' } }),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("col", { style: { width: '5%' } }),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("col", { style: { width: '6.24%' } }),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("col", { style: { width: '6.25%' } }),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("col", { style: { width: '6.67%' } }),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("col", { style: { width: '6.67%' } }),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("col", { style: { width: '6.67%' } }),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("col", { style: { width: '6.67%' } }),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("col", { style: { width: '6.67%' } }),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("col", { style: { width: '6.67%' } }),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("col", { style: { width: '6.67%' } }),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("col", { style: { width: '7.43%' } }),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("col", { style: { width: '7.6%' } }),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("col", { style: { width: '7.01%' } })),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("tbody", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", { className: "rowOne" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { style: { height: '28.2pt', width: '62pt' } }, "Country"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { style: { width: '62pt' } }, "Visa Type"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { style: { width: '62pt' } }, "Entry"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { style: { width: '62pt' } }, "Visa Cost"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { style: { width: '62pt' } }, "Flight Cost (Round trip)"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { style: { width: '62pt' } }, "Hotel Cost"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { style: { width: '62pt' } }, "Sim Card"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { style: { width: '62pt' } }, "Telephone Expenses (monthly)"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { style: { width: '62pt' } }, "Airport Transfers (both ways)"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { style: { width: '62pt' } }, "Additional Baggage"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { style: { width: '62pt' } }, "Taxi Expenses"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { style: { width: '62pt' } }, "Per Diem"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { style: { width: '62pt' } }, "Duration"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { style: { width: '62pt' } }, "Cost per resource (1st month)"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { style: { width: '62pt' } }, "Next Time Travel (per month)")),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "KSA (Riyadh)"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "Work Permit"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "Multiple"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "$ 800"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "$ 600"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "$ 130"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "$ 50"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "$ 25"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "$ 100"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "$ 200"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "$ 40"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "$ 70"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "$ 30"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "$ 9,025"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "$ 8,175"))))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row cv-g" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-6" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "ft-g" },
                            "FTE",
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", { className: "strong" }, " Active until 1st October 2024"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, " (India/Kerala)")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("iframe", { className: "e_a_866d546b vg-1", frameBorder: "0", tabIndex: 0, src: "https://sites.ey.com/sites/MENAEXM-TestSite/_layouts/15/embed.aspx?UniqueId=8b61dbf6-1ccb-4702-b232-989e19db0c09&client_id=FileViewerWebPart&showNewWindow=true&embed=%7B%22af%22%3Afalse%2C%22p%22%3A1%2C%22z%22%3A%22width%22%7D&auth=readwrite", title: "Embedded document", role: "document", style: { visibility: 'visible' } })),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-6" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "ft-g" },
                            " T&M ",
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", { className: "strong" }, " Active until 1st October 2024"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "(India, Philippines, Argentina, Poland, Hungary and Spain)")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("iframe", { className: "e_a_866d546b vg-1", frameBorder: "0", tabIndex: 0, src: "https://sites.ey.com/sites/MENAEXM-TestSite/_layouts/15/embed.aspx?UniqueId=c93295a7-ef55-4e16-a848-0a5862bf74f6&client_id=FileViewerWebPart&showNewWindow=true&embed=%7B%22af%22%3Afalse%2C%22p%22%3A1%2C%22z%22%3A%22width%22%7D&auth=readwrite", title: "Embedded document", role: "document", style: { visibility: 'visible' } }))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row tabCol trs-padding" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "s1-cf", style: { marginTop: '0px' } }, "Meet The Team"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("hr", { className: "hr ht" })),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 sm-tm-5 " },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "cf " },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "TmBox " },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "tmImg " },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Dileep-Rajasekhar.png", alt: "Dileep Rajasekhar" })),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmName " }, "Dileep Rajasekhar"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmp2 " }, "Assistant Director")))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 sm-tm-5 " },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "cf " },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "TmBox " },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "tmImg " },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/ellen-M-Jose.png", alt: "Jellen M Jose" })),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmName " }, "Jellen M Jose"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmp2 " }, " Assistant Director"))))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row " },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "footer " },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "\u00A9 2026 EYGM Limited. All rights reserved.")))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GDS);


/***/ }),

/***/ 664:
/*!********************************************************!*\
  !*** ./lib/webparts/menaTaxHub/components/Homepage.js ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};

var requestAccessWebUrl = 'https://sites.ey.com/sites/MENATaxHub';
var homepageStyles = "\nhtml,\nbody {\noverflow-x: hidden !important;\nfont-family: EYInterstate;\n}\n\n\n/* .container_wrapper{display: none;} */\n\n::-moz-selection {\ncolor: #ffffff;\nbackground: #27ACAA;\n}\n\n::selection {\ncolor: #ffffff;\nbackground: #27ACAA;\n}\n\n\n/* Hide scrollbar for Chrome, Safari and Opera */\n\nbody::-webkit-scrollbar {\ndisplay: none;\n}\n\n\n/*loading*/\n\n.loading-container {\nposition: relative;\nposition: fixed;\nz-index: 9999;\nbackground: #1a1a24;\nwidth: 100%;\nheight: 100vh;\nmargin: auto;\n}\n\n.loading-container .item {\nposition: absolute;\ntop: 50%;\nleft: 50%;\ntransform: translate(-50%, -50%);\nborder: .2vw solid #ffe600;\nborder-radius: 50%;\nborder-top-color: transparent;\nborder-bottom-color: transparent;\nanimation: spin 2s ease infinite;\n}\n\n.loading-container .item:nth-child(1) {\nwidth: 30px;\nheight: 30px;\n}\n\n.loading-container .item:nth-child(2) {\nwidth: 50px;\nheight: 50px;\nanimation-delay: 0.1s;\n}\n\n.loading-container .item:nth-child(3) {\nwidth: 70px;\nheight: 70px;\nanimation-delay: 0.2s;\n}\n\n.loading-container .item:nth-child(4) {\nwidth: 90px;\nheight: 90px;\nanimation-delay: 0.3s;\n}\n\n@keyframes spin {\n50% {\ntransform: translate(-50%, -50%) rotate(180deg);\n}\n100% {\ntransform: translate(-50%, -50%) rotate(0deg);\n}\n}\n\n\n/*loading*/\n\nbody {\n-ms-overflow-style: none;\n/* IE and Edge */\nscrollbar-width: none;\nposition: relative;\n/* Firefox */\n}\n\n.col-sm-8.bannerBackground {\n-ms-flex: 0 0 80%;\nflex: 0 0 80%;\nmax-width: 80%;\n}\n\n.col-sm-4.c47 {\n-ms-flex: 0 0 20%;\nflex: 0 0 20%;\nmax-width: 20%; padding:0px !important;\n}\n\n.bannerBackground {\nbackground-color: #2e2e38e0;\nbackground-size: 115% 115%;\nbackground-position: center center;\nposition: relative;\nbackground-attachment: fixed;\nanimation: shrink 20s infinite alternate;\npadding: 0px;\n}\n\n.quote_div {\nmin-height: 27.6vw;\nbackground-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/quote.jpg);\nbackground-size: cover;\nbackground-position: center;\npadding: 0vw 3vw 2vw 5vw;\n}\n\nimg.qtIcon {\nwidth: 2.5vw;\npadding-top: 7.5vw;\nmargin-bottom: 1vw;\n}\n\n.quoteTxt {\nfont-family: none;\ncolor: #ffffff;\nfont-size: 1.5vw;\nline-height: 1.9vw;\nwidth: 35vw;\n}\n\n@keyframes shrink {\n0% {\nbackground-size: 115% 115%;\n}\n100% {\nbackground-size: 100% 100%;\n}\n}\n\n.nav-bar {\nposition: relative;\nz-index: 999;\nbackground: #2e2e38;\nmin-height: 6vw;\nwidth: 100%;\nmargin: 0;\n}\n\n.nav-container {\npadding: 0px;\n}\n.c01 {padding:0px;}\n.r01{margin:0px !important;}\n.profileDes {\n    float: left;\n    width: 10vw;\n    text-align: left;\n    margin-left: 1vw;\n    margin-top: 0.7vw;\n}\n    .pName {\n    color: #ffffff;\n    font-size: .9vw;\n    font-family: EYInterstate;\n    margin: 1vw 0vw 0vw 0vw;\n}\n    .pDes {\n    color: #ffe600;\n    font-size: .8vw;\n    font-family: EYInterstate;\n    margin: 0vw 0vw 0vw 0vw;\n}\n.EYlogo {\nwidth: 3vw;\nposition: absolute;\nleft: 5vw;\ntop: 1.5vw;\n}\n\np.logoTxt {\ncolor: #ffffff;\nfont-size: 2vw;\nposition: absolute;\nleft: 11vw;\ntop: 2.2vw;\n}\n\nimg.home {\nwidth: 1.3vw;\n}\n\nul.navbarMenu {\nposition: absolute;\nright: 6vw;\ntop: 2.4vw;\nfont-family: EYInterstate;\n}\n\nul.navbarMenu li {\ndisplay: inline-block;\nfont-size: 1vw;\ncolor: #ffffff;\n}\n\nul.navbarMenu li a {\ncolor: #ffffff;\ntext-decoration: none;\npadding: 0vw 2vw;\n}\n\n.hd1 {\ncolor: #ffe600;\nfont-size: 2.5vw;\nline-height: 2.4vw;\nfont-family: EYinterstate;\nmargin-top: 3vw;\nmargin-left: 4vw;\n}\n\n.hd1 span {\ncolor: #ffffff;\n}\n\n.hd2 {\ncolor: #ffffff;\nfont-size: 1vw;\nwidth: 100%;\ndisplay: block;\nmargin-left: 4vw;\npadding-right: 5vw;\nmargin-bottom: 3vw;\n}\n\n.bt-txt {\nmargin: 0;\nbackground: #2e2e38e0;\npadding: 2.4vw 3vw 1vw 5vw;\nbackground-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);\nbackground-size: cover;\nbackground-attachment: fixed;\n}\n\n.m-bg {\nmin-height: 25vw;\nbackground-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/qlty.jpg);\nbackground-position: center;\nbackground-size: cover;\n}\n\n.m-lft {\nbackground-color: rgba(255, 255, 255, 0.1);\nbackground-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/wavebg.png);\nbackground-size: cover;\nbackground-position: center;\npadding: 2vw 2vw;\nmin-height: 14.5vw;\nheight: 100%;\npadding-right: 1vw;\n}\n\n.col-sm-12.m-6 {\nmin-height: 1vw;\npadding: 1vw 1vw;\ntext-align: center;\nmargin-top: 0vw;\nmargin-bottom: 0;\nheight: auto;\npadding-top: 0px;\n}\n\n.m3.col-sm-12.m-6 {\npadding-top: 3vw;\n}\n\n.col-sm-12.m-6 .m-lft {\npadding: 3vw 0vw;\nmin-height: 10vw;\nheight: auto;\npadding-right: 0vw;\nposition: relative;\nmargin-top: 0vw;\n}\n\n.col-sm-12.m-6 .m-lft img {\nwidth: 100%;\n}\n\n.m-6 {\noverflow: hidden;\npadding: 0vw 1vw;\n}\n\n.m-6.m0-6 {\npadding-right: .5vw;\n}\n\n.m-6.m1-6 {\npadding-left: .5vw;\n}\n\n.pr_hd {\ncolor: #ffffff;\nfont-size: 1.3vw;\nfont-family: EYInterstate;\nline-height: 1.6vw;\nmargin: 0;\nmargin-bottom: 1vw;\n}\n\n.col-sm-12.m-6 .m-lft .pr_hd {\nmargin-bottom: 0vw;\n}\n\n.pr_hd span {\ncolor: #ffe600;\nfont-size: 2vw;\n}\n\n.col-sm-12.m-6 .m-lft .pr_hd span {\nfont-size: 1.3vw;\ncolor: #ffe600;\n}\n\n.pr_txt {\ncolor: #ffffff;\nfont-size: .9vw;\nmargin-bottom: .5vw;\nmargin-top: 1vw;\nline-height: 1.2vw;\nwidth: 100%;\n}\n\n.img-bg {\nbackground-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/img_0p.jpg);\nbackground-size: cover;\n}\n\n.c4a7 {\ncolor: #ffffff !important;\nfont-size: .9vw;\ntext-decoration: none !important;\nmargin-bottom: 0px;\n}\n\np.m_btn {\nbackground: #ffffff;\nfont-size: .9vw;\nfont-family: EYInterstate;\npadding: 0.6vw 1vw;\nmargin-bottom: 0;\nmargin-top: 2vw;\nwidth: 7vw;\ntext-align: center;\n}\n\np.m_btn a {\ncolor: #000000;\ntext-decoration: none;\n}\n\n.rgt_container {\npadding: 0px;\n}\n\n.m-row {\npadding: 0vw 0vw;\nbackground: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/GettyImages-1327611460_edited.jpg);\nbackground-position: center;\nbackground-size: cover;\nbackground-attachment: fixed;\n}\n\n.left-0 {\nbackground: rgba(255, 255, 255, .10);\nmin-height: 20vw;\nbackground-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/wavebg.png);\nbackground-size: cover;\nbackground-position: center;\npadding: 1vw 4vw .5vw 5vw;\n-ms-flex: 0 0 40%;\nflex: 0 0 40%;\nmax-width: 40%;\n}\n\n.left-0 img {\nwidth: 100%;\n}\n\n.key-c7 {\ncolor: #ffe600 !important;\nfont-size: .8vw;\ndisplay: block;\nmargin-bottom: -1vw;\nmargin-top: 0.5vw;\ntext-decoration: none !important;\n}\n\n.fy7 {\nwidth: 8vw;\nheight: 84%;\nposition: absolute;\nleft: .8vw;\ntop: .8vw;\nbackground-size: cover;\nbackground-position: right;\nopacity: 0.9;\n}\n\n.news_1 {\nbackground: rgba(255, 255, 255, 0.1);\npadding: 1.5vw 1.5vw;\nmargin-top: 0;\nmargin-bottom: 1vw;\n-webkit-transition: all .2s ease-in-out;\n-moz-transition: all .2s ease-in-out;\n-o-transition: all .2s ease-in-out;\ntransition: all .2s ease-in-out;\npadding-left: 10vw;\nposition: relative;\nmin-height: 8.4vw;\n}\n\n.news_1:hover {\nbackground: rgba(255, 255, 255, 0.2);\n}\n\n.right-0 {\npadding: 1vw .5vw 0vw .5vw;\n-ms-flex: 0 0 60%;\nflex: 0 0 60%;\nmax-width: 60%;\n}\n\np.s1 {\ncolor: #ffffff;\nfont-size: 1vw;\nline-height: 1.3vw;\nwidth: 11vw;\nposition: absolute;\nleft: 5vw;\nmargin-bottom: 0vw;\ntop: 50%;\ntransform: translate(0%, -50%);\ntext-align: center;\n}\n\n\n/* .rgt_c7 {\nheight: 5.89vw;\npadding: 0vw;\n} */\n\n.rgt_c7 {\nheight: 4.58vw !important;\npadding: 0vw;\n}\n\n.rgt_c7 a {\ntext-decoration: none !important;\n}\n\n.rg_01 {\nbackground-color: rgb(255 255 255 / 13%);\nbackground-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);\nbackground-size: cover;\nbackground-position: center;\nheight: 100%;\nwidth: 100%;\n-webkit-transition: all .2s ease-in-out;\n-moz-transition: all .2s ease-in-out;\n-o-transition: all .2s ease-in-out;\ntransition: all .2s ease-in-out;\nposition: relative;\noverflow: hidden;\n}\n\n.rg_02 {\nbackground-color: #2e2e38;\nbackground-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);\nbackground-size: cover;\nbackground-position: center;\nheight: 100%;\nwidth: 100%;\n-webkit-transition: all .2s ease-in-out;\n-moz-transition: all .2s ease-in-out;\n-o-transition: all .2s ease-in-out;\ntransition: all .2s ease-in-out;\nposition: relative;\noverflow: hidden;\n}\n\n.rg_03 {\nbackground-color: rgb(255 255 255 / 13%);\nbackground-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);\nbackground-size: cover;\n;\nbackground-position: center;\nheight: 100%;\nwidth: 100%;\nbackground-repeat: no-repeat;\n-webkit-transition: all .2s ease-in-out;\n-moz-transition: all .2s ease-in-out;\n-o-transition: all .2s ease-in-out;\ntransition: all .2s ease-in-out;\nposition: relative;\noverflow: hidden;\n}\n\n.rg_04 {\nbackground-color: #2e2e38;\nbackground-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);\nbackground-size: cover;\nbackground-position: center;\nheight: 100%;\nwidth: 100%;\n-webkit-transition: all .2s ease-in-out;\n-moz-transition: all .2s ease-in-out;\n-o-transition: all .2s ease-in-out;\ntransition: all .2s ease-in-out;\nposition: relative;\noverflow: hidden;\n}\n\n.rg_05 {\nbackground-color: rgb(255 255 255 / 13%);\nbackground-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);\nbackground-size: cover;\nbackground-position: center;\nheight: 100%;\nwidth: 100%;\nbackground-repeat: no-repeat;\n-webkit-transition: all .2s ease-in-out;\n-moz-transition: all .2s ease-in-out;\n-o-transition: all .2s ease-in-out;\ntransition: all .2s ease-in-out;\nposition: relative;\noverflow: hidden;\n}\n\n.rg_06 {\nbackground-color: #2e2e38;\nbackground-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);\nbackground-size: cover;\nbackground-position: center;\nheight: 100%;\nwidth: 100%;\n-webkit-transition: all .2s ease-in-out;\n-moz-transition: all .2s ease-in-out;\n-o-transition: all .2s ease-in-out;\ntransition: all .2s ease-in-out;\nposition: relative;\noverflow: hidden;\n}\n\n.rg_07 {\nbackground-color: rgb(255 255 255 / 13%);\nbackground-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);\nbackground-size: cover;\nbackground-position: center;\nheight: 100%;\nwidth: 100%;\nbackground-repeat: no-repeat;\n-webkit-transition: all .2s ease-in-out;\n-moz-transition: all .2s ease-in-out;\n-o-transition: all .2s ease-in-out;\ntransition: all .2s ease-in-out;\nposition: relative;\noverflow: hidden;\n}\n\n.rg_08 {\nbackground-color: #2e2e38;\nbackground-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);\nbackground-size: cover;\nbackground-position: center;\nheight: 100%;\nwidth: 100%;\n-webkit-transition: all .2s ease-in-out;\n-moz-transition: all .2s ease-in-out;\n-o-transition: all .2s ease-in-out;\ntransition: all .2s ease-in-out;\nposition: relative;\noverflow: hidden;\n}\n\n\n/* .rg_01:hover,\n.rg_02:hover,\n.rg_04:hover {\nbackground-size: 190%;\n}\n\n.rg_03:hover {\nbackground-size: 190%;\n}\n.rg_05:hover {\nbackground-size: 190%;\n}\n.rg_06:hover {\nbackground-size: 190%;\n} */\n\n.archived {\nbackground: #ffe600;\ncolor: #000000 !important;\nfont-size: 1vw;\npadding: .5vw 1vw;\nfloat: right;\nmargin-bottom: 0.5vw;\nmargin-top: 0vw;\ntext-decoration: none !important;\nbackground: linear-gradient(to right, #ffe600 50%, #ffffff 50%);\nbackground-size: 200% 100%;\nbackground-position: left bottom;\n-webkit-transition: all .6s ease-in-out;\n-moz-transition: all .6s ease-in-out;\n-o-transition: all .6s ease-in-out;\ntransition: all .6s ease-in-out;\n}\n\n.archived img {\nwidth: 1.3vw;\nmargin-right: .5vw;\n}\n\n.archived:hover {\nbackground-position: right bottom;\n}\n\n.rs-01:hover {\nbackground-color: #000000 !important;\n}\n\n.f1y {\nwidth: 100%;\nposition: absolute;\nheight: 180%;\ntransform: rotate(180deg);\ntop: -1px;\ndisplay: none;\n}\n\n.boxContent span {\ncolor: #ffe600;\nfont-size: 1.2vw;\nmargin-right: .3vw;\nfont-weight: bold;\n}\n\n.boxContent p {\ncolor: #ffffff;\nfont-size: .9vw;\nline-height: 1.3vw;\nfont-family: EYInterstate;\nfont-weight: lighter;\n}\n\n.boxContent p b {\nfont-size: 1.2vw;\nline-height: 2.5vw;\n}\n\n.desc {\nbackground: #2e2e38e0;\npadding: 9vw 9vw 6vw 9vw;\nbackground-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);\nbackground-size: cover;\nbackground-attachment: fixed;\ndisplay: none;\n}\n\n.boxContent img {\nwidth: 3vw;\nmargin-bottom: .4vw;\n}\n\nimg.fg1 {\nwidth: 2vw;\nposition: absolute;\nleft: 2vw;\ntop: 50%;\ntransform: translate(0%, -50%);\ndisplay: none;\n}\n\np.c4 {\ncolor: #ffffff;\nfont-size: 1vw;\nfont-family: EYInterstate;\nline-height: 1.3vw;\nmargin-bottom: 0.8vw;\n}\n\nul.c5 {\ncolor: #ffffff;\nlist-style: none;\npadding: 0;\n}\n\nul.c5 li {\nposition: relative;\npadding-left: 1.3vw;\nmargin-bottom: 0.6vw;\nfont-size: 1vw;\n}\n\nul.c5 li::before {\ncontent: \"\";\nbackground-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/arrow_icon.png);\nposition: absolute;\nwidth: .6vw;\nheight: .6vw;\nbackground-size: contain;\nbackground-repeat: no-repeat;\ntop: 0.5vw;\nleft: 0;\n}\n\nhr.c8 {\nmargin-top: 2vw;\nmargin-bottom: 3vw;\nborder: 0;\nborder-top: .01vw solid rgb(116 116 116);\n}\n\n.hotNews {\nbackground: #ffe600;\nwidth: 6vw;\nmargin-bottom: -.6vw;\nz-index: 1;\n}\n\n.hotNews img {\nwidth: 1.6vw;\npadding: 0.2vw 0.1vw 0.3vw 0.5vw;\n}\n\n.hotNews span {\ncolor: #000000;\nfont-size: .8vw;\npadding: 0vw 0.3vw;\n}\n\n.footerTab {\nbackground: #1a1a24;\npadding: 5vw;\n}\n\na.qLInk {\ncolor: #ffffff;\nfont-family: EYInterstate;\nfont-size: 1vw;\nfont-weight: lighter;\nborder: .1vw dashed #9f9f9f;\npadding: 0.5vw 1.6vw;\nborder-radius: .2vw;\nmargin-right: .7vw;\ntext-decoration: none;\nfloat: left;\n-webkit-transition: all .2s ease-in-out;\n-moz-transition: all .2s ease-in-out;\n-o-transition: all .2s ease-in-out;\ntransition: all .2s ease-in-out;\nmargin-bottom: .8vw;\nwidth: 24%;\ntext-align: center;\nmargin-bottom: 1vw;\nposition: relative;\nmin-height: 3vw;\n}\n\n.sp_no {\nposition: absolute;\nbackground: rgb(255 255 255 / 12%);\nwidth: 1.7vw;\nheight: 1.7vw;\nborder-radius: 100vw;\nline-height: 0;\npadding-top: .8vw;\nfont-size: 0.7vw;\ntop: 50%;\ntransform: translate(0%, -50%);\nleft: 1vw;\n}\n\na.qLInk:hover {\nbackground: rgba(255, 255, 255, .2)\n}\n\n.quicklinks {\ncolor: #ffffff;\nfont-size: 1.3vw;\nmargin-bottom: 2vw;\n}\n\nimg.qklinks {\nwidth: 1.4vw;\nmargin-top: -0.2vw;\nmargin-right: .4vw;\n}\n\na.qLInk span {\nposition: absolute;\ntop: 50%;\nleft: 50%;\ntransform: translate(-50%, -50%);\nwidth: 60%;\n}\n\n\n/*WEbAnimation*/\n\n.footer {\nbackground-color: #000000;\nfloat: left;\nwidth: 100%;\n}\n\n.footer p {\nmargin-bottom: 0px;\ncolor: #ffffff;\nfont-size: 1vw;\npadding: 1vw 2vw;\ntext-align: right;\n}\n\n.navToggle {\ndisplay: none;\n}\n\n.modal-dialog{max-width:50%;}\n.modal-content{padding:0px !important;}\n/**/\n\n.footerTab {\nbackground: #1a1a24;\npadding: 5vw;\n}\n\n.quicklinks {\ncolor: #ffffff;\nfont-size: 1.3vw;\nmargin-bottom: 2vw;\n}\n\n.col-sm-bx {\nwidth: 100%;\nbackground: #ffffff0f;\nmin-height: 7.5vw;\nposition: relative;\nbackground-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);\nbackground-size: cover;\nbackground-position: center;\nbox-shadow: 0vw 0vw 1.5vw rgba(0, 0, 0, .44);\n}\n\n.img-bx {\nmin-height: 100%;\nposition: absolute;\nleft: 0;\ntop: 0;\nwidth: 37%;\nbackground-position: center;\nbackground-size: 160%;\n-webkit-transition: all .2s ease-in-out;\n-moz-transition: all .2s ease-in-out;\n-o-transition: all .2s ease-in-out;\ntransition: all .2s ease-in-out;\n}\n\n.col-sm-bx:hover .img-bx {\nbackground-size: 190%;\n}\n\n.col-sm-bx span {\ncolor: rgba(255, 255, 255, 0.522);\nposition: absolute;\nright: 1vw;\nbottom: .3vw;\nfont-size: 2vw;\nfont-weight: bold;\nopacity: 0.3;\n}\n\np.bx-link {\ncolor: #ffffff;\nfont-size: 1vw;\nposition: absolute;\nleft: 45%;\ntop: 2.6vw;\nline-height: 1.4vw;\n}\n\n.cl-3 {\npadding: .4vw;\n}\n\n\n/*contacts*/\n\n.col-sm-12.sm-tm-5 {\n-ms-flex: 0 0 16.6666%;\nflex: 0 0 16.6666%;\nmax-width: 16.6666%;\npadding: 0vw 0.8vw;\npadding-bottom: 1.6vw;\ntext-align: center;\n}\n\n.cf {\nbackground: rgb(255 255 255 / 6%);\nmin-height: 16vw;\n}\n\n.tmImg {\nbackground: #ffe600;\nwidth: 5.5vw;\nheight: 5.5vw;\nborder-radius: 100vw;\nposition: relative;\nleft: 50%;\ntransform: translate(-50%, 0);\ntop: 1.5vw;\noverflow: hidden;\n}\n\n.tmImg img {\nwidth: 100%;\n}\n\n.m1 {\nfloat: left;\ntext-align: left;\nfont-size: 1.5vw;\nline-height: 1.9vw;\nmargin: 0;\nborder-right: .1vw solid #000000;\npadding: 1.9vw 1vw;\nwidth: 31%;\ncolor: #000000;\nmin-height: 8vw;\n}\n\n.m2 {\ntext-align: left;\nfont-size: 1vw;\nline-height: 1.4vw;\npadding: 0vw 0.4vw 1vw 1.4vw;\nfloat: left;\nwidth: 65%;\nmargin: 0;\ncolor: #000000;\n}\n\n.m-lft.m0 {\nbackground: #ffffff;\nfloat: left;\npadding-right: 1vw !important;\n}\n.menuButton{width: auto;\n    height: auto;\n    padding: 0.6vw;\n    right: 1vw;\n    top: 2vw}\n.m-lft.m0 a {\ncolor: #ffffff !important;\nfont-size: .9vw;\ntext-decoration: none !important;\nbackground: #2e2e38;\npadding: 0.5vw 1vw;\nwidth: 11vw;\nfloat: right;\nmargin-right: 1vw;\nmargin-top: .5vw;\n}\n\n.m-lft.m0 a.b1 {\ntop: 10vw;\nright: 2vw;\ncursor: pointer;\n}\n\n.m-lft.m0 a.b2 {\ntop: 7vw;\nright: 2vw;\n}\n\n.n-b1 {\nmin-height: 0vw !important;\n}\n\n\n/**/\n\n.tmShare {\nfloat: left;\nposition: relative;\nleft: 50%;\ntransform: translate(-50%, 0%);\n}\n\n.Ic0 {\nwidth: 1.4vw;\nfloat: left;\n}\n\n.Ic2 {\nwidth: 1.4vw;\nfloat: left;\nmargin-left: 0.8vw;\n}\n\n.tmProfile {\nfont-size: 0.8vw;\ntext-align: center;\nmargin-top: -0.1vw;\nmargin-bottom: 1vw;\ncolor: #ffffff;\n}\n\n.tmName {\nfont-size: 1vw;\nfont-family: EYInterstate;\ntext-align: center;\nmargin-top: 2.5vw;\nmargin-bottom: 0;\ncolor: #ffe600;\n}\n\n.modal-dialog.modal-dialog-centered.carousel-dialog {\nmax-width: 80%;\n}\n#newsModalThree .modal-dialog.modal-dialog-centered.carousel-dialog {\nmax-width: 31vw;\n}\n\n.homepageModal {\ndisplay: flex !important;\nposition: fixed;\ninset: 0;\nz-index: 1000000;\nbackground: rgba(0, 0, 0, .65);\nalign-items: center;\njustify-content: center;\n}\n\n.homepageModal .modal-dialog {\nmargin: 1rem;\nwidth: 100%;\n}\n\n.homepageModal .modal-content {\nposition: relative;\n}\n\n.homepageModalClose {\nposition: absolute;\nright: .75rem;\ntop: .4rem;\nz-index: 1;\nborder: 0;\nbackground: transparent;\ncolor: #000000;\nfont-size: 2rem;\nline-height: 1;\ncursor: pointer;\n}\n\n.videoModalContent {\nbackground: #000000;\nmax-width: 900px;\npadding: 2rem;\n}\n\n.videoModalContent video {\ndisplay: block;\nwidth: 100%;\n}\n\n#newsModalThree .modal-dialog .modal-content {\nborder-radius: 0\n}\n\n#newsModalThree .modal-dialog .modal-content .modal-body {\npadding: 2vw 2vw;\n}\n\n.form-group {\ntext-align: left;\n}\n\n.form-group label {\nfont-size: .9vw;\nmargin-bottom: 0.2vw;\n}\n\n.form-control {\nmin-height: 3vw;\nborder-radius: 0;\nmargin-bottom: .5vw;\nfont-size: .9vw;\n}\n\n.btn-primary {\nbackground-color: #ffe600;\nborder-color: #ffe600;\ncolor: #000000;\nwidth: 100%;\nborder-radius: 0;\nmargin-top: 1vw;\npadding: 0.6vw 1vw;\nfont-size: 1.1vw;\n}\n\n.form-control::placeholder {\n/* Chrome, Firefox, Opera, Safari 10.1+ */\nopacity: 0.3;\n/* Firefox */\n}\n\n.form-control:-ms-input-placeholder {\n/* Internet Explorer 10-11 */\nopacity: 0.3;\n}\n\n.form-control::-ms-input-placeholder {\n/* Microsoft Edge */\nopacity: 0.3;\n}\n\n\n/**/\n\nimg.speakerIcon {\nwidth: 5vw !important;\nposition: absolute;\nleft: 11vw;\ntop: 2vw;\n}\n\np.subText {\nfont-size: .9vw;\nposition: absolute;\nleft: 1vw;\nbottom: 1vw;\ncolor: #155CB4;\n}\n\n.cf-7 {\nposition: relative;\ndisplay: block;\nmargin-bottom: 1vw;\n}\n.r02{margin:0px !important;}\n\n/* .cf-7:nth-child(2):before */\n\n.cf-7:nth-child(1):before {\ncontent: \"\";\nbackground-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/latest-icon.png);\nwidth: 6vw;\nheight: 1.8vw;\nposition: absolute;\ntop: -.8vw;\nleft: 0;\nbackground-size: 5vw;\nz-index: 1;\nbackground-repeat: no-repeat;\nbackground-color: #ffe600;\nbackground-position: center;\n}\n\n#divNews {\nmargin-top: 2vw;\n}\n\n@media only screen and (max-width: 1200px) {\n .col-sm-8.bannerBackground {\n-ms-flex: 0 0 100%;\nflex: 0 0 100%;\nmax-width: 100%;\n }\n .cnt-fdr {\nposition: static;\n }\n .col-sm-4.c47 {\n-ms-flex: 0 0 100%;\nflex: 0 0 100%;\nmax-width: 100%;\n }\n .col-sm-6.rgt_c7 {\n-ms-flex: 0 0 25%;\nflex: 0 0 25%;\nmax-width: 25%;\n }\n .hd1 {\nfont-size: 30px;\nline-height: 35px;\nmargin-top: 60px;\nmargin-left: 50px;\nmargin-bottom: 15px;\n }\n .hd2 {\nfont-size: 15px;\nmargin-bottom: 50px;\npadding-left: 50px;\npadding-right: 50px;\nmargin-left: auto;\n }\n .boxContent img {\nwidth: 50px;\nmargin-bottom: 10px;\n }\n .boxContent p {\ncolor: #ffffff;\nfont-size: 13px;\nline-height: 19px;\n }\n .boxContent span {\nfont-size: 16px;\nmargin-right: 7px;\n }\n .boxContent p b {\nfont-size: 16px;\nline-height: 25px;\n }\n .cnt-fdr {\npadding: 35px 40px;\n }\n p.s1 {\nfont-size: 16px;\nline-height: 20px;\nleft: 20px;\nbottom: 20px;\nwidth: auto;\n }\n .rg_01 {\nbackground-size: cover;\n }\n .rg_02 {\nbackground-size: cover;\n }\n .rg_03 {\nbackground-size: cover;\n }\n .rg_04 {\nbackground-size: cover;\n }\n .bt-txt {\npadding: 50px 50px;\n }\n ul.c5 li {\npadding-left: 20px;\nmargin-bottom: 12px;\nfont-size: 17px;\n }\n ul.c5 li::before {\nwidth: 12px;\nheight: 12px;\ntop: 7px;\nleft: 0;\n }\n p.c4 {\nfont-size: 20px;\nline-height: 26px;\nmargin-bottom: 15px;\n }\n .pg1 {\nfont-size: 25px;\nmargin-bottom: 10px;\npadding-top: 50px;\n }\n .pg2 {\nfont-size: 18px;\nmargin-bottom: -40px;\n }\n .webAnimation {\nmin-height: 62vw;\n }\n .quicklinks {\nfont-size: 16px;\nmargin-bottom: 25px;\n }\n .pg1x {\nfont-size: 30px;\nmargin-bottom: 35px;\n }\n .keyLinks {\nbackground: rgba(255, 255, 255, 0.07);\nwidth: 30%;\nmin-height: 150px;\npadding: 15px 20px;\nmargin-right: 15px;\nmargin-bottom: 10px;\n }\n .keyLinks img {\nwidth: 50px;\n }\n .keyLinks p {\nline-height: 16px;\nfont-size: 14px;\nmargin-top: 15px;\n }\n .table thead th {\nfont-size: 15px;\n }\n a.qLInk {\nfont-size: 15px;\npadding: 7px 30px;\nborder-radius: 0.4vw;\nmargin-bottom: 10px;\nmargin-right: 10px;\nwidth: 30%;\nmin-height: 60px;\n }\n .footerTab {\nbackground: #1a1a24;\npadding: 60px;\n }\n .EYlogo {\nwidth: 40px;\nleft: 60px;\ntop: 20px;\n }\n p.logoTxt {\nfont-size: 25px;\nleft: 130px;\ntop: 30px;\n }\n ul.navbarMenu {\nright: 50px;\ntop: 25px;\n }\n ul.navbarMenu li {\nfont-size: 15px;\n }\n ul.navbarMenu li a {\npadding: 0vw 20px;\n }\n img.home {\nwidth: 20px;\n }\n .nav-bar {\nmin-height: 90px;\n }\n ul.navbarMenu {\nright: 50px;\ntop: 31px;\n }\n .footer p {\nmargin-bottom: 0px;\ncolor: #ffffff;\nfont-size: 13px;\npadding: 15px 20px;\ntext-align: right;\n }\n .col-sm-12.rgt_c7 {\n-ms-flex: 0 0 33.333%;\nflex: 0 0 33.333%;\nmax-width: 33.333%;\n }\n p.s1 span {\nfont-size: 12px !important;\n }\n .rgt_c7 {\nheight: auto !important;\npadding: 0px 0px;\n }\n .rg_06 {\npadding: 10px 10px;\n }\n p.s1 {\nfont-size: 16px;\nline-height: 20px;\nwidth: auto;\nposition: static;\ntransform: translate(0%, 0%);\n }\n .rs-01 {\npadding: 30px 20px;\n }\n .m-row {\npadding: 0px 20px 0px 0px;\n }\n .m-lft {\npadding: 40px 40px;\n }\n .pr_hd {\nfont-size: 16px;\nmargin: 0;\nline-height: 25px;\nmargin-bottom: 40px;\n }\n .hotNews {\nwidth: 80px;\ntop: -27px;\nz-index: 1;\n }\n .hotNews span {\ncolor: #000000;\nfont-size: 13px;\npadding: 0vw 0px;\n }\n .hotNews img {\nwidth: 24px;\npadding: 4px 5px;\n }\n .pr_hd span {\nfont-size: 25px;\n }\n .pr_txt {\nfont-size: 14px;\nmargin-bottom: 0;\nmargin-top: 13px;\nline-height: 19px;\n }\n p.m_btn {\nfont-size: 13px;\npadding: 10px 10px;\nmargin-top: 20px;\nwidth: 120px;\n }\n .sp_no {\nposition: absolute;\nbackground: rgba(255, 255, 255, 0.12);\nwidth: 20px;\nheight: 20px;\nborder-radius: 100vw;\nline-height: 0;\npadding-top: 11px;\nfont-size: 12px;\nleft: 19px;\n }\n .c4a7 {\nfont-size: 11px;\nmargin-top: 11px;\n }\n .pr_txt {\nmargin-bottom: 10px;\n }\n .news_1 {\npadding: 15px 15px;\nmargin-top: 15px;\npadding-left: 10vw;\n }\n .left-0 {\npadding: 20px 20px;\n }\n .archived {\nfont-size: 11px;\npadding: 10px 12px;\nmargin-top: 5px;\n }\n .archived img {\nwidth: 18px;\nmargin-right: 5px;\n }\n .key-c7 {\nfont-size: 11px;\nmargin-bottom: -1px;\nmargin-top: 7px;\n }\n}\n\n@media only screen and (max-width: 1000px) {\n .news_1 {\npadding: 15px 15px;\nmargin-top: 15px;\npadding-left: 15px;\nfloat: left;\nwidth: 100%;\n }\n .fy7 {\nwidth: 120px;\nheight: 120px;\nposition: static;\nfloat: left;\nmargin-right: 20px;\n }\n .hotNews {\ntop: -5px;\n }\n .col-sm-6.m-6 {\n-ms-flex: 0 0 100%;\nflex: 0 0 100%;\nmax-width: 100%;\n }\n .m-6 {\noverflow: hidden;\npadding: 0vw 10px !important;\nmargin-bottom: 12px;\n }\n .m-lft {\npadding: 20px 40px;\n }\n .m1 {\nfont-size: 15px;\nline-height: 17px;\nborder-right: 1px solid #000000;\npadding: 11px 10px;\nwidth: 35%;\nmin-height: 70px;\n }\n p.subText {\nfont-size: 10px;\nleft: 10px;\nbottom: 0px;\n }\n img.speakerIcon {\nwidth: 47px !important;\nleft: 110px;\ntop: 0vw;\n }\n .m2 {\nfont-size: 12px;\nline-height: 15px;\npadding: 6px 14px;\n }\n .m-lft.m0 a {\nfont-size: 11px;\npadding: 6px 10px;\nwidth: 115px;\nmargin-right: 10px;\nmargin-top: 5px;\n }\n .col-sm-12.m-6 {\nmargin-top: 15px;\n }\n .cf-7 {\nfloat: left;\nwidth: 100%;\n }\n .cf-7:nth-child(1):before,\n .cf-7:nth-child(2):before {\nwidth: 70px;\nheight: 22px;\ntop: 4px;\nleft: 0;\nbackground-size: 60px;\n }\n}\n\n@media only screen and (max-width: 992px) {\n .quoteTxt {\nfont-family: none;\ncolor: #ffffff;\nfont-size: 18px;\nline-height: 20px;\nwidth: 40%;\n }\n p.bx-link {\nfont-size: 13px;\nleft: 45%;\ntop: 20px;\nline-height: 14px;\npadding-right: 30px;\n }\n\n .col-sm-bx span {\nright: 10px;\nbottom: 0px;\nfont-size: 15px;\nopacity: 0.3;\n }\n .col-sm-3.cl-3 {\n-ms-flex: 0 0 33.333%;\nflex: 0 0 33.333%;\nmax-width: 33.333%;\n }\n .col-sm-bx {\nmin-height: 70px;\n }\n .cl-3 {\npadding: 7px;\n }\n}\n\n@media only screen and (max-width: 950px) {\n a.qLInk {\nwidth: 48%;\n }\n}\n\n@media only screen and (max-width: 850px) {\n .left-0 {\nbackground: none;\npadding: 0 20px !important;\nmin-height: auto;\n }\n .subCircle {\nposition: static;\ndisplay: none;\n }\n .Ctext {\nposition: static;\n }\n hr.hrLine {\ndisplay: none;\n }\n .circlesTab {\nfloat: left;\npadding: 0;\n }\n .Ctext {\nwidth: 48%;\nmargin-right: 2%;\nmargin-left: 0px;\nfloat: left;\nbackground: #ffe600;\nmin-height: 60px;\ncolor: #000000;\ntext-align: center;\nfont-size: 18px;\nposition: relative;\nleft: auto;\ntop: auto;\nline-height: 21px;\npadding: 8px 30px 0px 65px;\npointer-events: unset !important;\ncursor: pointer;\n }\n .hrx {\ndisplay: none;\n }\n .Ctext img {\ndisplay: block;\nbackground: #2e2e38;\nwidth: 50px;\npadding: 17px 10px;\nposition: absolute;\nleft: 0;\nheight: 100%;\ntop: 0;\n }\n .webAnimation {\nmin-height: auto;\nmin-height: 860px;\npadding-left: 50px;\npadding-right: 50px;\n }\n .pg2 {\nmargin-bottom: 0;\n }\n .left-0 {\n-ms-flex: 0 0 100%;\nflex: 0 0 100%;\nmax-width: 100%;\n }\n .right-0 {\n-ms-flex: 0 0 100%;\nflex: 0 0 100%;\nmax-width: 100%;\n }\n .left-0 {\npadding: 20px 20px !important;\n }\n .m-row {\npadding: 0px 10px 0px 10px;\n }\n}\n\n@media only screen and (max-width: 800px) {\n .col-sm-4.c57 {\n-ms-flex: 0 0 100%;\nflex: 0 0 100%;\nmax-width: 100%;\n }\n .col-sm-6.rgt_c7 {\n-ms-flex: 0 0 50%;\nflex: 0 0 50%;\nmax-width: 50%;\nmin-height: 100px;\n }\n p.s1 {\nfont-size: 18px;\nline-height: 24px;\nleft: 40px;\nbottom: 20px;\n }\n p.c4 {\nfont-size: 20px;\nline-height: 27px;\nmargin-bottom: 20px;\n }\n .modal-dialog.md2 {\nmax-width: 80%;\n }\n}\n\n@media only screen and (max-width: 750px) {\n .Ctext {\nwidth: 100%;\nfloat: left;\nmin-height: 60px;\ncolor: #000000;\ntext-align: center;\nfont-size: 18px;\nposition: relative;\nleft: auto;\ntop: auto;\nline-height: 21px;\npadding: 8px 30px 0px 65px;\n }\n .webAnimation {\nfloat: left;\npadding-bottom: 40px;\n }\n table#tableID {\nborder: 0;\n }\n table#tableID caption {\nfont-size: 1.3em;\n }\n table#tableID thead {\nborder: none;\nclip: rect(0 0 0 0);\nheight: 1px;\nmargin: -1px;\noverflow: hidden;\npadding: 0;\nposition: absolute;\nwidth: 1px;\n }\n table#tableID tr {\ndisplay: block;\nbackground-color: rgb(255 255 255 / 16%) !important;\nborder: hidden;\npadding: 5px 20px;\nmargin-bottom: 15px;\n }\n table#tableID td {\nborder-bottom: 1px solid #ddd;\ndisplay: block;\nfont-size: 0.8em;\ntext-align: right;\nposition: relative;\n }\n table#tableID td::before {\ncontent: attr(data-label);\nfloat: left;\nfont-weight: bold;\ntext-transform: uppercase;\nposition: absolute;\nleft: 0px;\ntop: 10px;\n }\n table#tableID td:last-child {\nborder-bottom: 0;\n }\n table#tableID td p {\nmargin-bottom: 0;\ntext-align: left;\nmargin-top: 21px;\n }\n button.close {\nright: 30px;\ntop: 20px;\n }\n .footerTab {\nfloat: left;\n }\n img.qklinks {\ndisplay: none;\n }\n .m-row .col-sm-2 {\ndisplay: none;\n }\n .m-lft {\n-ms-flex: 0 0 100%;\nflex: 0 0 100%;\nmax-width: 100%;\n }\n .col-sm-3.cl-3 {\n-ms-flex: 0 0 50%;\nflex: 0 0 50%;\nmax-width: 50%;\n }\n #VideoPlay .modal-dialog {\nmax-width: 90% !important;\n }\n}\n\n@media only screen and (max-width: 650px) {\n .keyLinks {\nwidth: 100%;\nmin-height: auto;\npadding-bottom: 25px;\n }\n .col-sm-12.rgt_c7 {\n-ms-flex: 0 0 50%;\nflex: 0 0 50%;\nmax-width: 50%;\n }\n a.qLInk {\nwidth: 100%;\nmin-height: auto;\n }\n a.qLInk span {\nposition: static;\ntop: 50%;\nleft: 50%;\ntransform: translate(0%, 0%);\nwidth: 60%;\n }\n .sp_no {\ndisplay: none;\n }\n}\n\n@media only screen and (max-width: 575px) {\n .col-sm-6.rgt_c7 {\n-ms-flex: 0 0 100%;\nflex: 0 0 100%;\nmax-width: 100%;\n }\n ul.navbarMenu {\ntop: 110px;\n }\n .hd1 {\nmargin-top: 70px;\n }\n .modal-dialog.md2 {\nmax-width: 100%;\n }\n .modal-dialog.ctabl {\nmax-width: 100%;\n }\n .m-6 {\nmargin-bottom: 30px;\n }\n .news_1 {\npadding-left: 15px;\n }\n .fy7 {\nwidth: 90px;\nheight: 90px;\n }\n .jp {\ntext-align: left !important;\nfont-size: 12px !important;\nfont-style: italic !important;\nleft: 10px !important;\ntop: 10px !important;\nwidth: 100% !important;\nfloat: left !important;\ndisplay: block !important;\nposition: relative !important;\n }\n .jp a {\nfont-size: 11px !important;\nbackground: none !important;\ncolor: #000000 !important;\npadding: 0 !important;\nmargin: 0 !important;\nfont-style: italic !important;\ntext-decoration: underline !important;\ntext-align: left !important;\nwidth: auto !important;\nfloat: none !important;\nmargin-left: 3px !important;\n }\n .m2 {\nmin-height: 80px;\n }\n .col-sm-12.m-6 .m-lft img {\nleft: 30px !important;\ntop: 70px !important;\n }\n}\n\n@media only screen and (max-width: 500px) {\n .col-sm-3.cl-3 {\n-ms-flex: 0 0 100%;\nflex: 0 0 100%;\nmax-width: 100%;\n }\n .col-sm-12.m-6 .m-lft img {\nwidth: 100%;\nheight: 46px;\n }\n}\n\n@media only screen and (max-width: 460px) {\n .quoteTxt {\nwidth: 60%;\n }\n .col-sm-12.rgt_c7 {\n-ms-flex: 0 0 100%;\nflex: 0 0 100%;\nmax-width: 100%;\n }\n}\n\n@media only screen and (max-width: 400px) {\n .m1 {\nwidth: 100%;\nmargin-bottom: 0 !important;\npadding-right: 80px;\nborder: hidden;\n }\n .col-sm-12.m-6 .m-lft img {\nposition: static !important;\nmargin-top: -60px !important;\nfloat: right !important;\nmargin-right: 20px !important;\n }\n .m2 {\nmin-height: auto;\nwidth: 100%;\n }\n .m-lft.m0 a {\nfont-size: 11px;\npadding: 6px 10px;\nwidth: 95%;\nmargin-right: 2%;\nmargin-top: 5px;\n }\n}\n.c03{padding:0px !important;}\n.r03{margin:0px !important;}\n.m-lft.m0 a.OutlookLink{color:#000000 !important;}\n#lineManagerName {\nposition: relative;\nwidth: 100%;\nmin-height: 3vw;\nmargin-bottom: 1vw;\ntext-align: left;\ndisplay: block;\npadding: 0.6vw 1vw;\nfont-size: 0.9vw;\nborder: 1px solid #ababab;\nborder-radius: 0;\nbackground: rgba(255, 255, 255, 0.85);\ncolor: #444;\n}\n\n#lineManagerName:focus {\noutline: none;\nborder-color: #666;\n}\n";
var trendingNewsUri = "https://sites.ey.com/sites/MENATaxHub/_api/web/lists/getByTitle('Newsletter')/items?$select=Title,DisplayOrder,ThumbNail,File/Name&$expand=File&$orderby=DisplayOrder desc";
var trendingNewsFileRoot = 'https://sites.ey.com/sites/MENATaxHub/Newsletter/';
var Homepage = function (_a) {
    var onShowSSL = _a.onShowSSL, onShowCST = _a.onShowCST, onShowQuality = _a.onShowQuality, onShowFAQs = _a.onShowFAQs, onShowLeadership = _a.onShowLeadership, onShowMyDocs = _a.onShowMyDocs, onShowEYI = _a.onShowEYI, onShowResourcing = _a.onShowResourcing, onShowOnshore = _a.onShowOnshore, onShowNonGcc = _a.onShowNonGcc, onShowGDS = _a.onShowGDS, onShowTalent = _a.onShowTalent, onShowWebcast = _a.onShowWebcast, onShowCommunications = _a.onShowCommunications, onShowMarkets = _a.onShowMarkets, onShowEngagement = _a.onShowEngagement, onShowPolicies = _a.onShowPolicies, userDisplayName = _a.userDisplayName, userEmail = _a.userEmail;
    var _b = react__WEBPACK_IMPORTED_MODULE_0__.useState(false), isAccessModalOpen = _b[0], setIsAccessModalOpen = _b[1];
    var _c = react__WEBPACK_IMPORTED_MODULE_0__.useState(false), isVideoModalOpen = _c[0], setIsVideoModalOpen = _c[1];
    var _d = react__WEBPACK_IMPORTED_MODULE_0__.useState([]), trendingNews = _d[0], setTrendingNews = _d[1];
    var _e = react__WEBPACK_IMPORTED_MODULE_0__.useState(false), isSavingAccessRequest = _e[0], setIsSavingAccessRequest = _e[1];
    var getRequestDigest = function (webUrl) { return __awaiter(void 0, void 0, void 0, function () {
        var response, data;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, fetch("".concat(webUrl, "/_api/contextinfo"), {
                        method: 'POST',
                        headers: { Accept: 'application/json;odata=verbose' }
                    })];
                case 1:
                    response = _a.sent();
                    if (!response.ok) {
                        throw new Error("Unable to get SharePoint request digest (".concat(response.status, ")."));
                    }
                    return [4 /*yield*/, response.json()];
                case 2:
                    data = _a.sent();
                    return [2 /*return*/, data.d.GetContextWebInformation.FormDigestValue];
            }
        });
    }); };
    var handleAccessRequestSubmit = function () { return __awaiter(void 0, void 0, void 0, function () {
        var reasonInput, fileInput, lineManagerInput, lineManager, reason, file, listWebUrl, digest, requestHeaders, requestBody, ensureUserResponse, ensureUserData, itemResponse, itemData, attachmentResponse, _a, _b, error_1, message;
        var _c;
        var _d;
        return __generator(this, function (_e) {
            switch (_e.label) {
                case 0:
                    if (isSavingAccessRequest) {
                        return [2 /*return*/];
                    }
                    reasonInput = document.getElementById('Reason');
                    fileInput = document.getElementById('fileUploader');
                    lineManagerInput = document.getElementById('lineManagerName');
                    lineManager = (lineManagerInput === null || lineManagerInput === void 0 ? void 0 : lineManagerInput.value.trim()) || '';
                    reason = (reasonInput === null || reasonInput === void 0 ? void 0 : reasonInput.value.trim()) || '';
                    file = (_d = fileInput === null || fileInput === void 0 ? void 0 : fileInput.files) === null || _d === void 0 ? void 0 : _d[0];
                    if (!reason) {
                        window.alert('Reason cannot be blank.');
                        reasonInput === null || reasonInput === void 0 ? void 0 : reasonInput.focus();
                        return [2 /*return*/];
                    }
                    if (!file) {
                        window.alert('Upload the request approval mail.');
                        fileInput === null || fileInput === void 0 ? void 0 : fileInput.focus();
                        return [2 /*return*/];
                    }
                    setIsSavingAccessRequest(true);
                    _e.label = 1;
                case 1:
                    _e.trys.push([1, 10, 11, 12]);
                    listWebUrl = requestAccessWebUrl;
                    return [4 /*yield*/, getRequestDigest(listWebUrl)];
                case 2:
                    digest = _e.sent();
                    requestHeaders = {
                        Accept: 'application/json;odata=verbose',
                        'Content-Type': 'application/json;odata=verbose',
                        'X-RequestDigest': digest
                    };
                    requestBody = {
                        __metadata: { type: 'SP.Data.RequestAccessListItem' },
                        Title: userDisplayName,
                        Email: userEmail,
                        Reason: reason
                    };
                    if (!lineManager) return [3 /*break*/, 5];
                    return [4 /*yield*/, fetch("".concat(listWebUrl, "/_api/web/ensureuser"), {
                            method: 'POST',
                            headers: requestHeaders,
                            body: JSON.stringify({ logonName: lineManager })
                        })];
                case 3:
                    ensureUserResponse = _e.sent();
                    if (!ensureUserResponse.ok) {
                        throw new Error("Unable to resolve the line manager (".concat(ensureUserResponse.status, ")."));
                    }
                    return [4 /*yield*/, ensureUserResponse.json()];
                case 4:
                    ensureUserData = _e.sent();
                    requestBody.LineManagerId = ensureUserData.d.Id;
                    _e.label = 5;
                case 5: return [4 /*yield*/, fetch("".concat(listWebUrl, "/_api/web/lists/getbytitle('RequestAccess')/items"), {
                        method: 'POST',
                        headers: requestHeaders,
                        body: JSON.stringify(requestBody)
                    })];
                case 6:
                    itemResponse = _e.sent();
                    if (!itemResponse.ok) {
                        throw new Error("Unable to save the access request (".concat(itemResponse.status, ")."));
                    }
                    return [4 /*yield*/, itemResponse.json()];
                case 7:
                    itemData = _e.sent();
                    _a = fetch;
                    _b = ["".concat(listWebUrl, "/_api/web/lists/getbytitle('RequestAccess')/items(").concat(itemData.d.Id, ")/AttachmentFiles/add(FileName='").concat(encodeURIComponent(file.name), "')")];
                    _c = {
                        method: 'POST',
                        headers: {
                            Accept: 'application/json;odata=verbose',
                            'X-RequestDigest': digest,
                            'Content-Type': 'application/octet-stream'
                        }
                    };
                    return [4 /*yield*/, file.arrayBuffer()];
                case 8: return [4 /*yield*/, _a.apply(void 0, _b.concat([(_c.body = _e.sent(),
                            _c)]))];
                case 9:
                    attachmentResponse = _e.sent();
                    if (!attachmentResponse.ok) {
                        throw new Error("The request was saved, but the attachment failed (".concat(attachmentResponse.status, ")."));
                    }
                    window.alert('Request sent successfully.');
                    setIsAccessModalOpen(false);
                    return [3 /*break*/, 12];
                case 10:
                    error_1 = _e.sent();
                    message = error_1 instanceof Error ? error_1.message : String(error_1);
                    window.console.error('Unable to save the access request.', error_1);
                    window.alert(message);
                    return [3 /*break*/, 12];
                case 11:
                    setIsSavingAccessRequest(false);
                    return [7 /*endfinally*/];
                case 12: return [2 /*return*/];
            }
        });
    }); };
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
        var getTrendingNews = function () { return __awaiter(void 0, void 0, void 0, function () {
            var response, data, error_2, message;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 3, , 4]);
                        return [4 /*yield*/, fetch(trendingNewsUri, {
                                headers: { accept: 'application/json;odata=verbose' }
                            })];
                    case 1:
                        response = _a.sent();
                        if (!response.ok) {
                            throw new Error("".concat(response.status, " ").concat(response.statusText));
                        }
                        return [4 /*yield*/, response.json()];
                    case 2:
                        data = _a.sent();
                        setTrendingNews(data.d.results.slice(0, 3));
                        return [3 /*break*/, 4];
                    case 3:
                        error_2 = _a.sent();
                        message = error_2 instanceof Error ? error_2.message : String(error_2);
                        window.console.error("Unable to load trending news: ".concat(message));
                        return [3 /*break*/, 4];
                    case 4: return [2 /*return*/];
                }
            });
        }); };
        void getTrendingNews();
    }, []);
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("style", null, homepageStyles),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "loading-container", style: { display: 'none' } },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container_wrapper", style: { display: 'block' } },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "webPart" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid nav-container" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row nav-bar" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/EY_logo.png", className: "EYlogo", alt: "EY logo" }),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "logoTxt" }, "MENA Tax Hub"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/toggle.png", className: "navToggle", alt: "Navigation toggle" }))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid c01" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row r01" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-8 bannerBackground" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "quote_div", style: {
                                    backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/ey-ahmed-eldessouky-v1.jpg)'
                                } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/Quoteicon.png", className: "qtIcon", alt: "Quote icon" }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "quoteTxt" }, "In a region defined by transformation, our role as tax leaders is not just to interpret change - but to shape it with integrity, foresight and impact."),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes", style: { marginTop: '5px', display: 'flex', flexDirection: 'column', alignItems: 'flex-end' } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes", style: { marginTop: '5px', display: 'flex', flexDirection: 'column', alignItems: 'flex-end' } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes mt-3" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Ahmed Eldessouky"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Tax Leader"))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 bt-txt" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "c4" }, "Our working world is rapidly evolving, and with that evolution, comes unprecedented opportunities for our Tax and Law practices, and all our businesses across sectors and geographies, to transform, expand and build a better working world."),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "c4" }, "Governments in the MENA region are taking active measures to maintain economic equilibrium. Tax authorities are also responding to demands for amendments to tax policies and processes."),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "c4" }, "At EY, our Tax subservice lines have been keeping pace with the situation, delivering appropriate solutions and helping clients stay on top of tax developments in a volatile and complex tax environment."))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-4 c47" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid rgt_container" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row r02" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 rgt_c7", style: { height: '59px' } },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "rg_01 rs-01", role: "button", tabIndex: 0, onClick: onShowSSL, onKeyPress: function (event) {
                                                if (event.key === 'Enter' || event.key === ' ') {
                                                    event.preventDefault();
                                                    onShowSSL();
                                                }
                                            }, style: { cursor: 'pointer' } },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "f1y", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png", alt: "Overlay" }),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Picture01.png", className: "fg1", alt: "MENA Tax SSLs" }),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "s1" }, "MENA Tax SSLs"))),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 rgt_c7", style: { height: '59px' } },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#", onClick: function (event) { event.preventDefault(); onShowEngagement(); } },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "rg_02 rs-01" },
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "f1y", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png", alt: "Overlay" }),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Picture02.png", className: "fg1", alt: "Engagement Lifecycle Management" }),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "s1" }, "Engagement Lifecycle Management")))),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 rgt_c7", style: { height: '59px' } },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "rg_03 rs-01", role: "button", tabIndex: 0, onClick: onShowCST, onKeyPress: function (event) {
                                                if (event.key === 'Enter' || event.key === ' ') {
                                                    event.preventDefault();
                                                    onShowCST();
                                                }
                                            }, style: { cursor: 'pointer' } },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "f1y", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png", alt: "Overlay" }),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Picture02.png", className: "fg1", alt: "Central Support Team" }),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "s1" }, "Central Support Team"))),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 rgt_c7", style: { height: '59px' } },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "rg_04 rs-01", role: "button", tabIndex: 0, onClick: onShowQuality, onKeyPress: function (event) {
                                                if (event.key === 'Enter' || event.key === ' ') {
                                                    event.preventDefault();
                                                    onShowQuality();
                                                }
                                            }, style: { cursor: 'pointer' } },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "f1y", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png", alt: "Overlay" }),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Picture03.png", className: "fg1", alt: "MENA Tax Quality" }),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "s1" }, "MENA Tax Quality"))),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 rgt_c7", style: { height: '59px' } },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "rg_05 rs-01", role: "button", tabIndex: 0, onClick: onShowLeadership, onKeyPress: function (event) {
                                                if (event.key === 'Enter' || event.key === ' ') {
                                                    event.preventDefault();
                                                    onShowLeadership();
                                                }
                                            }, style: { cursor: 'pointer' } },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "f1y", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png", alt: "Overlay" }),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Picture04.png", className: "fg1", alt: "MENA Tax Leadership" }),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "s1" }, "MENA Tax Leadership"))),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 rgt_c7", style: { height: '59px' } },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "rg_08 rs-01", role: "button", tabIndex: 0, onClick: onShowResourcing, onKeyPress: function (event) {
                                                if (event.key === 'Enter' || event.key === ' ') {
                                                    event.preventDefault();
                                                    onShowResourcing();
                                                }
                                            }, style: { cursor: 'pointer' } },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "f1y", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png", alt: "Overlay" }),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Picture04.png", className: "fg1", alt: "MENA Tax Resourcing Hub" }),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "s1" }, "MENA Tax Resourcing Hub"))),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 rgt_c7", style: { height: '59px' } },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "rg_07 rs-01", role: "button", tabIndex: 0, onClick: onShowTalent, onKeyPress: function (event) {
                                                if (event.key === 'Enter' || event.key === ' ') {
                                                    event.preventDefault();
                                                    onShowTalent();
                                                }
                                            }, style: { cursor: 'pointer' } },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "f1y", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png", alt: "Overlay" }),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Picture04.png", className: "fg1", alt: "MENA Tax Talent" }),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "s1" }, "MENA Tax Talent"))),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 rgt_c7 cg4", style: { height: '59px' } },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#", onClick: function (event) { event.preventDefault(); onShowMarkets(); } },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "rg_08 rs-01" },
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "f1y", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png", alt: "Overlay" }),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Picture05.png", className: "fg1", alt: "MENA Tax Markets" }),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "s1" }, "MENA Tax Markets")))),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 rgt_c7", style: { height: '53px' } },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/MENALearningPortal/TaxLearning/SitePages/Homepage.aspx", target: "_blank", rel: "noreferrer" },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "rg_07 rs-01" },
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "f1y", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png", alt: "Overlay" }),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Picture04.png", className: "fg1", alt: "MENA Tax Learning" }),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "s1" }, "MENA Tax Learning")))),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 rgt_c7", style: { height: '59px' }, hidden: true },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "rg_08 rs-01", role: "button", tabIndex: 0, onClick: onShowCommunications, onKeyPress: function (event) {
                                                if (event.key === 'Enter' || event.key === ' ') {
                                                    event.preventDefault();
                                                    onShowCommunications();
                                                }
                                            }, style: { cursor: 'pointer' } },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "f1y", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png", alt: "Overlay" }),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "s1" }, "MENA Tax archived communications"))),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 rgt_c7", style: { height: '59px' }, hidden: true },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "rg_08 rs-01", role: "button", tabIndex: 0, onClick: onShowWebcast, onKeyPress: function (event) {
                                                if (event.key === 'Enter' || event.key === ' ') {
                                                    event.preventDefault();
                                                    onShowWebcast();
                                                }
                                            }, style: { cursor: 'pointer' } },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "f1y", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png", alt: "Overlay" }),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "s1" }, "MENA Tax all people webcast"))),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 rgt_c7", style: { height: '59px' }, hidden: true },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "rg_04 rs-01", role: "button", tabIndex: 0, onClick: onShowFAQs, onKeyPress: function (event) {
                                                if (event.key === 'Enter' || event.key === ' ') {
                                                    event.preventDefault();
                                                    onShowFAQs();
                                                }
                                            }, style: { cursor: 'pointer' } },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "f1y", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png", alt: "Overlay" }),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/faq.png?csf=1&web=1&e=ET46ax", className: "fg1", alt: "MENA Tax Quality FAQs" }),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "s1" }, "MENA Tax Quality FAQs"))),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 rgt_c7", style: { height: '59px' }, hidden: true },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "rg_06 rs-01", role: "button", tabIndex: 0, onClick: onShowMyDocs, onKeyPress: function (event) {
                                                if (event.key === 'Enter' || event.key === ' ') {
                                                    event.preventDefault();
                                                    onShowMyDocs();
                                                }
                                            }, style: { cursor: 'pointer' } },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "f1y", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png", alt: "Overlay" }),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Picture05.png", className: "fg1", alt: "MyDocs Minutes" }),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "s1" }, "MyDocs Minutes"))),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 rgt_c7", style: { height: '59px' }, hidden: true },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "rg_07 rs-01", role: "button", tabIndex: 0, onClick: onShowEYI, onKeyPress: function (event) {
                                                if (event.key === 'Enter' || event.key === ' ') {
                                                    event.preventDefault();
                                                    onShowEYI();
                                                }
                                            }, style: { cursor: 'pointer' } },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "f1y", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png", alt: "Overlay" }),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Picture06.png", className: "fg1", alt: "EYI Documentation" }),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "s1" }, "EYI Documentation"))),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 rgt_c7", style: { height: '59px' }, hidden: true },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "rg_08 rs-01", role: "button", tabIndex: 0, onClick: onShowOnshore, onKeyPress: function (event) {
                                                if (event.key === 'Enter' || event.key === ' ') {
                                                    event.preventDefault();
                                                    onShowOnshore();
                                                }
                                            }, style: { cursor: 'pointer' } },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "f1y", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png", alt: "Overlay" }),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/onshore.jpg", className: "fg1", alt: "Onshore Resourcing" }),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "s1" }, "Onshore Resourcing"))),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 rgt_c7", style: { height: '59px' }, hidden: true },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "rg_08 rs-01", role: "button", tabIndex: 0, onClick: onShowNonGcc, onKeyPress: function (event) {
                                                if (event.key === 'Enter' || event.key === ' ') {
                                                    event.preventDefault();
                                                    onShowNonGcc();
                                                }
                                            }, style: { cursor: 'pointer' } },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "f1y", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png", alt: "Overlay" }),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/thumbnail-203.png", className: "fg1", alt: "Non-GCC (Levant / Rapid Pakistan)" }),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "s1" }, "Non-GCC (Levant / Rapid Pakistan)"))),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 rgt_c7", style: { height: '59px' }, hidden: true },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "rg_05 rs-01", role: "button", tabIndex: 0, onClick: onShowGDS, onKeyPress: function (event) {
                                                if (event.key === 'Enter' || event.key === ' ') {
                                                    event.preventDefault();
                                                    onShowGDS();
                                                }
                                            }, style: { cursor: 'pointer' } },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "f1y", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home/overlay.png", alt: "Overlay" }),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Picture02.png", className: "fg1", alt: "GDS" }),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "s1" }, "GDS")))))))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid c03" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row m-row r03" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-4 left-0" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pr_hd" }, "Trending News"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { id: "divNews" }, trendingNews.map(function (item) {
                                var _a, _b, _c;
                                return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", key: "".concat(item.Title, "-").concat(((_a = item.File) === null || _a === void 0 ? void 0 : _a.Name) || ''), href: "".concat(trendingNewsFileRoot).concat(((_b = item.File) === null || _b === void 0 ? void 0 : _b.Name) || ''), target: "_blank", rel: "noreferrer", style: { textDecoration: 'none', position: 'relative' }, className: "cf-7" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "news_1" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "fy7", style: {
                                                backgroundImage: ((_c = item.ThumbNail) === null || _c === void 0 ? void 0 : _c.Url) ? "url(".concat(item.ThumbNail.Url, ")") : undefined,
                                                backgroundPosition: 'center'
                                            } }),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pr_txt", style: { marginTop: 0 } }, item.Title),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "c4a7" }, "READ MORE"))));
                            })),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", onClick: onShowCommunications, className: "archived", target: "_blank", rel: "noreferrer", style: { cursor: 'pointer' } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/archived.png", alt: "Archived communications" }),
                                "Archived communications")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-8 right-0" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 m-6 m3" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "m-lft m0" },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "m1" },
                                                "MENA Tax",
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                                "Reporting Dashboard"),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/speaker.png", className: "speakerIcon", alt: "Speaker" }),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "m2" }, "Provides regular reporting of vital KPIs in a highly visual format combined with the ability to drill down to the detail."),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: "b1", href: "#", onClick: function (event) { event.preventDefault(); setIsAccessModalOpen(true); } }, "Request Access"),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://app.powerbi.com/groups/me/apps/88b138f5-216c-4ac6-b72a-a19e005bd381/reports/dc7969d8-2122-4804-8516-afe5d60de0a4/1ca454fa5a5c0e5d4d0a?ctid=5b973f99-77df-4beb-b27d-aa0c70b8482c&chromeless=1&experience=power-bi", target: "_blank", rel: "noreferrer", className: "b2" }, "Read Reports"),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "jp", style: {
                                                    fontSize: '0.85vw',
                                                    fontStyle: 'italic',
                                                    position: 'absolute',
                                                    left: '20vw',
                                                    top: '11.2vw'
                                                } },
                                                "Any queries related to reporting dashboard, please reach out to",
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: 'OutlookLink', href: "mailto:MENA.Tax.operations@ae.ey.com", style: {
                                                        fontSize: '0.85vw',
                                                        background: 'none',
                                                        color: '#000000',
                                                        padding: 0,
                                                        margin: '0 0 0 -18px',
                                                        fontStyle: 'italic',
                                                        textDecoration: 'underline'
                                                    } }, "MENA Tax Operations")))),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 m-6" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "m-lft n-b1", style: { padding: '4vw 0.7vw', float: 'left' } },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", onClick: onShowWebcast, rel: "noreferrer", style: { float: 'left', width: '50%', cursor: 'pointer' } },
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/web-button-1.png", alt: "Webcast", style: { width: '96%' } })),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#", onClick: function (event) { event.preventDefault(); setIsVideoModalOpen(true); }, style: { cursor: 'pointer', float: 'left', width: '50%' } },
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/web-button-2.png", alt: "Video play", style: { width: '96%' } })))))))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid footerTab" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "quicklinks" }, "Quick links")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cl-3" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://lmsme.ey.net/", target: "_blank", rel: "noreferrer" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: {
                                        backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/lms.jpg)'
                                    } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bx-link" }, "LMS"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "01")))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cl-3" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sort.ey.net/", target: "_blank", rel: "noreferrer" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: {
                                        backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/gettyimages-1386672473-1024x1024.jpg)'
                                    } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bx-link" }, "SORT"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "02")))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cl-3" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sf.ey.net", target: "_blank", rel: "noreferrer" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: {
                                        backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/tx03.jpg)'
                                    } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bx-link" }, "SuccessFactors"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "03")))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cl-3" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://intranet.ey.com/sites/career-development/SitePageModern/342011/career-development", target: "_blank", rel: "noreferrer" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: {
                                        backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/tx04.jpg)'
                                    } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bx-link" }, "Career & development"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { "data-target": "#newsModal", "data-toggle": "modal" }, "04")))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cl-3" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/TaxLearning/TaxCopilot/SitePages/Homepage.aspx#/", target: "_blank", rel: "noreferrer" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: {
                                        backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/training.jpg)'
                                    } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bx-link" }, "EY Tax Copilot"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { "data-target": "#newsModal", "data-toggle": "modal" }, "05")))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cl-3" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://apps.powerapps.com/play/e/a3c669f6-ac2e-4e77-ad43-beab3e15bee7/a/51ea11c3-8427-4e7f-91c0-1997fabd6c16?tenantId=5b973f99-77df-4beb-b27d-aa0c70b8482c&hint=c40b4e6c-c8f3-4c32-8df8-eb772d355b4e&sourcetime=1767618367761&hidenavbar=true", target: "_blank", rel: "noreferrer" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: {
                                        backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/tx04.jpg)'
                                    } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bx-link" }, "MENA Tax Industry Mapping Tool"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { "data-target": "#newsModal", "data-toggle": "modal" }, "06")))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cl-3" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/excel/MENA_Skills_by_Role.xlsx", target: "_blank", rel: "noreferrer" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: {
                                        backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/GettyImages-691574503.jpg)'
                                    } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bx-link" }, "MENA Skills by Role"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { "data-target": "#newsModal", "data-toggle": "modal" }, "07")))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "footer" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "\u00A9 2026 EYGM Limited. All rights reserved."))),
        isAccessModalOpen && react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "homepageModal", id: "newsModalThree", tabIndex: -1, "aria-modal": "true", role: "dialog" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "modal-dialog md2 modal-dialog-centered carousel-dialog", role: "document" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "modal-content" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { type: "button", className: "homepageModalClose", onClick: function () { return setIsAccessModalOpen(false); }, "aria-label": "Close request access dialog" }, "\u00D7"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "modal-body carousel-body", style: { textAlign: 'center' } },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "modalBody bmodal" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "form-group" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("label", { htmlFor: "txtName" },
                                    "Name ",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "*")),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { type: "text", className: "form-control inputBox", id: "txtName", readOnly: true, value: userDisplayName, placeholder: "Enter your Name", required: true }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("label", { htmlFor: "txtEmail" },
                                    "Email ",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "*")),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { type: "text", className: "form-control inputBox", id: "txtEmail", readOnly: true, value: userEmail, placeholder: "Enter your email", required: true }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("label", { htmlFor: "lineManagerName" },
                                    "Line Manager Name ",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "*")),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { type: "text", className: "form-control", id: "lineManagerName", placeholder: "Enter line manager name or email", autoComplete: "off" }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("label", { htmlFor: "Reason" },
                                    "Reason for requesting access ",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "*")),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("textarea", { className: "form-control inputBox", placeholder: "Reason for requesting access", required: true, id: "Reason" }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("label", { htmlFor: "fileUploader" },
                                    "Please attach the approval mail ",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "*")),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { type: "file", style: { width: '27vw', height: '2.2vw', fontSize: '10px' }, id: "fileUploader" }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { type: "button", className: "btn btn-primary", onClick: function () { void handleAccessRequestSubmit(); }, disabled: isSavingAccessRequest }, isSavingAccessRequest ? 'Submitting...' : 'Submit'))))))),
        isVideoModalOpen && react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "homepageModal", id: "VideoPlay", tabIndex: -1, "aria-modal": "true", role: "dialog", onClick: function () { return setIsVideoModalOpen(false); } },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "modal-dialog modal-dialog-centered", role: "document", onClick: function (event) { return event.stopPropagation(); } },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "modal-content videoModalContent" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { type: "button", className: "homepageModalClose", onClick: function () { return setIsVideoModalOpen(false); }, "aria-label": "Close video dialog" }, "\u00D7"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("video", { controls: true, autoPlay: true, title: "MENA Tax video" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("source", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/Videos/MENA-Tax-All-People-Webcast-20260630_090205UTC-Meeting%20Recording.mp4", type: "video/mp4" })))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Homepage);


/***/ }),

/***/ 27:
/*!**********************************************************!*\
  !*** ./lib/webparts/menaTaxHub/components/MenaTaxHub.js ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _MenaTaxHub_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./MenaTaxHub.module.scss */ 847);
/* harmony import */ var _Homepage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Homepage */ 664);
/* harmony import */ var _SSL__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./SSL */ 748);
/* harmony import */ var _CST__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./CST */ 420);
/* harmony import */ var _MenaTaxQuality__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./MenaTaxQuality */ 425);
/* harmony import */ var _MenaTaxLeadership__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./MenaTaxLeadership */ 761);
/* harmony import */ var _MyDocsMinutes__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./MyDocsMinutes */ 136);
/* harmony import */ var _EYIDocumentation__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./EYIDocumentation */ 21);
/* harmony import */ var _MenaTaxQualityFAQs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./MenaTaxQualityFAQs */ 436);
/* harmony import */ var _MenaTaxResourcingHub__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./MenaTaxResourcingHub */ 494);
/* harmony import */ var _OnshoreResourcing__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./OnshoreResourcing */ 359);
/* harmony import */ var _NonGccResourcing__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./NonGccResourcing */ 345);
/* harmony import */ var _GDS__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./GDS */ 522);
/* harmony import */ var _MenaTaxTalent__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./MenaTaxTalent */ 504);
/* harmony import */ var _Webcast__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./Webcast */ 467);
/* harmony import */ var _Communications__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./Communications */ 621);
/* harmony import */ var _MenaTaxMarkets__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./MenaTaxMarkets */ 961);
/* harmony import */ var _EngagementLifecycleManagement__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./EngagementLifecycleManagement */ 936);
/* harmony import */ var _PoliciesAndProcedures__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./PoliciesAndProcedures */ 431);
/* harmony import */ var _MyTraining__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./MyTraining */ 904);
/* harmony import */ var _TrainingPackAndDocuments__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./TrainingPackAndDocuments */ 162);
/* harmony import */ var _TrainingRecordedSession__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./TrainingRecordedSession */ 20);
/* harmony import */ var _VirtualClinicsTrainingSessions__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./VirtualClinicsTrainingSessions */ 727);
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
























var BOOTSTRAP_CSS_ID = 'mena-tax-hub-bootstrap-css';
var JQUERY_SCRIPT_ID = 'mena-tax-hub-jquery';
var BOOTSTRAP_SCRIPT_ID = 'mena-tax-hub-bootstrap-js';
var ASSET_URLS = {
    css: 'https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css',
    jquery: 'https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js',
    bootstrap: 'https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js'
};
var globalAssetUsers = 0;
var createElement = function (tagName, attrs, container) {
    var existing = document.getElementById(attrs.id || '');
    if (existing)
        return existing;
    var element = document.createElement(tagName);
    for (var key in attrs) {
        if (Object.prototype.hasOwnProperty.call(attrs, key)) {
            element.setAttribute(key, attrs[key]);
        }
    }
    container.appendChild(element);
    return element;
};
var createScript = function (id, src) {
    var existing = document.getElementById(id);
    if (existing)
        return existing;
    var script = document.createElement('script');
    script.id = id;
    script.src = src;
    script.async = false;
    document.body.appendChild(script);
    return script;
};
var addGlobalAssets = function () {
    createElement('link', { id: BOOTSTRAP_CSS_ID, rel: 'stylesheet', href: ASSET_URLS.css }, document.head);
    var loadBootstrap = function () {
        if (!document.getElementById(BOOTSTRAP_SCRIPT_ID)) {
            createScript(BOOTSTRAP_SCRIPT_ID, ASSET_URLS.bootstrap);
        }
    };
    var jqueryScript = createScript(JQUERY_SCRIPT_ID, ASSET_URLS.jquery);
    var isJQueryReady = typeof window.jQuery !== 'undefined';
    if (isJQueryReady) {
        loadBootstrap();
    }
    else {
        jqueryScript.onload = loadBootstrap;
    }
};
var removeGlobalAssets = function () {
    [BOOTSTRAP_CSS_ID, JQUERY_SCRIPT_ID, BOOTSTRAP_SCRIPT_ID].forEach(function (assetId) {
        var element = document.getElementById(assetId);
        if (element === null || element === void 0 ? void 0 : element.parentNode) {
            element.parentNode.removeChild(element);
        }
    });
};
var viewNames = [
    'home',
    'ssl',
    'cst',
    'quality',
    'leadership',
    'mydocs',
    'eyi',
    'faqs',
    'resourcing',
    'onshore',
    'nongcc',
    'gds',
    'talent',
    'webcast',
    'communications',
    'markets',
    'engagement',
    'policies',
    'training',
    'training-pack',
    'training-recorded',
    'virtual-clinics'
];
var getViewFromHash = function () {
    var hashView = decodeURIComponent(window.location.hash.slice(1)).toLowerCase();
    return viewNames.indexOf(hashView) >= 0 ? hashView : 'home';
};
var menuItems = [
    { label: 'Home', view: 'home' },
    { label: 'MENA Tax SSLs', view: 'ssl' },
    { label: 'Engagement Lifecycle Management', view: 'engagement' },
    { label: 'Central Support Team', view: 'cst' },
    { label: 'MENA Tax Quality', view: 'quality' },
    { label: 'MENA Tax Leadership', view: 'leadership' },
    { label: 'MENA Tax Resourcing Hub', view: 'resourcing' },
    { label: 'MENA Tax Talent', view: 'talent' },
    { label: 'MENA Tax Markets', view: 'markets' },
    { label: 'MENA Tax Learning', href: 'https://sites.ey.com/sites/MENALearningPortal/TaxLearning/SitePages/Homepage.aspx' }
    // { label: 'MENA Tax Quality FAQs', view: 'faqs' },
    // { label: 'MyDocs Minutes', view: 'mydocs' },
    // { label: 'EYI Documentation', view: 'eyi' },
    // { label: 'Onshore Resourcing', view: 'onshore' },
    // { label: 'Non-GCC Resourcing', view: 'nongcc' },
    // { label: 'GDS', view: 'gds' },
    // { label: 'MENA Tax All People Webcast', view: 'webcast' },
    // { label: 'Archived Communications', view: 'communications' },
    // { label: 'Policies and procedures', view: 'policies' },
    // { label: 'My Training', view: 'training' },
    // { label: 'Training pack and documents', view: 'training-pack' },
    // { label: 'Training recorded session', view: 'training-recorded' },
    // { label: 'Virtual clinics training sessions', view: 'virtual-clinics' },
];
var MenaTaxHub = /** @class */ (function (_super) {
    __extends(MenaTaxHub, _super);
    function MenaTaxHub() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.state = {
            activeView: getViewFromHash(),
            menuOpen: false,
            routeLoading: false
        };
        _this.skipRouteLoading = false;
        _this.scrollToTop = function () {
            window.scrollTo(0, 0);
            var hubElement = document.querySelector(".".concat(_MenaTaxHub_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].menaTaxHub));
            if (hubElement) {
                hubElement.scrollTop = 0;
                hubElement.scrollTo(0, 0);
            }
        };
        _this.handleHashChange = function () {
            var activeView = getViewFromHash();
            if (activeView !== _this.state.activeView) {
                _this.skipRouteLoading = true;
                _this.setState({ activeView: activeView, menuOpen: false, routeLoading: false });
            }
        };
        _this.showSSL = function () {
            _this.setState({ activeView: 'ssl' });
        };
        _this.showCST = function () {
            _this.setState({ activeView: 'cst' });
        };
        _this.showQuality = function () {
            _this.setState({ activeView: 'quality' });
        };
        _this.showLeadership = function () {
            _this.setState({ activeView: 'leadership' });
        };
        _this.showMyDocs = function () {
            _this.setState({ activeView: 'mydocs' });
        };
        _this.showEYI = function () {
            _this.setState({ activeView: 'eyi' });
        };
        _this.showFAQs = function () {
            _this.setState({ activeView: 'faqs' });
        };
        _this.showResourcing = function () {
            _this.setState({ activeView: 'resourcing' });
        };
        _this.showOnshore = function () {
            _this.setState({ activeView: 'onshore' });
        };
        _this.showNonGcc = function () {
            _this.setState({ activeView: 'nongcc' });
        };
        _this.showGDS = function () {
            _this.setState({ activeView: 'gds' });
        };
        _this.showTalent = function () {
            _this.setState({ activeView: 'talent' });
        };
        _this.showWebcast = function () {
            _this.setState({ activeView: 'webcast' });
        };
        _this.showCommunications = function () {
            _this.setState({ activeView: 'communications' });
        };
        _this.showMarkets = function () {
            _this.setState({ activeView: 'markets' });
        };
        _this.showEngagement = function () {
            _this.setState({ activeView: 'engagement' });
        };
        _this.showPolicies = function () {
            _this.setState({ activeView: 'policies' });
        };
        _this.showTraining = function () {
            _this.setState({ activeView: 'training' });
        };
        _this.showTrainingPack = function () {
            _this.setState({ activeView: 'training-pack' });
        };
        _this.showRecordedSession = function () {
            _this.setState({ activeView: 'training-recorded' });
        };
        _this.showVirtualClinics = function () {
            _this.setState({ activeView: 'virtual-clinics' });
        };
        _this.showHome = function () {
            _this.setState({ activeView: 'home' });
        };
        _this.toggleMenu = function () {
            _this.setState(function (currentState) { return ({ menuOpen: !currentState.menuOpen }); });
        };
        _this.openExternalLink = function (event) {
            if (event.defaultPrevented || !(event.target instanceof Element)) {
                return;
            }
            var link = event.target.closest('a');
            var href = link === null || link === void 0 ? void 0 : link.getAttribute('href');
            if (!link || !href || href.charAt(0) === '#') {
                return;
            }
            var url = new URL(href, window.location.href);
            if (url.protocol !== 'http:' && url.protocol !== 'https:') {
                return;
            }
            event.preventDefault();
            window.open(url.href, '_blank', 'noopener,noreferrer');
        };
        _this.navigateFromMenu = function (view) {
            _this.setState({ activeView: view, menuOpen: false, routeLoading: view !== 'home' });
            _this.routeLoadingTimer = window.setTimeout(function () { return _this.setState({ routeLoading: false }); }, 2000);
        };
        return _this;
    }
    MenaTaxHub.prototype.componentDidMount = function () {
        this.scrollToTop();
        globalAssetUsers += 1;
        if (globalAssetUsers === 1) {
            addGlobalAssets();
        }
        window.addEventListener('hashchange', this.handleHashChange);
        window.loadMenaTaxPage = function (pageName) {
            var nextView = pageName.trim().toLowerCase();
            if (viewNames.indexOf(nextView) >= 0) {
                window.location.hash = nextView === 'home' ? '' : nextView;
            }
        };
        this.handleHashChange();
    };
    MenaTaxHub.prototype.componentWillUnmount = function () {
        if (this.routeLoadingTimer) {
            window.clearTimeout(this.routeLoadingTimer);
        }
        window.removeEventListener('hashchange', this.handleHashChange);
        delete window.loadMenaTaxPage;
        globalAssetUsers -= 1;
        if (globalAssetUsers <= 0) {
            removeGlobalAssets();
            globalAssetUsers = 0;
        }
    };
    MenaTaxHub.prototype.componentDidUpdate = function (_previousProps, previousState) {
        var _this = this;
        if (previousState.activeView !== this.state.activeView) {
            this.scrollToTop();
            var nextHash = this.state.activeView === 'home' ? '' : "#".concat(this.state.activeView);
            if (window.location.hash !== nextHash) {
                window.history.replaceState(null, '', "".concat(window.location.pathname).concat(window.location.search).concat(nextHash));
            }
        }
        if (this.skipRouteLoading) {
            this.skipRouteLoading = false;
            return;
        }
        if (previousState.activeView !== this.state.activeView && !this.state.routeLoading && this.state.activeView !== 'home') {
            this.setState({ routeLoading: true });
            this.routeLoadingTimer = window.setTimeout(function () { return _this.setState({ routeLoading: false }); }, 2000);
        }
    };
    MenaTaxHub.prototype.render = function () {
        var _this = this;
        var hasTeamsContext = this.props.hasTeamsContext;
        var _a = this.state, activeView = _a.activeView, menuOpen = _a.menuOpen, routeLoading = _a.routeLoading;
        return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("section", { className: "".concat(_MenaTaxHub_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].menaTaxHub, " ").concat(hasTeamsContext ? _MenaTaxHub_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].teams : ''), onClick: this.openExternalLink },
            activeView !== 'home' && (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { type: "button", className: _MenaTaxHub_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].menuButton, onClick: this.toggleMenu, "aria-label": menuOpen ? 'Close navigation menu' : 'Open navigation menu', "aria-expanded": menuOpen, "aria-controls": "mena-tax-hub-navigation" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENA_Tax/SiteAssets/MENATax/images/toggle.png", alt: "" })),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_MenaTaxHub_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].menuOverlay, " ").concat(menuOpen ? _MenaTaxHub_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].menuOverlayOpen : ''), onClick: this.toggleMenu, "aria-hidden": "true" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("nav", { id: "mena-tax-hub-navigation", className: "".concat(_MenaTaxHub_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].menuPanel, " ").concat(menuOpen ? _MenaTaxHub_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].menuPanelOpen : ''), "aria-label": "MENA Tax Hub navigation" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _MenaTaxHub_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].menuHeader },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "Menu"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { type: "button", className: _MenaTaxHub_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].menuClose, onClick: this.toggleMenu, "aria-label": "Close navigation menu" }, "\u00D7")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", null, menuItems.map(function (item) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", { key: item.view || item.href }, item.href ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: _MenaTaxHub_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].menuLink, href: item.href, target: "_blank", rel: "noreferrer" }, item.label)) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { type: "button", className: item.view === activeView ? _MenaTaxHub_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].menuItemActive : '', onClick: function () { return _this.navigateFromMenu(item.view); } }, item.label)))); }))))),
            routeLoading && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _MenaTaxHub_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].routeLoading, role: "status", "aria-label": "Loading" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _MenaTaxHub_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].loadingRing }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _MenaTaxHub_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].loadingRing }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _MenaTaxHub_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].loadingRing }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _MenaTaxHub_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].loadingRing }))),
            activeView === 'home' ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Homepage__WEBPACK_IMPORTED_MODULE_2__["default"], { onShowSSL: this.showSSL, onShowCST: this.showCST, onShowQuality: this.showQuality, onShowFAQs: this.showFAQs, onShowLeadership: this.showLeadership, onShowMyDocs: this.showMyDocs, onShowEYI: this.showEYI, onShowResourcing: this.showResourcing, onShowOnshore: this.showOnshore, onShowNonGcc: this.showNonGcc, onShowGDS: this.showGDS, onShowTalent: this.showTalent, onShowWebcast: this.showWebcast, onShowCommunications: this.showCommunications, onShowMarkets: this.showMarkets, onShowEngagement: this.showEngagement, onShowPolicies: this.showPolicies, userDisplayName: this.props.userDisplayName, userEmail: this.props.userEmail })) : activeView === 'ssl' ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_SSL__WEBPACK_IMPORTED_MODULE_3__["default"], { onShowHome: this.showHome }))) : activeView === 'cst' ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_CST__WEBPACK_IMPORTED_MODULE_4__["default"], { onShowHome: this.showHome })) : activeView === 'quality' ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_MenaTaxQuality__WEBPACK_IMPORTED_MODULE_5__["default"], { onShowHome: this.showHome, onShowFAQs: this.showFAQs })) : activeView === 'leadership' ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_MenaTaxLeadership__WEBPACK_IMPORTED_MODULE_6__["default"], { onShowHome: this.showHome })) : activeView === 'mydocs' ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_MyDocsMinutes__WEBPACK_IMPORTED_MODULE_7__["default"], { onShowHome: this.showHome })) : activeView === 'faqs' ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_MenaTaxQualityFAQs__WEBPACK_IMPORTED_MODULE_9__["default"], { onShowHome: this.showHome })) : activeView === 'resourcing' ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_MenaTaxResourcingHub__WEBPACK_IMPORTED_MODULE_10__["default"], { onShowHome: this.showHome, onShowOnshore: this.showOnshore, onShowNonGcc: this.showNonGcc })) : activeView === 'onshore' ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_OnshoreResourcing__WEBPACK_IMPORTED_MODULE_11__["default"], { onShowResourcing: this.showResourcing, onShowHome: this.showHome })) : activeView === 'nongcc' ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_NonGccResourcing__WEBPACK_IMPORTED_MODULE_12__["default"], { onShowResourcing: this.showResourcing, onShowHome: this.showHome })) : activeView === 'gds' ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_GDS__WEBPACK_IMPORTED_MODULE_13__["default"], { onShowHome: this.showHome })) : activeView === 'talent' ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_MenaTaxTalent__WEBPACK_IMPORTED_MODULE_14__["default"], { onShowHome: this.showHome })) : activeView === 'webcast' ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Webcast__WEBPACK_IMPORTED_MODULE_15__["default"], { onShowHome: this.showHome })) : activeView === 'communications' ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Communications__WEBPACK_IMPORTED_MODULE_16__["default"], { onShowHome: this.showHome })) : activeView === 'markets' ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_MenaTaxMarkets__WEBPACK_IMPORTED_MODULE_17__["default"], { onShowHome: this.showHome })) : activeView === 'engagement' ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_EngagementLifecycleManagement__WEBPACK_IMPORTED_MODULE_18__["default"], { onShowHome: this.showHome, onShowPolicies: this.showPolicies, onShowTraining: this.showTraining })) : activeView === 'policies' ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_PoliciesAndProcedures__WEBPACK_IMPORTED_MODULE_19__["default"], { onShowHome: this.showHome })) : activeView === 'training' ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_MyTraining__WEBPACK_IMPORTED_MODULE_20__["default"], { onShowHome: this.showHome, onShowTrainingPack: this.showTrainingPack, onShowRecordedSession: this.showRecordedSession, onShowVirtualClinics: this.showVirtualClinics })) : activeView === 'training-pack' ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_TrainingPackAndDocuments__WEBPACK_IMPORTED_MODULE_21__["default"], { onShowHome: this.showHome })) : activeView === 'training-recorded' ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_TrainingRecordedSession__WEBPACK_IMPORTED_MODULE_22__["default"], { onShowHome: this.showHome })) : activeView === 'virtual-clinics' ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_VirtualClinicsTrainingSessions__WEBPACK_IMPORTED_MODULE_23__["default"], { onShowHome: this.showHome })) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_EYIDocumentation__WEBPACK_IMPORTED_MODULE_8__["default"], { onShowHome: this.showHome }))));
    };
    return MenaTaxHub;
}(react__WEBPACK_IMPORTED_MODULE_0__.Component));
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MenaTaxHub);


/***/ }),

/***/ 847:
/*!**********************************************************************!*\
  !*** ./lib/webparts/menaTaxHub/components/MenaTaxHub.module.scss.js ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
__webpack_require__(/*! ./MenaTaxHub.module.css */ 11);
var styles = {
    menaTaxHub: 'menaTaxHub_befce39d',
    teams: 'teams_befce39d',
    menuButton: 'menuButton_befce39d',
    menuOverlay: 'menuOverlay_befce39d',
    menuOverlayOpen: 'menuOverlayOpen_befce39d',
    routeLoading: 'routeLoading_befce39d',
    loadingRing: 'loadingRing_befce39d',
    routeSpin: 'routeSpin_befce39d',
    menuPanel: 'menuPanel_befce39d',
    menuLink: 'menuLink_befce39d',
    menuPanelOpen: 'menuPanelOpen_befce39d',
    menuHeader: 'menuHeader_befce39d',
    menuClose: 'menuClose_befce39d',
    menuItemActive: 'menuItemActive_befce39d',
    welcome: 'welcome_befce39d',
    welcomeImage: 'welcomeImage_befce39d',
    links: 'links_befce39d'
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (styles);


/***/ }),

/***/ 761:
/*!*****************************************************************!*\
  !*** ./lib/webparts/menaTaxHub/components/MenaTaxLeadership.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

var leadershipStyles = "\nhtml,\nbody {\n    overflow-x: hidden !important;\n    font-family: EYInterstate;\n}\n\n::-moz-selection {\n    color: #ffffff;\n    background: #27ACAA;\n}\n\n::selection {\n    color: #ffffff;\n    background: #27ACAA;\n}\n\nbody::-webkit-scrollbar {\n    display: none;\n}\n\nbody {\n    -ms-overflow-style: none;\n    scrollbar-width: none;\n    position: relative;\n}\n\n.bannerBackground {\n    background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/banner.jpg);\n    background-color: #2e2e38;\n    background-size: 115% 115%;\n    background-position: center center;\n    position: relative;\n    background-attachment: fixed;\n    animation: shrink 20s infinite alternate;\n    padding: 0px;\n}\n\n.cf6 {\n    color: #ffffff;\n    width: 100%;\n    font-size: 1.5vw;\n    padding: 1vw 1vw;\n    margin-bottom: 0;\n}\n\n@keyframes shrink {\n    0% {\n        background-size: 115% 115%;\n    }\n    100% {\n        background-size: 100% 100%;\n    }\n}\n\n.nav-bar {\n    position: relative;\n    z-index: 999;\n    background: #2e2e38;\n    min-height: 6vw;\n    width: 100%;\n    margin: 0;\n}\n\n.nav-container {\n    padding: 0px;\n}\n\n.EYlogo {\n    width: 3vw;\n    position: absolute;\n    left: 5vw;\n    top: 1.5vw;\n}\n\np.logoTxt {\n    color: #ffffff;\n    font-size: 2vw;\n    position: absolute;\n    left: 11vw;\n    top: 2.2vw;\n}\n\nimg.home {\n    width: 1.3vw;\n}\n\nul.navbarMenu {\n    position: absolute;\n    right: 6vw;\n    top: 2.4vw;\n    font-family: EYInterstate;\n}\n\nul.navbarMenu li {\n    display: inline-block;\n    font-size: 1vw;\n    color: #ffffff;\n}\n\nul.navbarMenu li a {\n    color: #ffffff;\n    text-decoration: none;\n    padding: 0vw 2vw;\n}\n\n.boxContent span {\n    color: #ffe600;\n    font-size: 1.2vw;\n    margin-right: .3vw;\n    font-weight: bold;\n}\n\n.cnt-fdr {\n    padding: 2vw 5vw 2vw 5vw;\n    background: rgba(46, 46, 56, .5);\n    bottom: 0;\n    width: 100%;\n}\n\n.vh3 {\n    margin-top: 1.3vw;\n}\n\n.boxContent p {\n    color: #ffffff;\n    font-size: .9vw;\n    line-height: 1.3vw;\n    font-family: EYInterstate;\n    font-weight: lighter;\n}\n\n.boxContent p b {\n    font-size: 1.2vw;\n    line-height: 2.5vw;\n}\n\n.boxContent img {\n    width: 3vw;\n    margin-bottom: .4vw;\n}\n\np.c4 {\n    color: #ffffff;\n    font-size: 1.1vw;\n    font-family: EYInterstate;\n    line-height: 1.5vw;\n    margin-bottom: 1.3vw;\n}\n\nul.c5 {\n    color: #ffffff;\n    list-style: none;\n    padding: 0;\n}\n\nul.c5 li {\n    position: relative;\n    padding-left: 1.3vw;\n    margin-bottom: 0.6vw;\n    font-size: 1vw;\n}\n\nul.c5 li::before {\n    content: \"\";\n    background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/arrow_icon.png);\n    position: absolute;\n    width: .6vw;\n    height: .6vw;\n    background-size: contain;\n    background-repeat: no-repeat;\n    top: 0.5vw;\n    left: 0;\n}\n\n.footerTab {\n    background: #1a1a24;\n    padding: 5vw;\n}\n\na.qLInk {\n    color: #ffffff;\n    font-family: EYInterstate;\n    font-size: 1vw;\n    font-weight: lighter;\n    border: .1vw solid #9f9f9f;\n    padding: 0.5vw 1.6vw;\n    border-radius: .4vw;\n    margin-right: .7vw;\n    text-decoration: none;\n    float: left;\n    -webkit-transition: all .2s ease-in-out;\n    -moz-transition: all .2s ease-in-out;\n    -o-transition: all .2s ease-in-out;\n    transition: all .2s ease-in-out;\n    margin-bottom: .8vw;\n}\n\na.qLInk:hover {\n    background: rgba(255, 255, 255, .2)\n}\n\n.quicklinks {\n    color: #ffffff;\n    font-size: 2vw;\n    margin-bottom: 2vw;\n}\n\nimg.qklinks {\n    width: 1.4vw;\n    margin-top: -0.2vw;\n    margin-right: .4vw;\n}\n\n.tabContent {\n    background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);\n    background-position: center;\n    background-size: cover;\n    background-attachment: fixed;\n    background-color: #2e2e38;\n    min-height: 10vw;\n}\n\np.hder {\n    color: #ffffff;\n    padding-left: 1vw;\n    font-size: 1vw;\n    line-height: 1.5vw;\n    margin-bottom: 1vw;\n}\n\n.card_08 {\n    margin-left: 4vw !important;\n    margin-right: 6.5vw !important;\n}\n\nhr.cf7 {\n    margin-top: 1rem;\n    margin-bottom: 1rem;\n    border: 0;\n    border-top: .1vw dashed rgb(255 255 255 / 77%);\n    width: 20vw;\n    position: absolute;\n    left: 10vw;\n    transform: rotate(90deg);\n    top: 8.5vw;\n}\n\n.cvg-1 p {\n    text-align: left !important;\n    padding-left: 20vw !important;\n}\n\n.pro-12 {\n    padding: 2vw 0vw 2vw 0vw;\n    max-width: max-content !important;\n}\n\n.pro-13 {\n    padding: 3vw 5.1vw;\n    position: relative;\n    overflow: hidden;\n}\n\n.bg_m {\n    background: #ffffff0a;\n    position: absolute;\n    width: 20vw;\n    height: 20vw;\n    top: 0;\n    left: 0;\n}\n\n.bg {\n    background: rgba(102, 102, 127, .34) !important\n}\n\n.profileCard {\n    background: rgba(255, 255, 255, .04);\n    width: 19.8vw;\n    float: left;\n    padding: 1vw 1vw;\n    border-bottom: .1vw solid #4a4a4a;\n    -webkit-transition: all .2s ease-in-out;\n    -moz-transition: all .2s ease-in-out;\n    -o-transition: all .2s ease-in-out;\n    transition: all .2s ease-in-out;\n}\n\n.profileCard:hover {\n    background: rgba(255, 255, 255, .08);\n}\n\n.profileCard.c2 {\n    margin: 0vw 1vw;\n}\n\n.profileCard.c3 {\n    margin-right: 1vw;\n}\n\n.cg-6 .pro-13 .profileCard:nth-child(3n) {\n    margin: 0;\n}\n\n.cg-7 .pro-13 .profileCard:nth-child(3n) {\n    margin: 0;\n}\n\n.imgCircle {\n    background: #2e2e38;\n    width: 6vw;\n    height: 6vw;\n    border-radius: 100vw;\n    float: left;\n    background-size: cover;\n    background-position: center;    margin: 0 auto !important;\n}\n\n.pName {\n    color: #ffffff;\n    font-size: .9vw;\n    font-family: EYInterstate;\n    margin: 1vw 0vw 0vw 0vw;\n}\n\n.pDes {\n    color: #ffe600;\n    font-size: .8vw;\n    font-family: EYInterstate;\n    margin: 0vw 0vw 0vw 0vw;\n}\n\n.profileDes {\n    float: left;\n    width: 10vw;\n    text-align: left;\n    margin-left: 1vw;\n    margin-top: 0.7vw;\n}\n\n.pro-hd-1 {\n    background-color: rgba(26, 26, 36, .37);\n}\n\n.pro-hd-1 p {\n    margin: 0;\n    padding: 1vw 0vw;\n    color: #ffffff;\n    text-align: center;\n    font-family: EYInterstate;\n    font-size: 1.2vw;\n}\n\n.profileCard.v1 {\n    width: 11.9vw;\n    float: left;\n    margin-right: 1.5vw;\n    padding-top: 2vw;\n    min-height: 14vw;\n    position: relative;\n    z-index: 1;\n    margin-bottom: 1.5vw !important;\n}\n\n.cg-6 {\n    border-right: .1vw solid #ffffff17;\n}\n\n.cg-6,\n.cg-7 {\n    padding: 0px;\n}\n\n.col-flex {\n    display: flex;\n    flex-wrap: wrap;\n    justify-content: center;\n}\n\n.imgCircle.v1 {\n    float: none;\n    width: 5vw;\n    height: 5vw;\n}\n\n.profileDes.v1 {\n    float: none;\n    text-align: center;\n    margin-left: 0px;\n}\n\n.footer {\n    background-color: #000000;\n    float: left;\n    width: 100%;\n}\n\n.footer p {\n    margin-bottom: 0px;\n    color: #ffffff;\n    font-size: 1vw;\n    padding: 1vw 2vw;\n    text-align: right;\n}\n\n.navToggle {\n    display: none;\n}\n\n@media only screen and (max-width: 1200px) {\n    .cnt-fdr {\n        position: static;\n    }\n    .cnt-fdr {\n        padding: 35px 70px;\n    }\n    .quicklinks {\n        font-size: 30px;\n        margin-bottom: 25px;\n    }\n    a.qLInk {\n        font-size: 15px;\n        border: 1px solid #9f9f9f;\n        padding: 7px 25px;\n        border-radius: .4vw;\n        margin-bottom: 10px;\n        margin-right: 10px;\n    }\n    .footerTab {\n        background: #1a1a24;\n        padding: 60px;\n    }\n    .EYlogo {\n        width: 40px;\n        left: 60px;\n        top: 20px;\n    }\n    p.logoTxt {\n        font-size: 25px;\n        left: 130px;\n        top: 30px;\n    }\n    ul.navbarMenu {\n        right: 50px;\n        top: 25px;\n    }\n    ul.navbarMenu li {\n        font-size: 15px;\n    }\n    ul.navbarMenu li a {\n        padding: 0vw 20px;\n    }\n    img.home {\n        width: 20px;\n    }\n    .nav-bar {\n        min-height: 90px;\n    }\n    ul.navbarMenu {\n        right: 50px;\n        top: 31px;\n    }\n    .footer p {\n        margin-bottom: 0px;\n        color: #ffffff;\n        font-size: 13px;\n        padding: 15px 20px;\n        text-align: right;\n    }\n    .cf6 {\n        font-size: 30px;\n        margin-bottom: 0;\n    }\n}\n\n@media only screen and (max-width: 1100px) {\n    .pName {\n        font-size: 14px;\n        margin: 10px 0vw 0vw 0vw;\n        line-height: 18px;\n    }\n    .pDes {\n        font-size: 12px;\n        line-height: 14px;\n        margin: 7px 0vw 0vw 0vw;\n    }\n    .profileCard.v1 {\n        width: 25%;\n        float: left;\n        margin-right: 2%;\n        padding-top: 30px;\n    }\n    .profileDes {\n        width: 85%;\n    }\n    .profileCard.v1 {\n        min-height: 175px;\n    }\n    .imgCircle.v1 {\n        width: 70px;\n        height: 70px;\n    }\n    .profileCard.v1.x1 {\n        margin-left: 0px;\n    }\n    .pro-13 {\n        padding: 30px 0%;\n        margin-left: 10%;\n    }\n    .profileCard.v1 {\n        min-height: 175px;\n        margin-bottom: 15px;\n    }\n    .pro-hd-1 p {\n        padding: 15px 0vw;\n        font-size: 17px;\n    }\n    .profileCard {\n        min-height: 200px;\n        background: rgba(255, 255, 255, .04);\n        width: 24%;\n        padding: 20px 20px;\n    }\n    .pro-12 {\n        padding: 30px 8%;\n    }\n    .imgCircle {\n        width: 80px;\n        height: 80px;\n    }\n    .profileCard.v1 {\n        min-height: 190px;\n    }\n    .col-sm-3.pro-hd-1 {\n        -ms-flex: 0 0 40%;\n        flex: 0 0 40%;\n        max-width: 40%;\n    }\n    .col-sm-9.pro-hd-1 {\n        -ms-flex: 0 0 60%;\n        flex: 0 0 60%;\n        max-width: 60%;\n    }\n    .profileCard.card_08 {\n        min-height: 191px !important;\n        margin-bottom: 220px !important;\n    }\n    .bg_m {\n        background-color: transparent;\n    }\n    .cf7 {\n        display: none;\n    }\n    .card_08 {\n        margin-left: 0vw !important;\n        margin-right: 6.5vw !important;\n    }\n}\n\n@media only screen and (max-width: 800px) {\n    .col-sm-4.c57 {\n        -ms-flex: 0 0 100%;\n        flex: 0 0 100%;\n        max-width: 100%;\n    }\n    .profileCard {\n        min-height: 190px;\n    }\n    .sm-07 {\n        display: block !important;\n    }\n    .card_08 {\n        display: none !important;\n    }\n    .col-sm-3.pro-hd-1 {\n        display: none;\n    }\n    .col-sm-9.pro-hd-1 {\n        -ms-flex: 0 0 100%;\n        flex: 0 0 100%;\n        max-width: 100%;\n    }\n}\n\n@media only screen and (max-width: 769px) {\n    .footerTab {\n        float: left;\n    }\n    img.qklinks {\n        display: none;\n    }\n    .profileCard.v1 {\n        min-height: 225px;\n    }\n    .profileCard {\n        width: 48%;\n        margin-bottom: 1vw !important;\n    }\n}\n\n@media only screen and (max-width: 650px) {\n    .profileCard.v1 {\n        width: 45%;\n    }\n    .pro-13 {\n        padding: 30px 0%;\n        margin-left: 4%;\n    }\n    .profileCard.card_08 {\n        min-height: 190px !important;\n        margin-bottom: 15px !important;\n    }\n}\n\n@media only screen and (max-width: 575px) {\n    ul.navbarMenu {\n        top: 110px;\n    }\n    .profileCard.v1 {\n        width: 100%;\n    }\n    .pro-13 {\n        padding: 30px 5%;\n        margin-left: 0%;\n    }\n    .profileCard {\n        min-height: 150px;\n        width: 100%;\n        margin-left: 0 !important;\n        margin-bottom: 25px !important;\n        padding: 20px 20px;\n    }\n}\n";
var MenaTaxLeadership = function (_a) {
    var onShowHome = _a.onShowHome;
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("style", null, leadershipStyles),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container_wrapper" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "webPart" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid nav-container" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row nav-bar" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "EYlogo", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/EY_logo.png", alt: "EY logo" }),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "logoTxt" }, "MENA Tax Hub"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "navbarMenu" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#", onClick: function (event) { event.preventDefault(); onShowHome(); } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "home", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home.png", alt: "Home" })))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "navToggle", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/toggle.png", alt: "Toggle" }))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 bannerBackground" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid cnt-fdr" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "cf6" }, "MENA Tax Leadership Structure"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-4 c57" })))))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid tabContent" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid tabContent" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row justify-content-center" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 pro-12", style: { maxWidth: '600px' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard text-center" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle", style: {
                                                backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Ahmed%20Eldessouky-v2.jpg)',
                                                width: '80px',
                                                height: '80px',
                                                backgroundSize: 'cover',
                                                backgroundPosition: 'center',
                                                borderRadius: '50%',
                                                margin: '0 auto'
                                            } }),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes", style: { marginTop: '12px' } },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Ahmed Eldessouky"),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Tax Leader ")))))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid tabContent" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row justify-content-center" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 pro-12", style: { maxWidth: '600px' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard text-center" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle", style: {
                                                backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/asim%20sheikh.jpg)',
                                                width: '80px',
                                                height: '80px',
                                                backgroundSize: 'cover',
                                                backgroundPosition: 'center',
                                                borderRadius: '50%',
                                                margin: '0 auto'
                                            } }),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes", style: { marginTop: '12px' } },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Asim Sheikh"),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Tax COO")))))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 pro-hd-1" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "Sub Service Line & Tax Quality Leaders")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 pro-13" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1 x1", style: { textAlign: 'center' } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Ahmed%20Aboelfotouh.jpg)' } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Ahmed Aboelfotouh"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Global Compliance & Reporting (GCR)"))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1", style: { textAlign: 'center' } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Mohammed%20Bilal%20Akram.jpg)' } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Mohammed Bilal Akram"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Indirect Tax (IDT)"))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1", style: { textAlign: 'center' } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Rajan%20Parmar.png)' } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Rajan Parmar"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "International Tax & Transaction Services (ITTS)"))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1", style: { textAlign: 'center' } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/n8.png)' } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Chris P. Sioufi"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Law"))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1", style: { textAlign: 'center' } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Xavier%20Delaunay.jpg)' } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Xavier Delaunay"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "People Advisory Services (PAS)"))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1", style: { textAlign: 'center' } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Barry%20Magill.jpg)' } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Barry Magill"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Tax Quality Leader")))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 pro-hd-1" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "Competency Leaders")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 pro-13" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1 x1", style: { textAlign: 'center' } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Aamer%20Bhatti.jpg)' } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Aamer Bhatti"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "E - Invoicing"))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1", style: { textAlign: 'center' } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Jeanine%20Daou.jpg)' } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Jeanine Daou"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Tax Policy"))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1", style: { textAlign: 'center' } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Sohail%20Nini.jpg)' } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Sohail Nini"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Accounting Compliance & Reporting (ACR)"))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1 x1", style: { textAlign: 'center' } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Adil%20Rao.jpg)' } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Adil Rao"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Transfer Pricing"))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1", style: { textAlign: 'center' } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Ramy%20Rass.jpg)' } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Ramy Rass"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Global Trade")))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-6 cg-6" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 pro-hd-1" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "MENA Industry Group Leaders")),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 pro-13" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1 x1", style: { textAlign: 'center' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/ahmad.png)' } }),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Ahmad Ahmad"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Government & Infrastructure Industry"))),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1", style: { textAlign: 'center' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Mayur%20Pau.jpg)' } }),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Mayur Pau"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Financial Services Industry"))),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1", style: { textAlign: 'center' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Mobin%20Khan.jpg)' } }),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Mobin Khan"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Industrials & Energy Industry"))))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-6 cg-7" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 pro-hd-1" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "Tax Industry Group Leaders")),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 pro-13" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1", style: { textAlign: 'center' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/ey-stuart-halstead.jpg)' } }),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Stuart Halstead"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Government & Infrastructure Industry"))),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1 x1", style: { textAlign: 'center' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/ey-ahmed-akeel.jpg)' } }),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Ahmed Akeel"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Financial Services Industry"))),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1", style: { textAlign: 'center' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/ey-blake-langridge.jpg)' } }),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Blake Langridge"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Industrial & Energy Industry"))))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-6 cg-6" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 pro-hd-1" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "MENA Growth Accounts Leader")),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 pro-13 col-flex" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1 x1", style: { textAlign: 'center' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Fahad%20Altoaimi.jpg)' } }),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Fahad Altoaimi"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Growth Accounts"))))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-6 cg-7" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 pro-hd-1" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "Tax Growth Accounts Leader")),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 pro-13 col-flex" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1 x1", style: { textAlign: 'center' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Miranda%20Baas.jpg)' } }),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Miranda Baas"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Growth Accounts (GA)"))))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-6 cg-6" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 pro-hd-1" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "MENA Big Bets Leaders")),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 pro-13" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1 x1 b1", style: { textAlign: 'center' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Marco%20Biaggi.jpg)' } }),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Marco Biaggi"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "MENA AI Leader"))),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1 b1", style: { textAlign: 'center' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Michael%20Hasbani.jpg)' } }),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Michael Hasbani"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "MENA Alliances Leader"))),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1 b1", style: { textAlign: 'center' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Omar%20Odeh.jpg)' } }),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Omar Odeh"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "MENA Finance Leader"))),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1 b1", style: { textAlign: 'center' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Bhuvana%20Krishnamoorthy.jpg)' } }),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Bhuvana Krishnamoorthy"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "MENA Managed Services Leader"))),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1 b1", style: { textAlign: 'center' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Yasir%20Ahmad.jpg)' } }),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Yasir Ahmad"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, " MENA Sustainability Leader"))))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-6 cg-7" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 pro-hd-1" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "Tax Big Bets Leaders")),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 pro-13" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1 x1 b1", style: { textAlign: 'center' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Satish%20Karnam.jpg)' } }),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Satish Karnam"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Tax Technology and AI Leader"))),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1 b1", style: { textAlign: 'center' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/ey-lucy-satiyan.jpg)' } }),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Lucy Satiyan"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Tax Alliances Leader"))),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1 b1", style: { textAlign: 'center' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/ey-sohail-nini.jpg)' } }),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Sohail Nini"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Tax Finance Leader"))),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1 b1", style: { textAlign: 'center' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/ey-annabelle-hosatte.jpg)' } }),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Annabelle Hosatte"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Tax Managed Services Leader"))),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1 b1", style: { textAlign: 'center' } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/ey-stefan-majerowski.jpg)' } }),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Stefan Majerowski"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, " Tax Sustainability Leader"))))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 pro-hd-1" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "MENA GEO Leaders")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 pro-13" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1 x1 b1", style: { textAlign: 'center' } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Essa%20Al-Jowder.png)' } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Essa Al-Jowder"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Gulf Coast will include Kuwait, Qatar, Oman and Bahrain"))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1 b1", style: { textAlign: 'center' } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Fahad%20Altoaimi.png)' } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Fahad Altoaimi"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "KSA"))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1 b1", style: { textAlign: 'center' } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Raed%20Ahmad.png)' } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Raed Ahmad"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Levant + will include Iraq, Jordan, Libya, Lebanon, Palestine, Syria and Egypt"))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1 b1", style: { textAlign: 'center' } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Anthony%20O%27Sullivan.png)' } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Anthony O'Sullivan"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "UAE + will include UAE and Pakistan")))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 pro-hd-1" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "MENA TAX Country Leaders")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 pro-13" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1 x1 b1", style: { textAlign: 'center' } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Ali_Almahroos.png)' } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Ali Almahroos"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Bahrain"))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1 b1", style: { textAlign: 'center' } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Amit%20Arora.jpg)' } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Amit Arora"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Kuwait"))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1 b1", style: { textAlign: 'center' } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Sana%20Azam.jpg)' } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Sana Azam"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "United Arab Emirates"))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1 b1", style: { textAlign: 'center' } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Ahmed%20El%20Sayed.jpg)' } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Ahmed El Sayed"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Egypt"))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1 b1", style: { textAlign: 'center' } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Alkesh%20Joshi.jpg)' } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Alkesh Joshi"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Oman"))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1 b1", style: { textAlign: 'center' } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Kevin_Mcmanus.png)' } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Kevin McManus"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Qatar"))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1 b1", style: { textAlign: 'center' } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Haider%20Patel.jpg)' } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Haider Patel"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Pakistan"))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1 b1", style: { textAlign: 'center' } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Jacob%20Rabie.jpg)' } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Jacob Rabie"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Levant (Jordan, Iraq, Palestine, Lebanon, Syria) + Libya"))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileCard v1 b1", style: { textAlign: 'center' } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgCircle v1", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/asim%20sheikh.jpg)' } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDes v1" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" }, "Asim Sheikh"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pDes" }, "Saudi Arabia")))))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "footer" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "\u00A9 2026 EYGM Limited. All rights reserved."))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MenaTaxLeadership);


/***/ }),

/***/ 961:
/*!**************************************************************!*\
  !*** ./lib/webparts/menaTaxHub/components/MenaTaxMarkets.js ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};

var marketsStyles = "\nhtml, body { overflow-x: hidden !important; font-family: EYInterstate; }\n.markets-page { background: #2e2e38; color: #ffffff; min-height: 100vh; }\n.markets-page .container_wrapper { display: block; }\n.markets-page .bannerBackground { background: #2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/market-header.jpg') center / cover; min-height: 100vh; padding: 0; min-height:16vw}\n.markets-page .EYlogo { left: 5vw !important; position: absolute; top: 3vw !important; width: 4vw !important; }\n.markets-page .logoTxt { color: #ffffff; font-size: 2vw !important; left: 11vw !important; position: absolute; top: 4.6vw !important; }\n.markets-page .navbarMenu { list-style: none; margin: 0; padding: 0; position: absolute; right: 6vw !important; top: 5vw !important; }\n.markets-page .navbarMenu li { display: inline-block; }\n.markets-page .navbarMenu a { color: #ffffff; padding: 0 2vw; text-decoration: none; }\n.markets-page .home { width: 1.3vw; }\n.markets-page .navToggle { display: none; }\n.markets-page .row-2 { margin-top: 12vw; padding: 0; }\n.markets-page  .hd1 {\n    color: #ffe600;\n    font-size: 3vw;\n    width: 50%;\n    line-height: 3.4vw;\n    font-family: EYinterstate;\n    margin-top: 9vw;\n    margin-left: 5.5vw;\n    margin-bottom: 2vw; }\n    .row.tabCol{display:block;}\n.markets-page .hd1 span { color: #ffffff; }\n.markets-page .rightBox { background: #2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center / cover; padding: 2vw 4vw 4vw; width: 100%; }\n.markets-page .pageQuote { min-height: 0; }\n.markets-page .quoteLine { color: #ffffff; font-size: 1.05vw; font-weight: 600; line-height: 1.55; margin: 0 0 2.5vw; padding: 0; }\n.markets-page .quoteLine p { margin: 0 0 1.5vw; }\n.markets-page .quoteLine ul { list-style: none; margin: 0 0 1.5vw; padding: 0 0 0 1.6vw; }\n.markets-page .quoteLine li { margin: .35vw 0; position: relative; }\n.markets-page .quoteLine li::before { content: \"\";\n    background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/arrow_png.png);\n    position: absolute;\n    width: 0.7vw;\n    height: 0.6vw;\n    background-size: contain;\n    background-repeat: no-repeat;\n       margin-top: .6vw;\n    left: -1vw; }\n.markets-page .m-Title { color: #ffe600; font-size: 1.5vw; margin: 0 0 2vw; }\n.markets-page .teamGrid { display: flex; flex-wrap: wrap; gap: .6vw; }\n.markets-page .teamCard { background: rgba(255, 255, 255, .08); flex: 0 0 14vw; margin: 0 0 1.6vw; min-height: 14vw; padding: 1vw .6vw; text-align: center; }\n.markets-page .tmImg { background: #000000; border-radius: 50%; height: 5.5vw; margin: 0 auto 1vw; overflow: hidden; width: 5.5vw; }\n.markets-page .tmImg img { height: 100%; object-fit: cover; width: 100%; }\n.markets-page .tmName { color: #ffe600; font-size: 1vw; font-weight: 700; margin: 0; }\n.markets-page .tmp2, .markets-page .tmProfile { color: #ffffff; font-size: .8vw; line-height: 1.45; margin: .4vw 0; }\n.markets-page .footerTab { background: #1a1a24; padding: 5vw; }\n.markets-page .quicklinks { color: #ffffff; display: block; font-size: 1.3vw; margin: 0 0 2vw; width: 100%; }\n.markets-page .quickLinksGrid { display: flex; flex-wrap: wrap; margin: 0 -.4vw; }\n.markets-page .quickLink { flex: 0 0 20%; max-width: 20%; padding: .4vw; }\n.markets-page .footerTab > .row { display: flex; flex-wrap: wrap; margin: 0 -.4vw; }\n.markets-page .footerTab .cl-3 { flex: 0 0 20%; max-width: 20%; padding: .4vw; }\n.markets-page .footerTab .cl-3 > a { color: #ffffff; display: block; height: 100%; text-decoration: none; }\n.markets-page .quickLink a { color: #ffffff; text-decoration: none; }\n.markets-page .col-sm-bx { background: #ffffff0f url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center / cover; box-shadow: 0 0 1.5vw rgba(0, 0, 0, .44); min-height: 7.5vw; position: relative; }\n.markets-page .img-bx { background-position: center; background-size: 160%; bottom: 0; left: 0; position: absolute; top: 0; transition: all .2s ease-in-out; width: 37%; }\n.markets-page .col-sm-bx:hover .img-bx { background-size: 190%; }\n.markets-page .bx-link { font-size: 1vw; left: 45%; line-height: 1.4vw; margin: 0; padding-right: 1vw; position: absolute; top: 2.6vw; width: 44%; }\n.markets-page .bx-link strong { display: block; font-size: .8vw; opacity: .5; }\n.markets-page .col-sm-bx span { bottom: .3vw; color: rgba(255, 255, 255, .52); font-size: 2vw; font-weight: bold; position: absolute; right: 1vw; }\n.markets-page .footer { background: #000000; }\n.markets-page .footer p { color: #ffffff; margin: 0; padding: 1vw 2vw; text-align: right; }\n@media only screen and (max-width: 1200px) { .markets-page .bx-link { font-size: 13px; left: 45%; top: 20px; line-height: 14px; padding-right: 30px; } .markets-page .col-sm-bx span { bottom: 0; font-size: 15px; right: 10px; } .markets-page .col-sm-bx { min-height: 70px; } }\n@media only screen and (max-width: 992px) { .markets-page .teamCard { flex-basis: 33.3333%; max-width: calc(33.3333% - .8vw); } .markets-page .quickLink, .markets-page .footerTab .cl-3 { flex-basis: 33.3333%; max-width: 33.3333%; } }\n@media only screen and (max-width: 768px) { .markets-page .quickLink, .markets-page .footerTab .cl-3 { flex-basis: 50%; max-width: 50%; } }\n@media only screen and (max-width: 575px) { .markets-page .bannerBackground { min-height: 0; } .markets-page .EYlogo { top: 30px !important; width: 40px !important; } .markets-page .logoTxt { font-size: 25px !important; left: 130px !important; top: 30px !important; } .markets-page .navbarMenu { right: 50px !important; top: 60px !important; } .markets-page .home { width: 20px; } .markets-page .row-2 { margin-top: 110px; } .markets-page .hd1 { font-size: 40px; line-height: 36px; margin-top: 70px; width: 100%; } .markets-page .teamCard { flex-basis: 100%; max-width: 100%; } .markets-page .m-Title { font-size: 20px; } .markets-page .tmImg { height: 60px; width: 60px; } .markets-page .tmName { font-size: 13px; } .markets-page .tmp2, .markets-page .tmProfile { font-size: 11px; } }\n@media only screen and (max-width: 500px) { .markets-page .quickLink, .markets-page .footerTab .cl-3 { flex-basis: 100%; max-width: 100%; } }\n";
var apiRoot = 'https://sites.ey.com/sites/MENA_Tax/';
var imageRoot = "".concat(apiRoot, "SiteAssets/MENATax/");
var defaultQuickLinks = [
    { name: 'TAL programme', order: 1, url: "".concat(apiRoot, "SitePages/TAL%20programme.aspx"), image: "".concat(imageRoot, "images/FY23%20tax%20account%20planning%20template.png") },
    { name: 'Pipeline Management - EY CRM Dynamics', order: 2, url: "".concat(apiRoot, "SitePages/Pipeline%20Management.aspx"), image: "".concat(imageRoot, "Markets/mercury-management.png") },
    { name: 'Deal Review Process', order: 3, url: "".concat(apiRoot, "SitePages/Deal%20Review%20Process.aspx"), image: "".concat(imageRoot, "Markets/deal-review-icon.png") },
    { name: 'CX Lens - Our client feedback journey', order: 4, url: 'https://sites.ey.com/:u:/r/sites/MENA_Tax/SitePages/CX%20lens.aspx', image: "".concat(imageRoot, "Markets/feedback.png") },
    { name: 'Win-wire - Our successes in the market', order: 5, url: 'https://sites.ey.com/:u:/r/sites/MENA_Tax/SitePages/Win-wire.aspx', image: "".concat(imageRoot, "Markets/success.png") },
    { name: 'External marketing', order: 6, url: "".concat(apiRoot, "SitePages/External-marketing.aspx"), image: "".concat(imageRoot, "Markets/external-marketing.png") },
    { name: 'Management information reporting', order: 7, url: "".concat(apiRoot, "SitePages/Management-information-Reporting.aspx"), image: "".concat(imageRoot, "Markets/management.png") },
    { name: 'Pricing', order: 8, image: "".concat(imageRoot, "Markets/pricing.png"), status: '(Coming soon)' },
    { name: 'MENA Tax Knowledge and Publications', order: 9, url: "".concat(apiRoot, "SitePages/MENA-Tax-Knowledge-and-Publications.aspx"), image: "".concat(imageRoot, "Markets/mercury-management.png") }
];
var decodeHtml = function (value) {
    var textarea = document.createElement('textarea');
    textarea.innerHTML = value;
    return textarea.value;
};
var MenaTaxMarkets = function (_a) {
    var onShowHome = _a.onShowHome;
    var _b = react__WEBPACK_IMPORTED_MODULE_0__.useState([]), team = _b[0], setTeam = _b[1];
    var quickLinks = defaultQuickLinks;
    var _c = react__WEBPACK_IMPORTED_MODULE_0__.useState({}), introduction = _c[0], setIntroduction = _c[1];
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
        var headers = { accept: 'application/json;odata=verbose' };
        var load = function () { return __awaiter(void 0, void 0, void 0, function () {
            var _a, teamResponse, introResponse, teamData, introData, pageIntroduction;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0: return [4 /*yield*/, Promise.all([
                            fetch("".concat(apiRoot, "_api/web/lists/getByTitle('TeamDetails')/items?$select=Title,Rank,ProfileDetails,ProfileName/Title,File/Name&$expand=ProfileName,File"), { headers: headers }),
                            fetch("".concat(apiRoot, "_api/web/lists/getByTitle('PageIntroduction')/items?$select=Title,LeaderTitle,LeaderQuote"), { headers: headers })
                        ])];
                    case 1:
                        _a = _b.sent(), teamResponse = _a[0], introResponse = _a[1];
                        return [4 /*yield*/, teamResponse.json()];
                    case 2:
                        teamData = _b.sent();
                        return [4 /*yield*/, introResponse.json()];
                    case 3:
                        introData = _b.sent();
                        setTeam(teamData.d.results.map(function (item) { var _a, _b; return ({ name: ((_a = item.ProfileName) === null || _a === void 0 ? void 0 : _a.Title) || item.Rank || '', rank: item.Rank || '', details: item.ProfileDetails || '', image: ((_b = item.File) === null || _b === void 0 ? void 0 : _b.Name) ? "".concat(apiRoot, "TeamDetails/").concat(item.File.Name) : undefined }); }));
                        pageIntroduction = introData.d.results[0] || {};
                        setIntroduction(__assign(__assign({}, pageIntroduction), { LeaderQuote: pageIntroduction.LeaderQuote ? decodeHtml(pageIntroduction.LeaderQuote) : '' }));
                        return [2 /*return*/];
                }
            });
        }); };
        void load();
    }, []);
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "markets-page" },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("style", null, marketsStyles),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container_wrapper" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "webPart" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid bannerBackground" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "EYlogo", src: "".concat(imageRoot, "images/EY_logo.png"), alt: "EY logo" }),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "logoTxt" }, "MENA Tax Hub"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "navbarMenu" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#", onClick: function (event) { event.preventDefault(); onShowHome(); } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "home", src: "".concat(imageRoot, "images/home.png"), alt: "Home" })))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "navToggle", src: "".concat(imageRoot, "images/toggle.png"), alt: "Navigation toggle" })),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row row-2" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "hd1" },
                            "MENA",
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "Tax Markets")))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "rightBox" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { id: "PageContent" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDetails" }),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "pageQuote" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "quoteLine", dangerouslySetInnerHTML: { __html: introduction.LeaderQuote || '' } }))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row tabCol", id: "team-container" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "m-Title" }, "MENA Tax Markets team"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "teamGrid" }, team.map(function (member) { return react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "teamCard", key: "".concat(member.name, "-").concat(member.rank) },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "tmImg" }, member.image && react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: member.image, alt: member.name })),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmName" }, member.name),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmp2" }, member.rank),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmProfile" }, member.details)); })))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid footerTab" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "quicklinks" }, "Quick links")),
                        quickLinks.map(function (link) { return react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cl-3", key: link.order },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: link.url, target: "_blank", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: { backgroundImage: "url(".concat(link.image, ")") } }),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bx-link" },
                                        link.name,
                                        link.status && react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", null, link.status)),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, link.order < 10 ? "0".concat(link.order) : String(link.order))))); })))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "footer" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "\u00A9 2026 EYGM Limited. All rights reserved.")))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MenaTaxMarkets);


/***/ }),

/***/ 425:
/*!**************************************************************!*\
  !*** ./lib/webparts/menaTaxHub/components/MenaTaxQuality.js ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

var qualityStyles = "\nhtml,\nbody {\n    overflow-x: hidden !important;\n    font-family: EYInterstate;\n}\n\n::-moz-selection {\n    color: #ffffff;\n    background: #27ACAA;\n}\n\n::selection {\n    color: #ffffff;\n    background: #27ACAA;\n}\n\nbody::-webkit-scrollbar {\n    display: none;\n}\n\nbody {\n    -ms-overflow-style: none;\n    scrollbar-width: none;\n    position: relative;\n}\n\nform {\n    margin: 0px !important;\n}\n.row{margin:0px !important;}\n.bannerBackground {\n    background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/banner_2.jpg);\n    background-color: #2e2e38;\n    background-size: cover;\n    background-position: center;\n    min-height: 85h;\n    position: relative;\n    background-attachment: fixed;\n}\n\nimg.topShade {\n    position: absolute;\n    top: -17vw;\n    left: -10%;\n    width: 120%;\n}\n\n.EYlogo {\n    width: 4vw;\n    position: absolute;\n    left: 5vw;\n    top: 3vw;\n}\n\np.logoTxt {\n    color: #ffffff;\n    font-size: 2vw;\n    position: absolute;\n    left: 11vw;\n    top: 4.6vw;\n}\n\nimg.home {\n    width: 1.3vw;\n}\n\nul.navbarMenu {\n    position: absolute;\n    right: 6vw;\n    top: 5vw;\n    font-family: EYInterstate;\n}\n\nul.navbarMenu li {\n    display: inline-block;\n    font-size: 1vw;\n    color: #ffffff;\n}\n\nul.navbarMenu li a {\n    color: #ffffff;\n    text-decoration: none;\n    padding: 0vw 2vw;\n}\n\nimg.scrollDown {\n    width: 3vw;\n    position: absolute;\n    left: 50%;\n    bottom: 2vw;\n    background: rgb(255 255 255 / 17%);\n    padding: .7vw .7vw;\n    border-radius: 100vw;\n    transform: translate(-50%, 0%);\n    cursor: pointer;\n}\n\n.hd1 {\n    color: #ffe600;\n    font-size: 3vw;\n    width: 50%;\n    line-height: 3.4vw;\n    font-family: EYinterstate;\n}\n\n.hd1 span {\n    color: #ffffff;\n}\n\n.hd2 {\n    color: #ffffff;\n    font-size: 1vw;\n    width: 51%;\n    display: block;\n}\n\n.row-2 {\n    margin-top: 12vw !important;\n    padding-left: 5vw;\n}\n\n.boxMenu {\n    width: 60vw;\n    height: 11vw;\n    float: left;\n    margin-top: 2vw;\n}\n\n.subMenu {\n    width: 50%;\n    height: 11vw;\n    float: left;\n    -webkit-transition: all .2s ease-in-out;\n    -moz-transition: all .2s ease-in-out;\n    -o-transition: all .2s ease-in-out;\n    transition: all .2s ease-in-out;\n    cursor: pointer;\n}\n\n.subMenu:hover {\n    background-color: rgba(255, 255, 255, .2)\n}\n\n.bx1 {\n    padding: 1.5vw;\n    width: auto;\n    height: auto;\n    background-color: rgba(255, 255, 255, .12);\n    margin-right: 1vw;\n    float: left;\n    width: 18vw;\n    min-height: 13vw;\n    position: relative;\n}\n\n.bxinr1 img {\n    width: 3vw;\n}\n\n.boxInner p {\n    color: #ffffff;\n    line-height: 1.1vw;\n    margin-bottom: 0;\n    margin-top: .7vw;\n}\n\n.boxInner p.q3 {\n    text-align: right;\n    font-size: .9vw;\n    right: 2vw;\n    bottom: 1.5vw;\n    position: absolute;\n}\n\n.q2 {\n    font-size: .9vw;\n}\n\n.boxInner p.q1 {\n    font-size: 1.2vw;\n}\n\n.boxContent span {\n    color: #ffe600;\n    font-size: 1.5vw;\n    margin-right: .3vw;\n    font-weight: bold;\n}\n\n.boxContent p {\n    color: #ffffff;\n    font-size: 1.1vw;\n    line-height: 1.8vw;\n    font-family: EYInterstate;\n    font-weight: lighter;\n}\n\n.boxContent p b {\n    font-size: 1.5vw;\n    line-height: 2.5vw;\n}\n\n.desc {\n    background: #2e2e38;\n    padding: 9vw 9vw 6vw 9vw;\n    background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);\n    background-size: cover;\n    background-attachment: fixed;\n}\n\n.boxContent img {\n    width: 4.4vw;\n    margin-bottom: 1.3vw;\n}\n\np.c4 {\n    color: #ffffff;\n    font-size: 1.2vw;\n    font-family: EYInterstate;\n    line-height: 1.7vw;\n    margin-bottom: 1.5vw;\n}\n\nul.c5 {\n    color: #ffffff;\n    list-style: none;\n    padding: 0;\n}\n\nul.c5 li {\n    position: relative;\n    padding-left: 1.3vw;\n    margin-bottom: 0.6vw;\n    font-size: 1vw;\n}\n\nul.c5 li::before {\n    content: \"\";\n    background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/arrow_icon.png);\n    position: absolute;\n    width: .6vw;\n    height: .6vw;\n    background-size: contain;\n    background-repeat: no-repeat;\n    top: 0.5vw;\n    left: 0;\n}\n\nhr.c8 {\n    margin-top: 2vw;\n    margin-bottom: 3vw;\n    border: 0;\n    border-top: .01vw solid rgb(116 116 116);\n}\n\n.footerTab {\n    background: #1a1a24;\n    padding: 5vw;\n}\n\na.qLInk {\n    color: #ffffff;\n    font-family: EYInterstate;\n    font-size: 1vw;\n    font-weight: lighter;\n    border: .1vw solid #9f9f9f;\n    padding: 0.5vw 1.6vw;\n    border-radius: .4vw;\n    margin-right: .7vw;\n    text-decoration: none;\n    float: left;\n    -webkit-transition: all .2s ease-in-out;\n    -moz-transition: all .2s ease-in-out;\n    -o-transition: all .2s ease-in-out;\n    transition: all .2s ease-in-out;\n}\n\na.qLInk:hover {\n    background: rgba(255, 255, 255, .2)\n}\n\n.quicklinks {\n    color: #ffffff;\n    font-size: 2vw;\n    margin-bottom: 2vw;\n}\n\nimg.qklinks {\n    width: 1.4vw;\n    margin-top: -0.2vw;\n    margin-right: .4vw;\n}\n\na.minfo {\n    color: #000000;\n    text-decoration: none;\n    background: #ffffff;\n    font-size: 1vw;\n    font-family: EYinterstate;\n    padding: 0.5vw 1vw;\n    margin-left: 1.1vw;\n    margin-bottom: 1vw;\n    display: block;\n    float: left;\n    cursor: pointer;\n}\n\n.footer {\n    background-color: #000000;\n    float: left;\n    width: 100%;\n}\n\n.footer p {\n    margin-bottom: 0px;\n    color: #ffffff;\n    font-size: 1vw;\n    padding: 1vw 2vw;\n    text-align: right;\n}\n\n.navToggle {\n    display: none;\n}\n\n.modal-dialog {\n    width: 60%;\n    max-width: 60%;\n}\n\niframe {\n    border: hidden;\n}\n\n.modal-content {\n    background: transparent;\n}\n\n.blurbSec {\n    float: left;\n    width: 30vw;\n    color: #ffffff;\n    font-size: .9vw;\n    line-height: 1.3vw;\n    margin-top: -11.6vw;\n    padding: 2vw 2vw;\n    background: rgba(255, 255, 255, 0.078);\n    height: 25vw;\n}\n\na.lnk {\n    background: #ffe600;\n    color: #000000;\n    padding: 1vw 1vw;\n    margin-left: 60vw;\n    margin-top: 1vw;\n    margin-bottom: 2vw;\n    width: 30vw;\n    text-align: center;\n    font-size: 1.2vw;\n    text-decoration: none;\n    -webkit-transition: all .2s ease-in-out;\n    -moz-transition: all .2s ease-in-out;\n    -o-transition: all .2s ease-in-out;\n    transition: all .2s ease-in-out;\n}\n\na.lnk:hover {\n    background: #ffffff\n}\n\nimg.proImg {\n    width: 5vw;\n    border-radius: 100vw;\n    float: left;\n    margin-right: 1vw;\n}\n\n.tmp2 {\n    font-size: 0.9vw;\n    text-align: center;\n    margin-top: -0.1vw;\n    color: #ffffff;\n    font-weight: bold;\n    margin-bottom: 0.5vw;\n}\n\np.proName {\n    color: #ffffff;\n    font-size: 1vw;\n    margin-bottom: 0vw;\n    padding-top: 1.3vw;\n}\n\np.proDes {\n    color: #ffe600;\n    font-size: .9vw;\n    margin-bottom: 0;\n    margin-top: -.2vw;\n}\n\n.profileDetails {\n    float: left;\n    width: 100%;\n    margin-bottom: 1.2vw;\n}\n\n.tabContent {\n    background-image: url(../images/bgc.png);\n    background-position: center;\n    background-size: cover;\n    background-attachment: fixed;\n    background-color: #2e2e38;\n}\n\n.tabCol {\n    min-height: 10vw;\n    padding: 2vw 6vw;\n}\n\n.m-Title {\n    color: #ffffff;\n    width: 100%;\n    font-size: 1.5vw;\n    padding: 1vw 1vw;\n    margin-bottom: 2vw;\n}\n\n.col-sm-12.sm-tm-5 {\n    -ms-flex: 0 0 16.6666%;\n    flex: 0 0 16.6666%;\n    max-width: 16.6666%;\n    padding: 0vw 0.4vw;\n    padding-bottom: 1.6vw;\n}\n\n.cf {\n    background: rgb(255 255 255 / 6%);\n    min-height: 15vw;\n}\n\n.tmImg {\n    background: #ffffff;\n    width: 5.5vw;\n    height: 5.5vw;\n    border-radius: 100vw;\n    position: relative;\n    left: 50%;\n    transform: translate(-50%, 0);\n    top: 1.5vw;\n    overflow: hidden;\n}\n\n.tmImg img {\n    width: 101%;\n    position: absolute;\n    left: 50%;\n    top: 50%;\n    transform: translate(-50%, -50%);\n}\n\n.tmShare {\n    float: left;\n    position: relative;\n    left: 50%;\n    transform: translate(-50%, 0%);\n}\n\n.Ic0 {\n    width: 1.4vw;\n    float: left;\n}\n\n.Ic2 {\n    width: 1.4vw;\n    float: left;\n    margin-left: 0.8vw;\n}\n\n.tmProfile {\n    font-size: 0.8vw;\n    text-align: center;\n    margin-top: -0.1vw;\n    margin-bottom: 0.5vw;\n    color: #ffffff;\n    padding: 0vw 1vw;\n    padding-bottom: 1vw;\n}\n\n.tmName {\n    font-size: 1vw;\n    font-family: EYInterstate;\n    text-align: center;\n    margin-top: 2.5vw;\n    margin-bottom: 0;\n    color: #ffe600;\n}\n\n.faqBtn img,\nbutton.faqBtn img {\n    width: 1.5vw;\n    margin-left: 0.5vw;\n    margin-top: -.2vw;\n}\n\n.faqBtn {\n  background: transparent;\n  border: 0;\n  cursor: pointer;\n  font: inherit;\n  text-align: left;\n    background: #ffe600;\n    color: #000000;\n    font-size: 1vw;\n    text-decoration: none;\n    outline: none;\n    padding: 0.7vw 1vw;\n    margin-top: 1vw;\n    display: inline-block;\n}\n\n.contactIcons {\n    text-align: center;\n    margin-top: 1vw;\n    margin-bottom: 1vw;\n}\n\na.profile_icons img {\n    width: 1.6vw;\n}\n\na.profile_icons:nth-child(2) img {\n    margin: 0vw 0.5vw;\n}\n\n@media only screen and (max-width: 1200px) {\n    a.qLInk {\n        font-size: 15px;\n        border: 1px solid #9f9f9f;\n        padding: 7px 25px;\n        border-radius: .4vw;\n        margin-bottom: 10px;\n        margin-right: 10px;\n    }\n\n    .footerTab {\n        background: #1a1a24;\n        padding: 60px;\n    }\n\n    .EYlogo {\n        width: 40px;\n        left: 60px;\n        top: 20px;\n    }\n\n    p.logoTxt {\n        font-size: 25px;\n        left: 130px;\n        top: 30px;\n    }\n\n    ul.navbarMenu {\n        right: 50px;\n        top: 37px;\n    }\n\n    ul.navbarMenu li {\n        font-size: 15px;\n    }\n\n    ul.navbarMenu li a {\n        padding: 0vw 20px;\n    }\n\n    img.home {\n        width: 20px;\n    }\n\n    .nav-bar {\n        min-height: 90px;\n    }\n\n    .row-2 {\n        margin-top: 170px;\n        padding-left: 50px;\n    }\n\n    .hd1 {\n        font-size: 37px;\n        width: 50%;\n        line-height: 40px;\n    }\n\n    .hd2 {\n        color: #ffffff;\n        font-size: 16px;\n        width: 80%;\n        display: block;\n    }\n\n    .bannerBackground {\n        min-height: auto;\n    }\n\n    .boxMenu {\n        width: 100%;\n        height: auto;\n        position: static;\n        bottom: 0;\n        left: 40px;\n        margin-bottom: 15px;\n    }\n\n    .bxinr1 img {\n        width: 40px;\n    }\n\n    .boxInner p {\n        color: #ffffff;\n        line-height: 18px;\n        margin-bottom: 0;\n        margin-top: 18px;\n        font-size: 14px;\n    }\n\n    .bx1 {\n        padding: 20px;\n        margin-right: 10px;\n        margin-bottom: 15px;\n        width: 31%;\n        min-height: 190px;\n    }\n\n    .blurbSec {\n        width: 95%;\n        font-size: 14px;\n        line-height: 23px;\n        margin-top: -19px;\n        padding: 20px 20px;\n        height: auto;\n    }\n\n    img.proImg {\n        width: 80px;\n        margin-right: 15px;\n    }\n\n    p.proName {\n        font-size: 19px;\n        margin-bottom: 0vw;\n        padding-top: 15px;\n    }\n\n    .profileDetails {\n        margin-bottom: 20px;\n    }\n\n    p.proDes {\n        font-size: 16px;\n        margin-bottom: 0;\n        margin-top: 0px;\n    }\n\n    .quicklinks {\n        font-size: 30px;\n        margin-bottom: 25px;\n    }\n\n    .qklinks {\n        display: none;\n    }\n\n    .footer p {\n        margin-bottom: 0px;\n        color: #ffffff;\n        font-size: 13px;\n        padding: 15px 20px;\n        text-align: right;\n    }\n\n    .boxInner p.q1 {\n        font-size: 17px;\n    }\n\n    .boxInner p.q3 {\n        text-align: right;\n        font-size: 11px;\n    }\n\n    a.lnk {\n        padding: 10px 20px;\n        margin-top: 1vw;\n        font-size: 14px;\n        width: auto;\n        min-width: 35vw;\n        float: right;\n        margin-left: auto;\n        margin-right: 5%;\n    }\n\n    .m-Title {\n        font-size: 17px;\n        padding: 8px 7px;\n        margin-bottom: 10px;\n    }\n\n    .tmImg {\n        width: 50px;\n        height: 50px;\n        border-radius: 100vw;\n        top: 10px;\n    }\n\n    .tmName {\n        font-size: 12px;\n        margin-top: 14px;\n    }\n\n    .tmp2 {\n        font-size: 11px;\n        margin-top: -1px;\n        margin-bottom: 6px;\n    }\n\n    .tmProfile {\n        font-size: 11px;\n        margin-top: 0px;\n        margin-bottom: 10px;\n        padding: 0vw 10px;\n        padding-bottom: 10px;\n    }\n\n    .col-sm-12.sm-tm-5 {\n        -ms-flex: 0 0 16.6666%;\n        flex: 0 0 33.333%;\n        max-width: 33.333%;\n        padding: 5px 5px;\n        padding-bottom: 5px;\n    }\n\n    .cf {\n        height: 100%;\n    }\n}\n\n@media only screen and (max-width: 992px) {\n    .boxMenu {\n        width: 100%;\n    }\n}\n\n@media only screen and (max-width: 768px) {\n    .boxInner p.q3 {\n        position: static;\n    }\n\n    .bx1 {\n        min-height: 140px;\n        width: 93%;\n    }\n\n    .blurbSec {\n        width: 93%;\n    }\n\n    a.lnk {\n        margin-right: 7%;\n    }\n}\n\n@media only screen and (max-width: 750px) {\n    .bx1 {\n        min-height: 210px;\n    }\n}\n\n@media only screen and (max-width: 650px) {\n    ul.navbarMenu {\n        top: 90px;\n    }\n\n    .modal-dialog {\n        width: 100%;\n        max-width: 95% !important;\n    }\n}\n\n@media only screen and (max-width: 575px) {\n    .bx1 {\n        min-height: auto;\n    }\n\n    .col-sm-12.sm-tm-5 {\n        -ms-flex: 0 0 50%;\n        flex: 0 0 50%;\n        max-width: 50%;\n        padding: 5px 5px;\n        padding-bottom: 5px;\n    }\n\n    a.lnk {\n        width: 100%;\n    }\n}\n";
var MenaTaxQuality = function (_a) {
    var onShowHome = _a.onShowHome, onShowFAQs = _a.onShowFAQs;
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
        var $ = window.jQuery;
        if (!$) {
            return;
        }
        $(document).ready(function () {
            $('.subCircle').hover(function () {
                $('.overlayRight').removeClass('active');
                $('.overlayLeft').addClass('active');
            });
            $('.subCircle.c70').hover(function () {
                $('.overlayLeft').removeClass('active');
                $('.overlayRight').addClass('active');
            });
            $('.onClickShow').hover(function () {
                $('.inside').removeClass('active');
                var target = $(this).attr('target') || '';
                $('.ins' + target).addClass('active');
            });
            $('.close_slide').click(function () {
                $('.overlayLeft, .overlayRight').removeClass('active');
            });
            $('.scrollDown').click(function () {
                $('html, body').animate({
                    scrollTop: $('.webAnimation').offset().top
                }, 2000);
            });
            $('#newsModal').on('hidden.bs.modal', function () {
                $('#newsModal iframe').attr('src', $('#newsModal iframe').attr('src'));
            });
        });
    }, []);
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("style", null, qualityStyles),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container_wrapper" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "webPart" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid bannerBackground" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/EY_logo.png", className: "EYlogo", alt: "EY logo" }),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "logoTxt" }, "MENA Tax Hub"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "navbarMenu" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#", onClick: function (event) { event.preventDefault(); onShowHome(); } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "home", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home.png", alt: "Home" })),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "|")),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#engagement" }, "Engagement Lifecycle"))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/toggle.png", className: "navToggle", alt: "Toggle" })),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row row-2" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "hd1" }, "Tax Quality"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "hd2" }, "Tax Quality's goal is to improve your ability to serve clients and achieve success in the marketplace by supporting all Tax Service Line professionals with practical advice on quality and risk management."),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "boxMenu" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/MENATaxQualityKnowledge/SitePages/MENA_Tax_Quality.aspx", target: "_blank", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "bx1 subMenu" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "boxInner bxinr1" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "q1" }, "MENA Tax Quality"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "q2" }, "Provide insights on MENA TQ, Global policy documents, current news trends and many more."),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "q3" }, "READ MORE")))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#eyi" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "bx1 subMenu" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "boxInner bxinr1" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "q1" }, "EYI Documentation"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "q2" }, "EYI MyDocs is the client engagement filing and document management system for Tax."),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "q3" }, "READ MORE")))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://portalone.ey.net/app/home?i=mena", target: "_blank", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "bx1 subMenu" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "boxInner bxinr1" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "q1" }, "Knowledge Database"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "q2" }, "Provides information such as relevant tax laws, regulations, policies including guides, tax alerts and other thought leadership materials."),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "q3" }, "READ MORE")))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { type: "button", className: "faqBtn", onClick: onShowFAQs },
                                "MENA Tax Quality FAQs ",
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/faq.png?csf=1&web=1&e=ET46ax", alt: "FAQ" }))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "blurbSec" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDetails" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Barry%20Magill.jpg", className: "proImg", alt: "Barry Magill" }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "proName" }, "Barry Magill"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "proDes" }, "MENA Tax Quality Leader")),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "blurbTxt" }, "Barry, based in Abu Dhabi, is the MENA Tax Quality Leader and also leads EY's M&A Tax practice for the MENA region. He has over 17 years of experience across the UK, MENA and APAC regions, having worked in Saudi Arabia, the UAE and China. Barry specializes in transactions and international tax advisory, focusing on complex transactions and capital markets. He holds an LL.B from Queens University, Belfast, and is a member of the Institute of Chartered Accountants Ireland.")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: "lnk", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/MENA%20Tax%20Quality%20and%20Knowledge%20FY23%20Q1%20newsletter.pdf", target: "_blank", rel: "noreferrer" }, "Consultation and escalation approval process"))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid tabContent" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row tabCol" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "m-Title" }, "MENA Tax Quality team"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 sm-tm-5" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "cf" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "TmBox" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "tmImg" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Elis_Ademova.jpg", alt: "Elis Rallien", style: { width: '100% !important' } })),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmName" }, "Elis Rallien"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmp2" }, "Director"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "contactIcons" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "mailto:elis.rallien@qa.ey.com", target: "_blank", className: "profile_icons", rel: "noreferrer" },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/mail-icon01.png", alt: "mail" })),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "tel:+971563811888", target: "_blank", className: "profile_icons", rel: "noreferrer" },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/call-icon01.png", alt: "call" })),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://people.ey.com/PersonImmersive.aspx?accountname=i:0%23.f%7cmembership%7celis.ademova@uk.ey.com", target: "_blank", className: "profile_icons", rel: "noreferrer" },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/profile-icon01.png", alt: "profile" })))))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 sm-tm-5" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "cf" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "TmBox" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "tmImg" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Keshnee.png", alt: "Keshnee Pillay" })),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmName" }, "Keshnee Pillay"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmp2" }, "Senior Manager"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "contactIcons" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "mailto:keshnee.pillay@ae.ey.com", target: "_blank", className: "profile_icons", rel: "noreferrer" },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/mail-icon01.png", alt: "mail" })),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "tel:+97147010568", target: "_blank", className: "profile_icons", rel: "noreferrer" },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/call-icon01.png", alt: "call" })),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://people.ey.com/PersonImmersive.aspx?accountname=i:0%23.f%7cmembership%7ckeshnee.pillay@ae.ey.com", target: "_blank", className: "profile_icons", rel: "noreferrer" },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/profile-icon01.png", alt: "profile" })))))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 sm-tm-5" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "cf" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "TmBox" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "tmImg" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Sarah%20N%20Hussein.jpg", alt: "Sarah Hussein" })),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmName" }, "Sarah Hussein"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmp2" }, "Senior Manager"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "contactIcons" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "mailto:sarah.hussein@iq.ey.com", target: "_blank", className: "profile_icons", rel: "noreferrer" },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/mail-icon01.png", alt: "mail" })),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "tel:+9647835415011", target: "_blank", className: "profile_icons", rel: "noreferrer" },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/call-icon01.png", alt: "call" })),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://people.ey.com/PersonImmersive.aspx?accountname=i:0%23.f%7cmembership%7csarah.hussein@iq.ey.com", target: "_blank", className: "profile_icons", rel: "noreferrer" },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/profile-icon01.png", alt: "profile" })))))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 sm-tm-5" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "cf" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "TmBox" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "tmImg" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Amisha%20Khambhaita2.jpg", alt: "Amisha Khambhaita" })),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmName" }, "Amisha Khambhaita"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tmp2" }, "Senior Manager"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "contactIcons" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "mailto:amisha.khambhaita@ae.ey.com", target: "_blank", className: "profile_icons", rel: "noreferrer" },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/mail-icon01.png", alt: "mail" })),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "tel:+97147010703", target: "_blank", className: "profile_icons", rel: "noreferrer" },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/call-icon01.png", alt: "call" })),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://people.ey.com/PersonImmersive.aspx?accountname=i:0%23.f%7cmembership%7camisha.khambhaita@ae.ey.com", target: "_blank", className: "profile_icons", rel: "noreferrer" },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/profile-icon01.png", alt: "profile" })))))))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid footerTab", hidden: true },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "quicklinks" }, "Quick links"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://mercury.ey.net/Pages/default.aspx", className: "qLInk", target: "_blank", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "qklinks", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png", alt: "Mercury OneGate" }),
                                "Mercury OneGate"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://mybusiness.ey.net/", className: "qLInk", target: "_blank", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "qklinks", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png", alt: "Engagement metrics" }),
                                "Engagement metrics"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "http://www.mybusiness.ey.net/myportal/reporttree.aspx", className: "qLInk", target: "_blank", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "qklinks", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png", alt: "Time utilization report" }),
                                "Time utilization report"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://www.mdm.ey.net/bp/search/", className: "qLInk", target: "_blank", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "qklinks", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png", alt: "MDM" }),
                                "MDM"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sort.ey.net/", className: "qLInk", target: "_blank", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "qklinks", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png", alt: "SORT" }),
                                "SORT"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://gis.ey.net/home/dashboard/search", className: "qLInk", target: "_blank", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "qklinks", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png", alt: "GIS" }),
                                "GIS"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/GlobalMercurySupport/SitePages/MercuryHome.aspx", className: "qLInk", target: "_blank", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "qklinks", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png", alt: "Global Mercury" }),
                                "Global Mercury")))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "footer" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "\u00A9 2026 EYGM Limited. All rights reserved.")))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "modal fade show", id: "newsModal", tabIndex: -1, role: "dialog", "aria-modal": "true" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "modal-dialog modal-dialog-centered carousel-dialog", role: "document" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "modal-content", "ng-repeat": "abc in selectedvalues" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "modal-body carousel-body", style: { textAlign: 'center' } },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { type: "button", className: "close carousel-close", "data-dismiss": "modal", "aria-label": "Close" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { "aria-hidden": "true" }, "x")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "Hdimgz" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("iframe", { width: "100%", height: "500", src: "https://web.microsoftstream.com/embed/video/28ad8a48-6df2-46af-b718-746434a4d2be?autoplay=false&showinfo=true", allowFullScreen: true, title: "stream video" })),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "modalBody" })))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MenaTaxQuality);


/***/ }),

/***/ 436:
/*!******************************************************************!*\
  !*** ./lib/webparts/menaTaxHub/components/MenaTaxQualityFAQs.js ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

var faqStyles = "\n  .menaFaqs {\n    background: #2e2e38;\n    color: #ffffff;\n    font-family: EYInterstate, Arial, sans-serif;\n  }\n\n  .menaFaqs__banner {\n    background-color: #2e2e38;\n    background-image: url('https://sites.ey.com/sites/MENATaxQualityKnowledge/SiteAssets/MENA_Tax_Qaulity_Knowledge/images/GettyImages-1130492410.jpg');\n    background-position: center;\n    background-size: cover;\n    min-height: 30vh;\n    padding: 0 5vw;\n    position: relative;\n  }\n\n  .menaFaqs__user {\n    align-items: center;\n    display: flex;\n    gap: 1vw;\n    justify-content: flex-end;\n    padding-top: 4vw; display:none;\n  }\n\n  .menaFaqs__user p {\n    font-size: 1vw;\n    margin: 0;\n  }\n\n  .menaFaqs__user img {\n    border-radius: 50%;\n    height: 2.5vw;\n    object-fit: cover;\n    width: 2.5vw;\n  }\n\n  .menaFaqs__logo {\n    display: block;\n    padding-top: 3vw;\n    width: 3vw;\n  }\n\n  .menaFaqs__title {\n    color: #ffffff;\n    font-size: 2vw;\n    line-height: 3.3vw;\n    margin: 3vw 0 0;\n  }\n\n  .menaFaqs__content {\n    background-color: #2e2e38;\n    background-image: url('https://sites.ey.com/sites/MENATaxQualityKnowledge/SiteAssets/MENA_Tax_Qaulity_Knowledge/images/bgm.png');\n    background-position: center;\n    background-size: cover;\n    padding: 3vw 7vw;\n  }\n\n  .menaFaqs__section {\n    border-bottom: 1px solid rgba(255, 255, 255, 0.24);\n  }\n.menaFaqs__section button{}\n  .menaFaqs__trigger {\n    align-items: center;\n    background: transparent;\n    border: 0;\n    color: #ffffff;\n    cursor: pointer;\n    display: flex;\n    font-family: inherit;\n    font-size: 1.3vw;\n    justify-content: space-between;\n    line-height: 1.8vw;\n    padding: 0.8vw 0;\n    text-align: left;\n    width: 100%;\n  }\n\n  .menaFaqs__trigger:hover,\n  .menaFaqs__trigger:focus {\n    color: #ffe600;\n  }\n\n  .menaFaqs__icon {\n    color: #ffe600;\n    flex: 0 0 auto;\n    font-size: 1.5vw;\n    margin-left: 1vw;\n  }\n\n  .menaFaqs__answer {\n    color: #ffffff;\n    font-family: Arial, sans-serif;\n    font-size: 1vw;\n    line-height: 1.6;\n    padding: 0 2vw 1.5vw;\n  }\n\n  .menaFaqs__answer p {\n    margin: 0 0 1vw;\n  }\n\n  .menaFaqs__answer ul {\n    margin: 0 0 1vw;\n    padding-left: 2vw;\n  }\n\n  .menaFaqs__answer a {\n    color: #ffe600;\n  }\n\n  .menaFaqs__footer {\n    background: #000000;\n    color: #ffffff;\n    font-size: 1vw;\n    padding: 1vw 2vw;\n    text-align: right;\n  }\n\n  .menaFaqs__back {\n    background: #ffe600;\n    border: 0;\n    color: #2e2e38;\n    cursor: pointer;\n    font-weight: 700;\n    margin: 1vw 0 0 2vw;\n    padding: 0.6vw 1vw;\n  }\n\n  @media only screen and (max-width: 1200px) {\n    .menaFaqs__user { padding-top: 55px; }\n    .menaFaqs__user p { font-size: 12px; }\n    .menaFaqs__user img { height: 32px; width: 32px; }\n    .menaFaqs__logo { margin-top: 46px; width: 35px; }\n    .menaFaqs__title { font-size: 25px; line-height: 30px; margin-top: 40px; }\n    .menaFaqs__trigger { font-size: 18px; line-height: 26px; }\n    .menaFaqs__answer { font-size: 13px; line-height: 20px; }\n    .menaFaqs__footer { font-size: 12px; padding: 10px 20px; }\n  }\n\n  @media only screen and (max-width: 575px) {\n    .menaFaqs__banner { min-height: auto; padding-bottom: 30px; }\n    .menaFaqs__content { padding: 20px 40px; }\n    .menaFaqs__trigger { font-size: 16px; line-height: 23px; }\n    .menaFaqs__icon { font-size: 18px; }\n    .menaFaqs__answer { padding: 0 0 18px; }\n    .menaFaqs__back { margin: 12px 0 0 20px; }\n  }\n";
var faqSections = [
    {
        title: 'Tax Quality (TQ) essentials',
        items: [
            {
                question: 'How to achieve effective MENA Tax Quality (TQ) consultation?',
                answer: (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "Experience shows that engagement teams that consult as early as possible, and provide detailed background information from the outset, get quicker and better responses."),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "Before approaching TQ, reference relevant guidance and consult the TQ Champion dedicated to your jurisdiction. A productive consultation should include:"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "The full legal name of the client"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "The scope of the proposed work, including the SORT code"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Relevant contractual frameworks, such as MSAs or GFAs"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Approximate fees and any non-standard fee arrangements"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Third-party involvement and prior Quality or RM/Legal involvement")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "For complicated matters, use a phone call, face-to-face meeting, or email rather than lengthy Teams chats so the consultation can be properly documented.")))
            },
            {
                question: 'If a client asks us to raise an invoice to another entity of its group, what do we do?',
                answer: react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "Push back first. If the client persists, obtain proof that the entity is part of the client group, update the PACE form, issue a variation letter, and clarify that the original client remains ultimately responsible for the fees and liability.")
            },
            {
                question: 'Where can we find the list of TQ Champions?',
                answer: react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null,
                    "The list is available on the ",
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/MENATaxQualityKnowledge/SitePages/TQchampions.aspx", target: "_blank", rel: "noreferrer" }, "MENA TQ SharePoint site"),
                    ".")
            },
            {
                question: 'What is the policy around sharing deliverables in editable format?',
                answer: react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "Our standard policy is not to share editable deliverables. Ask why the client needs the editable version and assess the risk with the Partner, who remains responsible for the decision.")
            },
            {
                question: 'When do time reversals require approval from TQ?',
                answer: react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "Time reversals require approval as follows:"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "0-20 hours: EP"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "20-40 hours: SSL"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "40 hours or above: TQL")))
            },
            {
                question: "Where can I obtain EY's Professional Indemnity Insurance certificate?",
                answer: react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null,
                    "A copy of the certificate can be located on the ",
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/MENAGCOSharePoint/SitePages/MENA-Professional-Indemnity-Insurance-(PII).aspx", target: "_blank", rel: "noreferrer" }, "GCO SharePoint site"),
                    ".")
            }
        ]
    },
    {
        title: 'Process for Acceptance of Clients and Engagements (PACE)',
        items: []
    },
    {
        title: 'Contracting',
        items: [
            {
                question: 'Is it possible to amend or remove clauses from standard GTCs?',
                answer: react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "Refer first to the Global Business Guidelines Non-Audit GTCs and the contracting guidance. These resources explain when consultation with GCO is required and which additional approvals may be needed.")
            },
            {
                question: 'Can we use an addendum instead of a variation letter?',
                answer: react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null,
                    "Addendum and variation letters serve the same purpose. An EY variation/addendum template is available in the ",
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/MENAGCOSharePoint/Shared%20Documents/Forms/AllItems.aspx", target: "_blank", rel: "noreferrer" }, "GCO repository"),
                    ".")
            },
            {
                question: 'How do we implement a client data protection agreement request?',
                answer: react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "Consult MENA TQ and GCO before sharing or signing additional data protection agreements. All client requests must be reviewed internally before signing.")
            },
            {
                question: 'Is a new Engagement Agreement mandatory every year for recurring tax services?',
                answer: react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "Engagement agreements should be valid for the project duration. Agreements for recurring annual services must not remain effective for more than five years without a review of their terms.")
            },
            {
                question: 'Where can we find the Acknowledgment Agreement?',
                answer: react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "It is available under the Cross-border contracting guidance document. It should be used only when local billing under a PSM is necessary.")
            },
            {
                question: 'What are the requirements of a PSM?',
                answer: react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "The Prime Member Firm remains solely responsible and liable to the client. It must ensure the Engagement Agreement is signed, issue a PSM in line with the EAGP, satisfy itself about local work quality, and retain required working papers.")
            }
        ]
    },
    {
        title: 'EYI MyDocs',
        items: [
            {
                question: 'Are all client communications required to be filed under EYI during a project?',
                answer: react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "Yes. All key emails should be filed during the project so the EYI folder tells the engagement story from beginning to end. Refer to the Global Tax Service Line Policy and EYI MyDocs Global Protocols for further guidance.")
            }
        ]
    },
    { title: 'Tax Technology Approval Roadmap (TTAR)', items: [] },
    { title: 'Deal Review', items: [] }
];
var MenaTaxQualityFAQs = function (_a) {
    var onShowHome = _a.onShowHome;
    var _b = react__WEBPACK_IMPORTED_MODULE_0__.useState(faqSections[0].title), openSection = _b[0], setOpenSection = _b[1];
    var _c = react__WEBPACK_IMPORTED_MODULE_0__.useState(null), openQuestion = _c[0], setOpenQuestion = _c[1];
    var toggleSection = function (title) {
        setOpenSection(function (current) { return current === title ? null : title; });
        setOpenQuestion(null);
    };
    var toggleQuestion = function (questionKey) {
        setOpenQuestion(function (current) { return current === questionKey ? null : questionKey; });
    };
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "menaFaqs" },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("style", null, faqStyles),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("header", { className: "menaFaqs__banner" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#", onClick: function (event) { event.preventDefault(); onShowHome(); }, style: { position: 'absolute', right: '5vw', top: '2vw' } },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "home", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home.png", alt: "Home", style: { width: '1.3vw' } })),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "menaFaqs__user" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "Hi Hiran Jose"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENAInnovation/_layouts/15/userphoto.aspx?size=M&accountname=Hiran.Jose@gds.ey.com", alt: "Current user" })),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/MENATaxQualityKnowledge/SitePages/MENA_Tax_Quality.aspx", target: "_blank", rel: "noreferrer" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "menaFaqs__logo", src: "https://sites.ey.com/sites/MENATaxQualityKnowledge/SiteAssets/MENA_Tax_Qaulity_Knowledge/images/EY_logo.png", alt: "EY logo" })),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("h1", { className: "menaFaqs__title" }, "MENA Tax Quality FAQs")),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("main", { className: "menaFaqs__content", id: "mena-tax-quality-faqs" }, faqSections.map(function (section, sectionIndex) {
            var sectionOpen = openSection === section.title;
            var sectionId = "faq-section-".concat(sectionIndex);
            return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("section", { className: "menaFaqs__section", key: section.title },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { type: "button", className: "menaFaqs__trigger", "aria-expanded": sectionOpen, "aria-controls": sectionId, onClick: function () { return toggleSection(section.title); } },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, section.title),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "menaFaqs__icon", "aria-hidden": "true" }, sectionOpen ? '-' : '+')),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { id: sectionId, hidden: !sectionOpen }, sectionOpen && section.items.length > 0 && section.items.map(function (item, questionIndex) {
                    var questionKey = "".concat(sectionIndex, "-").concat(questionIndex);
                    var questionId = "faq-question-".concat(questionKey);
                    var answerId = "faq-answer-".concat(questionKey);
                    var questionOpen = openQuestion === questionKey;
                    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { key: questionKey },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { type: "button", id: questionId, className: "menaFaqs__trigger", "aria-expanded": questionOpen, "aria-controls": answerId, onClick: function () { return toggleQuestion(questionKey); } },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, item.question),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "menaFaqs__icon", "aria-hidden": "true" }, questionOpen ? '-' : '+')),
                        questionOpen && react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { id: answerId, className: "menaFaqs__answer", role: "region", "aria-labelledby": questionId }, item.answer)));
                }))));
        })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("footer", { className: "menaFaqs__footer" }, "\u00A9 2026 EYGM Limited. All rights reserved.")));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MenaTaxQualityFAQs);


/***/ }),

/***/ 494:
/*!********************************************************************!*\
  !*** ./lib/webparts/menaTaxHub/components/MenaTaxResourcingHub.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

var imageRoot = 'https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/';
var quickLinks = [
    ['https://apps.powerapps.com/play/e/c8ee9bdf-796c-e519-a5df-582e17394e4b/a/e5843273-4dd0-456f-bc51-a11b2a7b3b07', 'i1.png', 'High Level Budget Calculator'],
    ['https://app.powerbi.com/groups/me/apps/88b138f5-216c-4ac6-b72a-a19e005bd381/reports/db646e19-5e24-4e38-accc-9a8c2e8743e9/ReportSection?chromeless=1', 'i2.png', 'Finance & Engagement Report'],
    ['https://app.powerbi.com/groups/me/apps/88b138f5-216c-4ac6-b72a-a19e005bd381/reports/224a0ea2-bd8c-4441-b136-31641b8a8103/ReportSection7e1a9e9c667034ba4b14?chromeless=1', 'i3.png', 'People Dashboard (Utilzation & Nationalization)'],
    ['https://apps.powerapps.com/play/e/a3c669f6-ac2e-4e77-ad43-beab3e15bee7/a/a422fad2-0a90-4117-b14b-3da399c77b75', 'i4.png', 'Hiring Tool'],
    ['https://apps.powerapps.com/play/e/a3c669f6-ac2e-4e77-ad43-beab3e15bee7/a/3cfbfa9b-b76f-4eda-ac6d-4fca290223ed', 'apps.png', 'Hourly Cost Rate Comparison App']
];
var resources = [
    ['Onshore', '#onshore', 'onshore.jpg'],
    ['Non-GCC (Levant / Rapid Pakistan)', '#nongcc', 'thumbnail-203.png'],
    ['GDS', '#gds', 'thumbnail-304.jpg'],
    ['FY25-GDS FTE MENA Tax Rate Card', 'https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/ResourcingHub/FY25-GDS-FTE-Tax-Rate-Card_MENA%20.pdf', 'thumbnail306.png'],
    ['FY25-GDS T&M MENA Tax Rate Card', 'https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/ResourcingHub/FY25-GDS-T-M-Tax-Rate-Card_MENA%20.pdf', 'thumbnail307.png']
];
var people = [
    ['Bobin Abraham', 'MENA Tax EXM Leader', 'Riyadh, KSA', 'Bobin%20T.jpg'],
    ['Dileep Rajasekhar', 'Tax EXM Consultant', 'Kuwait', 'Dileep%20Rajasekhar.jpg'],
    ['Jellen M Jose', 'Tax EXM Consultant', 'Dubai, UAE', 'Jellen%20Jose.jpg'],
    ['Meghna Jayachandran', 'Tax EXM Analyst', 'GDS, India', 'fa4b0e99-0d5a-4485-bca4-de12736bb7b1_LThumb.jpg'],
    ['Jose Thomas', 'Tax EXM Analyst', 'GDS, India', 'Jose%20thomas.jpg']
];
var ResourcingStyles = function () { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("style", null, "\n    .resourcingHub{background:#2e2e38;color:#fff;font-family:EYInterstate,Arial,sans-serif;overflow:hidden}.resourcingHub *{box-sizing:border-box}.resourcingHub__loading{align-items:center;background:#1a1a24;display:flex;inset:0;justify-content:center;position:fixed;z-index:9999}.resourcingHub__loading.is-hidden{display:none}.resourcingHub__loading .item{border:.2vw solid #ffe600;border-bottom-color:transparent;border-top-color:transparent;border-radius:50%;position:absolute;animation:resourcingSpin 2s ease infinite}.resourcingHub__loading .item:nth-child(1){height:30px;width:30px}.resourcingHub__loading .item:nth-child(2){height:50px;width:50px;animation-delay:.1s}.resourcingHub__loading .item:nth-child(3){height:70px;width:70px;animation-delay:.2s}.resourcingHub__loading .item:nth-child(4){height:90px;width:90px;animation-delay:.3s}@keyframes resourcingSpin{50%{transform:rotate(180deg)}100%{transform:rotate(0)}}\n    .resourcingHub__nav{background:#2e2e38;min-height:6vw;position:relative}.resourcingHub__nav .EYlogo{left:5vw;position:absolute;top:1.5vw;width:3vw}.resourcingHub__nav .logoTxt{color:#fff;font-size:2vw;left:11vw;margin:0;position:absolute;top:2.2vw}.resourcingHub__nav .homeLink{position:absolute;right:6vw;top:2.4vw}.resourcingHub__nav .homeLink img{width:1.3vw}.resourcingHub__hero{background:url('".concat(imageRoot, "banner-images.png') center/cover;padding:2vw 5vw;min-height:17vw}.resourcingHub__hero h1{font-size:2vw;font-weight:400;margin:5vw 0 .3vw 1vw}.resourcingHub__hero hr,.resourcingHub__section hr{border:0;border-top:.2vw solid #ffe600;margin:0 0 0 1.2vw;width:3vw}.resourcingHub__accordion{background:#00000017;border-bottom:.1vw solid #363636;padding:1vw 6vw}.resourcingHub__accordion h2{background:url('").concat(imageRoot, "arrow-down.png') no-repeat 95% .3vw/1.23vw;cursor:pointer;font-size:1.5vw;font-weight:400;margin:0;padding:.4vw 6.5vw .4vw 0}.resourcingHub__accordion h2.is-open{background-image:url('").concat(imageRoot, "arrow-up.png')}.resourcingHub__accordionHint{color:#ffe600;float:right;font-size:.9vw}.resourcingHub__accordionBody{padding:1vw 0}.resourcingHub__accordionBody p,.resourcingHub__accordionBody li{font:1vw/1.5 Arial,sans-serif}.resourcingHub__accordionBody ul,.resourcingHub__intro ul{list-style:none;margin:0;padding:0}.resourcingHub__accordionBody li,.resourcingHub__intro li{margin-bottom:1.1vw;padding-left:1.5vw;position:relative}.resourcingHub__accordionBody li:before,.resourcingHub__intro li:before{content: \"\";\n    background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/arrow_png.png);\n    position: absolute;\n    width: 0.7vw;\n    height: 0.6vw;\n    background-size: contain;\n    background-repeat: no-repeat;\n    margin-top: 0.4vw;\n    left: 0;}.resourcingHub__quickLinks ul li:before{content \"\"; display:none;}.resourcingHub__accordionBody strong{color:#ffe600}.resourcingHub__intro{background:url('").concat(imageRoot, "bgc.png') center/cover;display:grid;grid-template-columns:1fr 1fr}.resourcingHub__introContent{padding:2vw 6vw}.resourcingHub__introContent h2{color:#ffe600;font-size:1.2vw;font-weight:400}.resourcingHub__introContent p,.resourcingHub__introContent li{font:1vw/1.5 Arial,sans-serif}.resourcingHub__quickLinks{background:#2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/gettyimages-607638780-1024x102.png') center/cover;overflow:hidden;padding:4vw;position:relative}.resourcingHub__quickLinks:before,.resourcingHub__quickLinks:after{background:url('").concat(imageRoot, "honeyComb.png') center/contain no-repeat;content:'';height:22vw;position:absolute;width:22vw}.resourcingHub__quickLinks:before{right:-1vw;top:-2vw;transform:rotate(90deg)}.resourcingHub__quickLinks:after{bottom:-2vw;left:-1vw}.resourcingHub__quickLinks h2{font:2vw Arial;margin:0 0 1vw}.resourcingHub__quickLinks ul{display:grid;grid-template-columns:1fr 1fr;list-style:none;margin:0;padding:0;position:relative;z-index:1}.resourcingHub__quickLinks li{padding:.5vw}.resourcingHub__quickLinks a{align-items:center;background:#ffffff17;color:#fff;display:grid;font:1vw/1.2 Arial;height:9vw;justify-content:center;padding:1vw;text-align:center;text-decoration:none}.resourcingHub__quickLinks a:hover{background:#ffffff47}.resourcingHub__quickLinks img{display:inline-block;margin:0 auto;width:2.3vw}.resourcingHub__section{padding:1vw 6vw 0}.resourcingHub__sectionTitle{color:#fff;display:block;font-size:1.4vw;margin:1vw 0 .7vw}.resourcingHub__cards{display:grid;gap:1vw;grid-template-columns:repeat(3,1fr)}.resourcingHub__card{min-height:11vw;overflow:hidden;position:relative}.resourcingHub__card a{display:block;height:11vw;position:relative}.resourcingHub__cardImage{background-position:center;background-size:cover;inset:0;position:absolute;transition:transform .2s}.resourcingHub__cardImage:after{background:linear-gradient(transparent,#000);content:'';inset:0;position:absolute}.resourcingHub__card:hover .resourcingHub__cardImage{transform:scale(1.05)}.resourcingHub__cardLabel{bottom:1.5vw;color:#fff;font-size:1vw;left:1.5vw;position:absolute;width:83%;z-index:1}.resourcingHub__team{padding:0 6vw 2vw}.resourcingHub__teamGrid{display:grid;gap:.8vw;grid-template-columns:repeat(5,1fr)}.resourcingHub__person{background:#ffffff0f;min-height:15vw;text-align:center}.resourcingHub__person img{border-radius:50%;height:5.5vw;margin-top:1.5vw;object-fit:cover;width:5.5vw}.resourcingHub__person strong{color:#ffe600;display:block;font-size:.9vw;margin-top:1vw}.resourcingHub__person span{display:block;font-size:.8vw;margin-top:.4vw}.resourcingHub__footer{background:#000;color:#fff;font-size:1vw;padding:1vw 2vw;text-align:right}\n    @media(max-width:1200px){.resourcingHub__nav{min-height:90px}.resourcingHub__nav .EYlogo{left:60px;top:20px;width:40px}.resourcingHub__nav .logoTxt{font-size:25px;left:130px;top:30px}.resourcingHub__nav .homeLink{right:50px;top:31px}.resourcingHub__nav .homeLink img{width:20px}.resourcingHub__hero h1{font-size:30px}.resourcingHub__accordion h2{font-size:20px}.resourcingHub__accordionHint{font-size:12px}.resourcingHub__introContent h2,.resourcingHub__sectionTitle{font-size:18px}.resourcingHub__introContent p,.resourcingHub__introContent li,.resourcingHub__accordionBody p,.resourcingHub__accordionBody li{font-size:14px}.resourcingHub__cardLabel,.resourcingHub__quickLinks a{font-size:13px}.resourcingHub__person strong{font-size:13px}.resourcingHub__person span{font-size:11px}.resourcingHub__footer{font-size:13px}}\n    @media(max-width:800px){.resourcingHub__intro{grid-template-columns:1fr}.resourcingHub__cards{grid-template-columns:repeat(2,1fr)}.resourcingHub__teamGrid{grid-template-columns:repeat(3,1fr)}}\n    @media(max-width:575px){.resourcingHub__nav .homeLink{top:110px}.resourcingHub__hero h1{font-size:24px;margin-top:20px}.resourcingHub__introContent,.resourcingHub__accordion,.resourcingHub__section,.resourcingHub__team{padding-left:30px;padding-right:30px}.resourcingHub__quickLinks ul{grid-template-columns:1fr}.resourcingHub__cards{grid-template-columns:1fr}.resourcingHub__teamGrid{grid-template-columns:repeat(2,1fr)}}\n    @media(max-width:400px){.resourcingHub__teamGrid{grid-template-columns:1fr}}\n  "))); };
var MenaTaxResourcingHub = function (_a) {
    var onShowHome = _a.onShowHome, onShowOnshore = _a.onShowOnshore, onShowNonGcc = _a.onShowNonGcc;
    var _b = react__WEBPACK_IMPORTED_MODULE_0__.useState(false), open = _b[0], setOpen = _b[1];
    var _c = react__WEBPACK_IMPORTED_MODULE_0__.useState(true), loading = _c[0], setLoading = _c[1];
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
        var timer = window.setTimeout(function () { return setLoading(false); }, 2000);
        window.scrollTo(0, 0);
        return function () { return window.clearTimeout(timer); };
    }, []);
    var renderResource = function (resource, index) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "resourcingHub__card", key: resource[0] },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: resource[1], target: "_blank", rel: "noreferrer", onClick: function (event) { if (index === 0) {
                event.preventDefault();
                onShowOnshore();
            } if (index === 1) {
                event.preventDefault();
                onShowNonGcc();
            } } },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "resourcingHub__cardImage", style: { backgroundImage: "url('".concat(imageRoot).concat(resource[2], "')") } }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "resourcingHub__cardLabel" }, resource[0])))); };
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "resourcingHub" },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement(ResourcingStyles, null),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "resourcingHub__loading".concat(loading ? '' : ' is-hidden'), "aria-hidden": !loading },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("nav", { className: "resourcingHub__nav" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "EYlogo", src: "".concat(imageRoot, "EY_logo.png"), alt: "EY logo" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "logoTxt" }, "MENA Tax Hub"),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: "homeLink", href: "#home", onClick: function (event) { event.preventDefault(); onShowHome(); } },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(imageRoot, "home.png"), alt: "Home" }))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("header", { className: "resourcingHub__hero" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("h1", null, "Welcome to MENA Tax Resourcing Hub"),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("hr", null)),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("main", null,
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("section", { className: "resourcingHub__accordion" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("h2", { className: open ? 'is-open' : '', onClick: function () { return setOpen(!open); }, "aria-expanded": open },
                    "The Role of Experience Management ",
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "resourcingHub__accordionHint" }, open ? 'Close' : 'Click here for more information')),
                open && react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "resourcingHub__accordionBody" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "The Experience Management function supports the business to maximize business performance and deliver on our talent promise through proactive management of our talent pool. Supporting MENA Tax by ensuring teams allocate the right people, to the right role, at the right time and support project demand prioritization. EXM provides specialist knowledge and manages relationships to ensure we maximize productivity and develop our talent through their on-the-job experiences."),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", null, "Key responsibilities")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", null, "Stakeholder Management"),
                            " - Responsible for managing key relationships within Leadership Team, Partner Group and Business Enablement Team across MENA."),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", null, "Pipeline & Demand management"),
                            " - Ensuring direct connectivity between pursuits teams and the experience management team across MENA Tax, Graduates, Experienced and sponsored pool of GDS FTE's."),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", null, "Talent pool management & experience optimization"),
                            " - Actively managing resourcing and available capacity by understanding capability and proactively identifying opportunities for all available resources."),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", null, "Experience optimization"),
                            " - Highlighting capability outside the home talent pool via cross-functional, cross-border or cross-region allocation to maximize productivity."),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", null, "Experience management"),
                            " - Promoting identification and delivery of career experiences as part of every engagement."),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", null, "Continuous improvement"),
                            " - Roll out of initiatives on behalf of the Tax COO and identifying opportunities to improve the Tax team performance.")))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("section", { className: "resourcingHub__intro" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "resourcingHub__introContent" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("h2", null, "Our purpose- built intranet site will serve as a convenient, comprehensive resource guide for Experience Management operations"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("hr", null),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("h2", null, "Here's what this platform provides:"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "An introduction to Experience Management where you'll get to meet our dedicated team with a focus on the services the EXM team offer. These include strategic and operational workforce planning, capacity management, headcount planning, and skills matching."),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                            "An overview and insight on key considerations, next steps, cost components and contacts of the diverse resource options for smart delivery",
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Onshore"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Non-GCC (Levant / Rapid Pakistan)"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "GDS (T&M/FTE)"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Contingent Worker (CW)"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                    "Global Mobility Assignments (Mobility program) - ",
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { style: { color: '#ff4136' } }, "Coming soon")))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Accessibility to useful links that provide a smooth working experience such as People, Finance reporting, the Tax Hiring tool and more."))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "resourcingHub__quickLinks" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("h2", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(imageRoot, "external-link.png"), alt: "" }),
                        " Quick Links"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", null, quickLinks.map(function (link) { return react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", { key: link[2] },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: link[0], target: "_blank", rel: "noreferrer" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(imageRoot).concat(link[1]), alt: "" }),
                            link[2])); })))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("section", { className: "resourcingHub__section" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "resourcingHub__sectionTitle" }, "Onshore / Non-GCC (Levant / Rapid Pakistan)"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("hr", null),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "resourcingHub__cards" }, resources.slice(0, 2).map(function (resource, index) { return renderResource(resource, index); })),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "resourcingHub__sectionTitle" }, "GDS"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("hr", null),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "resourcingHub__cards" }, resources.slice(2).map(function (resource, index) { return renderResource(resource, index + 2); }))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("section", { className: "resourcingHub__team" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "resourcingHub__sectionTitle" }, "Meet The Team"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("hr", null),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "resourcingHub__teamGrid" }, people.map(function (person) { return react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "resourcingHub__person", key: person[0] },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(imageRoot).concat(person[3]), alt: person[0] }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", null, person[0]),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, person[1]),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, person[2])); })))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("footer", { className: "resourcingHub__footer" }, "\u00A9 2026 EYGM Limited. All rights reserved.")));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MenaTaxResourcingHub);


/***/ }),

/***/ 504:
/*!*************************************************************!*\
  !*** ./lib/webparts/menaTaxHub/components/MenaTaxTalent.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

var talentStyles = "\n  .talent-page { background: #2e2e38; color: #ffffff; font-family: EYInterstate, Arial, sans-serif; overflow: hidden; }\n  .talent-page .loading-container { align-items: center; background: #1a1a24; display: flex; inset: 0; justify-content: center; position: fixed; z-index: 9999; }\n  .talent-page .loading-container.is-hidden { display: none; }\n  .talent-page .loading-container .item { border: .2vw solid #ffe600; border-bottom-color: transparent; border-radius: 50%; border-top-color: transparent; position: absolute; animation: talentSpin 2s ease infinite; }\n  .talent-page .loading-container .item:nth-child(1) { height: 30px; width: 30px; }\n  .talent-page .loading-container .item:nth-child(2) { animation-delay: .1s; height: 50px; width: 50px; }\n  .talent-page .loading-container .item:nth-child(3) { animation-delay: .2s; height: 70px; width: 70px; }\n  .talent-page .loading-container .item:nth-child(4) { animation-delay: .3s; height: 90px; width: 90px; }\n  @keyframes talentSpin { 50% { transform: rotate(180deg); } 100% { transform: rotate(0); } }\n  .talent-page .container_wrapper { display: block; }\n  .talent-page .webPart { background: #2e2e38; }\n  .talent-page .nav-container { padding: 0; }\n  .talent-page .nav-bar { background: #2e2e38; margin: 0; min-height: 6vw; position: relative; width: 100%; z-index: 999; }\n  .talent-page .EYlogo { left: 5vw; position: absolute; top: 1.5vw; width: 3vw; }\n  .talent-page .logoTxt { color: #ffffff; font-size: 2vw; left: 11vw; margin: 0; position: absolute; top: 2.2vw; }\n  .talent-page .navbarMenu { list-style: none; margin: 0; padding: 0; position: absolute; right: 6vw; top: 2.4vw; }\n  .talent-page .navbarMenu li { color: #ffffff; display: inline-block; font-size: 1vw; }\n  .talent-page .navbarMenu a { color: #ffffff; padding: 0 2vw; text-decoration: none; }\n  .talent-page .navbarMenu img { width: 1.3vw; }\n  .talent-page .bannerBackground { background: url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/banner.jpg') center / 115% 115%; background-color: #2e2e38; padding: 0; }\n  .talent-page .cnt-fdr { background: rgba(46, 46, 56, .5); padding: 2vw 5vw; }\n  .talent-page .cf6 { color: #ffffff; font-size: 1.5vw; margin: 0; padding: 1vw; }\n  .talent-page .hder { color: #ffffff; font-size: 1vw; line-height: 1.5vw; margin: 0 0 1vw; }\n  .talent-page .tabContent { background: url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center / cover; padding: .3vw 5vw 2vw; }\n  .talent-page .accordion { width: 100%; }\n  .talent-page .card { background: transparent; border: 0; border-bottom: .1vw solid #585858; padding: 0 1vw 0 0; }\n  .talent-page .card-header { border: 0; padding: 0; }\n  .talent-page .btn-link { background: transparent; border: 0; box-shadow: none; color: #ffffff; font-size: 1.5vw; padding: .6vw 0; text-align: left; text-decoration: none; width: 100%; }\n  .talent-page .btn-link:hover { color: #ffe600; }\n  .talent-page .fa { color: #ffe600; font-size: 1vw; margin-right: 1vw; }\n  .talent-page .card-body { padding: 1vw 0; }\n  .talent-page .profile-row { display: grid; gap: .6vw; grid-template-columns: repeat(5, 1fr); }\n  .talent-page .profile-column { min-width: 0; }\n  .talent-page .profile-people { display: block; }\n  .talent-page .profile-box { min-height: 13vw; position: relative; text-align: center; }\n  .talent-page .secHead { background: #747480; color: #ffffff; font-size: 1vw; margin-left: 7.5%; padding: 1vw .6vw; position: relative; width: 85%; z-index: 2; }\n  .talent-page .secBorder { border: .1vw dashed #ffffff; border-bottom: 0; margin: -2vw 0 1vw; min-height: 3.5vw; position: relative; z-index: 1; }\n  .talent-page .proBox { margin-bottom: 1vw; position: relative; }\n  .talent-page .psImage { border: .2vw solid #ffffff; border-radius: 100vw; margin-top: .8vw; position: absolute; width: 3vw; }\n  .talent-page .psTitle, .talent-page .psTitley1 { background-size: 100% 200%; background-position: bottom center; border: .1vw solid rgba(255, 255, 255, 0); color: #000000; font-size: .9vw; margin-left: 10%; min-height: 2.6vw; padding: .5vw .4vw .5vw 2vw; transition: all .3s ease-in-out; width: 80%; }\n  .talent-page .psTitle { background-image: linear-gradient(to top, #ffe600 50%, #2e2e38 50%); }\n  .talent-page .psTitley1 { background-image: linear-gradient(to top, #ffffff 50%, #2e2e38 50%); }\n  .talent-page .psName, .talent-page .psNamey1 { background-size: 100% 200%; background-position: bottom center; border: .1vw solid #4e4e59; border-top: 0; color: #ffffff; font-size: .8vw; margin-left: 10%; padding: .5vw .5vw .5vw 2vw; transition: all .3s ease-in-out; width: 80%; }\n  .talent-page .psName { background-image: linear-gradient(to top, #2e2e38 50%, #ffe600 50%); }\n  .talent-page .psNamey1 { background-image: linear-gradient(to top, #2e2e38 50%, #ffffff 50%); }\n  .talent-page .proBox:hover .psTitle, .talent-page .proBox:hover .psTitley1 { background-position: top center; border-color: #4e4e59; color: #ffffff; }\n  .talent-page .proBox:hover .psName, .talent-page .proBox:hover .psNamey1 { background-position: top center; color: #000000; }\n  .talent-page .table-wrap { overflow-x: auto; }\n  .talent-page table { border: .01vw solid #474747; color: #ffffff; font-size: .9vw; line-height: 1.1vw; margin: 2vw 0; text-align: center; width: 100%; }\n  .talent-page th { background: #1f2027; color: #ffe600; padding: 1vw 0; }\n  .talent-page td { border: .01vw solid #474747; padding: .4vw 1.5vw;  text-align:left;}\n  .talent-page .tableImg { border-radius: 100vw; display: inline-block; width: 3vw; }\n  .talent-page .nme { display: inline-block; margin: 0 0 0 1vw; }\n  .talent-page .documents { display: grid; gap: 1vw; grid-template-columns: repeat(5, 1fr); }\n  .talent-page .document-card { background: rgba(255, 255, 255, .08); min-height: 7.5vw; position: relative; text-decoration: none; }\n  .talent-page .box-banner { background: center / cover; min-height: 8vw; }\n  .talent-page .box-content { color: #ffffff; min-height: 6vw; padding: 1vw 1.5vw; }\n  .talent-page .box-cnt { font-size: .9vw; line-height: 1.2vw; margin: 0; }\n  .talent-page .box-readmore { color: #ffffff; font-size: .9vw; margin: 1vw 0 0; text-align: right; }\n  .talent-page .footerTab { background: #1a1a24; padding: 5vw; }\n  .talent-page .quicklinks { color: #ffffff; font-size: 1.3vw; margin: 0 0 2vw; }\n  .talent-page .footerTab .documents { display: grid; gap: .8vw; grid-template-columns: repeat(4, 1fr); }\n  .talent-page .footerTab .document-card { background: #ffffff0f url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center / cover; box-shadow: 0 0 1.5vw rgba(0, 0, 0, .44); min-height: 7.5vw; overflow: hidden; }\n  .talent-page .footerTab .box-banner { bottom: 0; left: 0; min-height: 0; position: absolute; top: 0; width: 37%; }\n  .talent-page .footerTab .box-content { margin-left: 37%; min-height: 7.5vw; padding: 1.5vw 1vw 1vw 5%; }\n  .talent-page .footerTab .box-cnt { color: #ffffff; font-size: 1vw; line-height: 1.3vw; max-height: 3.9vw; overflow: hidden; }\n  .talent-page .footerTab .box-readmore { display: none; }\n  .talent-page .footerTab .row { display: flex; flex-wrap: wrap; margin: 0 -.4vw; }\n  .talent-page .footerTab .cl-3 { flex: 0 0 25%; max-width: 25%; padding: .4vw; }\n  .talent-page .footerTab .cl-3 > a { display: block; height: 100%; text-decoration: none; }\n  .talent-page .footerTab .col-sm-bx { background: #ffffff0f url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center / cover; box-shadow: 0 0 1.5vw rgba(0, 0, 0, .44); min-height: 7.5vw; overflow: hidden; position: relative; width: 100%; }\n  .talent-page .footerTab .img-bx { background-position: center; background-size: cover; bottom: 0; left: 0; min-height: 0; position: absolute; top: 0; transition: all .2s ease-in-out; width: 37%; }\n  .talent-page .footerTab .col-sm-bx:hover .img-bx { transform: scale(1.08); }\n  .talent-page .footerTab .bx-link { color: #ffffff; font-size: 1vw; left: 42%; line-height: 1.3vw; margin: 0; position: absolute; top: 50%; transform: translateY(-50%); width: 48%; }\n  .talent-page .footerTab .col-sm-bx > span { bottom: .3vw; color: rgba(255, 255, 255, .52); font-size: 2vw; font-weight: bold; position: absolute; right: 1vw; }\n  .talent-page .footer { background: #000000; color: #ffffff; padding: 1vw 2vw; text-align: right; }\n  .talent-page .footer p { font-size: 1vw; margin: 0; }\n   .talent-page .btn-link:before {\n  content: \"-\";\n}\n .talent-page .btn-link.collapsed:before {\n  content: \"+\";\n}\n  @media only screen and (max-width: 1200px) {\n    .talent-page .nav-bar { min-height: 90px; }\n    .talent-page .EYlogo { left: 60px; top: 20px; width: 40px; }\n    .talent-page .logoTxt { font-size: 25px; left: 130px; top: 30px; }\n    .talent-page .navbarMenu { right: 50px; top: 31px; }\n    .talent-page .navbarMenu img { width: 20px; }\n    .talent-page .cnt-fdr { padding: 35px 70px; }\n    .talent-page .cf6 { font-size: 30px; }\n    .talent-page .hder { font-size: 16px; line-height: 23px; }\n    .talent-page .tabContent { padding: 50px 70px; }\n    .talent-page .btn-link { font-size: 20px; }\n    .talent-page .profile-row { gap: 10px; grid-template-columns: repeat(4, 1fr); }\n    .talent-page .secHead { font-size: 14px; }\n    .talent-page .psTitle, .talent-page .psTitley1, .talent-page .psName, .talent-page .psNamey1 { font-size: 11px; }\n    .talent-page table { font-size: 13px; line-height: 18px; }\n    .talent-page .box-cnt, .talent-page .box-readmore { font-size: 13px; line-height: 18px; }\n    .talent-page .footer p { font-size: 13px; }\n    .talent-page .footerTab .documents { grid-template-columns: repeat(3, 1fr); }\n    .talent-page .footerTab .box-content { min-height: 70px; padding: 15px 10px 10px 5%; }\n    .talent-page .footerTab .box-cnt { font-size: 13px; line-height: 16px; max-height: 48px; }\n    .talent-page .footerTab .bx-link { font-size: 13px; line-height: 16px; }\n    .talent-page .footerTab .col-sm-bx > span { bottom: 0; font-size: 15px; }\n  }\n  @media only screen and (max-width: 800px) {\n    .talent-page .tabContent { padding: 50px 30px; }\n    .talent-page .profile-row { grid-template-columns: repeat(2, 1fr); }\n    .talent-page .documents { grid-template-columns: repeat(3, 1fr); }\n    .talent-page .footerTab .cl-3 { flex-basis: 33.3333%; max-width: 33.3333%; }\n    .talent-page .footerTab .documents { grid-template-columns: repeat(2, 1fr); }\n  }\n  @media only screen and (max-width: 575px) {\n    .talent-page .navbarMenu { top: 110px; }\n    .talent-page .profile-row, .talent-page .documents { grid-template-columns: 1fr; }\n    .talent-page .footerTab .documents { grid-template-columns: 1fr; }\n    .talent-page .footerTab .cl-3 { flex-basis: 50%; max-width: 50%; }\n  }\n  @media only screen and (max-width: 500px) { .talent-page .footerTab .cl-3 { flex-basis: 100%; max-width: 100%; } }\n";
var imageRoot = 'https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/';
var profileImageRoot = 'https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/';
var profilePdfRoot = 'https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/pdf/';
var profiles = [
    {
        heading: 'Talent Consulting',
        people: [
            { email: 'eman.ayyoub@jo.ey.com', image: "".concat(imageRoot, "Eman-Ayyoub.jpg"), title: 'Strategic Talent Leader', name: 'Eman Ayyoub' },
            { email: 'alyaa.almulla@bh.ey.com', image: "".concat(profileImageRoot, "Alyaa-Almulla.jpg"), title: 'Lead Talent Consultant', name: 'Alyaa Almulla', titleClass: 'psTitley1', nameClass: 'psNamey1' },
            { email: 'asha.rajan1@kw.ey.com', image: "".concat(profileImageRoot, "Asha%20Rajan.jpg"), title: 'Lead Talent Consultant', name: 'Asha Rajan', titleClass: 'psTitley1', nameClass: 'psNamey1' },
            { email: 'Danish.Khan@pk.ey.com', image: "".concat(profileImageRoot, "Danish%20Khan.png"), title: 'Lead Talent Consultant', name: 'Danish Khan', titleClass: 'psTitley1', nameClass: 'psNamey1' }
        ]
    },
    {
        heading: 'Experience Management',
        people: [
            { email: 'bobin.abraham@gds.ey.com', image: "".concat(profileImageRoot, "Bobin%20T.jpg"), title: 'Experience Management Leader', name: 'Bobin T Abraham' },
            { email: 'jellen.jose@ae.ey.com', image: "".concat(profileImageRoot, "Jellen%20Jose.jpg"), title: 'EM Consultant', name: 'Jellen Jose', titleClass: 'psTitley1', nameClass: 'psNamey1' },
            { email: 'dileep.rajasekhar@kw.ey.com', image: "".concat(profileImageRoot, "Dileep%20Rajasekhar.jpg"), title: 'EM Consultant', name: 'Dileep Rajasekhar', titleClass: 'psTitley1', nameClass: 'psNamey1' },
            { email: 'meghna.jayachandran@gds.ey.com', image: "".concat(profileImageRoot, "fa4b0e99-0d5a-4485-bca4-de12736bb7b1_LThumb.jpg"), title: 'EM Analyst', name: 'Meghna Jayachandran', titleClass: 'psTitley1', nameClass: 'psNamey1' },
            { email: 'Jose.T@gds.ey.com', image: "".concat(profileImageRoot, "Jose%20Thomas.jpg"), title: 'EM Analyst', name: 'Jose Thomas', titleClass: 'psTitley1', nameClass: 'psNamey1' }
        ]
    },
    {
        heading: 'Recruitment',
        people: [
            { email: 'dania.zalatimo@jo.ey.com', image: "".concat(profileImageRoot, "dania_zalatimo_jo_ey_com_LThumb.jpg"), title: 'DAP/NEP recruiter-Tax', name: 'Dania Zalatimo' },
            { email: 'Ali.Abdulla@bh.ey.com', image: "".concat(profileImageRoot, "ali-abdulla.jpg"), title: 'Recruitment Leader - Experienced Hire - Tax', name: 'Ali Abdulla' },
            { email: 'anum.z.merchant@rapid.ey.com', image: "".concat(profileImageRoot, "Anum%20Merchant.jpg"), title: 'MENA Tax Experience Hire Recruiter', name: 'Anum Merchant', titleClass: 'psTitley1', nameClass: 'psNamey1' },
            { email: 'reem.farghaly@eg.ey.com', image: "".concat(profileImageRoot, "Reem%20A%20Farghaly.jpg"), title: 'MENA Tax Experience Hire Recruiter', name: 'Reem Farghaly', titleClass: 'psTitley1', nameClass: 'psNamey1' },
            { email: 'amna.zarin@rapid.ey.com', image: "".concat(profileImageRoot, "amna%20zarin.jpg"), title: 'MENA Tax Experience Hire Recruiter', name: 'Amna Zarin', titleClass: 'psTitley1', nameClass: 'psNamey1' },
            { email: 'Talal.Obeidat@jo.ey.com', image: 'https://people.ey.com/User%20Photos/Profile%20Pictures/17bb805e-d935-446e-8fcb-8667711129dd_LThumb.jpg', title: 'MENA Tax Experience Hire Recruiter', name: 'Talal Obeidat', titleClass: 'psTitley1', nameClass: 'psNamey1' }
        ]
    },
    {
        heading: 'Learning',
        people: [
            { email: 'subarna.ramamoorthy@bh.ey.com', image: "".concat(profileImageRoot, "subarna.ramamoorthy.png"), title: 'Tax Learning Lead', name: 'Subarna Ramamoorthy', titleClass: 'psTitley1', nameClass: 'psNamey1' },
            { email: 'Shari.J@gds.ey.com', image: "".concat(profileImageRoot, "Shari%20-1.jpg"), title: 'Learning Coordinator', name: 'Shari J', titleClass: 'psTitley1', nameClass: 'psNamey1' },
            { email: 'Anusree.Bhaskar@gds.ey.com', image: "".concat(profileImageRoot, "Anusree%20Bhaskar.jpg"), title: 'Learning Coordinator', name: 'Anusree Bhaskar', titleClass: 'psTitley1', nameClass: 'psNamey1' }
        ]
    }
];
var TalentProfiles = function (_a) {
    var group = _a.group;
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "secHead" }, group.heading),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "secBorder" }),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profile-column" }, group.people.map(function (person) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", key: person.email, href: "mailto:".concat(person.email), style: { textDecoration: 'none' } },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "proBox" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: person.image, className: "psImage", alt: person.name }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: person.titleClass || 'psTitle' }, person.title),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: person.nameClass || 'psName' }, person.name)))); }))));
};
var MenaTaxTalent = function (_a) {
    var onShowHome = _a.onShowHome;
    var _b = react__WEBPACK_IMPORTED_MODULE_0__.useState(null), openSection = _b[0], setOpenSection = _b[1];
    var _c = react__WEBPACK_IMPORTED_MODULE_0__.useState(true), loading = _c[0], setLoading = _c[1];
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
        var timer = window.setTimeout(function () { return setLoading(false); }, 2000);
        window.scrollTo(0, 0);
        return function () { return window.clearTimeout(timer); };
    }, []);
    var toggleSection = function (sectionId) {
        setOpenSection(function (currentSection) { return currentSection === sectionId ? null : sectionId; });
    };
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("style", null, talentStyles),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "talent-page" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "loading-container".concat(loading ? '' : ' is-hidden'), "aria-hidden": !loading },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" })),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container_wrapper" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "webPart" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid nav-container" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row nav-bar" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "EYlogo", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/EY_logo.png", alt: "EY logo" }),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "logoTxt" }, "MENA Tax Hub"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "navbarMenu" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#", onClick: function (event) { event.preventDefault(); onShowHome(); } },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "home", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home.png", alt: "Home" })))))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 bannerBackground" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid cnt-fdr" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "cf6" }, "Tax Talent"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "hder" },
                                            "You come to EY to be even better, to be exceptional. You come here because of the people and the culture, to contribute to the highest performing teams, to be challenged and stretched every step of the way. You can be yourself in a place where people value differences and listen to each other.",
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                            "What is the EY experience? It's the opportunity to do something exceptional, something that matters. It's owning your career, shaping your future and becoming the leader you want to be.",
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                            "It's how together we build a better working world, because better begins with you.")))))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid tabContent" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "accordion", id: "accordionExample" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "card" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "card-header", id: "headingOne" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("h2", { className: "mb-0" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { type: "button", className: "btn btn-link ".concat(openSection === 'collapseOne' ? '' : 'collapsed'), onClick: function () { return toggleSection('collapseOne'); }, "aria-expanded": openSection === 'collapseOne', "aria-controls": "collapseOne" },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("i", { className: "fa fa-plus" }),
                                            "MENA Tax Talent Functions"))),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { id: "collapseOne", className: openSection === 'collapseOne' ? 'collapse show' : 'collapse', "aria-labelledby": "headingOne" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "card-body" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "hder" },
                                            "The Talent function supports our business in various ways relating to our people. Talent supports with Diversity, Equity and Inclusiveness (DE&I), Learning & Development (L&D), Mobility, Talent Attraction and Acquisition (TA\u00B2), Talent Consulting, Performance and Reward, Talent Strategy & Organizational Effectiveness (TS&OE), and Talent Delivery. You can read more about the Talent function on the Global Talent Function homepage and MENA Talent Hub.",
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                            "In MENA, many of these functions are run cross-Service Line. However, Talent has teams that focus specifically on the Tax Service Line for Talent Consulting, Experience Management, Recruitment and Learning."),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profile-row" }, profiles.map(function (group) { return react__WEBPACK_IMPORTED_MODULE_0__.createElement(TalentProfiles, { key: group.heading, group: group }); })),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "hder" },
                                            "Matters related to Experience Management and Recruitment should be discussed and agreed with your Subservice Line Leader in the first instance before any hiring requests or communications are initiated. If an issue requires assistance from Tax Operations, Dave McKenna is the Tax Operations Point of Contact.",
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                            "Tax Learning is under the oversight of Paul Cooper, with support from Venice Segarra. Subarna\u2019s team deals with most day-to-day issues that arise (e.g., support in matters related to SuccessFactors, recording CE hours for one-time-opportunity training sessions). However, if you want to explore learning campaigns or events that may require budget allocation, Paul Cooper should be looped into the conversation.")))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "card" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "card-header", id: "headingTwo" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("h2", { className: "mb-0" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { type: "button", className: "btn btn-link ".concat(openSection === 'collapseTwo' ? '' : 'collapsed'), onClick: function () { return toggleSection('collapseTwo'); }, "aria-expanded": openSection === 'collapseTwo', "aria-controls": "collapseTwo" },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("i", { className: "fa fa-plus" }),
                                            "MENA Tax SSL Talent Champions"))),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { id: "collapseTwo", className: openSection === 'collapseTwo' ? 'collapse show' : 'collapse', "aria-labelledby": "headingTwo" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "card-body" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "hder" },
                                            "At EY, we are committed to create an inclusive environment where our people are enabled to strive and perform at their best. For that, we have appointed a Talent Champion across our SSLs and geographies to ensure you have the support and guidance needed to maintain your full engagement and wellbeing.",
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                            "Talent Champions work closely with Tax Talent team to support the successful implementation of talent initiatives and priorities and be your go to person to seek the support you need in addressing any of your needs, concerns and issues."),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "table-wrap" },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("table", { className: "table table-bordered ts_7 ty_7" },
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("thead", null,
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "SSL"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Talent champion"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Garde"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Geographic scope"))),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("tbody", null,
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { rowSpan: 2 }, "GCR"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "mailto:imran.iqbal@sa.ey.com", style: { color: '#ffffff', textDecoration: 'none' } },
                                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(profileImageRoot, "imran_iqbal_sa_ey_com_LThumb.jpg"), className: "tableImg", alt: "Imran Iqbal" }),
                                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "nme" }, "Imran Iqbal"))),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "Partner"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "GCC")),
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "mailto:ahmed.aboelfotouh@eg.ey.com", style: { color: '#ffffff', textDecoration: 'none' } },
                                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(profileImageRoot, "ahmed_aboelfotouh_eg_ey_com_LThumb.jpg"), className: "tableImg", alt: "Ahmed Abo El Fotouh" }),
                                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "nme" }, "Ahmed Abo El Fotouh"))),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "Partner"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "Levent")),
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "ACR"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "mailto:sohail.nini@sa.ey.com", style: { color: '#ffffff', textDecoration: 'none' } },
                                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(profileImageRoot, "21bd67ba-4dca-434b-b090-ffa3da600ddc_LThumb.jpg"), className: "tableImg", alt: "Sohail Nini" }),
                                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "nme" }, "Sohail Nini"))),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "Partner"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "MENA")),
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "IDT"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "mailto:mohammedbilal.akram@sa.ey.com", style: { color: '#ffffff', textDecoration: 'none' } },
                                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(profileImageRoot, "Mohammed%20Bilal.jpg"), className: "tableImg", alt: "Mohammed Bilal Akram" }),
                                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "nme" }, "Mohammed Bilal Akram"))),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "Partner"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "MENA")),
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "ITTS"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "mailto:mina.alkhudairi@ae.ey.com", style: { color: '#ffffff', textDecoration: 'none' } },
                                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(profileImageRoot, "6b98dfff-b2bf-487e-b065-767ac640ac1f_LThumb.jpg"), className: "tableImg", alt: "Mina Al-Khudairi" }),
                                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "nme" }, "Mina Al-Khudairi"))),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "Partner"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "MENA")),
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "PAS"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "mailto:roman.gusev@bh.ey.com", style: { color: '#ffffff', textDecoration: 'none' } },
                                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(profileImageRoot, "roman-gusev.jpg"), className: "tableImg", alt: "Roman Gusev" }),
                                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "nme" }, "Roman Gusev"))),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "Partner"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "MENA")),
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "Law"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "mailto:rodolphe.pellerin@ae.ey.com", style: { color: '#ffffff', textDecoration: 'none' } },
                                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(profileImageRoot, "rodolphe-pellerin.jpg"), className: "tableImg", alt: "Rodolphe R Pellerin" }),
                                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "nme" }, "Rodolphe R Pellerin"))),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "Partner"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "MENA")))))))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "card" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "card-header", id: "headingThree" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("h2", { className: "mb-0" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { type: "button", className: "btn btn-link ".concat(openSection === 'collapseThree' ? '' : 'collapsed'), onClick: function () { return toggleSection('collapseThree'); }, "aria-expanded": openSection === 'collapseThree', "aria-controls": "collapseThree" },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("i", { className: "fa fa-plus" }),
                                            "Key Talent Documents and references"))),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { id: "collapseThree", className: openSection === 'collapseThree' ? 'collapse show' : 'collapse', "aria-labelledby": "headingThree" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "card-body" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "documents" },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: "document-card", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/Your%20Career%20Guide%20at%20MENA%20Tax%20-%20FY26%20(003).pdf", target: "_blank", rel: "noreferrer" },
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "box-banner", style: { backgroundImage: "url(".concat(profilePdfRoot, "Career%20Guide%20FY26%20Image.png)") } }),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "box-content" },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-cnt" }, "Your Career Guide at MENA Tax"),
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-readmore" }, "READ MORE"))),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: "document-card", style: { display: 'none' }, href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/FY23%20Tax%20-%20Rapid%20Pakistan%20PQ%20Policy.pdf", target: "_blank", rel: "noreferrer" },
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "box-banner", style: { backgroundImage: "url(".concat(profileImageRoot, "thum3.png)") } }),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "box-content" },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-cnt" }, "Rapid Innovation TAX Professional Qualification Policy"),
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-readmore" }, "READ MORE"))),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: "document-card", style: { display: 'none' }, href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/MENA%20TAX_PQ%20Policy_FY26.pdf", target: "_blank", rel: "noreferrer" },
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "box-banner", style: { backgroundImage: "url(".concat(profileImageRoot, "thum02.png)") } }),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "box-content" },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-cnt" }, "MENA Tax Professional Qualification Policy FY26"),
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-readmore" }, "READ MORE"))),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: "document-card", href: "https://sites.ey.com/sites/TaxLearning/SitePages/HomepageCopy.aspx", target: "_blank", rel: "noreferrer" },
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "box-banner", style: { backgroundImage: "url(".concat(profileImageRoot, "tax-learning-hub.jpg)") } }),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "box-content" },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-cnt" }, "Tax Learning Hub"),
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-readmore" }, "READ MORE")))))))),
                        "  "),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid footerTab" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "quicklinks" }, "Quick links")),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cl-3" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/EYMENA/SiteAssets/PDF/MENA%20TE%20Policy/ME%20TE%20Policy.pdf", target: "_blank", rel: "noreferrer" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: { backgroundImage: "url(".concat(imageRoot, "MENA-Expense-Policy.jpg)") } }),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bx-link" },
                                            "MENA Expense",
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                            "Policy"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "01")))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cl-3" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/menapeopleconnect/SitePages/TotalReward.aspx", target: "_blank", rel: "noreferrer" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: { backgroundImage: "url(".concat(profileImageRoot, "People-News.png)") } }),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bx-link" },
                                            "MENA Total ",
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                            "Reward"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "02")))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cl-3" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/menapeopleconnect/SitePages/Policies%20and%20Procedures.aspx", target: "_blank", rel: "noreferrer" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: { backgroundImage: "url(".concat(profileImageRoot, "tx03.jpg)") } }),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bx-link" }, "MENA Talent Policies & Procedures"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "03")))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cl-3" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://intranet.ey.com/sites/career-development/SitePageModern/342011/career-development", target: "_blank", rel: "noreferrer" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: { backgroundImage: "url(".concat(profileImageRoot, "tx04.jpg)") } }),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bx-link" },
                                            "Career & ",
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                            "development"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "04")))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cl-3" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/menapeopleconnect/SitePages/Onboarding.aspx", target: "_blank", rel: "noreferrer" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: { backgroundImage: "url(".concat(imageRoot, "eng_02.jpg)") } }),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bx-link" }, "New starters (first 90 days)"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "05")))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cl-3" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/menapeopleconnect/SitePages/Home.aspx", target: "_blank", rel: "noreferrer" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: { backgroundImage: "url(".concat(profileImageRoot, "talent-hub.jpg)") } }),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bx-link" },
                                            "The Talent",
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                            "Hub"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "06")))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cl-3" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://jam12.sapjam.com/home", target: "_blank", rel: "noreferrer" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: { backgroundImage: "url(".concat(profileImageRoot, "badges.jpg)") } }),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bx-link" },
                                            "EY ",
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                            "Badges"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "07")))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cl-3" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://jam12.sapjam.com/groups/nBYctR4FmssgPPbOZnL19h/overview_page/qDLfmkXJzgezWV5L4yWoJr", target: "_blank", rel: "noreferrer" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: { backgroundImage: "url(".concat(profileImageRoot, "tech-mba.jpg)") } }),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bx-link" },
                                            "EY Tech ",
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                            "MBA"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "08")))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cl-3" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/MENATaxHub/ProFinda/Forms/AllItems.aspx", target: "_blank", rel: "noreferrer" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: { backgroundImage: "url(".concat(profileImageRoot, "AdobeStock-331188576.jpeg)") } }),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bx-link" }, "ProFinda"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "09")))))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "footer" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "\u00A9 2026 EYGM Limited. All rights reserved.")))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MenaTaxTalent);


/***/ }),

/***/ 136:
/*!*************************************************************!*\
  !*** ./lib/webparts/menaTaxHub/components/MyDocsMinutes.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

var myDocsStyles = "\nhtml,\nbody {\n    overflow-x: hidden !important;\n    font-family: EYInterstate;\n}\n\n::-moz-selection {\n    color: #ffffff;\n    background: #27ACAA;\n}\n\n::selection {\n    color: #ffffff;\n    background: #27ACAA;\n}\n\nbody::-webkit-scrollbar {\n    display: none;\n}\n\nbody {\n    -ms-overflow-style: none;\n    scrollbar-width: none;\n    position: relative;\n}\n\n.bannerBackground {\n    background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/banner.jpg);\n    background-color: #2e2e38;\n    background-size: 115% 115%;\n    background-position: center center;\n    position: relative;\n    background-attachment: fixed;\n    animation: shrink 20s infinite alternate;\n    padding: 0px;\n}\n\n.cf6 {\n    color: #ffffff;\n    width: 100%;\n    font-size: 1.5vw;\n    padding: 1vw 1vw;\n    margin-bottom: 0;\n}\n\n@keyframes shrink {\n    0% {\n        background-size: 115% 115%;\n    }\n    100% {\n        background-size: 100% 100%;\n    }\n}\n\n.nav-bar {\n    position: relative;\n    z-index: 999;\n    background: #2e2e38;\n    min-height: 6vw;\n    width: 100%;\n    margin: 0;\n}\n\n.nav-container {\n    padding: 0px;\n}\n\n.EYlogo {\n    width: 3vw;\n    position: absolute;\n    left: 5vw;\n    top: 1.5vw;\n}\n\np.logoTxt {\n    color: #ffffff;\n    font-size: 2vw;\n    position: absolute;\n    left: 11vw;\n    top: 2.2vw;\n}\n\nimg.home {\n    width: 1.3vw;\n}\n\nul.navbarMenu {\n    position: absolute;\n    right: 6vw;\n    top: 2.4vw;\n    font-family: EYInterstate;\n}\n\nul.navbarMenu li {\n    display: inline-block;\n    font-size: 1vw;\n    color: #ffffff;\n}\n\nul.navbarMenu li a {\n    color: #ffffff;\n    text-decoration: none;\n    padding: 0vw 2vw;\n}\n\n.cnt-fdr {\n    padding: 2vw 5vw 2vw 5vw;\n    background: rgba(46, 46, 56, .5);\n    bottom: 0;\n    width: 100%;\n}\n\n.footerTab {\n    background: #1a1a24;\n    padding: 5vw;\n}\n\na.qLInk {\n    color: #ffffff;\n    font-family: EYInterstate;\n    font-size: 1vw;\n    font-weight: lighter;\n    border: .1vw solid #9f9f9f;\n    padding: 0.5vw 1.6vw;\n    border-radius: .4vw;\n    margin-right: .7vw;\n    text-decoration: none;\n    float: left;\n    -webkit-transition: all .2s ease-in-out;\n    -moz-transition: all .2s ease-in-out;\n    -o-transition: all .2s ease-in-out;\n    transition: all .2s ease-in-out;\n    margin-bottom: .8vw;\n}\n\na.qLInk:hover {\n    background: rgba(255, 255, 255, .2)\n}\n\n.quicklinks {\n    color: #ffffff;\n    font-size: 2vw;\n    margin-bottom: 2vw;\n}\n\nimg.qklinks {\n    width: 1.4vw;\n    margin-top: -0.2vw;\n    margin-right: .4vw;\n}\n\np.hder {\n    color: #ffffff;\n    padding-left: 1vw;\n    font-size: 1vw;\n    line-height: 1.5vw;\n    margin-bottom: 1vw;\n}\n\n.main-Content {\n    background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);\n    min-height: 30vw;\n    background-attachment: fixed;\n    background-position: center;\n    background-color: #2e2e38;\n    background-size: cover;\n    padding: 4vw 8vw;\n}\n\n.box-header {\n    color: #ffffff;\n    font-size: 1.3vw;\n    text-align: center;\n    margin-bottom: -.4vw;\n    padding-top: 3vw;\n    font-family: EYInterstate;\n}\n\n.box-volume {\n    color: #ffe600;\n    font-family: EYInterstate;\n    text-align: center;\n    margin-bottom: 0;\n    font-size: 1.4vw;\n}\n\n.box-volume span {\n    font-size: 1.4vw;\n}\n\n.box-banner {\n    background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bg_box.jpg);\n    min-height: 8vw;\n    background-size: cover;\n    background-position: center;\n}\n\n.box-readmore {\n    margin-top: 1.5vw;\n    font-size: .9vw;\n    color: #ffe600;\n    text-align: right;\n    margin-bottom: 0;\n}\n\np.box-cnt {\n    font-size: .9vw;\n    line-height: 1.2vw;\n    margin: 0;\n}\n\n.box-content {\n    background: rgba(255, 255, 255, 0.129);\n    min-height: 10vw;\n    padding: 2vw 1.5vw;\n    color: #ffffff;\n}\n\n.col-sm-3.col-3-sm {\n    -ms-flex: 0 0 25%;\n    flex: 0 0 20%;\n    max-width: 20%;\n}\n\n.col-3-sm a {\n    text-decoration: none;\n}\n\n.col-sm-3.col-3-sm {\n    margin-bottom: 2vw;\n}\n\n.footer {\n    background-color: #000000;\n    float: left;\n    width: 100%;\n}\n\n.footer p {\n    margin-bottom: 0px;\n    color: #ffffff;\n    font-size: 1vw;\n    padding: 1vw 2vw;\n    text-align: right;\n}\n\n.navToggle {\n    display: none;\n}\n\n@media only screen and (max-width: 1200px) {\n    .cnt-fdr {\n        position: static;\n    }\n\n    .cnt-fdr {\n        padding: 35px 70px;\n    }\n\n    .quicklinks {\n        font-size: 30px;\n        margin-bottom: 25px;\n    }\n\n    a.qLInk {\n        font-size: 15px;\n        border: 1px solid #9f9f9f;\n        padding: 7px 25px;\n        border-radius: .4vw;\n        margin-bottom: 10px;\n        margin-right: 10px;\n    }\n\n    .footerTab {\n        background: #1a1a24;\n        padding: 60px;\n    }\n\n    .EYlogo {\n        width: 40px;\n        left: 60px;\n        top: 20px;\n    }\n\n    p.logoTxt {\n        font-size: 25px;\n        left: 130px;\n        top: 30px;\n    }\n\n    ul.navbarMenu {\n        right: 50px;\n        top: 25px;\n    }\n\n    ul.navbarMenu li {\n        font-size: 15px;\n    }\n\n    ul.navbarMenu li a {\n        padding: 0vw 20px;\n    }\n\n    img.home {\n        width: 20px;\n    }\n\n    .nav-bar {\n        min-height: 90px;\n    }\n\n    ul.navbarMenu {\n        right: 50px;\n        top: 31px;\n    }\n\n    .footer p {\n        margin-bottom: 0px;\n        color: #ffffff;\n        font-size: 13px;\n        padding: 15px 20px;\n        text-align: right;\n    }\n\n    .cf6 {\n        font-size: 30px;\n        margin-bottom: 0;\n    }\n\n    p.hder {\n        color: #ffffff;\n        font-size: 16px;\n        line-height: 23px;\n        margin-bottom: 10px;\n    }\n\n    .main-Content {\n        padding: 60px 70px;\n    }\n\n    .box-banner {\n        min-height: 90px;\n    }\n\n    .box-header {\n        font-size: 16px;\n        margin-bottom: -5px;\n        padding-top: 35px;\n    }\n\n    .box-content {\n        min-height: 100px;\n        padding: 20px 20px;\n    }\n\n    p.box-cnt {\n        font-size: 12px;\n        line-height: 15px;\n    }\n\n    .box-readmore {\n        margin-top: 14px;\n        font-size: 12px;\n    }\n\n    .col-sm-3.col-3-sm {\n        -ms-flex: 0 0 30%;\n        flex: 0 0 30%;\n        max-width: 30%;\n    }\n\n    .box-volume span {\n        font-size: 20px;\n    }\n\n    .col-sm-3.col-3-sm {\n        margin-bottom: 20px;\n    }\n}\n\n@media only screen and (max-width: 850px) {\n    .col-sm-3.col-3-sm {\n        -ms-flex: 0 0 50%;\n        flex: 0 0 50%;\n        max-width: 50%;\n    }\n}\n\n@media only screen and (max-width: 800px) {\n    .col-sm-4.c57 {\n        -ms-flex: 0 0 100%;\n        flex: 0 0 100%;\n        max-width: 100%;\n    }\n}\n\n@media only screen and (max-width: 750px) {\n    .footerTab {\n        float: left;\n    }\n\n    img.qklinks {\n        display: none;\n    }\n}\n\n@media only screen and (max-width: 575px) {\n    ul.navbarMenu {\n        top: 110px;\n    }\n\n    .col-sm-3.col-3-sm {\n        -ms-flex: 0 0 100%;\n        flex: 0 0 100%;\n        max-width: 100%;\n        margin-bottom: 20px;\n    }\n\n    p.box-cnt {\n        font-size: 17px;\n        line-height: 21px;\n    }\n}\n\n@media only screen and (max-width: 400px) {\n    .main-Content {\n        padding: 50px 40px;\n    }\n}\n";
var MyDocsMinutes = function (_a) {
    var onShowHome = _a.onShowHome;
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
        var $ = window.jQuery;
        if (!$) {
            return;
        }
        $(document).ready(function () {
            $(document).scrollTop(0);
            $('.nav-item').click(function () {
                $('html, body').animate({
                    scrollTop: $('.tabCol').offset().top
                }, 1000);
            });
        });
    }, []);
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("style", null, myDocsStyles),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "webPart" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid nav-container" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row nav-bar" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "EYlogo", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/EY_logo.png", alt: "EY logo" }),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "logoTxt" }, "MENA Tax Hub"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "navbarMenu" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#", onClick: function (event) { event.preventDefault(); onShowHome(); } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "home", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home.png", alt: "Home" })),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "|")),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", { hidden: true },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#quality" }, "Tax Quality"))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "navToggle", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/toggle.png", alt: "Toggle" }))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 bannerBackground" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid cnt-fdr" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "cf6" }, "MyDocs Minutes"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "hder" }, "Increase your EYI MyDocs knowledge in minutes"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-4 c57" })))))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "main-Content" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 col-3-sm" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/MyDocs%20Minutes_01.pdf", target: "_blank", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3-box" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "box-banner" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-header" }, "MyDocs Minutes"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-volume" },
                                            "Vol - ",
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "01"))),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "box-content" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-cnt" }, "Closing an Engagement Workspace and Library - why, when and how"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-readmore" }, "READ MORE"))))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 col-3-sm" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/MyDocs%20Minutes_02.pdf", target: "_blank", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3-box" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "box-banner" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-header" }, "MyDocs Minutes"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-volume" },
                                            "Vol - ",
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "02"))),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "box-content" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-cnt" }, "Take care when removing synced libraries from Windows File Explorer"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-readmore" }, "READ MORE"))))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 col-3-sm" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/MyDocs%20Minutes_03.pdf", target: "_blank", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3-box" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "box-banner" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-header" }, "MyDocs Minutes"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-volume" },
                                            "Vol - ",
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "03"))),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "box-content" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-cnt" }, "Deleting Workspaces - steps for workspace owners/administrators"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-readmore" }, "READ MORE"))))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 col-3-sm" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/MyDocs%20Minutes04.pdf", target: "_blank", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3-box" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "box-banner" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-header" }, "MyDocs Minutes"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-volume" },
                                            "Vol - ",
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "04"))),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "box-content" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-cnt" }, "Increase your EYI MyDocs knowledge in minutes"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-readmore" }, "READ MORE"))))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 col-3-sm" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/Timely%20filing.pdf", target: "_blank", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3-box" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "box-banner", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/timely.png)' } },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-header" }, "MyDocs Minutes"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-volume" },
                                            "Vol - ",
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "05"))),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "box-content" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-cnt" }, "Timely filing - Save directly to your workspaces"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-readmore" }, "READ MORE"))))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 col-3-sm" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/MyDocs_06.pdf", target: "_blank", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3-box" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "box-banner", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/timely.png)' } },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-header" }, "MyDocs Minutes"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-volume" },
                                            "Vol - ",
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "06"))),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "box-content" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-cnt" }, "Quickly update document tags (metadata)"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-readmore" }, "READ MORE"))))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 col-3-sm" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/MyDocs_07.pdf", target: "_blank", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3-box" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "box-banner", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/timely.png)' } },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-header" }, "MyDocs Minutes"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-volume" },
                                            "Vol - ",
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "07"))),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "box-content" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-cnt" }, "Assistance with bulk access management"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-readmore" }, "READ MORE"))))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 col-3-sm" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/MyDocs_08.pdf", target: "_blank", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3-box" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "box-banner", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/timely.png)' } },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-header" }, "MyDocs Minutes"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-volume" },
                                            "Vol - ",
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "08"))),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "box-content" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-cnt" }, "Why and how to create additional libraries"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "box-readmore" }, "READ MORE"))))))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid footerTab", hidden: true },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "quicklinks" }, "Quick links"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/EYMENA/SiteAssets/PDF/MENA%20TE%20Policy/ME%20TE%20Policy.pdf", target: "_blank", className: "qLInk", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "qklinks", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png", alt: "MENA Expense Policy" }),
                                "MENA Expense Policy"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/menapeopleconnect/SitePages/TotalReward.aspx", target: "_blank", className: "qLInk", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "qklinks", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png", alt: "MENA Total Reward" }),
                                "MENA Total Reward"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/menapeopleconnect/SitePages/Policies%20and%20Procedures.aspx", target: "_blank", className: "qLInk", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "qklinks", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png", alt: "MENA Talent Policies" }),
                                "MENA Talent Policies & Procedures"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://lms.ey.net/", target: "_blank", className: "qLInk", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "qklinks", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png", alt: "LMS" }),
                                "LMS"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sort.ey.net/", target: "_blank", className: "qLInk", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "qklinks", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png", alt: "SORT" }),
                                "SORT"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sf.ey.net", target: "_blank", className: "qLInk", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "qklinks", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png", alt: "SuccessFactors" }),
                                "SuccessFactors"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://intranet.ey.com/sites/career-development/SitePageModern/342011/career-development", target: "_blank", className: "qLInk", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "qklinks", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png", alt: "Career & development" }),
                                "Career & development"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/menapeopleconnect/SitePages/Onboarding.aspx", target: "_blank", className: "qLInk", rel: "noreferrer" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "qklinks", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png", alt: "New starters" }),
                                "New starters (first 90 days)")))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "footer" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "\u00A9 2026 EYGM Limited. All rights reserved."))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyDocsMinutes);


/***/ }),

/***/ 904:
/*!**********************************************************!*\
  !*** ./lib/webparts/menaTaxHub/components/MyTraining.js ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

var imageRoot = 'https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/';
var trainingStyles = "\nhtml,body{overflow-x:hidden!important;font-family:EYInterstate}.my-training{background:#2e2e38;color:#fff;min-height:100vh}.my-training .loading-container{align-items:center;background:#1a1a24;display:flex;inset:0;justify-content:center;position:fixed;z-index:9999}.my-training .loading-container .item{border:.2vw solid #ffe600;border-bottom-color:transparent;border-radius:50%;border-top-color:transparent;position:absolute;animation:training-spin 2s ease infinite}.my-training .loading-container .item:nth-child(1){height:30px;width:30px}.my-training .loading-container .item:nth-child(2){animation-delay:.1s;height:50px;width:50px}.my-training .loading-container .item:nth-child(3){animation-delay:.2s;height:70px;width:70px}.my-training .loading-container .item:nth-child(4){animation-delay:.3s;height:90px;width:90px}@keyframes training-spin{50%{transform:rotate(180deg)}100%{transform:rotate(0)}}.my-training .nav-bar{background:#2e2e38;min-height:6vw;position:relative}.my-training .EYlogo{left:5vw;position:absolute;top:1.5vw;width:3vw}.my-training .logoTxt{color:#fff;font-size:2vw;left:11vw;position:absolute;top:2.2vw}.my-training .navbarMenu{list-style:none;margin:0;padding:0;position:absolute;right:6vw;top:2.4vw}.my-training .navbarMenu li{display:inline-block;font-size:1vw}.my-training .navbarMenu a{color:#fff;padding:0 2vw;text-decoration:none}.my-training .home{width:1.3vw}.my-training .bannerBackground{background:#2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/banner.jpg') center/cover;min-height:auto}.my-training .cnt-fdr{background:rgba(46,46,56,.5);min-height:auto;padding:2vw 3.5vw}.my-training .cf6{color:#fff;font-size:1.5vw;margin:0 0 1vw}.my-training .hder{color:#fff;font-size:1vw;line-height:1.5vw;margin:0 0 1vw}.my-training .ul-s4{font-size:1vw;line-height:1.3vw;list-style:none;margin:0 0 1.5vw;padding:0;width:100%}.my-training .ul-s4 li{margin-bottom:.6vw;padding-left:1.3vw;position:relative}.my-training .ul-s4 li:before{background:url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/arrow_icon.png') center/contain no-repeat;content:'';height:.6vw;left:0;position:absolute;top:.4vw;width:.6vw}.my-training .htr{width:100%}.my-training .cf7{background:#ffe600;color:#000;cursor:pointer;font-size:1vw;margin:0 0 1vw;padding:1vw;text-align:center;width:20vw}.my-training .c09{display:flex;flex-wrap:wrap;gap:1vw}.my-training .boxTag{color:#fff;text-decoration:none}.my-training .box_page{background:rgba(255,255,255,.09);height:10vw;padding:1.5vw 2vw;text-align:center;transition:background .2s;width:15vw}.my-training .box_page:hover{background:rgba(255,255,255,.2)}.my-training .iconBox{width:3vw}.my-training .txtBox{font-size:1vw;line-height:1.3vw;margin:1vw 0 0;width:10vw}.my-training .main-Content{background:#2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center/cover;padding:2vw 5vw 4vw}.my-training .cnt_header{color:#fff;font-size:1.5vw;margin:1vw 0}.my-training .table{color:#fff;font-size:.9vw;line-height:1.3vw;margin:2vw 0;width:100%}.my-training .table th{background:#1f2027;color:#ffe600;font-size:1.1vw;padding:1vw 1.5vw;border: 1px solid #474747;}.my-training .table td{border:1px solid #474747;padding:.7vw 1.5vw}.my-training .table tbody tr:nth-child(even){background:#1f2027}.my-training .table .mandatory{color:#27acaa}.my-training .cv7{background:rgba(255,255,255,.07);float:left;margin-bottom:1vw;padding:1vw;width:100%}.my-training .vb1,.my-training .vb2{float:right;font-size:.9vw;margin:0 0 0 1vw;padding-left:2vw;position:relative}.my-training .vb1:before,.my-training .vb2:before{content:'';height:1.3vw;left:0;position:absolute;top:0;width:1.3vw}.my-training .vb1:before{background:#27acaa}.my-training .vb2:before{background:#fff}.my-training .hder a{color:#ffe600;text-decoration:none}.my-training .footer{background:#000;float:left;width:100%}.my-training .footer p{font-size:1vw;margin:0;padding:1vw 2vw;text-align:right}\n@media(max-width:1200px){.my-training .EYlogo{left:60px;top:20px;width:40px}.my-training .logoTxt{font-size:25px;left:130px;top:30px}.my-training .navbarMenu{right:50px;top:31px}.my-training .home{width:20px}.my-training .nav-bar{min-height:90px}.my-training .cf6{font-size:23px}.my-training .hder{font-size:16px;line-height:23px}.my-training .ul-s4{font-size:14px;line-height:21px;padding:0 25px}.my-training .cnt-fdr{padding:35px 70px}.my-training .main-Content{padding:60px 70px}.my-training .cnt_header{font-size:23px}.my-training .table th{font-size:15px}.my-training .table td{font-size:13px}.my-training .box_page{height:130px;padding:25px 20px;width:160px}.my-training .iconBox{width:35px}.my-training .txtBox{font-size:14px;line-height:16px;width:95%}.my-training .footer p{font-size:13px;padding:15px 20px}}\n+@media(max-width:850px){.my-training .c09{gap:10px}.my-training .boxTag{width:48%}.my-training .box_page{width:100%}}\n+@media(max-width:750px){.my-training .table thead{display:none}.my-training .table,.my-training .table tbody,.my-training .table tr,.my-training .table td{display:block}.my-training .table tr{margin-bottom:15px}.my-training .table td{border:1px solid #646464!important;padding:36px 20px 12px;position:relative;text-align:left}.my-training .table td:before{color:#ffe600;content:attr(data-label);font-size:12px;left:20px;position:absolute;text-transform:uppercase;top:12px}.my-training .vb1,.my-training .vb2{font-size:13px}}\n+@media(max-width:575px){.my-training .logoTxt{font-size:20px;left:115px}.my-training .EYlogo{left:30px}.my-training .navbarMenu{top:110px}.my-training .cnt-fdr{padding:35px 30px}.my-training .cf7{width:100%}.my-training .boxTag{width:100%}.my-training .main-Content{padding:50px 40px}.my-training .hder{font-size:14px;line-height:21px}.my-training .cnt_header{font-size:23px}.my-training .vb1,.my-training .vb2{float:none;display:inline-block}}\n";
var MyTraining = function (_a) {
    var onShowHome = _a.onShowHome, onShowTrainingPack = _a.onShowTrainingPack, onShowRecordedSession = _a.onShowRecordedSession, onShowVirtualClinics = _a.onShowVirtualClinics;
    var _b = react__WEBPACK_IMPORTED_MODULE_0__.useState(true), isLoading = _b[0], setIsLoading = _b[1];
    var _c = react__WEBPACK_IMPORTED_MODULE_0__.useState(false), showMaterials = _c[0], setShowMaterials = _c[1];
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
        var timer = window.setTimeout(function () { return setIsLoading(false); }, 2000);
        return function () { return window.clearTimeout(timer); };
    }, []);
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "my-training" },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("style", null, trainingStyles),
        isLoading && react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "loading-container", "aria-label": "Loading" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "webPart" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid nav-container" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row nav-bar" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "EYlogo", src: "".concat(imageRoot, "EY_logo.png"), alt: "EY logo" }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "logoTxt" }, "MENA Tax Hub"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "navbarMenu" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#home", onClick: function (event) { event.preventDefault(); onShowHome(); } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "home", src: "".concat(imageRoot, "home.png"), alt: "Home" })))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 bannerBackground" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid cnt-fdr" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "cf6" }, "My Training"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "hder" }, "Engagement Lifecycle Management is critical to our business, hence it is important that you fully understand Mercury concepts. To help you make the most of Mercury's capabilities, there is an array of training resources available, including:"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "ul-s4" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("b", null, "Web Based Learnings (WBL)"),
                                    ": A series of conceptual WBLs are available. No matter your role or function, the WBLs are the best place to get started."),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("b", null, "Instructor led trainings"),
                                    ": Additionally, there are a number of trainings available if you need to be an expert in a certain area.")),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "htr" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "cf7", onClick: function () { return setShowMaterials(function (visible) { return !visible; }); } }, "Instructor led training materials")),
                            showMaterials && react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "c09" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: "boxTag", href: "#training-pack", onClick: function (event) { event.preventDefault(); onShowTrainingPack === null || onShowTrainingPack === void 0 ? void 0 : onShowTrainingPack(); } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "box_page" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(imageRoot, "docIcon.png"), className: "iconBox", alt: "" }),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "txtBox" }, "Training pack and documents"))),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: "boxTag", href: "#training-recorded", onClick: function (event) { event.preventDefault(); onShowRecordedSession === null || onShowRecordedSession === void 0 ? void 0 : onShowRecordedSession(); } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "box_page" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(imageRoot, "videoIcon.png"), className: "iconBox", alt: "" }),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "txtBox" }, "Training recorded sessions"))),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: "boxTag", href: "#virtual-clinics", onClick: function (event) { event.preventDefault(); onShowVirtualClinics === null || onShowVirtualClinics === void 0 ? void 0 : onShowVirtualClinics(); } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "box_page" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/iconvideo.png", className: "iconBox", alt: "" }),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "txtBox" }, "Virtual clinics training sessions"))),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: "boxTag", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/FAQs%20%20ELM%20%20Introduction%20to%20Mercury%20and%20Engagement%20economics_Rev%2001.pdf", target: "_blank", rel: "noreferrer" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "box_page" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(imageRoot, "faqIcon.png"), className: "iconBox", alt: "" }),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "txtBox" }, "FAQs")))))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "main-Content" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "cnt_header" }, "Web Based Learnings (WBL)"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "hder" },
                    "Below mentioned WBLs are mandatory for all new joiners in MENA Tax SSLs (i.e. Staff to PPED).",
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                    "Learnings must be completed within 90 days from the date of assignment."),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("table", { className: "table table-bordered tx_7" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("thead", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Description"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "SuccessFactors Course Code"))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("tbody", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { "data-label": "Description" }, "The Essentials of Time"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { "data-label": "SuccessFactors Course Code" }, "GLOBALALLHRC6061526")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { className: "mandatory", "data-label": "Description" }, "Opportunity Management and Pricing - Detailed Knowledge Check"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { className: "mandatory", "data-label": "SuccessFactors Course Code" }, "GLOBALALLHRC4210972")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { "data-label": "Description" }, "Creating a pricing plan"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { "data-label": "SuccessFactors Course Code" }, "GLOBALALLHRC5834126")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { "data-label": "Description" }, "Mercury ETC - Getting Started and Scenarios"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { "data-label": "SuccessFactors Course Code" }, "GLOBALALLHRC7889055")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { className: "mandatory", "data-label": "Description" }, "Advanced Mercury Economics - Detailed"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { className: "mandatory", "data-label": "SuccessFactors Course Code" }, "GLOBALCBSHRC4691515")))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "cv7" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "vb1" }, "Optional trainings"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "vb2" }, "Mandatory trainings")),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "hder" },
                    "For existing personnel, use the table above to access courses in ",
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "http://sf.ey.net/", target: "_blank", rel: "noreferrer" }, "SuccessFactors"),
                    " by entering the course code in the Find Learning search field."),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "cnt_header" }, "Instructor Led Trainings"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "hder" }, "Multiple sessions led jointly by MBAs and PFA ensure practical in-system walk-throughs, case studies, FAQ, best practices and Q&A."),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "hder" }, "Virtual sessions in the year 2024:"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("table", { className: "table table-bordered ty_7" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("thead", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Training sessions"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Instructors"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Tentative Date"))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("tbody", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { "data-label": "Training sessions" }, "Opportunity & Pricing Plan"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { "data-label": "Instructors" }, "Juli Ceasar; Shalini George"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { "data-label": "Tentative Date" }, "19-Nov-24")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { "data-label": "Training sessions" }, "Engagement Budget and Release (Lean & Standard Path)"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { "data-label": "Instructors" }, "Rand Zarour; Juli Ceasar"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { "data-label": "Tentative Date" }, "20-Nov-24")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { "data-label": "Training sessions" }, "Estimate to Complete"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { "data-label": "Instructors" }, "Rand Zarour; Shalini George"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { "data-label": "Tentative Date" }, "21-Nov-24")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { "data-label": "Training sessions" }, "Billing process"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { "data-label": "Instructors" }, "Juli Ceasar; Shalini George"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { "data-label": "Tentative Date" }, "26-Nov-24")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { "data-label": "Training sessions" }, "Engagement Economics"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { "data-label": "Instructors" }, "Rand Zarour; Shalini George"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { "data-label": "Tentative Date" }, "27-Nov-24")))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "hder" },
                    "If you wish to register for these trainings please contact ",
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "mailto:ghazanfar.iqbal@sa.ey.com" }, "Ghazanfar Iqbal"),
                    "."),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "hder" },
                    "Please click on ",
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: "topClass", style: { cursor: 'pointer' } }, "\u201CInstructor led training materials\u201D"),
                    " to find the training materials and recordings for each session type.")),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "footer" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "\u00A9 2026 EYGM Limited. All rights reserved.")))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyTraining);


/***/ }),

/***/ 345:
/*!****************************************************************!*\
  !*** ./lib/webparts/menaTaxHub/components/NonGccResourcing.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

var nonGccStyles = "\n  .nonGccResourcing { background: #2e2e38; color: #ffffff; font-family: EYInterstate, Arial, sans-serif; overflow: hidden; }\n  .nonGccResourcing__nav { background: #2e2e38; min-height: 6vw; position: relative; }\n  .nonGccResourcing__nav .EYlogo { left: 5vw; position: absolute; top: 1.5vw; width: 3vw; }\n  .nonGccResourcing__nav .logoTxt { color: #ffffff; font-size: 2vw; left: 11vw; margin: 0; position: absolute; top: 2.2vw; }\n  .nonGccResourcing__nav .navLinks { display: flex; gap: 1vw; list-style: none; margin: 0; padding: 0; position: absolute; right: 6vw; top: 2.4vw; }\n  .nonGccResourcing__nav .navLinks a { align-items: center; color: #ffffff; display: flex; font-size: 1vw; gap: .5vw; text-decoration: none; }\n  .nonGccResourcing__nav .navLinks img { width: 1vw; }\n  .nonGccResourcing__nav .navLinks img.home { width: 1.3vw; }\n  .nonGccResourcing__nav .navToggle { display: none; }\n  .nonGccResourcing__hero { background-color: #2e2e38; background-image: url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Rapid-Nearshore.jpg'); background-position: center; background-size: cover; min-height: 17vw; padding: 0 5vw; }\n  .nonGccResourcing__hero h1 { border-bottom: 2px solid #ffffff; font-size: 1.9vw; margin: 0 0 1.3vw 1vw; padding-bottom: 3px; padding-top: 5vw; width: 34vw; }\n  .nonGccResourcing__hero hr { border: 0; border-top: .2vw solid #ffe600; margin: 0 0 0 1.2vw; width: 3vw; }\n  .nonGccResourcing__main { background-image: url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png'); background-position: center; background-size: cover; }\n  .nonGccResourcing__intro { background: rgba(0, 0, 0, .09); border-bottom: .1vw solid #363636; padding: 2vw 6vw 1vw; }\n  .nonGccResourcing__intro p, .nonGccResourcing__accordionBody li, .nonGccResourcing__table { font-family: Arial, sans-serif; font-size: 1vw; line-height: 1.5; }\n  .nonGccResourcing__accordion { padding: 0 6vw 2vw; }\n  .nonGccResourcing__item { border-bottom: 1px solid rgba(255, 255, 255, .25); }\n  .nonGccResourcing__heading { color: #ffe600; font-size: 1.3vw; margin: 1.2vw 0 .6vw; }\n  .nonGccResourcing__accordionBody { padding-bottom: .5vw; }\n  .nonGccResourcing__accordionBody ul { list-style: none; margin: 0; padding: 0; }\n  .nonGccResourcing__accordionBody li { margin-bottom: .6vw; padding-left: 1.5vw; position: relative; }\n  .nonGccResourcing__accordionBody li::before { color: #ffe600; content: '>'; left: 0; position: absolute; }\n  .nonGccResourcing__accordionBody a { color: #ffe600; font-weight: 700; }\n  .nonGccResourcing__table { border: .1vw solid rgba(255, 255, 255, .14); border-collapse: collapse; margin: 3.5vw 2.5% 1vw; text-align: center; width: 95%; }\n  .nonGccResourcing__table td { border-right: .1vw solid rgba(255, 255, 255, .12); height: 80px; padding: 1vw; }\n  .nonGccResourcing__table tr:first-child { border-bottom: .1vw solid rgba(255, 255, 255, .12); }\n  .nonGccResourcing__team { padding: 0 6vw 2vw; }\n  .nonGccResourcing__sectionTitle { border-bottom: 1px solid rgba(255, 255, 255, .4); border-top: 1px solid rgba(255, 255, 255, .4); color: #ffffff; display: block; font-size: 1.4vw; margin: 0 0 2vw; padding: 1vw 0; }\n  .nonGccResourcing__teamGrid { display: grid; gap: .8vw; grid-template-columns: repeat(5, 1fr); }\n  .nonGccResourcing__person { background: rgba(255, 255, 255, .06); min-height: 13vw; padding: 1vw .4vw; text-align: center; }\n  .nonGccResourcing__person img { border-radius: 50%; height: 5.5vw; object-fit: cover; width: 5.5vw; }\n  .nonGccResourcing__person strong { color: #ffe600; display: block; font-size: .9vw; margin-top: 1vw; }\n  .nonGccResourcing__person span { display: block; font-size: .8vw; margin-top: .4vw; }\n  .nonGccResourcing__footer { background: #000000; color: #ffffff; font-size: 1vw; padding: 1vw 2vw; text-align: right; }\n  .nonGccResourcing__back { align-items: center; background: #ffe600; border: 0; color: #000000; cursor: pointer; display: flex; font-weight: 700; gap: .5vw; margin: 1vw 0 0 2vw; padding: .6vw 1vw; }\n  .nonGccResourcing__back img { width: 1vw; }\n  @media only screen and (max-width: 1200px) {\n    .nonGccResourcing__nav { min-height: 90px; }\n    .nonGccResourcing__nav .EYlogo { left: 60px; top: 20px; width: 40px; }\n    .nonGccResourcing__nav .logoTxt { font-size: 25px; left: 130px; top: 30px; }\n    .nonGccResourcing__nav .navLinks { right: 50px; top: 31px; }\n    .nonGccResourcing__nav .navLinks a { font-size: 13px; }\n    .nonGccResourcing__nav .navLinks img { width: 13px; }\n    .nonGccResourcing__nav .navLinks img.home { width: 20px; }\n    .nonGccResourcing__hero { min-height: 220px; }\n    .nonGccResourcing__hero h1 { font-size: 30px; padding-top: 70px; width: 420px; }\n    .nonGccResourcing__intro p, .nonGccResourcing__accordionBody li, .nonGccResourcing__table { font-size: 14px; }\n    .nonGccResourcing__heading, .nonGccResourcing__sectionTitle { font-size: 18px; }\n    .nonGccResourcing__person strong { font-size: 13px; }\n    .nonGccResourcing__person span, .nonGccResourcing__footer { font-size: 11px; }\n  }\n  @media only screen and (max-width: 800px) {\n    .nonGccResourcing__hero { min-height: 190px; }\n    .nonGccResourcing__teamGrid { grid-template-columns: repeat(3, 1fr); }\n  }\n  @media only screen and (max-width: 575px) {\n    .nonGccResourcing__nav .navLinks { top: 110px; }\n    .nonGccResourcing__hero { min-height: 170px; padding: 0 30px; }\n    .nonGccResourcing__hero h1 { font-size: 20px; padding-top: 55px; width: 100%; }\n    .nonGccResourcing__intro, .nonGccResourcing__accordion, .nonGccResourcing__team { padding-left: 30px; padding-right: 30px; }\n    .nonGccResourcing__heading { font-size: 17px; line-height: 23px; }\n    .nonGccResourcing__table { display: block; font-size: 12px; overflow-x: auto; white-space: nowrap; }\n    .nonGccResourcing__teamGrid { grid-template-columns: repeat(2, 1fr); }\n    .nonGccResourcing__person { min-height: 180px; }\n    .nonGccResourcing__person img { height: 80px; width: 80px; }\n    .nonGccResourcing__back { margin-left: 20px; }\n  }\n  @media only screen and (max-width: 400px) { .nonGccResourcing__teamGrid { grid-template-columns: 1fr; } }\n";
var NonGccResourcing = function (_a) {
    var onShowResourcing = _a.onShowResourcing, onShowHome = _a.onShowHome;
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "nonGccResourcing" },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("style", null, nonGccStyles),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("nav", { className: "nonGccResourcing__nav" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "EYlogo", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/EY_logo.png", alt: "EY logo" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "logoTxt" }, "MENA Tax Hub"),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "navLinks" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#resourcing" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/back-button_resource-hub.png", alt: "" }),
                        "Back")),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#", onClick: function (event) { event.preventDefault(); onShowHome(); } },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "home", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home.png", alt: "Home" })))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "navToggle", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/toggle.png", alt: "Navigation toggle" })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("header", { className: "nonGccResourcing__hero" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("h1", null, "Non-GCC (Levant / Rapid Pakistan)"),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("hr", null)),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("main", { className: "nonGccResourcing__main" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("section", { className: "nonGccResourcing__intro" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "Rapid/Pakistan and the Levant region is scaling up to meet increasing demand.")),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("section", { className: "nonGccResourcing__accordion" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "nonGccResourcing__item" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("h2", { className: "nonGccResourcing__heading" }, "Key Considerations:"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "nonGccResourcing__accordionBody" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Is this request within your SSL Financial plan?"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Are the types of skills required available onshore or within the existing GDS FTE pool?"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Have you reviewed utilization of onshore resources against capacity and rank utilization expectations?"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Have you reviewed utilization of sponsored GDS FTE and Rapid pool against expectations?")))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "nonGccResourcing__item" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("h2", { className: "nonGccResourcing__heading" }, "What happens next?"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "nonGccResourcing__accordionBody" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                "Carry out an assessment of your current state using the ",
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://app.powerbi.com/groups/me/apps/88b138f5-216c-4ac6-b72a-a19e005bd381/reports/224a0ea2-bd8c-4441-b136-31641b8a8103/ReportSectionbd6d72f0b28d653ff863?ctid=5b973f99-77df-4beb-b27d-aa0c70b8482c&experience=power-bi", target: "_blank", rel: "noreferrer" }, "Tax People Dashboard"),
                                ", ",
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://app.powerbi.com/groups/me/apps/88b138f5-216c-4ac6-b72a-a19e005bd381/reports/db646e19-5e24-4e38-accc-9a8c2e8743e9/ReportSection?ctid=5b973f99-77df-4beb-b27d-aa0c70b8482c&chromeless=1&experience=power-bi", target: "_blank", rel: "noreferrer" }, "Finance & Engagement Dashboard")),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                "If your request aligns with the considerations above and the Financial Plan, proceed with raising a resource request on the ",
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://apps.powerapps.com/play/e/a3c669f6-ac2e-4e77-ad43-beab3e15bee7/a/a422fad2-0a90-4117-b14b-3da399c77b75?tenantId=5b973f99-77df-4beb-b27d-aa0c70b8482c&sourcetime=1721291017599&hidenavbar=true", target: "_blank", rel: "noreferrer" }, "MENA Tax Hiring Tool")),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Your request would be routed through EXM (Experience Management), SSL leader and COO for approval"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Once fully approved, an automated email is generated and sent to the appropriate recruitment team for next steps"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Typical turnaround time for approval is between 2- 4 business days"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "For requests that do not meet the requirements, please connect with your respective EXM contact for any additional information and guidance on the optimal approach to fulfil your requirement along with a business case.")))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "nonGccResourcing__item" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("h2", { className: "nonGccResourcing__heading" }, "Cost components:"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "nonGccResourcing__accordionBody" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                "Cost of the nearshore resources will be guided by the EY salary banding for that rank and location - ",
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://apps.powerapps.com/play/e/a3c669f6-ac2e-4e77-ad43-beab3e15bee7/a/3cfbfa9b-b76f-4eda-ac6d-4fca290223ed?tenantId=5b973f99-77df-4beb-b27d-aa0c70b8482c&hint=44598ecd-53c9-437b-84db-7ad09753f59c&sourcetime=1707913990980&source=portal", target: "_blank", rel: "noreferrer" }, "Mercury cost rates can be found using \"MENA Tax Cost Comparison Tool\""))))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "nonGccResourcing__item" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("h2", { className: "nonGccResourcing__heading" }, "Out-of-pocket expenses (this will apply for onsite MENA deployments)."),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "nonGccResourcing__accordionBody" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Travel OPE Cost Estimation - EXAMPLE"))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("table", { className: "nonGccResourcing__table" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("tbody", null,
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "Country"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "Visa Type"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "Entry"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "Visa Cost"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "Flight Cost (Round trip)"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "Hotel Cost"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "Sim Card"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "Telephone Expenses (monthly)"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "Airport Transfers (both ways)"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "Additional Baggage"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "Taxi Expenses"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "Per Diem"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "Duration"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "Cost per resource (1st month)"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "Next Time Travel (per month)")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "KSA (Riyadh)"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "Work Permit"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "Multiple"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "$ 800"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "$ 600"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "$ 130"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "$ 50"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "$ 25"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "$ 100"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "$ 200"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "$ 40"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "$ 70"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "$ 30"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "$ 9,025"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, "$ 8,175")))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("section", { className: "nonGccResourcing__team" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "nonGccResourcing__sectionTitle" }, "Meet The Team"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "nonGccResourcing__teamGrid" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "nonGccResourcing__person" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Dania-Zalatimo.png", alt: "Dania Zalatimo" }),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", null, "Dania Zalatimo"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "Assistant Director"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "Tax Experience Hire Leader")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "nonGccResourcing__person" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Farrah-Imran.png", alt: "Farrah Imran" }),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", null, "Farrah Imran"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "Assistant Director"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "MENA Campus Hire leader")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "nonGccResourcing__person" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Dileep-Rajasekhar.png", alt: "Dileep Rajasekhar" }),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", null, "Dileep Rajasekhar"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "Assistant Director")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "nonGccResourcing__person" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/ellen-M-Jose.png", alt: "Jellen M Jose" }),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", null, "Jellen M Jose"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "Assistant Director"))))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("footer", { className: "nonGccResourcing__footer" }, "\u00A9 2026 EYGM Limited. All rights reserved.")));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NonGccResourcing);


/***/ }),

/***/ 359:
/*!*****************************************************************!*\
  !*** ./lib/webparts/menaTaxHub/components/OnshoreResourcing.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

var onshoreStyles = "\n  .onshoreResourcing { background: #2e2e38; color: #ffffff; font-family: EYInterstate, Arial, sans-serif; overflow: hidden; }\n  .onshoreResourcing__nav { background: #2e2e38; min-height: 6vw; position: relative; }\n  .onshoreResourcing__nav .EYlogo { left: 5vw; position: absolute; top: 1.5vw; width: 3vw; }\n  .onshoreResourcing__nav .logoTxt { color: #ffffff; font-size: 2vw; left: 11vw; margin: 0; position: absolute; top: 2.2vw; }\n  .onshoreResourcing__nav .navLinks { display: flex; gap: 1vw; list-style: none; margin: 0; padding: 0; position: absolute; right: 6vw; top: 2.4vw; }\n  .onshoreResourcing__nav .navLinks a { align-items: center; color: #ffffff; display: flex; font-size: 1vw; gap: .5vw; text-decoration: none; }\n  .onshoreResourcing__nav .navLinks img { width: 1vw; }\n  .onshoreResourcing__nav .navLinks img.home { width: 1.3vw; }\n  .onshoreResourcing__nav .navToggle { display: none; }\n  .onshoreResourcing__hero { background-color: #2e2e38; background-image: url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/banner-images-onshore.png'); background-position: center; background-size: cover; min-height: 17vw; padding: 0 5vw; }\n  .onshoreResourcing__hero h1 { border-bottom: 2px solid #ffffff; font-size: 1.9vw; margin: 0 0 1.3vw 1vw; padding-top: 5vw; padding-bottom: 3px; width: 34vw; }\n  .onshoreResourcing__hero hr { border: 0; border-top: .2vw solid #ffe600; margin: 0 0 0 1.2vw; width: 3vw; }\n  .onshoreResourcing__main { background-image: url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png'); background-position: center; background-size: cover; }\n  .onshoreResourcing__intro { background: rgba(0, 0, 0, .09); border-bottom: .1vw solid #363636; padding: 2vw 6vw 1vw; }\n  .onshoreResourcing__intro p, .onshoreResourcing__accordionBody li { font-family: Arial, sans-serif; font-size: 1vw; line-height: 1.5; }\n  .onshoreResourcing__accordion { padding: 0 6vw 2vw; }\n  .onshoreResourcing__item { border-bottom: 1px solid rgba(255, 255, 255, .25); }\n  .onshoreResourcing__heading { color: #ffe600; font-size: 1.3vw; margin: 1.2vw 0 .6vw; }\n  .onshoreResourcing__accordionBody { padding-bottom: .5vw; }\n  .onshoreResourcing__accordionBody ul { list-style: none; margin: 0; padding: 0; }\n  .onshoreResourcing__accordionBody li { margin-bottom: .6vw; padding-left: 1.5vw; position: relative; }\n  .onshoreResourcing__accordionBody li::before { color: #ffe600; content: '>'; left: 0; position: absolute; }\n  .onshoreResourcing__accordionBody a { color: #ffe600; font-weight: 700; }\n  .onshoreResourcing__team { padding: 0 6vw 2vw; }\n  .onshoreResourcing__sectionTitle { border-bottom: 1px solid rgba(255, 255, 255, .4); border-top: 1px solid rgba(255, 255, 255, .4); color: #ffffff; display: block; font-size: 1.4vw; margin: 0 0 2vw; padding: 1vw 0; }\n  .onshoreResourcing__teamGrid { display: grid; gap: .8vw; grid-template-columns: repeat(5, 1fr); }\n  .onshoreResourcing__person { background: rgba(255, 255, 255, .06); min-height: 13vw; padding: 1vw .4vw; text-align: center; }\n  .onshoreResourcing__person img { border-radius: 50%; height: 5.5vw; object-fit: cover; width: 5.5vw; }\n  .onshoreResourcing__person strong { color: #ffe600; display: block; font-size: .9vw; margin-top: 1vw; }\n  .onshoreResourcing__person span { display: block; font-size: .8vw; margin-top: .4vw; }\n  .onshoreResourcing__footer { background: #000000; color: #ffffff; font-size: 1vw; padding: 1vw 2vw; text-align: right; }\n  .onshoreResourcing__back { align-items: center; background: #ffe600; border: 0; color: #000000; cursor: pointer; display: flex; font-weight: 700; gap: .5vw; margin: 1vw 0 0 2vw; padding: .6vw 1vw; }\n  .onshoreResourcing__back img { width: 1vw; }\n  @media only screen and (max-width: 1200px) {\n    .onshoreResourcing__nav { min-height: 90px; }\n    .onshoreResourcing__nav .EYlogo { left: 60px; top: 20px; width: 40px; }\n    .onshoreResourcing__nav .logoTxt { font-size: 25px; left: 130px; top: 30px; }\n    .onshoreResourcing__nav .navLinks { right: 50px; top: 31px; }\n    .onshoreResourcing__nav .navLinks a { font-size: 13px; }\n    .onshoreResourcing__nav .navLinks img { width: 13px; }\n    .onshoreResourcing__nav .navLinks img.home { width: 20px; }\n    .onshoreResourcing__hero { min-height: 220px; }\n    .onshoreResourcing__hero h1 { font-size: 30px; padding-top: 70px; width: 420px; }\n    .onshoreResourcing__intro p, .onshoreResourcing__accordionBody li { font-size: 14px; }\n    .onshoreResourcing__heading { font-size: 18px; }\n    .onshoreResourcing__sectionTitle { font-size: 18px; }\n    .onshoreResourcing__person strong { font-size: 13px; }\n    .onshoreResourcing__person span { font-size: 11px; }\n    .onshoreResourcing__footer { font-size: 13px; }\n  }\n  @media only screen and (max-width: 800px) {\n    .onshoreResourcing__hero { min-height: 190px; }\n    .onshoreResourcing__teamGrid { grid-template-columns: repeat(3, 1fr); }\n  }\n  @media only screen and (max-width: 575px) {\n    .onshoreResourcing__nav .navLinks { top: 110px; }\n    .onshoreResourcing__nav .navLinks a { font-size: 12px; }\n    .onshoreResourcing__hero { min-height: 170px; padding: 0 30px; }\n    .onshoreResourcing__hero h1 { font-size: 24px; padding-top: 55px; width: 100%; }\n    .onshoreResourcing__intro, .onshoreResourcing__accordion, .onshoreResourcing__team { padding-left: 30px; padding-right: 30px; }\n    .onshoreResourcing__heading { font-size: 17px; line-height: 23px; }\n    .onshoreResourcing__teamGrid { grid-template-columns: repeat(2, 1fr); }\n    .onshoreResourcing__person { min-height: 180px; }\n    .onshoreResourcing__person img { height: 80px; width: 80px; }\n    .onshoreResourcing__back { margin-left: 20px; }\n  }\n  @media only screen and (max-width: 400px) {\n    .onshoreResourcing__teamGrid { grid-template-columns: 1fr; }\n  }\n";
var OnshoreResourcing = function (_a) {
    var onShowResourcing = _a.onShowResourcing, onShowHome = _a.onShowHome;
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "onshoreResourcing" },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("style", null, onshoreStyles),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("nav", { className: "onshoreResourcing__nav" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "EYlogo", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/EY_logo.png", alt: "EY logo" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "logoTxt" }, "MENA Tax Hub"),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "navLinks" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#resourcing" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/back-button_resource-hub.png", alt: "" }),
                        "Back")),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#", onClick: function (event) { event.preventDefault(); onShowHome(); } },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "home", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home.png", alt: "Home" })))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "navToggle", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/toggle.png", alt: "Navigation toggle" })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("header", { className: "onshoreResourcing__hero" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("h1", null, "Onshore Resourcing"),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("hr", null)),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("main", { className: "onshoreResourcing__main" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("section", { className: "onshoreResourcing__intro" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "Onshore resources are associated with high costs to deliver, which in turn impacts expected margins. As profit margins become a decisive factor in onshore staffing decisions, the high direct costs associated with onshore resources, such as salaries, are shifting demand towards locations with lower costs."),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "Cost remains a key element when considering/ validating value driven from an onshore vs. offshore resource, and the following considerations are integral to making the right resourcing decision.")),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("section", { className: "onshoreResourcing__accordion" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "onshoreResourcing__item" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("h2", { className: "onshoreResourcing__heading" }, "Key Considerations:"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "onshoreResourcing__accordionBody" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Is this request within your SSL Financial plan?"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Have you reviewed utilization of onshore resources against capacity and rank utilization expectations?"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Are Internal promotion/ progression opportunities an option?"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Are the types of skills required available internally?"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Have you reviewed utilization of sponsored GDS FTE, GDS T&M and Rapid pool against expectations?"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Have you considered offshoring the role? If not, what is stopping you?"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Would FTTE, contractors, and manpower agencies be suitable?"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Consider the effects on your current Nationalization, and Diversity & Inclusivity objectives, particularly when considering expatriates.")))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "onshoreResourcing__item" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("h2", { className: "onshoreResourcing__heading" }, "What happens next?"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "onshoreResourcing__accordionBody" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                "Carry out an assessment of your current state using the ",
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://app.powerbi.com/groups/me/apps/88b138f5-216c-4ac6-b72a-a19e005bd381/reports/224a0ea2-bd8c-4441-b136-31641b8a8103/ReportSectionbd6d72f0b28d653ff863?ctid=5b973f99-77df-4beb-b27d-aa0c70b8482c&experience=power-bi", target: "_blank", rel: "noreferrer" }, "Tax People Dashboard"),
                                ", ",
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://app.powerbi.com/groups/me/apps/88b138f5-216c-4ac6-b72a-a19e005bd381/reports/db646e19-5e24-4e38-accc-9a8c2e8743e9/ReportSection?ctid=5b973f99-77df-4beb-b27d-aa0c70b8482c&chromeless=1&experience=power-bi", target: "_blank", rel: "noreferrer" }, "Finance & Engagement Dashboard")),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                "If your request aligns with the considerations above and the Financial Plan, proceed with raising a resource request on the ",
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://apps.powerapps.com/play/e/a3c669f6-ac2e-4e77-ad43-beab3e15bee7/a/8617d89c-6f71-4969-ace8-5904bcfefc65?tenantId=5b973f99-77df-4beb-b27d-aa0c70b8482c&source=portal&screenColor=rgba%280%2c+176%2c+240%2c+1%29&skipAppMetadata=true", target: "_blank", rel: "noreferrer" }, "MENA Tax Hiring Tool")),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Your request would be routed through EXM (Experience Management), SSL leader and COO for approval"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Once fully approved, an automated email is generated and sent to the appropriate recruitment team for next steps"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Typical turnaround time for approval is between 2- 4 business days"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "For requests that do not meet the requirements, please connect with your respective EXM contact for any additional information and guidance on the optimal approach to fulfil your requirement along with a business case.")))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "onshoreResourcing__item" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("h2", { className: "onshoreResourcing__heading" }, "Cost components:"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "onshoreResourcing__accordionBody" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Cost of the onshore resources will be guided by the EY salary banding for that rank and location. Alternatively please feel free to use the \"MENA Tax - Cost Comparison App\""))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("section", { className: "onshoreResourcing__team" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "onshoreResourcing__sectionTitle" }, "Meet The Team"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "onshoreResourcing__teamGrid" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "onshoreResourcing__person" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Dania-Zalatimo.png", alt: "Dania Zalatimo" }),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", null, "Dania Zalatimo"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "Assistant Director"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "Tax Experience Hire Leader")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "onshoreResourcing__person" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Farrah-Imran.png", alt: "Farrah Imran" }),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", null, "Farrah Imran"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "Assistant Director"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "MENA Campus Hire leader")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "onshoreResourcing__person" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Bobin%20T.jpg", alt: "Bobin T Abraham" }),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", null, "Bobin T Abraham"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "Associate Director")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "onshoreResourcing__person" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Dileep%20Rajasekhar.jpg", alt: "Dileep Rajasekhar" }),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", null, "Dileep Rajasekhar"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "Assistant Director")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "onshoreResourcing__person" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Jellen%20Jose.jpg", alt: "Jellen M Jose" }),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", null, "Jellen M Jose"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "Assistant Director"))))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("footer", { className: "onshoreResourcing__footer" }, "\u00A9 2026 EYGM Limited. All rights reserved.")));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OnshoreResourcing);


/***/ }),

/***/ 431:
/*!*********************************************************************!*\
  !*** ./lib/webparts/menaTaxHub/components/PoliciesAndProcedures.js ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

var imageRoot = 'https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/';
var policyCards = [
    ['z1.png', 'Selling', 'an opportunity', 'is progressing the right opportunities and proposing the work we deliver to our clients. It is about focusing on and improving margin.'],
    ['z2.png', 'Planning', 'an engagement', 'is using our resources in a cost-effective way and providing valuable career opportunities, while enabling us to deliver quality solutions and services to our clients.'],
    ['z3.png', 'Delivering', 'an engagement', 'working on client deliverables, with a continuous focus on margin and managing the health of an engagement.']
];
var resources = [
    ['Engagement lifecycle management checklist', 'https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/Engagement%20lifecycle%20management%20key%20changes.pdf'],
    ['Lean and standard: process steps in Mercury', 'https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/Document%20in%20SOPs_01.pdf'],
    ['Lean vs. standard comparison', 'https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/Lean-vs-Standard.pdf'],
    ['High level budget calculator', 'https://apps.powerapps.com/play/e/c8ee9bdf-796c-e519-a5df-582e17394e4b/a/e5843273-4dd0-456f-bc51-a11b2a7b3b07'],
    ['Financial thresholds control framework', 'https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/MENA%20Tax%20-%20Financial%20Thresholds%20Control%20Framework%20v2.2.pdf'],
    ['RACI', 'https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/raci.pdf'],
    ['Exchange Rates', 'https://www.xe.com/currencyconverter'],
    ['Key Glossary', 'https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/Engagement%20Lifecycle%20Glossary%20%26%20Abbreviations%20V1.0.pdf'],
    ['FAQs', 'https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/Engagement%20Lifecycle%20FAQs%20V1.0.pdf']
];
var stepDetails = [
    ['Mercury Customer Relationship Management (CRM) acts as the single source for global client contact, account, and opportunity data.', 'CRM is standard terminology for creating and editing contact data to improve data accuracy, consistency and integrity.'],
    ['The Opportunity Management process creates, updates and sets the outcome of new opportunities while maintaining existing opportunities.', 'All opportunities need to be created in Mercury CRM and set to WON before an engagement can be created.'],
    ['A pricing plan is required for all opportunities and should reflect market and Service Line benchmarks for the type of work.', 'Pricing is done with a view of the fees required to deliver what the client has requested, with a primary focus on optimized margin.'],
    ['PACE remains the primary tool for risk assessments, while Mercury provides an easy entry point to the system.', 'Every opportunity requires a PACE form for Client Acceptance, Engagement Acceptance, Subcontract or a combination thereof.'],
    ['Pricing plans can be updated until the opportunity status is set to Won, representing the sold-at metric.', 'Keep the pricing plan updated to reflect client and deal review feedback and ensure you are optimizing the opportunity margin.'],
    ['In Mercury, capture the status of the signed Statement of Work (SOW) or Engagement Agreement (EA).', 'To set an opportunity to Won and release an engagement, a signed EA/SOW or exceptional or internal approval is needed.'],
    ['Updating opportunity information throughout the engagement lifecycle is critical because it supports engagement setup and downstream decision-making.', 'Keep opportunity details accurate and up to date, including information used for resourcing and future investment allocations.'],
    ['Every engagement must be linked to an opportunity. You cannot set up an engagement without an opportunity.', 'When setting up an engagement, provide opportunity and PACE details, engagement roles, engagement agreements and billing details.'],
    ['Standard engagements require detailed budgets, while Lean engagements require a high-level budget including the engagement value and margin threshold.', 'Complete the Engagement Budget to release the engagement and begin charging hours.'],
    ['Resourcing is the process of identifying and assigning individuals to an opportunity or engagement.', 'It ensures the right people are available to deliver on client needs on a timely basis.'],
    ['Resource scheduling ensures the right people are available to deliver on client needs on time.', 'Send the resource request and maintain the engagement schedule as requirements change.'],
    ['Timely and accurate recording and submission of time and expenses is crucial because every hour and expense charged is potential revenue or cost for the firm.'],
    ['Engagement Economics reviews and manages the financial aspects of an engagement, including forecasting against the Mercury budget.', 'Complete regular and timely reviews, optimize engagement margin and minimize write-offs by keeping data accurate and up to date.'],
    ['The billing process is crucial to mitigate risk and improve working capital management.', 'By billing correctly from the start and monitoring aged invoices, collection issues can be identified and resolved in a timely manner.'],
    ['Collections communicates with engagement teams and clients to ensure timely collection of Accounts Receivable.', 'Escalate issues or client disputes that prevent collection of Accounts Receivable.'],
    ['Closing an engagement is the final step of the Engagement Lifecycle and enables us to review financial performance.', 'This information helps us make informed decisions on how to approach or pursue similar engagements in the future.']
];
var styles = "\n.policies-page{background:#2e2e38;color:#fff;font-family:EYInterstate,Arial,sans-serif;min-height:100vh;overflow:hidden}.policies-page *{box-sizing:border-box}.loading-container{align-items:center;background:#1a1a24;display:flex;inset:0;justify-content:center;position:fixed;z-index:1000001}.loading-container .item{border:.2vw solid #ffe600;border-bottom-color:transparent;border-radius:50%;border-top-color:transparent;position:absolute;animation:spin 2s ease infinite}.loading-container .item:nth-child(1){height:30px;width:30px}.loading-container .item:nth-child(2){animation-delay:.1s;height:50px;width:50px}.loading-container .item:nth-child(3){animation-delay:.2s;height:70px;width:70px}.loading-container .item:nth-child(4){animation-delay:.3s;height:90px;width:90px}@keyframes spin{50%{transform:rotate(180deg)}100%{transform:rotate(0deg)}}.policy-nav{height:6vw;min-height:72px;background:#2e2e38;position:relative;z-index:3}.EYlogo{position:absolute;left:5vw;top:1.5vw;width:3vw}.logoTxt{position:absolute;left:11vw;top:2.2vw;margin:0;color:#fff;font-size:2vw}.navbarMenu{position:absolute;right:6vw;top:2.4vw;margin:0;padding:0;list-style:none}.navbarMenu li{display:inline-block;color:#fff;font-size:1vw}.navbarMenu a{color:#fff;padding:0 2vw;text-decoration:none}.home{width:1.3vw}.policy-hero{display:grid;grid-template-columns:minmax(0,3fr) minmax(230px,1fr);background:#2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/banner.jpg') center/cover;padding:0 0 0 5vw}.hero-copy{background:rgba(46,46,56,.54);padding:2vw 2vw 2.2vw 0}.policy-hero h1{color:#fff;font-size:1.5vw;font-weight:400;margin:0 0 2vw}.policy-card-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:2vw}.policy-card{min-height:10vw}.policy-card img{display:block;width:3vw;margin-bottom:.4vw}.policy-card p{font-size:.75vw;line-height:1.3;margin:0}.policy-card span{color:#ffe600;font-weight:700;font-size:.9vw;margin-right:.3vw}.policy-card b{font-size:.9vw}.hero-intro{margin-top:2vw;font-size:.75vw;line-height:1.4}.hero-intro ul{list-style:none;margin:1vw 0 0;padding:0}.hero-intro li{margin:.45vw 0;padding-left:1vw;position:relative}.hero-intro li:before{content:'>';color:#ffe600;position:absolute;left:0;font-weight:bold}.hero-resources{background:rgba(24,24,32,.7);padding:0}.hero-resources a{display:flex;align-items:center;justify-content:center;min-height:3.6vw;padding:.6vw 1.2vw;border-bottom:1px solid rgba(255,255,255,.08);color:#fff;text-align:center;font-size:.7vw;line-height:1.25;text-decoration:none;    font-size: 1vw;\n    padding: 1vw 2vw;     min-height: 5.5vw;}\n    .hero-resources a:nth-child(even){background:#ffffff12;}\n    .hero-resources a:hover{background:rgba(255,255,255,.1)}.lifecycle{background:#2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/wecast.png') center/cover;padding:3.5vw 8vw 4vw;position:relative}.lifecycle h2{font-size:2.3vw;font-weight:400;margin:0 0 .3vw}.lifecycle>p{color:#ffe600;font-size:.75vw;margin:0}.phase-labels{display:grid;grid-template-columns:repeat(3,1fr);margin-top:1.7vw}.phase-label{border-bottom:3px solid;text-align:center;padding-bottom:.4vw;font-size:.7vw}.phase-label:nth-child(1){border-color:#2db757}.phase-label:nth-child(2){border-color:#27acaa}.phase-label:nth-child(3){border-color:#188ce5}.step-map{display:grid;grid-template-columns:repeat(8,1fr);grid-template-rows:repeat(2,8.5vw);margin-top:1.5vw;position:relative}.step-map:before{content:'';position:absolute;left:1.2vw;right:1.2vw;top:8.5vw;border-top:1px dashed rgba(255,255,255,.6)}.step-cell{position:relative;display:flex;align-items:center;justify-content:center}.step-cell:nth-child(4n+1),.step-cell:nth-child(4n+2){grid-row:2}.step-cell:nth-child(4n+3),.step-cell:nth-child(4n+4){grid-row:1}.step-cell:after{content:'';position:absolute;top:0;bottom:0;border-left:1px dashed rgba(255,255,255,.6);z-index:0}.step-cell:nth-child(4n+1):after,.step-cell:nth-child(4n+2):after{top:-3.5vw}.step-cell:nth-child(4n+3):after,.step-cell:nth-child(4n+4):after{bottom:-3.5vw}.step-cell:nth-child(4n+1) .step,.step-cell:nth-child(4n+2) .step{transform:translateY(2.4vw)}.step-cell:nth-child(4n+3) .step,.step-cell:nth-child(4n+4) .step{transform:translateY(-2.4vw)}.step{position:relative;z-index:1;background:transparent;border:0;color:#fff;cursor:pointer;padding:0;width:100%;text-align:center}.step:hover .step-number,.step:focus-visible .step-number{background:#fff;color:#000;outline:none}.step-number{display:flex;align-items:center;justify-content:center;background:#ffe600;border-radius:50%;color:#000;font-size:1vw;height:2.2vw;margin:auto;width:2.2vw}.step img{display:block;margin:.4vw auto;width:2vw;max-height:2vw;object-fit:contain}.step-label{display:block;font-size:.65vw;line-height:1.15;margin:auto;max-width:7vw}.lifecycle-links{display:flex;justify-content:flex-end;gap:.6vw;margin-top:1.2vw}.lifecycle-links a{background:rgba(255,255,255,.1);border-radius:2vw;color:#fff;font-size:.7vw;padding:.45vw 1.5vw;text-decoration:none}.lifecycle-links a:before{content:'';display:inline-block;background:#ffe600;border-radius:50%;height:.45vw;margin-right:.7vw;width:.45vw}.mercury{background:#2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center/cover;padding:4vw 5vw 3vw;min-height:18vw}.mercury h2{color:#ffe600;font-size:2.5vw;font-weight:400;margin:0 0 .8vw}.mercury p{font-size:.8vw;line-height:1.5;margin:0 0 1.5vw}.mercury-links{display:flex;gap:.8vw}.mercury-links a{background:rgba(255,255,255,.1);color:#fff;display:flex;flex-direction:column;font-size:.7vw;padding:1vw;text-decoration:none;width:9vw}.mercury-links img{height:2vw;margin-bottom:.5vw;object-fit:contain;width:2vw}.footer{background:#000;padding:.8vw 2vw;text-align:right}.footer p{font-size:.7vw;margin:0}.policy-panel{align-items:center;background:rgba(0,0,0,.72);display:flex;inset:0;justify-content:center;padding:2vw;position:fixed;z-index:1000000}.policy-panel-content{background:#2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center/cover;max-height:90vh;max-width:42vw;overflow-y:auto;padding:3vw;position:relative;width:100%}.policy-panel-content h3{color:#ffe600;font-size:2vw;font-weight:400;margin:0 0 1.5vw}.policy-panel-content ul{margin:0;padding-left:1.2vw}.policy-panel-content li{font-size:1vw;line-height:1.5;margin-bottom:1vw}.policy-panel-content a{color:#ffe600;display:block;font-size:1vw;margin-top:1.5vw}.close-panel{background:#ffe600;border:0;cursor:pointer;font-size:1.5vw;height:2.2vw;position:absolute;right:1.5vw;top:1.5vw;width:2.2vw}\n@media(max-width:900px){.policy-nav{height:90px}.EYlogo{left:30px;top:20px;width:40px}.logoTxt{font-size:24px;left:90px;top:28px}.navbarMenu{right:25px;top:32px}.home{width:20px}.policy-hero{display:block;padding:0}.hero-copy{padding:35px 30px}.policy-hero h1{font-size:28px}.policy-card-grid{gap:25px}.policy-card img{width:45px}.policy-card p,.hero-intro{font-size:13px}.policy-card span,.policy-card b{font-size:16px}.hero-resources{display:grid;grid-template-columns:repeat(3,1fr)}.hero-resources a{font-size:11px;min-height:70px}.lifecycle{padding:40px 30px}.lifecycle h2{font-size:28px}.lifecycle>p{font-size:14px}.phase-label{font-size:11px}.step-map{grid-template-rows:repeat(2,110px);margin-top:20px}.step-number{font-size:14px;height:32px;width:32px}.step img{height:26px;width:30px}.step-label{font-size:10px}.lifecycle-links{justify-content:center}.lifecycle-links a{font-size:11px}.mercury{padding:40px 30px}.mercury h2{font-size:30px}.mercury p{font-size:14px}.mercury-links a{font-size:12px;width:130px}.footer p{font-size:11px}.policy-panel-content{max-width:90vw;padding:45px 25px 25px}.policy-panel-content h3{font-size:24px}.policy-panel-content li,.policy-panel-content a{font-size:14px}.close-panel{font-size:24px;height:32px;right:15px;top:15px;width:32px}}\n@media(max-width:600px){.logoTxt{font-size:19px;left:85px}.navbarMenu{right:15px}.policy-card-grid{grid-template-columns:1fr}.hero-resources{grid-template-columns:1fr 1fr}.hero-resources a{min-height:58px}.phase-labels{grid-template-columns:1fr}.phase-label{margin-top:8px}.step-map{display:grid;grid-template-columns:repeat(2,1fr);grid-template-rows:none;gap:8px;margin-top:20px}.step-map:before,.step-cell:after{display:none}.step-cell,.step-cell:nth-child(4n+1),.step-cell:nth-child(4n+2),.step-cell:nth-child(4n+3),.step-cell:nth-child(4n+4){grid-row:auto}.step-cell .step,.step-cell:nth-child(4n+1) .step,.step-cell:nth-child(4n+2) .step,.step-cell:nth-child(4n+3) .step,.step-cell:nth-child(4n+4) .step{transform:none}.step{background:rgba(255,230,0,.95);color:#000;display:grid;grid-template-columns:45px 1fr;min-height:70px;padding:8px;text-align:left}.step-number{grid-row:span 2;margin:auto}.step img{grid-column:2;height:23px;margin:0;width:25px}.step-label{font-size:11px;max-width:none;width:100%}.lifecycle-links{flex-wrap:wrap}.mercury-links{flex-wrap:wrap}.mercury-links a{width:120px}}\n.policies-page .logoTxt{font-size:2vw}.policies-page .navbarMenu li{font-size:1vw}.policies-page .policy-hero h1{color:#ffe600;font-size:3vw;line-height:3.4vw;margin:3vw 0 2vw}.policies-page .policy-card p{font-size:1vw;line-height:1.3vw}.policies-page .policy-card span,.policies-page .policy-card b{font-size:1.2vw}.policies-page .hero-intro{font-size:1vw;line-height:1.5vw}.policies-page .lifecycle h2,.policies-page .mercury h2{font-size:2.3vw}.policies-page .lifecycle>p{font-size:1vw}.policies-page .phase-label{font-size:1vw}.policies-page .step-label{font-size:1vw}.policies-page .mercury p{font-size:1vw}.policies-page .footer p{font-size:1vw}\n@media only screen and (max-width:1200px){.policies-page .policy-hero h1{font-size:40px;line-height:35px}.policies-page .policy-card p,.policies-page .hero-intro{font-size:16px;line-height:24px}.policies-page .policy-card span,.policies-page .policy-card b{font-size:16px}.policies-page .lifecycle h2,.policies-page .mercury h2{font-size:30px}.policies-page .lifecycle>p,.policies-page .phase-label,.policies-page .step-label{font-size:15px}.policies-page .mercury p{font-size:16px}.policies-page .footer p{font-size:13px}}\n@media only screen and (max-width:800px){.policies-page .EYlogo{left:60px;top:20px;width:40px}.policies-page .logoTxt{font-size:25px;left:130px;top:30px}.policies-page .navbarMenu{right:50px;top:31px}.policies-page .home{width:20px}.policies-page .policy-hero h1{font-size:40px;line-height:36px}.policies-page .policy-card p,.policies-page .hero-intro{font-size:15px;line-height:24px}.policies-page .policy-card span,.policies-page .policy-card b{font-size:18px}.policies-page .lifecycle h2,.policies-page .mercury h2{font-size:30px}.policies-page .lifecycle>p,.policies-page .phase-label,.policies-page .step-label{font-size:15px}.policies-page .mercury p{font-size:15px}.policies-page .footer p{font-size:13px}}\n@media only screen and (max-width:500px){.policies-page .logoTxt{font-size:20px;left:115px}.policies-page .EYlogo{left:30px}.policies-page .policy-hero h1{font-size:30px}.policies-page .policy-card p,.policies-page .hero-intro{font-size:14px;line-height:21px}.policies-page .policy-card span,.policies-page .policy-card b{font-size:16px}.policies-page .lifecycle h2,.policies-page .mercury h2{font-size:30px}}\n.policies-page .lifecycle{min-height:59vw;padding:4vw 8vw;overflow:hidden}.policies-page .step-map{display:block;height:45vw;margin-top:1vw;position:relative}.policies-page .step-map:before{display:none}.policies-page .step-cell{display:block;height:3vw;position:absolute;width:9vw}.policies-page .step-cell:nth-child(1){left:0;top:26vw}.policies-page .step-cell:nth-child(2){left:0;top:33vw}.policies-page .step-cell:nth-child(3){left:11vw;top:33vw}.policies-page .step-cell:nth-child(4){left:11vw;top:17vw}.policies-page .step-cell:nth-child(5){left:22vw;top:17vw}.policies-page .step-cell:nth-child(6){left:22vw;top:33vw}.policies-page .step-cell:nth-child(7){left:33vw;top:33vw}.policies-page .step-cell:nth-child(8){left:33vw;top:20vw}.policies-page .step-cell:nth-child(9){left:44vw;top:20vw}.policies-page .step-cell:nth-child(10){left:44vw;top:33vw}.policies-page .step-cell:nth-child(11){left:55vw;top:33vw}.policies-page .step-cell:nth-child(12){left:55vw;top:14vw}.policies-page .step-cell:nth-child(13){left:66vw;top:14vw}.policies-page .step-cell:nth-child(14){left:66vw;top:33vw}.policies-page .step-cell:nth-child(15){left:77vw;top:33vw}.policies-page .step-cell:nth-child(16){left:77vw;top:26vw}.policies-page .step-cell:after{display:none}.policies-page .step{height:3vw;position:static;width:3vw}.policies-page .step-number{font-size:1.5vw;height:3vw;padding-top:.3vw;width:3vw}.policies-page .step img{height:auto;margin:.5vw 0 0;width:3vw}.policies-page .step-label{font-size:1vw;left:0;line-height:1.2vw;max-width:9vw;position:absolute;text-align:left;top:4vw;width:9vw}.policies-page .step-cell:nth-child(odd) .step-label{top:-6vw}.policies-page .step-cell:nth-child(odd) .step img{position:absolute;top:-4vw}.policies-page .step-cell:nth-child(even) .step img{position:absolute;top:4vw}.policies-page .step-cell:nth-child(1) .step-label,.policies-page .step-cell:nth-child(3) .step-label,.policies-page .step-cell:nth-child(5) .step-label,.policies-page .step-cell:nth-child(7) .step-label,.policies-page .step-cell:nth-child(9) .step-label,.policies-page .step-cell:nth-child(11) .step-label,.policies-page .step-cell:nth-child(13) .step-label,.policies-page .step-cell:nth-child(15) .step-label{top:-6vw}.policies-page .connector{border-top:.15vw dashed #fff;position:absolute;transform-origin:left center}.policies-page .connector-0{left:1.5vw;top:34.5vw;width:9.5vw}.policies-page .connector-1{left:12.5vw;top:34.5vw;width:9.5vw}.policies-page .connector-2{left:23.5vw;top:34.5vw;width:9.5vw}.policies-page .connector-3{left:12.5vw;top:18.5vw;width:9.5vw}.policies-page .connector-4{left:23.5vw;top:18.5vw;width:9.5vw}.policies-page .connector-5{left:34.5vw;top:34.5vw;width:9.5vw}.policies-page .connector-6{left:34.5vw;top:21.5vw;width:9.5vw}.policies-page .connector-7{left:45.5vw;top:21.5vw;width:9.5vw}.policies-page .connector-8{left:45.5vw;top:34.5vw;width:9.5vw}.policies-page .connector-9{left:56.5vw;top:34.5vw;width:9.5vw}.policies-page .connector-10{left:56.5vw;top:15.5vw;width:9.5vw}.policies-page .connector-11{left:67.5vw;top:15.5vw;width:9.5vw}.policies-page .connector-12{left:67.5vw;top:34.5vw;width:9.5vw}.policies-page .connector-13{left:78.5vw;top:34.5vw;width:7vw}.policies-page .connector-14{left:79.5vw;top:29.5vw;height:7vw;width:0;transform:rotate(90deg)}.policies-page .lifecycle-links{margin-top:0}.policies-page .policy-panel{align-items:stretch;justify-content:flex-end;padding:0}.policies-page .policy-panel-content{height:100%;margin:0;max-height:none;max-width:35vw;padding:10vw 3vw 3vw;transform:translateX(0)}\n.policies-page .step-cell:nth-child(odd) .step-label,.policies-page .step-cell:nth-child(even) .step-label{top:4vw}.policies-page .step-cell:nth-child(4) .step-label,.policies-page .step-cell:nth-child(5) .step-label,.policies-page .step-cell:nth-child(8) .step-label,.policies-page .step-cell:nth-child(9) .step-label,.policies-page .step-cell:nth-child(12) .step-label,.policies-page .step-cell:nth-child(13) .step-label,.policies-page .step-cell:nth-child(16) .step-label{top:-6vw}.policies-page .step-cell:nth-child(odd) .step img,.policies-page .step-cell:nth-child(even) .step img{top:4vw}.policies-page .step-cell:nth-child(4) .step img,.policies-page .step-cell:nth-child(5) .step img,.policies-page .step-cell:nth-child(8) .step img,.policies-page .step-cell:nth-child(9) .step img,.policies-page .step-cell:nth-child(12) .step img,.policies-page .step-cell:nth-child(13) .step img,.policies-page .step-cell:nth-child(16) .step img{top:-4vw}.policies-page .panel-left{justify-content:flex-end}.policies-page .panel-right{justify-content:flex-start}.policies-page .panel-left .policy-panel-content{transform:translateX(0)}.policies-page .panel-right .policy-panel-content{transform:translateX(0)}\n@media only screen and (max-width:850px){.policies-page .step-map{display:flex;flex-wrap:wrap;gap:0;height:auto;margin-top:25px}.policies-page .step-map .connector{display:none}.policies-page .step-cell,.policies-page .step-cell:nth-child(n){height:auto;left:auto;top:auto;position:static;width:48%;margin:0 2% 10px 0}.policies-page .step-cell .step,.policies-page .step-cell:nth-child(n) .step{background:#ffe600;color:#000;display:grid;grid-template-columns:50px 1fr;height:auto;min-height:70px;padding:8px;text-align:left;transform:none;width:100%}.policies-page .step-cell .step-number{grid-row:span 2;margin:auto}.policies-page .step-cell .step img,.policies-page .step-cell:nth-child(n) .step img{grid-column:2;height:35px;margin:0;position:static;width:35px}.policies-page .step-cell .step-label,.policies-page .step-cell:nth-child(n) .step-label{font-size:18px;line-height:21px;max-width:none;position:static;width:auto}.policies-page .policy-panel-content{max-width:90vw;padding:40px 30px}.policies-page .policy-panel-content h3{font-size:19px}.policies-page .policy-panel-content li{font-size:12px}}\n.policies-page .webAnimation{background:#2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/wecast.png') center/cover;min-height:59vw;overflow:hidden;padding:4vw 8vw;position:relative}.policies-page .pg1{color:#fff;font-size:2.3vw;margin:0 0 .3vw;padding-top:0}.policies-page .pg2{color:#ffe600;font-size:1vw;margin:0}.policies-page .hrx{border-bottom:.2vw solid;float:left;color:#fff;font-size:1vw;margin:2vw 0 0;padding-bottom:.5vw;text-align:center}.policies-page .br1{border-color:#2db757;width:34vw}.policies-page .br2{border-color:#27acaa;margin-left:.4vw;margin-right:.4vw;width:21.6vw}.policies-page .br3{border-color:#188ce5;width:22vw}.policies-page .circlesTab{height:43vw;list-style:none;margin:0;padding:0;position:relative}.policies-page .circlesTab .subCircle{background:#ffe600;border:0;border-radius:50%;color:#000;cursor:pointer;font-size:1.5vw;height:3vw;line-height:2.4vw;padding:0;position:absolute;text-align:center;width:3vw;z-index:2;padding-top: 0.25vw;}.policies-page .circlesTab .subCircle:before{animation:ripple 1.5s ease-out infinite;background:inherit;border-radius:50%;content:'';height:100%;left:0;position:absolute;top:0;width:100%;z-index:-1}.policies-page .circlesTab .subCircle:hover{border:.4vw solid #fff;line-height:1.7vw}.policies-page .circle-c0{left:0;top:26vw}.policies-page .circle-c1{left:0;top:33vw}.policies-page .circle-c2{left:11vw;top:33vw}.policies-page .circle-c3{left:11vw;top:17vw}.policies-page .circle-c4{left:22vw;top:17vw}.policies-page .circle-c5{left:22vw;top:33vw}.policies-page .circle-c6{left:33vw;top:33vw}.policies-page .circle-c7{left:33vw;top:20vw}.policies-page .circle-c8{left:44vw;top:20vw}.policies-page .circle-c9{left:44vw;top:33vw}.policies-page .circle-c10{left:55vw;top:33vw}.policies-page .circle-c11{left:55vw;top:14vw}.policies-page .circle-c12{left:66vw;top:14vw}.policies-page .circle-c13{left:66vw;top:33vw}.policies-page .circle-c14{left:77vw;top:33vw}.policies-page .circle-c15{left:77vw;top:26vw}.policies-page .hrLine{border-top:.15vw dashed #fff;position:absolute;z-index:1}.policies-page .hr0{left:-2vw;top:30vw;transform:rotate(90deg);width:7vw}.policies-page .hr1{left:1.5vw;top:33.5vw;width:9vw}.policies-page .hr2{left:4.5vw;top:26vw;transform:rotate(90deg);width:16vw}.policies-page .hr3{left:12vw;top:17.5vw;width:12vw}.policies-page .hr4{left:15.5vw;top:26vw;transform:rotate(90deg);width:16vw}.policies-page .hr5{left:25vw;top:33.5vw;width:11vw}.policies-page .hr6{left:28.5vw;top:26vw;transform:rotate(90deg);width:12vw}.policies-page .hr7{left:34vw;top:20.5vw;width:11vw}.policies-page .hr8{left:39.5vw;top:27vw;transform:rotate(90deg);width:12vw}.policies-page .hr9{left:46vw;top:33.5vw;width:11vw}.policies-page .hr10{left:48vw;top:24vw;transform:rotate(90deg);width:17vw}.policies-page .hr11{left:57vw;top:14.5vw;width:11vw}.policies-page .hr12{left:59vw;top:24vw;transform:rotate(90deg);width:17vw}.policies-page .hr13{left:68vw;top:33.5vw;width:11vw}.policies-page .hr14{left:75vw;top:30vw;transform:rotate(90deg);width:7vw}.policies-page .Ctext{color:#fff;cursor:pointer;font-size:1vw;line-height:1.2vw;pointer-events:auto;position:absolute;text-align:left;width:9vw;z-index:1}.policies-page .Ctext img{display:block;padding-bottom:.5vw;width:3vw}.policies-page .p1{left:0;top:20vw}.policies-page .p2{left:0;top:37vw}.policies-page .p3{left:11vw;top:37vw}.policies-page .p4{left:11vw;top:11.5vw}.policies-page .p5{left:22vw;top:10.7vw}.policies-page .p6{left:22vw;top:37.2vw}.policies-page .p7{left:33vw;top:37vw}.policies-page .p8{left:33vw;top:14vw}.policies-page .p9{left:44vw;top:14vw;width:10vw}.policies-page .p10{left:44vw;top:37vw}.policies-page .p11{left:55vw;top:37.3vw}.policies-page .p12{left:55vw;top:9.3vw}.policies-page .p13{left:66vw;top:8.3vw;width:10vw}.policies-page .p14{left:66vw;top:37.1vw;width:8vw}.policies-page .p15{left:77vw;top:37.1vw;width:8vw}.policies-page .p16{left:77vw;top:20.5vw;width:8vw}.policies-page .overlayLeft,.policies-page .overlayRight{height:100%;position:absolute;top:0;transition:all 1s ease-in-out;width:35vw;z-index:5}.policies-page .overlayLeft{background:rgba(46,46,56,.9);right:-36vw}.policies-page .overlayRight{background:rgba(46,46,56,.9);left:-36vw}.policies-page .overlayLeft.active{right:0}.policies-page .overlayRight.active{left:0}.policies-page .inside{height:100%;left:0;opacity:0;overflow-y:auto;padding:10vw 3vw 3vw;position:absolute;top:0;transition:opacity 1s;visibility:hidden;width:100%;z-index:0}.policies-page .inside.active{opacity:1;visibility:visible;z-index:1}.policies-page .def-head{color:#ffe600;font-size:2vw;margin:0 0 1.4vw}.policies-page .definition{color:#fff;font-size:1vw;list-style:none;margin:0;padding:0}.policies-page .definition li{margin-bottom:1vw;padding-left:1vw;position:relative}.policies-page .definition li:before{color:#ffe600;content:'>';left:0;position:absolute}.policies-page .close_slide{background:#ffe600;cursor:pointer;font-size:1vw;font-weight:bold;height:2vw;left:-1vw;padding-top:.2vw;position:absolute;text-align:center;top:8vw;width:2vw;z-index:3}.policies-page .close_slide.c70{border-radius:0 .5vw 0 0;left:auto;right:-1vw}.policies-page .inside .minfo{color:#ffe600;display:block;font-size:.9vw;margin:1vw 0;text-decoration:underline}.policies-page .rows{bottom:2vw;left:0;padding:1vw 5vw;position:absolute;width:95%}.policies-page .bx-01{background:rgba(255,255,255,.09);border:1px solid rgba(255,255,255,.2);border-radius:5vw;float:right;margin:0 .4vw;position:relative;width:12vw}.policies-page .bx-01:before{background:#ffe600;border-radius:50%;content:'';height:.8vw;left:1.3vw;position:absolute;top:50%;transform:translate(-50%,-50%);width:.8vw}.policies-page .bx-01 .cb-box{min-height:auto;    padding: 0.6vw 1.5vw;}.policies-page .bx-01 p{color:#fff;font-size:1vw;line-height:1.3vw;margin:0;text-align:center}\n@keyframes ripple{from{opacity:1;transform:scale(0)}to{opacity:0;transform:scale(1.8)}}\n@media only screen and (max-width:850px){.policies-page .webAnimation{min-height:860px;padding:50px}.policies-page .pg1{font-size:25px}.policies-page .pg2{font-size:18px}.policies-page .hrx{display:none}.policies-page .circlesTab{height:auto}.policies-page .circlesTab .subCircle,.policies-page .hrLine{display:none}.policies-page .Ctext{background:#ffe600;color:#000;display:block;float:left;font-size:18px;line-height:21px;margin:0 2% 10px 0;min-height:60px;padding:8px 30px 0 65px;position:relative;top:auto!important;left:auto!important;width:48%}.policies-page .Ctext img{background:#2e2e38;height:100%;left:0;padding:17px 10px;position:absolute;top:0;width:50px}.policies-page .overlayLeft,.policies-page .overlayRight{height:100%;width:90%}.policies-page .overlayLeft{right:-110%}.policies-page .overlayRight{left:-110%}.policies-page .inside{padding:40px 30px}.policies-page .def-head{font-size:19px;line-height:20px}.policies-page .definition{font-size:12px}.policies-page .definition li{margin-bottom:10px;padding-left:15px}.policies-page .inside .minfo{font-size:12px}.policies-page .rows{bottom:auto;padding:10px;position:static;width:100%}.policies-page .bx-01{float:none;margin:10px;width:calc(100% - 20px)}.policies-page .bx-01 p{font-size:13px}}\n";
var PoliciesAndProcedures = function (_a) {
    var onShowHome = _a.onShowHome;
    var _b = react__WEBPACK_IMPORTED_MODULE_0__.useState(null), selectedStep = _b[0], setSelectedStep = _b[1];
    var _c = react__WEBPACK_IMPORTED_MODULE_0__.useState(true), isLoading = _c[0], setIsLoading = _c[1];
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
        var closeOnEscape = function (event) {
            if (event.key === 'Escape')
                setSelectedStep(null);
        };
        document.addEventListener('keydown', closeOnEscape);
        var loadingTimer = window.setTimeout(function () { return setIsLoading(false); }, 2000);
        return function () {
            document.removeEventListener('keydown', closeOnEscape);
            window.clearTimeout(loadingTimer);
        };
    }, []);
    var renderPanel = function (index, title) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "inside ins".concat(index).concat(selectedStep === index ? ' active' : ''), key: title },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "def-head" }, title),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "definition" }, stepDetails[index].map(function (detail) { return react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", { key: detail }, detail); })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: "minfo in-c4", href: resources[index % resources.length][1], target: "_blank", rel: "noreferrer" }, "View process guide"))); };
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "policies-page" },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("style", null, styles),
        isLoading && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "loading-container", "aria-label": "Loading" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("header", { className: "policy-nav" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "EYlogo", src: "".concat(imageRoot, "EY_logo.png"), alt: "EY logo" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "logoTxt" }, "MENA Tax Hub"),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "navbarMenu" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#home", onClick: function (event) { event.preventDefault(); onShowHome(); } },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "home", src: "".concat(imageRoot, "home.png"), alt: "Home" }))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "|")),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#lifecycle" }, "Engagement Lifecycle")))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("main", null,
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("section", { className: "policy-hero" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "hero-copy" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("h1", null, "Policies and procedures"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "policy-card-grid" }, policyCards.map(function (card) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("article", { className: "policy-card", key: card[1] },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(imageRoot).concat(card[0]), alt: "" }),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, card[1]),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("b", null, card[2]),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                            card[3]))); })),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "hero-intro" },
                        "Depending on the value and the characteristics of your engagement, the journey through the engagement lifecycle may differ:",
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Opportunities with a total higher opportunity value (TOV) are called \"standard\" and will pass through most steps."),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Smaller opportunities are called \"Lean\" and will not require as much information as the standard opportunity."),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Thresholds are determined locally.")))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("nav", { className: "hero-resources" }, resources.slice(0, 6).map(function (resource) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: resource[1], key: resource[0], target: "_blank", rel: "noreferrer" }, resource[0])); }))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("section", { className: "webAnimation", id: "lifecycle" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pg1" }, "Engagement Lifecycle Management - Policy Guidance"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pg2" }, "Click on each step to view more"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "br1 hrx" }, "Selling an opportunity (0-6)"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "br2 hrx" }, "Planning an engagement (7-10)"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "br3 hrx" }, "Delivering an engagement (11-15)"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "circlesTab" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#step-0", onClick: function (event) { return event.preventDefault(); } },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", { className: "circle-c0 subCircle onClickShow vf1", onClick: function () { return setSelectedStep(0); } }, "0"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "p1 Ctext onClickShow1", onClick: function () { return setSelectedStep(0); } },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(imageRoot, "Picture00.png"), alt: "" }),
                            "Create or maintain contacts")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("hr", { className: "hr0 hrLine" }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#step-1", onClick: function (event) { return event.preventDefault(); } },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", { className: "circle-c1 subCircle onClickShow vf1", onClick: function () { return setSelectedStep(1); } }, "1"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "p2 Ctext onClickShow1", onClick: function () { return setSelectedStep(1); } },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(imageRoot, "Picture01.png"), alt: "" }),
                            "Create opportunity")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("hr", { className: "hr1 hrLine" }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#step-2", onClick: function (event) { return event.preventDefault(); } },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", { className: "circle-c2 subCircle onClickShow vf1", onClick: function () { return setSelectedStep(2); } }, "2"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "p3 Ctext onClickShow1", onClick: function () { return setSelectedStep(2); } },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(imageRoot, "Picture02.png"), alt: "" }),
                            "Create Pricing Plan")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("hr", { className: "hr2 hrLine" }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#step-3", onClick: function (event) { return event.preventDefault(); } },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", { className: "circle-c3 subCircle onClickShow vf1", onClick: function () { return setSelectedStep(3); } }, "3"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "p4 Ctext onClickShow1", onClick: function () { return setSelectedStep(3); } },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(imageRoot, "Picture03.png"), alt: "" }),
                            "Perform Acceptance")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("hr", { className: "hr3 hrLine" }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#step-4", onClick: function (event) { return event.preventDefault(); } },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", { className: "circle-c4 subCircle onClickShow vf1", onClick: function () { return setSelectedStep(4); } }, "4"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "p5 Ctext onClickShow1", onClick: function () { return setSelectedStep(4); } },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(imageRoot, "Picture04.png"), alt: "" }),
                            "Update Pricing Plan")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("hr", { className: "hr4 hrLine" }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#step-5", onClick: function (event) { return event.preventDefault(); } },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", { className: "circle-c5 subCircle onClickShow vf1", onClick: function () { return setSelectedStep(5); } }, "5"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "p6 Ctext onClickShow1", onClick: function () { return setSelectedStep(5); } },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(imageRoot, "Picture05.png"), alt: "" }),
                            "Statement of Work (SOW) sign off and contract")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("hr", { className: "hr5 hrLine" }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#step-6", onClick: function (event) { return event.preventDefault(); } },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", { className: "circle-c6 subCircle onClickShow vf1", onClick: function () { return setSelectedStep(6); } }, "6"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "p7 Ctext onClickShow1", onClick: function () { return setSelectedStep(6); } },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(imageRoot, "Picture06.png"), alt: "" }),
                            "Update Opportunity details")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("hr", { className: "hr6 hrLine" }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#step-7", onClick: function (event) { return event.preventDefault(); } },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", { className: "circle-c7 subCircle onClickShow vf1", onClick: function () { return setSelectedStep(7); } }, "7"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "p8 Ctext onClickShow1", onClick: function () { return setSelectedStep(7); } },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(imageRoot, "Picture07.png"), alt: "" }),
                            "Create Engagement")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("hr", { className: "hr7 hrLine" }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#step-8", onClick: function (event) { return event.preventDefault(); } },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", { className: "circle-c8 subCircle onClickShow vf1 c70", onClick: function () { return setSelectedStep(8); } }, "8"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "p9 Ctext onClickShow1 c70", onClick: function () { return setSelectedStep(8); } },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(imageRoot, "Picture08.png"), alt: "" }),
                            "Create Engagement Budget")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("hr", { className: "hr8 hrLine" }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#step-9", onClick: function (event) { return event.preventDefault(); } },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", { className: "circle-c9 subCircle onClickShow vf1 c70", onClick: function () { return setSelectedStep(9); } }, "9"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "p10 Ctext onClickShow1 c70", onClick: function () { return setSelectedStep(9); } },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(imageRoot, "Picture09.png"), alt: "" }),
                            "Send Resource Request")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("hr", { className: "hr9 hrLine" }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#step-10", onClick: function (event) { return event.preventDefault(); } },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", { className: "circle-c10 subCircle onClickShow vf1 c70", onClick: function () { return setSelectedStep(10); } }, "10"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "p11 Ctext onClickShow1 c70", onClick: function () { return setSelectedStep(10); } },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(imageRoot, "Picture10.png"), alt: "" }),
                            "Schedule resources")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("hr", { className: "hr10 hrLine" }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#step-11", onClick: function (event) { return event.preventDefault(); } },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", { className: "circle-c11 subCircle onClickShow vf1 c70", onClick: function () { return setSelectedStep(11); } }, "11"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "p12 Ctext onClickShow1 c70", onClick: function () { return setSelectedStep(11); } },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(imageRoot, "Picture11.png"), alt: "" }),
                            "Charge T&E")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("hr", { className: "hr11 hrLine" }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#step-12", onClick: function (event) { return event.preventDefault(); } },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", { className: "circle-c12 subCircle onClickShow vf1 c70", onClick: function () { return setSelectedStep(12); } }, "12"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "p13 Ctext onClickShow1 c70", onClick: function () { return setSelectedStep(12); } },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(imageRoot, "Picture12.png"), alt: "" }),
                            "Perform Engagement economics")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("hr", { className: "hr12 hrLine" }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#step-13", onClick: function (event) { return event.preventDefault(); } },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", { className: "circle-c13 subCircle onClickShow vf1 c70", onClick: function () { return setSelectedStep(13); } }, "13"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "p14 Ctext onClickShow1 c70", onClick: function () { return setSelectedStep(13); } },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(imageRoot, "Picture13.png"), alt: "" }),
                            "Initiate or Perform billing")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("hr", { className: "hr13 hrLine" }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#step-14", onClick: function (event) { return event.preventDefault(); } },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", { className: "circle-c14 subCircle onClickShow vf1 c70", onClick: function () { return setSelectedStep(14); } }, "14"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "p15 Ctext onClickShow1 c70", onClick: function () { return setSelectedStep(14); } },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(imageRoot, "Picture14.png"), alt: "" }),
                            "Dunning and Collection")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("hr", { className: "hr14 hrLine" }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#step-15", onClick: function (event) { return event.preventDefault(); } },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", { className: "circle-c15 subCircle onClickShow vf1 c70", onClick: function () { return setSelectedStep(15); } }, "15"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "p16 Ctext onClickShow1 c70", onClick: function () { return setSelectedStep(15); } },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(imageRoot, "Picture15.png"), alt: "" }),
                            "Close Engagement"))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "overlayLeft".concat(selectedStep !== null && selectedStep < 8 ? ' active' : '') },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "close_slide", onClick: function () { return setSelectedStep(null); } }, "X"),
                    renderPanel(0, 'Create or maintain contacts'),
                    renderPanel(1, 'Create Opportunity'),
                    renderPanel(2, 'Create Pricing Plan'),
                    renderPanel(3, 'Perform Acceptance'),
                    renderPanel(4, 'Update pricing plan'),
                    renderPanel(5, 'Statement of Work (SOW) sign off and contract'),
                    renderPanel(6, 'Update opportunity details'),
                    renderPanel(7, 'Create Engagement')),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "overlayRight".concat(selectedStep !== null && selectedStep >= 8 ? ' active' : '') },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "close_slide c70", onClick: function () { return setSelectedStep(null); } }, "X"),
                    renderPanel(8, 'Create Engagement Budget'),
                    renderPanel(9, 'Send and schedule resource'),
                    renderPanel(10, 'Send and schedule resource'),
                    renderPanel(11, 'Charge T&E'),
                    renderPanel(12, 'Perform Engagement Economics'),
                    renderPanel(13, 'Initiate or perform billing'),
                    renderPanel(14, 'Collections'),
                    renderPanel(15, 'Close engagement')),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "rows" }, resources.slice(6, 9).map(function (resource) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "bx-01", key: resource[0] },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: resource[1], target: "_blank", rel: "noreferrer" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "cb-box" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, resource[0]))))); }))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("section", { className: "mercury" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("h2", null, "What is Mercury?"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "Mercury is an integrated SAP system, which enables us to become an even better connected and globally integrated organization. Mercury has already been deployed in 148 EY offices, capturing more than 75% of our global revenues."),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "mercury-links" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://web.microsoftstream.com/embed/video/28ad8a48-6df2-46af-b718-746434a4d2be?autoplay=false&showinfo=true", target: "_blank", rel: "noreferrer" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(imageRoot, "m1.png"), alt: "" }),
                        "Mercury Video"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/MercuryLearningCatalogue/SitePages/TypeProceduralGuides.aspx", target: "_blank", rel: "noreferrer" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "".concat(imageRoot, "m2.png"), alt: "" }),
                        "Procedural Guides")))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("footer", { className: "footer" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "\u00A9 2026 EYGM Limited. All rights reserved."))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PoliciesAndProcedures);


/***/ }),

/***/ 748:
/*!***************************************************!*\
  !*** ./lib/webparts/menaTaxHub/components/SSL.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

var SSL = function (_a) {
    var onShowHome = _a.onShowHome;
    var _b = react__WEBPACK_IMPORTED_MODULE_0__.useState('two'), activeTab = _b[0], setActiveTab = _b[1];
    var sslStyles = "\nhtml,body {\n  overflow-x: hidden !important;\n  font-family: EYInterstate;\n}\n::-moz-selection {\n  color: #ffffff;\n  background: #27ACAA;\n}\n::selection {\n  color: #ffffff;\n  background: #27ACAA;\n}\nbody::-webkit-scrollbar {\n  display: none;\n}\nbody {\n  -ms-overflow-style: none;\n  scrollbar-width: none;\n  position: relative;\n}\n.bannerBackground {\n  background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/banner.jpg);\n  background-color: #2e2e38;\n  background-size: 115% 115%;\n  background-position: center center;\n  position: relative;\n  background-attachment: fixed;\n  animation: shrink 20s infinite alternate;\n  padding: 0px;\n}\n.cf6 {\n  color: #ffffff;\n  width: 100%;\n  font-size: 1.5vw;\n  padding: 1vw 1vw;\n  margin-bottom: 0;\n}\n@keyframes shrink {\n  0% {\n    background-size: 115% 115%;\n  }\n  100% {\n    background-size: 100% 100%;\n  }\n}\n.nav-bar {\n  position: relative;\n  z-index: 999;\n  background: #2e2e38;\n  min-height: 6vw;\n  width: 100%;\n  margin: 0;\n}\n.nav-container {\n  padding: 0px;\n}\n.EYlogo {\n  width: 3vw;\n  position: absolute;\n  left: 5vw;\n  top: 1.5vw;\n}\np.logoTxt {\n  color: #ffffff;\n  font-size: 2vw;\n  position: absolute;\n  left: 11vw;\n  top: 2.2vw;\n}\nimg.home {\n  width: 1.3vw;\n}\nul.navbarMenu {\n  position: absolute;\n  right: 6vw;\n  top: 2.4vw;\n  font-family: EYInterstate;\n}\nul.navbarMenu li {\n  display: inline-block;\n  font-size: 1vw;\n  color: #ffffff;\n}\nul.navbarMenu li a {\n  color: #ffffff;\n  text-decoration: none;\n  padding: 0vw 2vw;\n}\n.boxContent span {\n  color: #ffe600;\n  font-size: 1.2vw;\n  margin-right: .3vw;\n  font-weight: bold;\n}\n.cnt-fdr {\n  padding: 2vw 5vw 2vw 3.5vw;\n  background: rgba(46, 46, 56, .5);\n  bottom: 0;\n  width: 100%;\n}\n.vh3 {\n  margin-top: 1.3vw;\n}\n.boxContent p {\n  color: #ffffff;\n  font-size: .9vw;\n  line-height: 1.3vw;\n  font-family: EYInterstate;\n  font-weight: lighter;\n}\n.boxContent p b {\n  font-size: 1.2vw;\n  line-height: 2.5vw;\n}\n.boxContent img {\n  width: 3vw;\n  margin-bottom: .4vw;\n}\np.c4 {\n  color: #ffffff;\n  font-size: 1.1vw;\n  font-family: EYInterstate;\n  line-height: 1.5vw;\n  margin-bottom: 1.3vw;\n}\nul.c5 {\n  color: #ffffff;\n  list-style: none;\n  padding: 0;\n}\nul.c5 li {\n  position: relative;\n  padding-left: 1.3vw;\n  margin-bottom: 0.6vw;\n  font-size: 1vw;\n}\nul.c5 li::before {\n  content: \"\";\n  background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/arrow_icon.png);\n  position: absolute;\n  width: .6vw;\n  height: .6vw;\n  background-size: contain;\n  background-repeat: no-repeat;\n  top: 0.5vw;\n  left: 0;\n}\n.footerTab {\n  background: #1a1a24;\n  padding: 5vw;\n}\na.qLInk {\n  color: #ffffff;\n  font-family: EYInterstate;\n  font-size: 1vw;\n  font-weight: lighter;\n  border: .1vw solid #9f9f9f;\n  padding: 0.5vw 1.6vw;\n  border-radius: .4vw;\n  margin-right: .7vw;\n  text-decoration: none;\n  float: left;\n  transition: all .2s ease-in-out;\n  margin-bottom: .8vw;\n}\na.qLInk:hover {\n  background: rgba(255, 255, 255, .2);\n}\n.quicklinks {\n  color: #ffffff;\n  font-size: 2vw;\n  margin-bottom: 2vw;\n}\nimg.qklinks {\n  width: 1.4vw;\n  margin-top: -0.2vw;\n  margin-right: .4vw;\n}\n.tabContent {\n  background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png);\n  background-position: center;\n  background-size: cover;\n  background-attachment: fixed;\n  background-color: #2e2e38;\n}\n.tabCol {\n  min-height: 10vw;\n}\n.nav-tabs .nav-link {\n  margin-bottom: 0vw;\n  border: hidden;\n  border-radius: 0px;\n  color: #ffffff !important;\n  font-size: 1.1vw;\n  font-family: EYInterstate;\n  font-weight: lighter;\n  border-right: .1vw solid #9e9e9e !important;\n  padding: 0.2vw 2.5vw;\n}\n.nav-tabs .nav-item.show .nav-link,\n.nav-tabs .nav-link.active {\n  color: #ffe600 !important;\n  background-color: transparent;\n}\n#myTab {\n  border-bottom: .1vw solid #7e7e7e;\n  padding-bottom: 1vw;\n  margin-bottom: 0px;\n}\n.tabCol {\n  min-height: 10vw;\n  padding: 4vw 6vw;\n}\np.tabTxt {\n  color: #ffffff;\n  font-size: 1vw;\n  line-height: 1.5vw;\n  margin-bottom: 0;\n}\n.cl-tx {\n  border-bottom: .01vw solid #ffffff61;\n  padding-bottom: 2vw;\n  margin-bottom: 2vw !important;\n}\np.tabTxt a {\n  color: #ffe600;\n  text-decoration: none;\n  font-weight: bold;\n}\nul.ul_01 li a {\n  color: #ffe600;\n  text-decoration: none;\n  font-weight: bold;\n}\n.tab-pane {\n  padding: 3vw 4vw !important;\n}\n.tabCol ul.ul_01 {\n  color: #ffffff;\n  font-size: 1vw;\n  list-style: none;\n  padding: 0;\n  margin: 0;\n  font-family: EYInterstate;\n  font-weight: lighter;\n}\n.tabCol ul.ul_02 {\n  color: #ffffff;\n  font-size: 1vw;\n  list-style: none;\n  padding: 0;\n  margin: 0;\n  font-family: EYInterstate;\n  font-weight: lighter;\n}\np.bt_7 {\n  color: #ffffff;\n  font-size: 2vw;\n  margin-bottom: 1vw;\n  margin-top: -1vw;\n}\n.tabCol ul.ul_01 li {\n  position: relative;\n  padding-left: 1.5vw;\n  margin-bottom: 1.7vw;\n}\n.tabCol ul.ul_02 li {\n  position: relative;\n  padding-left: 1.5vw;\n  margin-bottom: .7vw;\n}\n.tabCol ul.ul_01 li::before {\n  content: \"\";\n  background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/arrow_png.png);\n  position: absolute;\n  width: 0.7vw;\n  height: 0.6vw;\n  background-size: contain;\n  background-repeat: no-repeat;\n  margin-top: 0.4vw;\n  left: 0;\n}\n.tabCol ul.ul_02 li::before {\n  content: \"\";\n  background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/tick.png);\n  position: absolute;\n  width: 0.7vw;\n  height: 0.6vw;\n  background-size: contain;\n  background-repeat: no-repeat;\n  margin-top: 0.4vw;\n  left: 0;\n}\n.col_1 {\n  width: 20%;\n  background: rgba(255, 255, 255, .08);\n  color: #ffffff;\n  font-size: .9vw;\n  line-height: 1.3vw;\n  float: left;\n  border-right: .1vw solid #616161;\n}\n.col_1:last-child {\n  border-right: hidden;\n}\n.Hdline {\n  background: #1a1a24;\n  padding: 1.5vw;\n  min-height: 7vw;\n}\n.p-text {\n  padding: 1.5vw;\n  margin: 0;\n  min-height: 17vw;\n}\np.c8 {\n  color: #ffe600;\n  padding: 0vw 1.5vw;\n}\nul.c9 {\n  padding: 0vw 1.5vw 1.5vw 1.5vw;\n  list-style: none;\n  margin-bottom: 0;\n  min-height: 20vw;\n}\nul.c9 li {\n  position: relative;\n  padding-left: 1vw;\n  margin-bottom: 1vw;\n}\nul.c9 li::before {\n  content: \"\";\n  background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/arrow_png.png);\n  position: absolute;\n  width: 0.7vw;\n  height: 0.6vw;\n  background-size: contain;\n  background-repeat: no-repeat;\n  margin-top: 0.4vw;\n  left: 0;\n}\nimg.cf_img {\n  width: 100%;\n  height: 8vw;\n}\n.cf_head {\n  background: #747480;\n  padding: 0.6vw 0vw;\n  text-align: center;\n  color: #ffffff;\n  font-size: 1.2vw;\n  float: left;\n  width: 100%;\n}\nimg.proImg {\n  width: 5vw;\n  border-radius: 100vw;\n  float: left;\n  margin-right: 1vw;\n}\np.proName {\n  color: #ffffff;\n  font-size: 1vw;\n  margin-bottom: 0vw;\n  padding-top: 1.3vw;\n}\np.proDes {\n  color: #ffe600;\n  font-size: .9vw;\n  margin-bottom: 0;\n  margin-top: -.2vw;\n}\n.profileDetails {\n  float: left;\n  width: 100%;\n  margin-bottom: 2vw;\n}\nli.subList {\n  margin: 2vw 0vw !important;\n  font-size: 1.5vw !important;\n}\nli.subList::before {\n  display: none !important;\n}\n#Six-tab {\n  border-right: hidden !important;\n}\np.hder {\n  color: #ffffff;\n  padding-left: 1vw;\n  font-size: 1vw;\n  line-height: 1.5vw;\n  margin-bottom: 1vw;\n}\n.news_box {\n  float: left;\n  margin-right: 1.5vw;\n  background: rgba(255, 255, 255, .08);\n  width: 22%;\n  border: .01vw solid #444343;\n  border-radius: .2vw;\n  overflow: hidden;\n  margin-bottom: 20px;\n  min-height: 18vw;\n}\n.nws02.nsw a .news_box {\n  width: 100%;\n}\n.imgTile {\n  width: 100%;\n  height: 7vw;\n  background-size: cover;\n  background-position: center;\n}\n.newsHd {\n  color: #ffffff;\n  font-size: 2vw;\n  margin-bottom: 0.5vw;\n  margin-top: 3vw;\n}\nhr.newsHr {\n  margin-top: 0;\n  margin-bottom: 2vw;\n  border: 0;\n  border-top: 1px solid rgba(255, 255, 255, .64);\n  width: 4vw;\n}\n.Ntitle {\n  color: #ffe600;\n  margin-bottom: .5vw;\n  font-size: .9vw;\n}\n.Nsubtitle {\n  color: #ffe600;\n  font-size: 1vw;\n  margin-bottom: 0.6vw;\n  margin-top: -0.4vw;\n}\n.Ndes {\n  color: #ffffff;\n  font-size: .8vw;\n  line-height: 1.1vw;\n  margin-bottom: 0;\n}\n.Nread {\n  color: #ffffff;\n  font-size: .8vw;\n  font-style: italic;\n  margin: 0;\n  text-align: right;\n  margin-top: 0.4vw;\n  position: absolute;\n  right: 1vw;\n  bottom: 1vw;\n}\n.newsDes {\n  padding: 2vw 1vw;\n  position: relative;\n  min-height: 10vw;\n}\n.footer {\n  background-color: #000000;\n  float: left;\n  width: 100%;\n}\n.footer p {\n  margin-bottom: 0px;\n  color: #ffffff;\n  font-size: 1vw;\n  padding: 1vw 2vw;\n  text-align: right;\n}\n.txtTwo {\n  border-bottom: .01vw solid #ffffff61;\n  padding-bottom: 1vw;\n  margin-bottom: 2vw !important;\n}\n.navToggle {\n  display: none;\n}\n.cl-v1 {\n  background: #ffe600;\n  color: #000000 !important;\n  font-family: EYInterstate;\n  padding: 0.7vw 2vw;\n  float: right;\n  text-decoration: none !important;\n  font-size: .9vw;\n  position: relative;\n  z-index: 1;\n  margin-top: 5px;\n}\n.cl-v1 img {\n  width: 2vw;\n  margin-right: .6vw;\n}\n.u0 {\n  color: #ffe600 !important;\n}\n.u1 {\n  margin: 1vw 0vw !important;\n}\n.u2 li {\n  margin-bottom: .5vw !important;\n}\n.hotNews {\n  background: #ffe600;\n  width: 6vw;\n  margin-bottom: -1vw;\n  position: relative;\n  z-index: 1;\n  margin-left: 1vw;\n}\n.hotNews img {\n  width: 1.6vw;\n  padding: 0.2vw 0.1vw 0.3vw 0.5vw;\n}\n.hotNews span {\n  color: #000000;\n  font-size: .8vw;\n  padding: 0vw 0.3vw;\n}\n.table.table-bordered {\n  color: #ffffff;\n  margin-top: 2vw;\n}\n.table-bordered thead th {\n  color: #ffe600;\n  padding: 1vw 1.5vw;\n  font-size: 1.1vw;\n  line-height: 1.4vw;\n}\n.table-bordered.ty_7 thead th {\n  padding: 1vw 0vw;\n}\n.table-bordered tbody td {\n  padding: 0.7vw 1.5vw;\n  font-size: .9vw;\n}\n.table-bordered td,.table-bordered th,.table-bordered {\n  border: .01vw solid #474747 !important;\n}\ntable.table-bordered thead tr {\n  background-color: #1f2027;\n}\n.col_20 {\n  background-color: #1f2027;\n}\n.col_10 td ul {\n  list-style: none;\n  padding: 0px;\n  margin-top: 1vw;\n}\n.col_10 td ul li {\n  margin-bottom: .7vw !important;\n}\n.nws01 {\n  float: left;\n  width: 80%;\n  border-right: .1vw solid #8e8e8e;\n  padding-bottom: 2vw;\n}\n.nws02 {\n  float: left;\n  width: 20%;\n  padding-left: 2vw;\n}\na.cr7 {\n  text-decoration: none;\n  position: relative;\n}\n.news_1 {\n  background: rgba(255, 255, 255, 0.1);\n  padding: 1.5vw 1.5vw;\n  margin-top: 0;\n  margin-bottom: 1vw;\n  transition: all .2s ease-in-out;\n  padding-left: 10vw;\n  position: relative;\n  min-height: 8.4vw;\n}\n.fy7 {\n  background-image: url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/FSleader.png?csf=1&web=1&e=t2oWU0);\n  width: 8vw;\n  height: 84%;\n  position: absolute;\n  left: .8vw;\n  top: .8vw;\n  background-size: cover;\n  background-position: right;\n  opacity: 0.9;\n}\n.pr_txt {\n  color: #ffffff;\n  font-size: .9vw;\n  margin-bottom: .5vw;\n  margin-top: 1vw;\n  line-height: 1.2vw;\n  width: 100%;\n}\n.c4a7 {\n  color: #ffffff !important;\n  font-size: .9vw;\n  text-decoration: none !important;\n  margin-bottom: 0px;\n}\na.newClass {\n  color: #ffe600;\n  text-decoration: none;\n  font-weight: bold;\n  margin-top: 20px;\n  display: block;\n  margin-bottom: 12px;\n}\n@media only screen and (min-width: 641px) and (max-width: 1000px) {\n  .container_wrapper p,\n  .container_wrapper li,\n  .container_wrapper a,\n  .container_wrapper td,\n  .container_wrapper th,\n  .container_wrapper span,\n  .container_wrapper button {\n    font-size: 15px !important;\n    line-height: 1.45 !important;\n  }\n  .container_wrapper p.logoTxt { font-size: 25px !important; }\n  .container_wrapper .cf6,\n  .container_wrapper .quicklinks,\n  .container_wrapper .newsHd,\n  .container_wrapper p.bt_7 { font-size: 24px !important; line-height: 1.2 !important; }\n  .container_wrapper .nav-tabs .nav-link { font-size: 15px !important; padding: 8px 18px; }\n  .container_wrapper .table-bordered thead th { font-size: 16px !important; line-height: 1.35 !important; }\n  .container_wrapper .table-bordered tbody td { font-size: 15px !important; }\n  .container_wrapper .col_1 { width: 50%; }\n  .container_wrapper .news_box { width: 47%; margin-right: 2%; min-height: 260px; }\n  .container_wrapper .Ntitle { font-size: 16px !important; }\n  .container_wrapper .Ndes,\n  .container_wrapper .Nread,\n  .container_wrapper .pr_txt,\n  .container_wrapper .c4a7 { font-size: 14px !important; line-height: 1.4 !important; }\n  .container_wrapper .hotNews { width: auto; }\n  .container_wrapper .hotNews span { font-size: 14px !important; }\n}\n";
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("style", null, sslStyles),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "loading-container", style: { display: 'none' } },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container_wrapper", style: { display: 'block' } },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "webPart" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid nav-container" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row nav-bar" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "EYlogo", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/EY_logo.png", alt: "EY logo" }),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "logoTxt" }, "MENA Tax Hub"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "navbarMenu" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#", onClick: function (event) { event.preventDefault(); onShowHome(); } },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "home", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home.png", alt: "Home" })))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "navToggle", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/toggle.png", alt: "Toggle navigation" }))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 bannerBackground" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid cnt-fdr" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "cf6" }, "Tax Sub Service Lines (SSLs)"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "hder" }, "In Tax, we equip clients to make better business decisions by bringing insights to the forefront. We help companies understand the tax policies and tax laws of governments around the world to plan and comply accordingly. Our teams leverage transformative technologies to deliver strategy and execution, from tax and regulatory obligations to operations and workforce management, to reduce risk and drive sustainable value."),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-4 c57" })))))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid tabContent" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 tabCol" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "nav nav-tabs card-header-tabs", id: "myTab", role: "tablist" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", { className: "nav-item" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: activeTab === 'two' ? 'nav-link active' : 'nav-link', id: "two-tab", href: "#two", role: "tab", "aria-controls": "Two", "aria-selected": activeTab === 'two', onClick: function (event) {
                                            event.preventDefault();
                                            setActiveTab('two');
                                        } }, "GCR")),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", { className: "nav-item" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: activeTab === 'three' ? 'nav-link active' : 'nav-link', id: "three-tab", href: "#three", role: "tab", "aria-controls": "Three", "aria-selected": activeTab === 'three', onClick: function (event) {
                                            event.preventDefault();
                                            setActiveTab('three');
                                        } }, "Law")),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", { className: "nav-item" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: activeTab === 'four' ? 'nav-link active' : 'nav-link', id: "four-tab", href: "#four", role: "tab", "aria-controls": "four", "aria-selected": activeTab === 'four', onClick: function (event) {
                                            event.preventDefault();
                                            setActiveTab('four');
                                        } }, "IDT")),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", { className: "nav-item" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: activeTab === 'five' ? 'nav-link active' : 'nav-link', id: "five-tab", href: "#five", role: "tab", "aria-controls": "Five", "aria-selected": activeTab === 'five', onClick: function (event) {
                                            event.preventDefault();
                                            setActiveTab('five');
                                        } }, "ITTS")),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", { className: "nav-item" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: activeTab === 'six' ? 'nav-link l1 active' : 'nav-link l1', id: "Six-tab", href: "#six", role: "tab", "aria-controls": "Six", "aria-selected": activeTab === 'six', onClick: function (event) {
                                            event.preventDefault();
                                            setActiveTab('six');
                                        } }, "PAS"))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "tab-content", id: "myTabContent" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: activeTab === 'two' ? 'tab-pane fade show active p-3' : 'tab-pane fade p-3', id: "two", role: "tabpanel", "aria-labelledby": "two-tab" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bt_7" }, "Global Compliance and Reporting (GCR)"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDetails" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Ahmed%20Aboelfotouh.jpg", className: "proImg", alt: "Ahmed Aboelfotouh" }),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "proName" }, "Ahmed Aboelfotouh"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "proDes" }, "MENA GCR Leader")),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt" },
                                        "Global Compliance and Reporting (GCR) represents an integrated service offering, drawing on competencies across our practice to become the outsourcing answer to our clients' compliance and reporting challenges around the world. Whether we are delivering in a single country or worldwide, our standardized approach across the ",
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/DS_Tax/GCR/Pages/Home.aspx", target: "_blank", rel: "noreferrer" }, "Record to Report (R2R)"),
                                        " cycle achieves efficiencies for our clients and identifies other EY opportunities.",
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/DS_Tax/GCR/Pages/Home.aspx", target: "_blank", rel: "noreferrer" }, "Visit the Discover GCR site to know more."),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null)),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "ul_01" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/DS_Tax/GCR/Pages/accounting-compliance-and-reporting.aspx", target: "_blank", rel: "noreferrer" }, "Accounting Compliance and Reporting (ACR)")),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/DS_Tax/GCR/Pages/direct-tax-compliance.aspx", target: "_blank", rel: "noreferrer" }, "Business Tax Compliance (BTC)")),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/DS_Tax/GCR/Pages/global-operations.aspx", target: "_blank", rel: "noreferrer" }, "GCR Global Operations")),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/DS_Tax/GCR/Pages/indirect-tax-compliance.aspx", target: "_blank", rel: "noreferrer" }, "Indirect Tax Compliance")),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/DS_Tax/GCR/Pages/tax-accounting-and-risk-advisory-services.aspx", target: "_blank", rel: "noreferrer" }, "Tax Accounting and Risk Advisory Services (TARAS)")),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/DS_Tax/BTS/Pages/global-customer-tax-operations-and-reporting-ctors.aspx", target: "_blank", rel: "noreferrer" }, "Global Customer Tax Operations and Reporting (CTORS)")),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/DS_Tax/BTS/Pages/ey-private-tax.aspx", target: "_blank", rel: "noreferrer" }, "EY Private Tax")),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/DS_Tax/BTS/Pages/quantitative-services.aspx", target: "_blank", rel: "noreferrer" }, "Quantitative Services (QS)")))),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: activeTab === 'three' ? 'tab-pane fade show active p-3' : 'tab-pane fade p-3', id: "three", role: "tabpanel", "aria-labelledby": "three-tab" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bt_7" }, "Law"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDetails" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/law.png", className: "proImg", alt: "Law team" }),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "proName" }, "Chris P. Sioufi"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "proDes" }, "MENA Law Leader")),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt txtTwo" },
                                        "The EY MENA Law team are a team of lawyers who together have decades of experience and multinational legal qualifications. The team is led by Chris P. Sioufi, a leading corporate and finance transactional lawyer with over 25 years' experience.",
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        "EY MENA Law services include transaction law (corporate/M&A), commercial law, entity compliance & governance, digital & data privacy, financial services and energy and infrastructure.",
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        "The team can and has advised on a large range of corporate transactions including M&A, private equity, structured finance and Islamic finance matters as well as several advisory mandates, market entry analyses, digital law and data protection advice. The team also boasts experienced regulatory and energy lawyers with years of experience in their field. The team has advised on private and public corporate and financial transactions totaling billions of dollars including a number of high-profile deals in the MENA region. Members of the team have been consistently recognised by leading publications which highlight their regional practice and expertise.",
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        "The EY MENA Law team understands the increasingly complex regulatory frameworks and corporate compliance laws and regulations of this global economy. The team has a strong local knowledge of the laws and regulations of a number of jurisdictions within MENA, including the United Arab Emirates and the Kingdom of Saudi Arabia but has also familiarity of the different legal systems across the MENA region and regularly manages multi-jurisdiction transactions. It also has a close network of advisors throughout the MENA region who can support on technical local aspects of transactions in the region.",
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        "Our lawyers have an entrepreneurial, innovative and solution-based approach that has earned us an outstanding reputation in the market. We understand that legal solutions must, above all, be practical solutions for our clients focusing on our clients' objectives.",
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        "The EY MENA Law team works alongside other EY professionals, including tax, transactions, consulting and advisory. Serving you across borders. EY's sector-focused, multidisciplinary approach means EY MENA Law can offer integrated, broad and pertinent advice you can trust. EY MENA Law has access to the international EY Law network of legal practices affiliated to EY. The EY Law network currently consists of 3,500+ qualified legal professionals in 90 countries. EY Law has a truly global footprint."),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "ul_01" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", { className: "subList" }, "Our services"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: "u0" }, "Corporate/M&A"),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt u1" }, "Help companies grow their market share, expanding into new geographies, or support for carve-outs and divestitures to streamline client's portfolio."),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "ul_01 u2" },
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Mid-market M&A transactions"),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Private equity and joint venture transactions"),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Stand alone buy or sell side legal due diligence"),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Pre and post transaction reorganizations"),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Pre and post transaction integration"),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Joint ventures"),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Regulatory authorizations: multi-jurisdictional merger control analysis"))),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: "u0" }, "Commercial"),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt u1" }, "Help companies confidently cover the range of issues that may arise in a single corporate transaction and make the most of today's business opportunities."),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "ul_01 u2" },
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Company law and commercial law"),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Commercial contracts"),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Corporate governance"),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Restructuring"),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Legal entity rationalization"),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Operating model effectiveness"))),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: "u0" }, "Entity, Compliance & Governance (ECG)"),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt u1" }, "Help multinational clients with corporate regulatory advice and practical assistance with establishing a presence in the chosen jurisdiction."),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "ul_01 u2" },
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Market entry report"),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Implementation and set up assistance"),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Annual and ongoing compliance services"))),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: "u0" }, "Financial services"),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt u1" }, "Help multinational financial sector to comply with ongoing regulatory changes globally and address challenges relating to developing disruptive technologies."),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "ul_01 u2" },
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Corporate finance (ordinary, structured and special financing, through bank lending and debt securities)"),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Incorporation, expansion, reorganization and branch registration for financial institutions"),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Regulatory compliance for financial Institutions"),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Banking and Finance (including Islamic Finance)"),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Banking and financial regulations")),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt u1", style: { fontWeight: 'bolder', fontSize: '1.1vw' } }, "Capability"),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt u1" }, "The Financial Services Team at EY Law (FS Law Team) provides legal assistance to private and public clients across the following markets on matters linked to the MENA Region:"),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt u1", style: { fontWeight: 'bolder', fontSize: '1.1vw' } }, "Markets"),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("table", { className: "table table-bordered ts_7 ty_7" },
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("thead", null,
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", { style: { textAlign: 'center' } },
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", { scope: "col", style: { verticalAlign: 'middle' } }),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", { scope: "col", style: { verticalAlign: 'middle' } }, "Banking & Finance"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", { scope: "col", style: { verticalAlign: 'middle' } }, "Capital Markets"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", { scope: "col", style: { verticalAlign: 'middle' } }, "Wealth & Asset Management"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", { scope: "col", style: { verticalAlign: 'middle' } }, "Insurance"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", { scope: "col", style: { verticalAlign: 'middle' } }, "Fintech"))),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("tbody", null,
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", { className: "col_10" },
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { style: { verticalAlign: 'middle' } }, "Clients"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { style: { verticalAlign: 'middle' } }, "Corporate borrowers, banks, finance companies, central banks"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { style: { verticalAlign: 'middle' } }, "Issuers, arrangers, placement managers and intermediaries, financial services authorities and stock exchanges"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { style: { verticalAlign: 'middle' } }, "Sovereign/Government funds, investment funds, investment managers, asset managers, investors and asset owners"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { style: { verticalAlign: 'middle' } }, "Insurance and reinsurance companies"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { style: { verticalAlign: 'middle' } }, "Tech companies, financial institutions, JVs, investment and asset managers.")),
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", { className: "col_20" },
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { style: { verticalAlign: 'middle' } }, "Matters"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { style: { verticalAlign: 'middle' } }, "Corporate finance, Project and asset finance, trade finance; Payment services, cash pooling and treasury centers; Investment banking; ESG Financing; Public finance"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { style: { verticalAlign: 'middle' } }, "Debt, equity and hybrid securities offering, placement and listing; Debt restructuring and liability management; Capital markets readiness"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { style: { verticalAlign: 'middle' } }, "Public, Exempt and QI funds; Alternative Investment Management; ESG Investment"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { style: { verticalAlign: 'middle' } }, "Life and Non-life insurance; Credit insurance; Investment policies and unit-linked policies; JVs and outsourcing"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { style: { verticalAlign: 'middle' } }, "Virtual assets; Digital banking and investment; Crypto currencies and Central Bank Digital Currencies")))),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt u1", style: { fontWeight: 'bolder', fontSize: '1.1vw' } }, "Services"),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt u1" }, "In the above market context, the FS Law Team offers its main legal services in the below areas on a stand-alone basis or on an integrated, multi-disciplinary basis, together with EY Strategy and Transactions, EY Consulting and EY Tax. In specific circumstances, the FS Law Team can plug-in subject matter experts within the EY network on specific business and operational propositions, as a project may require."),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("table", { className: "table table-bordered ts_7 ty_7" },
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("thead", null,
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", { style: { textAlign: 'center' } },
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", { scope: "col", style: { verticalAlign: 'middle' } },
                                                            "Legal and Regulatory",
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                                            "Advice"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", { scope: "col", style: { verticalAlign: 'middle' } },
                                                            "Transactions and Legal ",
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                                            "Documentation"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", { scope: "col", style: { verticalAlign: 'middle' } },
                                                            "Entity Compliance",
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                                            "and Governance"),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", { scope: "col", style: { verticalAlign: 'middle' } },
                                                            "Product Structuring",
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                                            "and Review"))),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("tbody", null,
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", { className: "col_10" },
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                                                            "Regulatory roadmaps and analysis on:",
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", null,
                                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Business transformation (single and multi-jurisdiction);"),
                                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Intragroup operability;"),
                                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Investment and asset management structuring;"),
                                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Cross-border activities (through permanent establishments or not);"),
                                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "ESG financing and investment compliance and implementation.Legal and regulatory risk assessment and opinions."))),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", null,
                                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Transactional due diligence;"),
                                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Draft, review, negotiation and execution of contractual and disclosure documents and internal authorization documents;"),
                                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Legal opinions for internal (e.g., BoDs) and external (e.g., lenders, investors, regulatory and rating agencies) use."))),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", null,
                                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Incorporation and licensing (onshore/free zones) of financial and investment entities, branches;"),
                                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Investment fund registration; Passporting advice;"),
                                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Market entry guidelines and jurisdictional comparison;"),
                                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Entities relocation and reorganization; Dealing with regulatory authorities."))),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", null,
                                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Regulatory review and advice;"),
                                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Drafting and reviewing legal and disclosure templates and guidelines;"),
                                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Assistance with approvals of new products by BoDs;"),
                                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Legal and regulatory risk assessment and opinions.")))))),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "nws01 nsw" },
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "newsHd" }, "Newsletters"),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("hr", { className: "newsHr" }),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/Newsletter/Law%20Edition%2018.pdf", target: "_blank", rel: "noreferrer", style: { textDecoration: 'none' } },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "news_box" },
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgTile", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' } }),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "newsDes" },
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ntitle" }, "Edition-18"),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ndes" }, "Welcome to the Eighteenth edition of 'To The Point', the internal MENA Law Team Newsletter."),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Nread" }, "READ MORE")))),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/Newsletter/Law%20Edition%2017.pdf", target: "_blank", rel: "noreferrer", style: { textDecoration: 'none' } },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "news_box" },
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgTile", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' } }),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "newsDes" },
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ntitle" }, "Edition-17"),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ndes" }, "Welcome to the Seventeenth edition of 'To The Point', the internal MENA Law Team Newsletter."),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Nread" }, "READ MORE")))),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/Newsletter/Law_edition%2015.pdf", target: "_blank", rel: "noreferrer", style: { textDecoration: 'none' } },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "news_box" },
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgTile", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' } }),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "newsDes" },
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ntitle" }, "Edition-15"),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ndes" }, "Welcome to the fifteenth edition of 'To The Point', the internal MENA Law Team Newsletter."),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Nread" }, "READ MORE")))),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/Newsletter/Law_edition%2014.pdf", target: "_blank", rel: "noreferrer", style: { textDecoration: 'none' } },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "news_box" },
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgTile", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' } }),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "newsDes" },
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ntitle" }, "Edition-14"),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ndes" }, "Welcome to the fourteenth edition of 'To The Point', the internal MENA Law Team Newsletter."),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Nread" }, "READ MORE")))),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/Newsletter/To%20The%20Point%20-%20Edition%2013.pdf", target: "_blank", rel: "noreferrer", style: { textDecoration: 'none' } },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "news_box" },
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgTile", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' } }),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "newsDes" },
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ntitle" }, "Edition-13"),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ndes" }, "Welcome to the thirteenth edition of 'To The Point', the internal MENA Law Team Newsletter."),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Nread" }, "READ MORE")))),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/Newsletter/To%20The%20Point%20-%20Edition%2012.pdf", target: "_blank", rel: "noreferrer", style: { textDecoration: 'none' } },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "news_box" },
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgTile", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' } }),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "newsDes" },
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ntitle" }, "Edition-12"),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ndes" }, "Welcome to the twelveth edition of 'To The Point', the internal MENA Law Team Newsletter."),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Nread" }, "READ MORE")))),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/Newsletter/To%20the%20point-edition-11.pdf", target: "_blank", rel: "noreferrer", style: { textDecoration: 'none' } },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "news_box" },
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgTile", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' } }),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "newsDes" },
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ntitle" }, "Edition-11"),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ndes" }, "Welcome to the eleventh edition of 'To The Point', the internal MENA Law Team Newsletter."),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Nread" }, "READ MORE")))),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/To-the-point-editon-10.pdf", target: "_blank", rel: "noreferrer", style: { textDecoration: 'none' } },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "news_box" },
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgTile", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' } }),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "newsDes" },
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ntitle" }, "Edition-10"),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ndes" }, "Welcome to the tenth edition of 'To The Point', the internal MENA Law Team Newsletter."),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Nread" }, "READ MORE")))),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/To-the-point-editon-9.pdf", target: "_blank", rel: "noreferrer", style: { textDecoration: 'none' } },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "news_box" },
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgTile", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' } }),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "newsDes" },
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ntitle" }, "Edition-09"),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ndes" }, "Welcome to the ninth edition of 'To The Point', the internal MENA Law Team Newsletter."),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Nread" }, "READ MORE")))),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/Newsletter/To%20the%20Point%20Edition%208.pdf", target: "_blank", rel: "noreferrer", style: { textDecoration: 'none' } },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "news_box" },
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgTile", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' } }),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "newsDes" },
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ntitle" }, "Edition-08"),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ndes" }, "Welcome to the eighth edition of 'To The Point', the internal MENA Law Team Newsletter."),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Nread" }, "READ MORE")))),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/To%20the%20Point%20Edition%207.pdf", target: "_blank", rel: "noreferrer", style: { textDecoration: 'none' } },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "news_box" },
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgTile", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' } }),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "newsDes" },
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ntitle" }, "Edition-07"),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ndes" }, "Welcome to the seventh edition of 'To The Point', the internal MENA Law Team Newsletter."),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Nread" }, "READ MORE")))),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/To%20the%20Point%20Edition%206.pdf", target: "_blank", rel: "noreferrer", style: { textDecoration: 'none' } },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "news_box" },
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgTile", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' } }),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "newsDes" },
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ntitle" }, "Edition-06"),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ndes" }, "Welcome to the sixth edition of 'To The Point', the internal MENA Law Team Newsletter."),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Nread" }, "READ MORE")))),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/To-The-Point-Edition-5.pdf", target: "_blank", rel: "noreferrer", style: { textDecoration: 'none' } },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "news_box" },
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgTile", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' } }),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "newsDes" },
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ntitle" }, "Edition-05"),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ndes" }, "Welcome to the fifth edition of 'To The Point', the internal MENA Law Team Newsletter."),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Nread" }, "READ MORE")))),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/To-The-Point-Edition-4.pdf", target: "_blank", rel: "noreferrer", style: { textDecoration: 'none' } },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "news_box" },
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgTile", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' } }),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "newsDes" },
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ntitle" }, "Edition-04"),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ndes" }, "Welcome to the fourth edition of 'To The Point', the internal MENA Law Team Newsletter."),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Nread" }, "READ MORE")))),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/To-The-Point-Edition-3.pdf", target: "_blank", rel: "noreferrer", style: { textDecoration: 'none' } },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "news_box" },
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgTile", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' } }),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "newsDes" },
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ntitle" }, "Edition-03"),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ndes" }, "Welcome to the third edition of 'To The Point', the internal MENA Law Team Newsletter."),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Nread" }, "READ MORE")))),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/MENA_Law_Team_Newsletter-02.pdf", target: "_blank", rel: "noreferrer", style: { textDecoration: 'none' } },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "news_box" },
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgTile", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' } }),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "newsDes" },
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ntitle" }, "Edition-02"),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ndes" }, "Welcome to the second edition of 'To The Point', the internal MENA Law Team Newsletter."),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Nread" }, "READ MORE")))),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/images/Dear%20All.pdf", target: "_blank", rel: "noreferrer", style: { textDecoration: 'none' } },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "news_box" },
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgTile", style: { backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/news1.jpg)' } }),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "newsDes" },
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ntitle" }, "Edition-01"),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ndes" }, "Welcome to 'To The Point', our first edition of the internal MENA Law Team Newsletter."),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Nread" }, "READ MORE"))))),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "nws02 nsw" },
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "newsHd" }, "LT updates"),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("hr", { className: "newsHr" }),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/MENATaxHub/Newsletter/New%20MENA%20Law%20FS%20Leader.pdf", target: "_blank", rel: "noreferrer" },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "news_box" },
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "imgTile", style: {
                                                                backgroundImage: 'url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/FSleader_.png)',
                                                            } }),
                                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "newsDes" },
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ntitle", style: { visibility: 'hidden' } }, "Edition-01"),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Ndes" }, "New MENA Law FS Leader"),
                                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "Nread" }, "READ MORE")))))))),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: activeTab === 'four' ? 'tab-pane fade show active p-3' : 'tab-pane fade p-3', id: "four", role: "tabpanel", "aria-labelledby": "four-tab" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bt_7" }, "Indirect Tax (IDT)"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDetails" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Mohammed%20Bilal%20Akram.jpg", className: "proImg", alt: "Mohammed Bilal Akram" }),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "proName" }, "Mohammed Bilal Akram"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "proDes" }, "MENA IDT Leader")),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt" },
                                        "Indirect taxes affect the supply chain and the financial system of companies. Our network combines technical knowledge with industry understanding and access to technologically advanced tools and methodologies. We identify risk areas and sustainable planning opportunities for indirect taxes throughout the tax life cycle, helping clients meet their compliance obligations and business goals around the world. ",
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/DS_Tax/IndirectTax/Pages/Home.aspx", target: "_blank", rel: "noreferrer" }, "Visit the Discover Global Indirect site to know more.")),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "ul_01" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/DS_Tax/IndirectTax/Pages/vatgst.aspx", target: "_blank", rel: "noreferrer" }, "Value-added tax (VAT)")),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/DS_Tax/IndirectTax/Pages/global-trade.aspx", target: "_blank", rel: "noreferrer" }, "Global Trade")),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/DS_Tax/IndirectTax/Pages/excise-taxes.aspx", target: "_blank", rel: "noreferrer" }, "Excise taxes")),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#" }, "Sustainability tax")))),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: activeTab === 'five' ? 'tab-pane fade show active p-3' : 'tab-pane fade p-3', id: "five", role: "tabpanel", "aria-labelledby": "five-tab" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bt_7" }, "International Tax & Transaction Services (ITTS)"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDetails" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Rajan%20Parmar.png", className: "proImg", alt: "Rajan Parmar" }),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "proName" }, "Rajan Parmar"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "proDes" }, "MENA ITTS Leader")),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/DS_Tax/Pages/international-tax-transaction-services.aspx", target: "_blank", rel: "noreferrer" }, "International Tax and Transaction Services (ITTS)"),
                                        "is comprised of three competencies: International Corporate Tax Advisory (ICTA), Transaction Tax Advisory (TTA) and Transfer Pricing (TP). Our practice helps financial sponsors, private capital enterprises and multinational corporations proactively address challenges by bringing globally connected services to all tax aspects of their business and investment models, corporate structure, treasury management and overall tax and transaction strategy. This encompasses the client's full transaction life cycle, from strategy and corporate finance, through to acquisition, optimization and eventual disposal.",
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        "The ITTS go-to-market approach is organized around five global services pillars. Our teams are organized and deployed globally, they aim to create innovative and saleable content and to support you in tailoring, and where relevant delivering, these offerings to your clients.",
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/DS_Tax/Pages/international-tax-transaction-services.aspx", target: "_blank", rel: "noreferrer" }, "Visit the Discover ITTS site to know more.")),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/DS_Tax/BTS/Pages/business-tax-advisory.aspx", className: "newClass", target: "_blank", rel: "noreferrer" }, "Corporate Tax Advisory (CTA)"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt" }, "CTA advises clients on a broad range of tax planning and advisory matters based on both in-country tax technical knowledge and sector insights. It helps corporations, partnerships, joint ventures and other business entities to build sustainable tax strategies in order to achieve their full potential. This can include day-to-day domestic tax advice, as well as project work on a variety of aspects across a client's tax life cycle."),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/DS_Tax/BTS/Pages/global-tax-controversy.aspx", className: "newClass", target: "_blank", rel: "noreferrer" }, "Tax Controversy (TC)"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt" },
                                        "In an increasingly interconnected global tax environment, Tax Controversy helps companies address multi-dimensional, multi-country tax issues and keep up with the latest regulatory and technology developments, maintaining a focus on compliance and risk management. Organizations that want to manage current and future tax disputes effectively need to make investments - in people, processes and technology - now.",
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        "The ",
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/DS_Tax_BTS/Pages/tax-controversy-department-of-the-future.aspx", target: "_blank", rel: "noreferrer" }, "Tax Controversy Department of the Future"),
                                        "can help them do just that, identifying leading practices, gathered through intense research and collective experience, across every area of the tax controversy management lifecycle."),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: "newClass", href: "https://sites.ey.com/sites/DS_Tax/BTS/Pages/ey-private-tax.aspx", target: "_blank", rel: "noreferrer" }, "EY Private Tax"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt" }, "EY Private Tax takes an integrated and global approach in delivering a range of tax and advisory services to private owners, their families and their businesses, private equity and asset management stakeholders and high-net-worth individuals. We support Private Tax clients with speciality services that are \"designed for Private\" including Private Business tax advisory and compliance services, family office advisory services, and wealth transition and succession planning."),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { style: { marginBottom: '5vw', marginRight: '0.4vw' } },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://eyus.sharepoint.com/sites/Navigate-ITTS-Global", target: "_blank", rel: "noreferrer", className: "cl-v1" },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/icon-png.png", className: "info-img", alt: "Icon" }),
                                            "Navigate to ITTS Global")),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "cf_head" }, "Five Global Services Pillars"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "tableSection" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col_1" },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "Hdline" }, "IP Alignment, Operating Model and Supply Chain"),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "cnt-sec" },
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "p-text" }, "Integrates Tax (indirect and direct), Transaction, Advisory and other service lines for supply chain and operating model effectiveness."),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "c8" },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", null, "Service offerings")),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "c9" },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Operating model effectiveness (OME)/ Supply chain"),
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "IP alignment and industry convergence (IAIC)"),
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Permanent establishment management")))),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col_1" },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "Hdline" }, "Corporate Structure"),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "cnt-sec" },
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "p-text" }, "Provides advice on the tax implications of global legal structure, internal restructuring and third-party transaction structuring."),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "c8" },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", null, "Service offerings")),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "c9" },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Holding, Finance and SPV Structuring"),
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Internal corporate restructuring"),
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Legal entity rationalization")))),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col_1" },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "Hdline" }, "Global Treasury"),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "cnt-sec" },
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "p-text" }, "Brings tax efficiency to treasury goals, including capital structure planning, internal financing of domestic or cross-border activities."),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "c8" },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", null, "Service offerings")),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "c9" },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Cross border risk management"),
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Liquidity management"),
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Bankruptcy and distressed debt restructuring (Reshaping Results)"),
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Cross border capital structure planning"),
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Transfer pricing for global treasury")))),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col_1" },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "Hdline" }, "Transaction Advisory"),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "cnt-sec" },
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "p-text" }, "Serves corporate and private capital markets clients undertaking third-party transactions in tax diligence, general transaction advisory and overall transaction project management."),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "c8" },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", null, "Service offerings")),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "c9" },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Bankruptcy and distressed debt restructuring (Reshaping Results)"),
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Buy-side and sell-side diligence"),
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Private equity"),
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Buy & Integrate"),
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Sell & Separate")))),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col_1" },
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "Hdline" }, "Tax Operations"),
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "cnt-sec" },
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "p-text" }, "Provides assistance to multinational corporations with cross border controversy, policy related matters, international tax compliance and quantitative decision support as well as transfer pricing documentation."),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "c8" },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", null, "Service offerings")),
                                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "c9" },
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Transfer pricing documentation and transparency"),
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Cross-border controversy"),
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "International Tax policy"),
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Quantitative decision support"),
                                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Inter-company effectiveness")))))),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: activeTab === 'six' ? 'tab-pane fade show active p-3' : 'tab-pane fade p-3', id: "six", role: "tabpanel", "aria-labelledby": "Six-tab" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bt_7" }, "People Advisory Services (PAS)"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "profileDetails" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Xavier.jpg", className: "proImg", alt: "Xavier Delaunay" }),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "proName" }, "Xavier Delaunay"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "proDes" }, "MENA PAS Leader")),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tabTxt" },
                                        "PAS helps clients with their people agenda, working with them to cultivate impactful people, human resource (HR) and organizational alignment at critical business crossroads.",
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        "The ",
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/DS_PAS/Pages/org-culture-people-and-workforce-experience-fop.aspx", target: "_blank", rel: "noreferrer" }, "Organization and People Field of Play"),
                                        "is one of the 14 cross-Service line Fields of Play that have been established to help our account teams translate the needs of our clients' most pressing people-related needs and align them to our solutions, services and capabilities.",
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        "Our solutions underpin the Organization and People Field of Play. These are designed to provide clients with the right set of services to address their needs at the critical junctures of their journey.",
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                        "Visit the ",
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/DS_PAS/Pages/Home.aspx", target: "_blank", rel: "noreferrer" }, "Discover PAS site"),
                                        " to know more."),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "ul_01" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "Organization and Workforce Transformation - Aligning organization and workforce capability"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "HR Transformation - Outpacing the competition to get work done efficiently"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "People Mobility - Enables quicker decision-making across the mobility agenda"),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null, "People Experience - Enhancing employee engagement, productivity, and well-being through new ways of working."),
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/DS_Tax/GCR/Pages/payroll-operations.aspx", target: "_blank", rel: "noreferrer" }, "Payroll Operate")))))))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid footerTab", hidden: true },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "quicklinks" }, "Quick links"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/EYMENA/SiteAssets/PDF/MENA%20TE%20Policy/ME%20TE%20Policy.pdf", target: "_blank", rel: "noreferrer", className: "qLInk" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "qklinks", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png", alt: "Link icon" }),
                                "MENA Expense Policy"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/menapeopleconnect/SitePages/TotalReward.aspx", target: "_blank", rel: "noreferrer", className: "qLInk" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "qklinks", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png", alt: "Link icon" }),
                                "MENA Total Reward"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/menapeopleconnect/SitePages/Policies%20and%20Procedures.aspx", target: "_blank", rel: "noreferrer", className: "qLInk" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "qklinks", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png", alt: "Link icon" }),
                                "MENA Talent Policies & Procedures"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://lms.ey.net/", target: "_blank", rel: "noreferrer", className: "qLInk" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "qklinks", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png", alt: "Link icon" }),
                                "LMS"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sort.ey.net/", target: "_blank", rel: "noreferrer", className: "qLInk" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "qklinks", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png", alt: "Link icon" }),
                                "SORT"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sf.ey.net", target: "_blank", rel: "noreferrer", className: "qLInk" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "qklinks", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png", alt: "Link icon" }),
                                "SuccessFactors"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://intranet.ey.com/sites/career-development/SitePageModern/342011/career-development", target: "_blank", rel: "noreferrer", className: "qLInk" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "qklinks", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png", alt: "Link icon" }),
                                "Career & development"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "https://sites.ey.com/sites/menapeopleconnect/SitePages/Onboarding.aspx", target: "_blank", rel: "noreferrer", className: "qLInk" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "qklinks", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/hyperlink-icon.png", alt: "Link icon" }),
                                "New starters (first 90 days)")))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "footer" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "\u00A9 2026 EYGM Limited. All rights reserved."))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SSL);


/***/ }),

/***/ 162:
/*!************************************************************************!*\
  !*** ./lib/webparts/menaTaxHub/components/TrainingPackAndDocuments.js ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

var imageRoot = 'https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/';
var trainingPackStyles = "\nhtml,body{overflow-x:hidden!important;font-family:EYInterstate}.training-pack{background:#2e2e38;color:#fff;min-height:100vh}.training-pack .loading-container{align-items:center;background:#1a1a24;display:flex;inset:0;justify-content:center;position:fixed;z-index:9999}.training-pack .loading-container .item{border:.2vw solid #ffe600;border-bottom-color:transparent;border-radius:50%;border-top-color:transparent;position:absolute;animation:pack-spin 2s ease infinite}.training-pack .loading-container .item:nth-child(1){height:30px;width:30px}.training-pack .loading-container .item:nth-child(2){animation-delay:.1s;height:50px;width:50px}.training-pack .loading-container .item:nth-child(3){animation-delay:.2s;height:70px;width:70px}.training-pack .loading-container .item:nth-child(4){animation-delay:.3s;height:90px;width:90px}@keyframes pack-spin{50%{transform:rotate(180deg)}100%{transform:rotate(0)}}.training-pack .nav-bar{background:#2e2e38;min-height:6vw;position:relative}.training-pack .EYlogo{left:5vw;position:absolute;top:1.5vw;width:3vw}.training-pack .logoTxt{color:#fff;font-size:2vw;left:11vw;position:absolute;top:2.2vw}.training-pack .navbarMenu{list-style:none;margin:0;padding:0;position:absolute;right:6vw;top:2.4vw}.training-pack .navbarMenu li{display:inline-block;font-size:1vw}.training-pack .navbarMenu a{color:#fff;padding:0 2vw;text-decoration:none}.training-pack .home{width:1.3vw}.training-pack .bannerBackground{background:#2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/banner.jpg') center/cover;min-height:8vw}.training-pack .cnt-fdr{background:rgba(46,46,56,.5);min-height:8vw;padding:2vw 3.5vw}.training-pack .cf6{color:#fff;font-size:1.5vw;margin:0}.training-pack .tabContent{background:#2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center/cover;min-height:35vw;padding:4vw 7vw}.training-pack .cl-3{padding:.7vw}.training-pack .col-sm-bx{background:#ffffff0f url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center/cover;box-shadow:0 0 1.5vw rgba(0,0,0,.44);min-height:19vw;overflow:hidden;position:relative;width:100%}.training-pack .boxTag{display:block;text-decoration:none}.training-pack .img-bx{background-position:right;background-size:100%;min-height:9vw;transition:all .2s ease-in-out;width:100%}.training-pack .col-sm-bx:hover .img-bx{background-size:110%}.training-pack .count{background:#fff;border-radius:100vw;float:right;margin-right:2vw;margin-top:-1.7vw;padding:.3vw;width:2.5vw}.training-pack .bx-link{color:#fff;font-size:.9vw;line-height:1.3vw;margin:0;padding:2vw 1vw 0 1.5vw}.training-pack .footer{background:#000;float:left;width:100%}.training-pack .footer p{font-size:1vw;margin:0;padding:1vw 2vw;text-align:right}\n@media(max-width:1200px){.training-pack .EYlogo{left:60px;top:20px;width:40px}.training-pack .logoTxt{font-size:25px;left:130px;top:30px}.training-pack .navbarMenu{right:50px;top:31px}.training-pack .home{width:20px}.training-pack .nav-bar{min-height:90px}.training-pack .cf6{font-size:30px}.training-pack .cnt-fdr{padding:35px 70px}.training-pack .tabContent{padding:50px 70px}.training-pack .col-sm-bx{min-height:70px}.training-pack .bx-link{font-size:13px;line-height:17px;padding:30px 30px}.training-pack .count{margin-right:20px;margin-top:-17px;width:35px;padding:6px}.training-pack .footer p{font-size:13px;padding:15px 20px}}\n    .col-sm-3 {\n        -ms-flex: 0 0 20%;\n        flex: 0 0 20%;\n        max-width: 20%;\n    }\n@media(max-width:992px){.training-pack .col-sm-3.cl-3{flex:0 0 33.333%;max-width:33.333%}}\n@media(max-width:750px){.training-pack .tabContent{padding:40px 30px}.training-pack .col-sm-3.cl-3{flex:0 0 50%;max-width:50%}.training-pack .img-bx{min-height:140px}}\n@media(max-width:575px){.training-pack .logoTxt{font-size:20px;left:115px}.training-pack .EYlogo{left:30px}.training-pack .navbarMenu{top:110px}.training-pack .col-sm-3.cl-3{flex:0 0 100%;max-width:100%}.training-pack .col-sm-bx{min-height:0}.training-pack .img-bx{min-height:200px}.training-pack .bx-link{font-size:14px;line-height:20px;padding:20px}.training-pack .tabContent{padding:40px 20px}}\n";
var TrainingPackAndDocuments = function (_a) {
    var onShowHome = _a.onShowHome;
    var _b = react__WEBPACK_IMPORTED_MODULE_0__.useState(true), isLoading = _b[0], setIsLoading = _b[1];
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
        var timer = window.setTimeout(function () { return setIsLoading(false); }, 2000);
        return function () { return window.clearTimeout(timer); };
    }, []);
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "training-pack" },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("style", null, trainingPackStyles),
        isLoading && react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "loading-container", "aria-label": "Loading" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "webPart" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid nav-container" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row nav-bar" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "EYlogo", src: "".concat(imageRoot, "EY_logo.png"), alt: "EY logo" }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "logoTxt" }, "MENA Tax Hub"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "navbarMenu" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#home", onClick: function (event) { event.preventDefault(); onShowHome(); } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "home", src: "".concat(imageRoot, "home.png"), alt: "Home" })))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 bannerBackground" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid cnt-fdr" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "cf6" }, "Training pack and documents"))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid tabContent" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cl-3" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: "boxTag", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/Introduction%20to%20Mercury%20Training%20Deck%20v5_V1.pdf", target: "_blank", rel: "noreferrer" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: { backgroundImage: "url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/Screenshot.png)" } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/pdf_icon.png", className: "count", alt: "PDF" }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bx-link" }, "Instructor led training October / November 2022 - Introduction to Mercury and Engagement Economics")))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cl-3" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: "boxTag", href: "https://sites.ey.com/:b:/r/sites/MENATaxHub/SiteAssets/MENATax/pdf/PfV%20Session%201%20-%20MENA.pdf", target: "_blank", rel: "noreferrer" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: { backgroundImage: "url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/pricing%20for%20value.png)" } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/pdf_icon.png", className: "count", alt: "PDF" }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bx-link" }, "Working Capital Management_Pricing for Value_Session 1_16 Jun 23")))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "footer" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "\u00A9 2026 EYGM Limited. All rights reserved.")))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TrainingPackAndDocuments);


/***/ }),

/***/ 20:
/*!***********************************************************************!*\
  !*** ./lib/webparts/menaTaxHub/components/TrainingRecordedSession.js ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

var imageRoot = 'https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/';
var recordedSessionStyles = "\nhtml,body{overflow-x:hidden!important;font-family:EYInterstate}.training-recorded{background:#2e2e38;color:#fff;min-height:100vh}.training-recorded .loading-container{align-items:center;background:#1a1a24;display:flex;inset:0;justify-content:center;position:fixed;z-index:9999}.training-recorded .loading-container .item{border:.2vw solid #ffe600;border-bottom-color:transparent;border-radius:50%;border-top-color:transparent;position:absolute;animation:recorded-spin 2s ease infinite}.training-recorded .loading-container .item:nth-child(1){height:30px;width:30px}.training-recorded .loading-container .item:nth-child(2){animation-delay:.1s;height:50px;width:50px}.training-recorded .loading-container .item:nth-child(3){animation-delay:.2s;height:70px;width:70px}.training-recorded .loading-container .item:nth-child(4){animation-delay:.3s;height:90px;width:90px}@keyframes recorded-spin{50%{transform:rotate(180deg)}100%{transform:rotate(0)}}.training-recorded .nav-bar{background:#2e2e38;min-height:6vw;position:relative}.training-recorded .EYlogo{left:5vw;position:absolute;top:1.5vw;width:3vw}.training-recorded .logoTxt{color:#fff;font-size:2vw;left:11vw;position:absolute;top:2.2vw}.training-recorded .navbarMenu{list-style:none;margin:0;padding:0;position:absolute;right:6vw;top:2.4vw}.training-recorded .navbarMenu li{display:inline-block;font-size:1vw}.training-recorded .navbarMenu a{color:#fff;padding:0 2vw;text-decoration:none}.training-recorded .home{width:1.3vw}.training-recorded .bannerBackground{background:#2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/banner.jpg') center/cover;min-height:8vw}.training-recorded .cnt-fdr{background:rgba(46,46,56,.5);min-height:8vw;padding:2vw 3.5vw}.training-recorded .cf6{color:#fff;font-size:1.5vw;margin:0}.training-recorded .tabContent{background:#2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center/cover;min-height:35vw;padding:4vw 5.5vw}.training-recorded .cl-3{cursor:pointer;padding:.35vw}.training-recorded .boxTag{display:block;text-decoration:none}.training-recorded .col-sm-bx{background:#ffffff0f url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center/cover;box-shadow:0 0 1.5vw rgba(0,0,0,.44);min-height:19vw;overflow:hidden;position:relative;width:100%}.training-recorded .img-bx{background-position:right;background-size:100%;min-height:10vw;transition:all .2s ease-in-out;width:100%}.training-recorded .col-sm-bx:hover .img-bx{background-size:110%}.training-recorded .playIcon{background:#fff;border:.3vw solid #fff;border-radius:50%;float:right;margin-right:2vw;margin-top:-1.2vw;width:2.5vw}.training-recorded .bx-link{color:#fff;font-size:.9vw;line-height:1.3vw;margin:0;padding:2vw 1vw 0 1.5vw}.training-recorded .footer{background:#000;float:left;width:100%}.training-recorded .footer p{font-size:1vw;margin:0;padding:1vw 2vw;text-align:right}\n@media(max-width:1200px){.training-recorded .EYlogo{left:60px;top:20px;width:40px}.training-recorded .logoTxt{font-size:25px;left:130px;top:30px}.training-recorded .navbarMenu{right:50px;top:31px}.training-recorded .home{width:20px}.training-recorded .nav-bar{min-height:90px}.training-recorded .cf6{font-size:30px}.training-recorded .cnt-fdr{padding:35px 70px}.training-recorded .tabContent{padding:50px 70px}.training-recorded .col-sm-bx{min-height:70px}.training-recorded .bx-link{font-size:13px;line-height:17px;padding:30px}.training-recorded .playIcon{border:3px solid #fff;margin-right:30px;margin-top:-13px;width:30px}.training-recorded .footer p{font-size:13px;padding:15px 20px}}\n\n  .col-sm-3 {\n        -ms-flex: 0 0 20%;\n        flex: 0 0 20%;\n        max-width: 20%;\n    }\n\n\n@media(max-width:992px){.training-recorded .col-sm-3.cl-3{flex:0 0 33.333%;max-width:33.333%}}\n@media(max-width:750px){.training-recorded .tabContent{padding:40px 30px}.training-recorded .col-sm-3.cl-3{flex:0 0 50%;max-width:50%}.training-recorded .img-bx{min-height:140px}}\n@media(max-width:575px){.training-recorded .logoTxt{font-size:20px;left:115px}.training-recorded .EYlogo{left:30px}.training-recorded .navbarMenu{top:110px}.training-recorded .col-sm-3.cl-3{flex:0 0 100%;max-width:100%}.training-recorded .col-sm-bx{min-height:0}.training-recorded .img-bx{min-height:200px}.training-recorded .bx-link{font-size:14px;line-height:20px;padding:20px}.training-recorded .tabContent{padding:40px 20px}}\n";
var TrainingRecordedSession = function (_a) {
    var onShowHome = _a.onShowHome;
    var _b = react__WEBPACK_IMPORTED_MODULE_0__.useState(true), isLoading = _b[0], setIsLoading = _b[1];
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
        var timer = window.setTimeout(function () { return setIsLoading(false); }, 2000);
        return function () { return window.clearTimeout(timer); };
    }, []);
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "training-recorded" },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("style", null, recordedSessionStyles),
        isLoading && react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "loading-container", "aria-label": "Loading" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "webPart" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid nav-container" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row nav-bar" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "EYlogo", src: "".concat(imageRoot, "EY_logo.png"), alt: "EY logo" }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "logoTxt" }, "MENA Tax Hub"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "navbarMenu" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#home", onClick: function (event) { event.preventDefault(); onShowHome(); } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "home", src: "".concat(imageRoot, "home.png"), alt: "Home" })))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 bannerBackground" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid cnt-fdr" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "cf6" }, "Training recorded session"))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid tabContent" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cl-3" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: "boxTag", href: "https://sites.ey.com/:v:/r/sites/MENATaxHub/SiteAssets/MENATax/Videos/ELM_Introduction%20to%20Mercury%20and%20Engagement%20Economics_31%20Oct%2022-20221031_123624-Meeting%20Recording.mp4", target: "_blank", rel: "noreferrer" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: { backgroundImage: "url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/vd01.png)" } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/play.png", className: "playIcon", alt: "Play" }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bx-link" }, "ELM_Introduction to Mercury and Engagement Economics_31 Oct 22")))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cl-3" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: "boxTag", href: "https://sites.ey.com/:v:/r/sites/MENATaxHub/SiteAssets/MENATax/Videos/ELM_Mercury%20and%20Reporting%20tool_01%20Nov%2022%20(Hands-on%20session)-20221101_120309-Meeting%20Recording.mp4", target: "_blank", rel: "noreferrer" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: { backgroundImage: "url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/vd04.png)" } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/play.png", className: "playIcon", alt: "Play" }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bx-link" }, "ELM_Mercury and Reporting tool_01 Nov 22 (Hands-on session)")))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cl-3" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: "boxTag", href: "https://sites.ey.com/:v:/r/sites/MENATaxHub/SiteAssets/MENATax/Videos/Recording_Pricing%20for%20Value%20-%20Part%201.mp4", target: "_blank", rel: "noreferrer" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: { backgroundImage: "url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/pricing%20for%20value.png)" } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/play.png", className: "playIcon", alt: "Play" }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bx-link" }, "Working Capital Management_Pricing for Value_Session 1_16 Jun 23")))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "footer" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "\u00A9 2026 EYGM Limited. All rights reserved.")))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TrainingRecordedSession);


/***/ }),

/***/ 727:
/*!******************************************************************************!*\
  !*** ./lib/webparts/menaTaxHub/components/VirtualClinicsTrainingSessions.js ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

var imageRoot = 'https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/';
var virtualClinicsStyles = "\nhtml,body{overflow-x:hidden!important;font-family:EYInterstate}.virtual-clinics{background:#2e2e38;color:#fff;min-height:100vh}.virtual-clinics .loading-container{align-items:center;background:#1a1a24;display:flex;inset:0;justify-content:center;position:fixed;z-index:9999}.virtual-clinics .loading-container .item{border:.2vw solid #ffe600;border-bottom-color:transparent;border-radius:50%;border-top-color:transparent;position:absolute;animation:clinic-spin 2s ease infinite}.virtual-clinics .loading-container .item:nth-child(1){height:30px;width:30px}.virtual-clinics .loading-container .item:nth-child(2){animation-delay:.1s;height:50px;width:50px}.virtual-clinics .loading-container .item:nth-child(3){animation-delay:.2s;height:70px;width:70px}.virtual-clinics .loading-container .item:nth-child(4){animation-delay:.3s;height:90px;width:90px}@keyframes clinic-spin{50%{transform:rotate(180deg)}100%{transform:rotate(0)}}.virtual-clinics .nav-bar{background:#2e2e38;min-height:6vw;position:relative}.virtual-clinics .EYlogo{left:5vw;position:absolute;top:1.5vw;width:3vw}.virtual-clinics .logoTxt{color:#fff;font-size:2vw;left:11vw;position:absolute;top:2.2vw}.virtual-clinics .navbarMenu{list-style:none;margin:0;padding:0;position:absolute;right:6vw;top:2.4vw}.virtual-clinics .navbarMenu li{display:inline-block;font-size:1vw}.virtual-clinics .navbarMenu a{color:#fff;padding:0 2vw;text-decoration:none}.virtual-clinics .home{width:1.3vw}.virtual-clinics .bannerBackground{background:#2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/banner.jpg') center/cover;min-height:8vw}.virtual-clinics .cnt-fdr{background:rgba(46,46,56,.5);min-height:8vw;padding:2vw 3.5vw}.virtual-clinics .cf6{color:#fff;font-size:1.5vw;margin:0}.virtual-clinics .tabContent{background:#2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center/cover;min-height:35vw;padding:4vw 5.5vw}.virtual-clinics .cl-3{cursor:pointer;padding:.35vw}.virtual-clinics .boxTag{display:block;text-decoration:none}.virtual-clinics .col-sm-bx{background:#ffffff0f url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center/cover;box-shadow:0 0 1.5vw rgba(0,0,0,.44);min-height:19vw;overflow:hidden;position:relative;width:100%}.virtual-clinics .img-bx{background-position:right;background-size:100%;min-height:10vw;transition:all .2s ease-in-out;width:100%}.virtual-clinics .col-sm-bx:hover .img-bx{background-size:110%}.virtual-clinics .playIcon{background:#fff;border:.3vw solid #fff;border-radius:50%;float:right;margin-right:2vw;margin-top:-1.2vw;width:2.5vw}.virtual-clinics .bx-link{color:#fff;font-size:.9vw;line-height:1.3vw;margin:0;padding:2vw 1vw 0 1.5vw}.virtual-clinics .footer{background:#000;float:left;width:100%}.virtual-clinics .footer p{font-size:1vw;margin:0;padding:1vw 2vw;text-align:right}\n .col-sm-3 {\n        -ms-flex: 0 0 20%;\n        flex: 0 0 20%;\n        max-width: 20%;\n    }\n@media(max-width:1200px){.virtual-clinics .EYlogo{left:60px;top:20px;width:40px}.virtual-clinics .logoTxt{font-size:25px;left:130px;top:30px}.virtual-clinics .navbarMenu{right:50px;top:31px}.virtual-clinics .home{width:20px}.virtual-clinics .nav-bar{min-height:90px}.virtual-clinics .cf6{font-size:30px}.virtual-clinics .cnt-fdr{padding:35px 70px}.virtual-clinics .tabContent{padding:50px 70px}.virtual-clinics .col-sm-bx{min-height:70px}.virtual-clinics .bx-link{font-size:13px;line-height:17px;padding:30px}.virtual-clinics .playIcon{border:3px solid #fff;margin-right:30px;margin-top:-13px;width:30px}.virtual-clinics .footer p{font-size:13px;padding:15px 20px}}\n\n@media(max-width:992px){.virtual-clinics .col-sm-3.cl-3{flex:0 0 33.333%;max-width:33.333%}}\n@media(max-width:750px){.virtual-clinics .tabContent{padding:40px 30px}.virtual-clinics .col-sm-3.cl-3{flex:0 0 50%;max-width:50%}.virtual-clinics .img-bx{min-height:140px}}\n@media(max-width:575px){.virtual-clinics .logoTxt{font-size:20px;left:115px}.virtual-clinics .EYlogo{left:30px}.virtual-clinics .navbarMenu{top:110px}.virtual-clinics .col-sm-3.cl-3{flex:0 0 100%;max-width:100%}.virtual-clinics .col-sm-bx{min-height:0}.virtual-clinics .img-bx{min-height:200px}.virtual-clinics .bx-link{font-size:14px;line-height:20px;padding:20px}.virtual-clinics .tabContent{padding:40px 20px}}\n";
var VirtualClinicsTrainingSessions = function (_a) {
    var onShowHome = _a.onShowHome;
    var _b = react__WEBPACK_IMPORTED_MODULE_0__.useState(true), isLoading = _b[0], setIsLoading = _b[1];
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
        var timer = window.setTimeout(function () { return setIsLoading(false); }, 2000);
        return function () { return window.clearTimeout(timer); };
    }, []);
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "virtual-clinics" },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("style", null, virtualClinicsStyles),
        isLoading && react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "loading-container", "aria-label": "Loading" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "webPart" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid nav-container" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row nav-bar" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "EYlogo", src: "".concat(imageRoot, "EY_logo.png"), alt: "EY logo" }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "logoTxt" }, "MENA Tax Hub"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "navbarMenu" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#home", onClick: function (event) { event.preventDefault(); onShowHome(); } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "home", src: "".concat(imageRoot, "home.png"), alt: "Home" })))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 bannerBackground" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid cnt-fdr" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "cf6" }, "Virtual clinics training sessions"))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid tabContent" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cl-3" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: "boxTag", href: "https://sites.ey.com/:v:/r/sites/MENATaxHub/SiteAssets/MENATax/Videos/VC%201A%20%E2%80%93%20Estimate%20to%20Complete%20(12%20Dec%2022)-20221212_120301-Meeting%20Recording.mp4", target: "_blank", rel: "noreferrer" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: { backgroundImage: "url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/vid_001.jpg?csf=1&web=1&e=1Us2Bh)" } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/play.png", className: "playIcon", alt: "Play" }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bx-link" }, "Estimate to Complete Demo_12 Dec 22")))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cl-3" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", className: "boxTag", href: "https://sites.ey.com/:v:/r/sites/MENATaxHub/SiteAssets/MENATax/Videos/VC%201B%20%E2%80%93%20Lean%20Opportunity%20and%20Engagement%20(13%20Dec%2022)-20221213_130314-Meeting%20Recording.mp4", target: "_blank", rel: "noreferrer" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: { backgroundImage: "url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/vid_002.jpg)" } }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/play.png", className: "playIcon", alt: "Play" }),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bx-link" }, "Lean Opportunity and Engagement Demo_13 Dec 22")))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "footer" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "\u00A9 2026 EYGM Limited. All rights reserved.")))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VirtualClinicsTrainingSessions);


/***/ }),

/***/ 467:
/*!*******************************************************!*\
  !*** ./lib/webparts/menaTaxHub/components/Webcast.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

var webcastStyles = "\nhtml, body { overflow-x: hidden !important; font-family: EYInterstate; }\n.webcast-page { background: #2e2e38; color: #ffffff; font-family: EYInterstate, Arial, sans-serif; overflow: hidden; }\n.webcast-page .loading-container { align-items: center; background: #1a1a24; display: flex; inset: 0; justify-content: center; position: fixed; z-index: 9999; }\n.webcast-page .loading-container .item { border: .2vw solid #ffe600; border-bottom-color: transparent; border-radius: 50%; border-top-color: transparent; height: 30px; position: absolute; width: 30px; animation: webcastSpin 2s ease infinite; }\n.webcast-page .loading-container .item:nth-child(2) { height: 50px; width: 50px; animation-delay: .1s; }\n.webcast-page .loading-container .item:nth-child(3) { height: 70px; width: 70px; animation-delay: .2s; }\n.webcast-page .loading-container .item:nth-child(4) { height: 90px; width: 90px; animation-delay: .3s; }\n@keyframes webcastSpin { 50% { transform: rotate(180deg); } 100% { transform: rotate(0deg); } }\n.webcast-page .container-wrapper { display: block; }\n.webcast-page .nav-bar { background: #2e2e38; margin: 0; min-height: 6vw; position: relative; width: 100%; z-index: 999; }\n.webcast-page .EYlogo { left: 5vw; position: absolute; top: 1.5vw; width: 3vw; }\n.webcast-page p.logoTxt { color: #ffffff; font-size: 2vw; left: 11vw; position: absolute; top: 2.2vw; }\n.webcast-page img.home { width: 1.3vw; }\n.webcast-page ul.navbarMenu { font-family: EYInterstate; list-style: none; margin: 0; padding: 0; position: absolute; right: 6vw; top: 2.4vw; }\n.webcast-page ul.navbarMenu li { color: #ffffff; display: inline-block; font-size: 1vw; }\n.webcast-page ul.navbarMenu li a { color: #ffffff; padding: 0 2vw; text-decoration: none; }\n.webcast-page .navToggle { display: none; }\n.webcast-page .bannerBackground { background: #2e2e38 url(https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/banner.jpg);\n    animation: communicationsShrink 20s infinite alternate;    min-height: 8vw;\n    padding: 0;\n    background-size: cover !important;\n    background-position: 0% 21%; }\n.webcast-page .cf6 { color: #ffffff; font-size: 1.5vw; margin: 0; padding: 1vw; }\n@keyframes webcastShrink { 0% { background-size: 115% 115%; } 100% { background-size: 100% 100%; } }\n.webcast-page .tabContent { background: #2e2e38 url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center / cover; min-height: 100vh; padding: 4vw 7vw; }\n.webcast-page .cl-3 { cursor: pointer; padding: .7vw; }\n.webcast-page .col-sm-3.cl-3 { flex: 0 0 20%; max-width: 20%; }\n.webcast-page .col-sm-bx { background: #ffffff0f url('https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/bgc.png') center / cover; box-shadow: 0 0 1.5vw rgba(0, 0, 0, .44); min-height: 21vw; position: relative; width: 100%; }\n.webcast-page .img-bx { background-position: center; background-size: 110%; min-height: 10vw; transition: all .2s ease-in-out; width: 100%; }\n.webcast-page .col-sm-bx:hover .img-bx { background-size: 130%; }\n.webcast-page .bx-link { color: #ffffff; font-size: 1vw; line-height: 1.4vw; margin: 0; padding: 2vw 2vw 0; }\n.webcast-page .date01 { color: #ffffff; display: block; font-size: .7vw; font-weight: lighter; padding: 0 2vw; }\n.webcast-page .pName { color: #ffe600; font-size: .8vw; margin: 1vw 0 0; padding: 0 2vw; }\n.webcast-page .pName span { color: #ffffff; }\n.webcast-page .playIcon { float: right; margin-right: 2vw; margin-top: -1.2vw; width: 2.5vw; }\n.webcast-page .footer { background: #000000; float: left; width: 100%; }\n.webcast-page .footer p { color: #ffffff; font-size: 1vw; margin: 0; padding: 1vw 2vw; text-align: right; }\n.webcast-page .modal-content { background: transparent; border: hidden; }\n.webcast-page .modal-body { padding: 0; }\n.webcast-page .modal-dialog { max-width: 60% !important; }\n.webcast-page .webcast-modal { align-items: center; background: rgba(0, 0, 0, .8); display: flex; inset: 0; justify-content: center; position: fixed; z-index: 1000006; }\n.webcast-page .webcast-modal-content { max-width: 900px; position: relative; width: 90%; }\n.webcast-page .webcast-modal-content video { display: block; height: auto; position: static; width: 100%; }\n.webcast-page .close { background: #ffe600; color: #000000; cursor: pointer; font-size: 1.5vw; line-height: 1.5vw; opacity: 1; padding: 0 .5vw; position: absolute; right: 0; top: 0; z-index: 1; }\n.webcast-page .video-wrap { height: 0; overflow: hidden; padding-bottom: 56.25%; position: relative; }\n.webcast-page video { border: none; height: 100%; left: 0; max-width: 100%; position: absolute; top: 0; width: 100%; }\n .webcast-page .cnt-fdr {background: rgba(46, 46, 56, .5);\n    padding: 2vw 5vw;\n    width: 100%;}\n@media only screen and (max-width: 1200px) {\n  .webcast-page .cnt-fdr { padding: 35px 70px; }\n  .webcast-page .EYlogo { left: 60px; top: 20px; width: 40px; }\n  .webcast-page .logoTxt { font-size: 25px; left: 130px; top: 30px; }\n  .webcast-page .nav-bar { min-height: 90px; }\n  .webcast-page .cf6 { font-size: 30px; }\n  .webcast-page .footer p { font-size: 13px; padding: 15px 20px; }\n  .webcast-page .bx-link { font-size: 13px; line-height: 14px; }\n  .webcast-page .date01 { font-size: 15px; }\n}\n@media only screen and (max-width: 992px) { .webcast-page .col-sm-3.cl-3 { flex: 0 0 33.333%; max-width: 33.333%; } .webcast-page .col-sm-bx { min-height: 70px; } .webcast-page .cl-3 { padding: 7px; } }\n@media only screen and (max-width: 750px) { .webcast-page .col-sm-3.cl-3 { flex: 0 0 50%; max-width: 50%; } }\n@media only screen and (max-width: 500px) { .webcast-page .col-sm-3.cl-3 { flex: 0 0 100%; max-width: 100%; } }\n";
var imageRoot = 'https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/';
var videoRoot = 'https://sites.ey.com/:v:/r/sites/MENATaxHub/SiteAssets/MENATax/Videos/';
var webcastItems = [
    { id: 'webCast15', image: 'june2026.jpg', date: '30-06-2026', presenter: 'Ahmed Eldessouky', video: 'MENA-Tax-All-People-Webcast-20260630_090205UTC-Meeting%20Recording.mp4' },
    { id: 'webCastFrtn', image: 'mar2026.jpg', date: '31-03-2026', presenter: 'Ahmed Eldessouky', video: 'MENA%20Tax%20All%20People%20Webcast-20260331-Meeting%20Recording.mp4' },
    { id: 'webCastThrtn', image: 'Jan2026.jpg', date: '12-01-2026', presenter: 'Ahmed Eldessouky', video: 'MENA%20Tax%20All%20People%20Webcast-20260112_073200UTC-Meeting%20Recording.mp4' },
    { id: 'webCastTwl', image: 'MENA-Tax-All-People-Webcast-Oct-2025.png', date: '02-10-2025', presenter: 'Ahmed Eldessouky', video: 'Recording_MENA%20Tax%20All%20People%20Webcast_02102025.mp4' },
    { id: 'webCastElv', image: 'webcast%20june%202025.png', date: '30-06-2025', presenter: 'Ahmed Al Esry', video: 'Recording_MENA%20Tax%20All%20People%20Webcast_30062025.mp4' },
    { id: 'webCastTen', image: 'webcast%20april%202025.png', date: '10-04-2025', presenter: 'Ahmed Al Esry', video: 'Recording_MENA%20Tax%20All%20People%20Webcast_10042025.mp4' },
    { id: 'webCastNine', image: 'video-thumb19December.png', date: '19-12-2024', presenter: 'Ahmed Al Esry', video: 'Recording_MENA%20Tax%20All%20People%20Webcast_19122024%20(1).mp4' },
    { id: 'webCastEight', image: 'sept2024.jpg', date: '30-09-2024', presenter: 'Ahmed Al Esry', video: 'Recording_MENA%20Tax%20All%20People%20webcast_30%20Sept.mp4' },
    { id: 'webCastSeven', image: 'webcast-30April.png', date: '30-04-2024', presenter: 'Ahmed Al Esry', video: 'Recording_MENA%20Tax%20All%20People%20Webcast_30042024.mp4' },
    { id: 'webCastSix', image: 'mena-all-people-webcat-final.png', date: '19-12-2023', presenter: 'Ahmed Al Esry', video: 'MENA_All_People_webcast_Final.mp4' },
    { id: 'webCastFive', image: 'Recording_MENA%20Tax%20All%20People%20Webcast.PNG', date: '12-10-2023', presenter: 'Ahmed Al Esry', video: 'Recording_MENA%20Tax%20All%20People%20Webcast.mp4' },
    { id: 'webCastFour', image: 'video-thumba.jpg', date: '22-06-2023', presenter: 'Ahmed Al Esry', video: 'Recording%20-%20MENA%20Tax%20All%20People%20Webcast_Trim.mp4' },
    { id: 'webCastThree', image: 'video-thumb.jpg', date: '10-04-2023', presenter: 'Ahmed Al Esry', video: 'Recording_MENA%20Tax%20All%20People%20Webcastmp4.mp4' },
    { id: 'webCastTwo', image: 'webcastTwo.png', date: '20-12-2022', presenter: 'Ahmed Al Esry', video: 'MENA%20Tax%20All%20People%20Webcast%2020th%20Dec%202022.mp4' },
    { id: 'webCast', image: 'webcast.jpg', date: '13-10-2022', presenter: 'Ahmed Al Esry', video: 'MENA%20Tax%20All%20People%20Webcast%2013th%20Oct.mp4' }
];
var Webcast = function (_a) {
    var onShowHome = _a.onShowHome;
    var _b = react__WEBPACK_IMPORTED_MODULE_0__.useState(true), loading = _b[0], setLoading = _b[1];
    var _c = react__WEBPACK_IMPORTED_MODULE_0__.useState(null), selectedWebcast = _c[0], setSelectedWebcast = _c[1];
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
        window.scrollTo(0, 0);
        var timer = window.setTimeout(function () { return setLoading(false); }, 2000);
        return function () { return window.clearTimeout(timer); };
    }, []);
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "webcast-page" },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("style", null, webcastStyles),
        loading && react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "loading-container" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "item" })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-wrapper" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "webPart" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row nav-bar" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "EYlogo", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/EY_logo.png", alt: "EY logo" }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "logoTxt" }, "MENA Tax Hub"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("ul", { className: "navbarMenu" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("li", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#", onClick: function (event) { event.preventDefault(); onShowHome(); } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "home", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/home.png", alt: "Home" })))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "navToggle", src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/toggle.png", alt: "Toggle navigation" })),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-12 bannerBackground" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid cnt-fdr" },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "cf6" }, "MENA Tax all people webcast"),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-4 c57" })))))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "container-fluid tabContent" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" }, webcastItems.map(function (item) { return react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-3 cl-3", key: item.id, onClick: function () { return setSelectedWebcast(item); }, onKeyDown: function (event) { if (event.key === 'Enter' || event.key === ' ')
                            setSelectedWebcast(item); }, role: "button", tabIndex: 0 },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-sm-bx" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "img-bx", style: { backgroundImage: "url(".concat(imageRoot).concat(item.image, ")") } }),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://sites.ey.com/sites/MENATaxHub/SiteAssets/MENATax/images/play.png", className: "playIcon", alt: "Play" }),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bx-link" }, "MENA Tax All People Webcast"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "date01" },
                                "Date: ",
                                item.date),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "pName" },
                                item.presenter,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "MENA Tax Leader")))); })))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "footer" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { "data-interception": "off", href: "#ssl" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "\u00A9 2026 EYGM Limited. All rights reserved.")))),
        selectedWebcast && react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "webcast-modal", role: "dialog", "aria-modal": "true", "aria-label": "MENA Tax All People Webcast", onClick: function () { return setSelectedWebcast(null); } },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "webcast-modal-content", onClick: function (event) { return event.stopPropagation(); } },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { type: "button", className: "close", onClick: function () { return setSelectedWebcast(null); }, "aria-label": "Close" }, "\u00D7"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("video", { src: "".concat(videoRoot).concat(selectedWebcast.video), controls: true, autoPlay: true, title: "MENA Tax All People Webcast" })))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Webcast);


/***/ }),

/***/ 323:
/*!***********************************************************************************************************!*\
  !*** ./node_modules/@microsoft/sp-css-loader/node_modules/@microsoft/load-themed-styles/lib-es6/index.js ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ClearStyleOptions: () => (/* binding */ ClearStyleOptions),
/* harmony export */   Mode: () => (/* binding */ Mode),
/* harmony export */   clearStyles: () => (/* binding */ clearStyles),
/* harmony export */   configureLoadStyles: () => (/* binding */ configureLoadStyles),
/* harmony export */   configureRunMode: () => (/* binding */ configureRunMode),
/* harmony export */   detokenize: () => (/* binding */ detokenize),
/* harmony export */   flush: () => (/* binding */ flush),
/* harmony export */   loadStyles: () => (/* binding */ loadStyles),
/* harmony export */   loadTheme: () => (/* binding */ loadTheme),
/* harmony export */   splitStyles: () => (/* binding */ splitStyles)
/* harmony export */ });
// Copyright (c) Microsoft Corporation. All rights reserved. Licensed under the MIT license.
// See LICENSE in the project root for license information.
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
/**
 * In sync mode, styles are registered as style elements synchronously with loadStyles() call.
 * In async mode, styles are buffered and registered as batch in async timer for performance purpose.
 */
var Mode;
(function (Mode) {
    Mode[Mode["sync"] = 0] = "sync";
    Mode[Mode["async"] = 1] = "async";
})(Mode || (Mode = {}));
/**
 * Themable styles and non-themable styles are tracked separately
 * Specify ClearStyleOptions when calling clearStyles API to specify which group of registered styles should be cleared.
 */
var ClearStyleOptions;
(function (ClearStyleOptions) {
    /** only themable styles will be cleared */
    ClearStyleOptions[ClearStyleOptions["onlyThemable"] = 1] = "onlyThemable";
    /** only non-themable styles will be cleared */
    ClearStyleOptions[ClearStyleOptions["onlyNonThemable"] = 2] = "onlyNonThemable";
    /** both themable and non-themable styles will be cleared */
    ClearStyleOptions[ClearStyleOptions["all"] = 3] = "all";
})(ClearStyleOptions || (ClearStyleOptions = {}));
// Store the theming state in __themeState__ global scope for reuse in the case of duplicate
// load-themed-styles hosted on the page.
var _root = typeof window === 'undefined' ? __webpack_require__.g : window; // eslint-disable-line @typescript-eslint/no-explicit-any
// Nonce string to inject into script tag if one provided. This is used in CSP (Content Security Policy).
var _styleNonce = _root && _root.CSPSettings && _root.CSPSettings.nonce;
var _themeState = initializeThemeState();
/**
 * Matches theming tokens. For example, "[theme: themeSlotName, default: #FFF]" (including the quotes).
 */
var _themeTokenRegex = /[\'\"]\[theme:\s*(\w+)\s*(?:\,\s*default:\s*([\\"\']?[\.\,\(\)\#\-\s\w]*[\.\,\(\)\#\-\w][\"\']?))?\s*\][\'\"]/g;
var now = function () {
    return typeof performance !== 'undefined' && !!performance.now ? performance.now() : Date.now();
};
function measure(func) {
    var start = now();
    func();
    var end = now();
    _themeState.perf.duration += end - start;
}
/**
 * initialize global state object
 */
function initializeThemeState() {
    var state = _root.__themeState__ || {
        theme: undefined,
        lastStyleElement: undefined,
        registeredStyles: []
    };
    if (!state.runState) {
        state = __assign(__assign({}, state), { perf: {
                count: 0,
                duration: 0
            }, runState: {
                flushTimer: 0,
                mode: Mode.sync,
                buffer: []
            } });
    }
    if (!state.registeredThemableStyles) {
        state = __assign(__assign({}, state), { registeredThemableStyles: [] });
    }
    _root.__themeState__ = state;
    return state;
}
/**
 * Loads a set of style text. If it is registered too early, we will register it when the window.load
 * event is fired.
 * @param {string | ThemableArray} styles Themable style text to register.
 * @param {boolean} loadAsync When true, always load styles in async mode, irrespective of current sync mode.
 */
function loadStyles(styles, loadAsync) {
    if (loadAsync === void 0) { loadAsync = false; }
    measure(function () {
        var styleParts = Array.isArray(styles) ? styles : splitStyles(styles);
        var _a = _themeState.runState, mode = _a.mode, buffer = _a.buffer, flushTimer = _a.flushTimer;
        if (loadAsync || mode === Mode.async) {
            buffer.push(styleParts);
            if (!flushTimer) {
                _themeState.runState.flushTimer = asyncLoadStyles();
            }
        }
        else {
            applyThemableStyles(styleParts);
        }
    });
}
/**
 * Allows for customizable loadStyles logic. e.g. for server side rendering application
 * @param {(processedStyles: string, rawStyles?: string | ThemableArray) => void}
 * a loadStyles callback that gets called when styles are loaded or reloaded
 */
function configureLoadStyles(loadStylesFn) {
    _themeState.loadStyles = loadStylesFn;
}
/**
 * Configure run mode of load-themable-styles
 * @param mode load-themable-styles run mode, async or sync
 */
function configureRunMode(mode) {
    _themeState.runState.mode = mode;
}
/**
 * external code can call flush to synchronously force processing of currently buffered styles
 */
function flush() {
    measure(function () {
        var styleArrays = _themeState.runState.buffer.slice();
        _themeState.runState.buffer = [];
        var mergedStyleArray = [].concat.apply([], styleArrays);
        if (mergedStyleArray.length > 0) {
            applyThemableStyles(mergedStyleArray);
        }
    });
}
/**
 * register async loadStyles
 */
function asyncLoadStyles() {
    // Use "self" to distinguish conflicting global typings for setTimeout() from lib.dom.d.ts vs Jest's @types/node
    // https://github.com/jestjs/jest/issues/14418
    return self.setTimeout(function () {
        _themeState.runState.flushTimer = 0;
        flush();
    }, 0);
}
/**
 * Loads a set of style text. If it is registered too early, we will register it when the window.load event
 * is fired.
 * @param {string} styleText Style to register.
 * @param {IStyleRecord} styleRecord Existing style record to re-apply.
 */
function applyThemableStyles(stylesArray, styleRecord) {
    if (_themeState.loadStyles) {
        _themeState.loadStyles(resolveThemableArray(stylesArray).styleString, stylesArray);
    }
    else {
        registerStyles(stylesArray);
    }
}
/**
 * Registers a set theme tokens to find and replace. If styles were already registered, they will be
 * replaced.
 * @param {theme} theme JSON object of theme tokens to values.
 */
function loadTheme(theme) {
    _themeState.theme = theme;
    // reload styles.
    reloadStyles();
}
/**
 * Clear already registered style elements and style records in theme_State object
 * @param option - specify which group of registered styles should be cleared.
 * Default to be both themable and non-themable styles will be cleared
 */
function clearStyles(option) {
    if (option === void 0) { option = ClearStyleOptions.all; }
    if (option === ClearStyleOptions.all || option === ClearStyleOptions.onlyNonThemable) {
        clearStylesInternal(_themeState.registeredStyles);
        _themeState.registeredStyles = [];
    }
    if (option === ClearStyleOptions.all || option === ClearStyleOptions.onlyThemable) {
        clearStylesInternal(_themeState.registeredThemableStyles);
        _themeState.registeredThemableStyles = [];
    }
}
function clearStylesInternal(records) {
    records.forEach(function (styleRecord) {
        var styleElement = styleRecord && styleRecord.styleElement;
        if (styleElement && styleElement.parentElement) {
            styleElement.parentElement.removeChild(styleElement);
        }
    });
}
/**
 * Reloads styles.
 */
function reloadStyles() {
    if (_themeState.theme) {
        var themableStyles = [];
        for (var _i = 0, _a = _themeState.registeredThemableStyles; _i < _a.length; _i++) {
            var styleRecord = _a[_i];
            themableStyles.push(styleRecord.themableStyle);
        }
        if (themableStyles.length > 0) {
            clearStyles(ClearStyleOptions.onlyThemable);
            applyThemableStyles([].concat.apply([], themableStyles));
        }
    }
}
/**
 * Find theme tokens and replaces them with provided theme values.
 * @param {string} styles Tokenized styles to fix.
 */
function detokenize(styles) {
    if (styles) {
        styles = resolveThemableArray(splitStyles(styles)).styleString;
    }
    return styles;
}
/**
 * Resolves ThemingInstruction objects in an array and joins the result into a string.
 * @param {ThemableArray} splitStyleArray ThemableArray to resolve and join.
 */
function resolveThemableArray(splitStyleArray) {
    var theme = _themeState.theme;
    var themable = false;
    // Resolve the array of theming instructions to an array of strings.
    // Then join the array to produce the final CSS string.
    var resolvedArray = (splitStyleArray || []).map(function (currentValue) {
        var themeSlot = currentValue.theme;
        if (themeSlot) {
            themable = true;
            // A theming annotation. Resolve it.
            var themedValue = theme ? theme[themeSlot] : undefined;
            var defaultValue = currentValue.defaultValue || 'inherit';
            // Warn to console if we hit an unthemed value even when themes are provided, but only if "DEBUG" is true.
            // Allow the themedValue to be undefined to explicitly request the default value.
            if (theme &&
                !themedValue &&
                console &&
                !(themeSlot in theme) &&
                "boolean" !== 'undefined' &&
                true) {
                // eslint-disable-next-line no-console
                console.warn("Theming value not provided for \"".concat(themeSlot, "\". Falling back to \"").concat(defaultValue, "\"."));
            }
            return themedValue || defaultValue;
        }
        else {
            // A non-themable string. Preserve it.
            return currentValue.rawString;
        }
    });
    return {
        styleString: resolvedArray.join(''),
        themable: themable
    };
}
/**
 * Split tokenized CSS into an array of strings and theme specification objects
 * @param {string} styles Tokenized styles to split.
 */
function splitStyles(styles) {
    var result = [];
    if (styles) {
        var pos = 0; // Current position in styles.
        var tokenMatch = void 0;
        while ((tokenMatch = _themeTokenRegex.exec(styles))) {
            var matchIndex = tokenMatch.index;
            if (matchIndex > pos) {
                result.push({
                    rawString: styles.substring(pos, matchIndex)
                });
            }
            result.push({
                theme: tokenMatch[1],
                defaultValue: tokenMatch[2] // May be undefined
            });
            // index of the first character after the current match
            pos = _themeTokenRegex.lastIndex;
        }
        // Push the rest of the string after the last match.
        result.push({
            rawString: styles.substring(pos)
        });
    }
    return result;
}
/**
 * Registers a set of style text. If it is registered too early, we will register it when the
 * window.load event is fired.
 * @param {ThemableArray} styleArray Array of IThemingInstruction objects to register.
 * @param {IStyleRecord} styleRecord May specify a style Element to update.
 */
function registerStyles(styleArray) {
    if (typeof document === 'undefined') {
        return;
    }
    var head = document.getElementsByTagName('head')[0];
    var styleElement = document.createElement('style');
    var _a = resolveThemableArray(styleArray), styleString = _a.styleString, themable = _a.themable;
    styleElement.setAttribute('data-load-themed-styles', 'true');
    if (_styleNonce) {
        styleElement.setAttribute('nonce', _styleNonce);
    }
    styleElement.appendChild(document.createTextNode(styleString));
    _themeState.perf.count++;
    head.appendChild(styleElement);
    var ev = document.createEvent('HTMLEvents');
    ev.initEvent('styleinsert', true /* bubbleEvent */, false /* cancelable */);
    ev.args = {
        newStyle: styleElement
    };
    document.dispatchEvent(ev);
    var record = {
        styleElement: styleElement,
        themableStyle: styleArray
    };
    if (themable) {
        _themeState.registeredThemableStyles.push(record);
    }
    else {
        _themeState.registeredStyles.push(record);
    }
}


/***/ }),

/***/ 676:
/*!*********************************************!*\
  !*** external "@microsoft/sp-core-library" ***!
  \*********************************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__676__;

/***/ }),

/***/ 877:
/*!**********************************************!*\
  !*** external "@microsoft/sp-property-pane" ***!
  \**********************************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__877__;

/***/ }),

/***/ 642:
/*!*********************************************!*\
  !*** external "@microsoft/sp-webpart-base" ***!
  \*********************************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__642__;

/***/ }),

/***/ 76:
/*!*******************************************!*\
  !*** external "MenaTaxHubWebPartStrings" ***!
  \*******************************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__76__;

/***/ }),

/***/ 959:
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__959__;

/***/ }),

/***/ 398:
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__398__;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/*!******************************************************!*\
  !*** ./lib/webparts/menaTaxHub/MenaTaxHubWebPart.js ***!
  \******************************************************/
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom */ 398);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @microsoft/sp-core-library */ 676);
/* harmony import */ var _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @microsoft/sp-property-pane */ 877);
/* harmony import */ var _microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _microsoft_sp_webpart_base__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @microsoft/sp-webpart-base */ 642);
/* harmony import */ var _microsoft_sp_webpart_base__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_webpart_base__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var MenaTaxHubWebPartStrings__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! MenaTaxHubWebPartStrings */ 76);
/* harmony import */ var MenaTaxHubWebPartStrings__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(MenaTaxHubWebPartStrings__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components_MenaTaxHub__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./components/MenaTaxHub */ 27);
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();







var MenaTaxHubWebPart = /** @class */ (function (_super) {
    __extends(MenaTaxHubWebPart, _super);
    function MenaTaxHubWebPart() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._isDarkTheme = false;
        _this._environmentMessage = '';
        return _this;
    }
    MenaTaxHubWebPart.prototype.render = function () {
        var element = react__WEBPACK_IMPORTED_MODULE_0__.createElement(_components_MenaTaxHub__WEBPACK_IMPORTED_MODULE_6__["default"], {
            description: this.properties.description,
            isDarkTheme: this._isDarkTheme,
            environmentMessage: this._environmentMessage,
            hasTeamsContext: !!this.context.sdks.microsoftTeams,
            userDisplayName: this.context.pageContext.user.displayName,
            userEmail: this.context.pageContext.user.email
        });
        react_dom__WEBPACK_IMPORTED_MODULE_1__.render(element, this.domElement);
    };
    MenaTaxHubWebPart.prototype.onInit = function () {
        var _this = this;
        return this._getEnvironmentMessage().then(function (message) {
            _this._environmentMessage = message;
        });
    };
    MenaTaxHubWebPart.prototype._getEnvironmentMessage = function () {
        var _this = this;
        if (!!this.context.sdks.microsoftTeams) { // running in Teams, office.com or Outlook
            return this.context.sdks.microsoftTeams.teamsJs.app.getContext()
                .then(function (context) {
                var environmentMessage = '';
                switch (context.app.host.name) {
                    case 'Office': // running in Office
                        environmentMessage = _this.context.isServedFromLocalhost ? MenaTaxHubWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.AppLocalEnvironmentOffice : MenaTaxHubWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.AppOfficeEnvironment;
                        break;
                    case 'Outlook': // running in Outlook
                        environmentMessage = _this.context.isServedFromLocalhost ? MenaTaxHubWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.AppLocalEnvironmentOutlook : MenaTaxHubWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.AppOutlookEnvironment;
                        break;
                    case 'Teams': // running in Teams
                    case 'TeamsModern':
                        environmentMessage = _this.context.isServedFromLocalhost ? MenaTaxHubWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.AppLocalEnvironmentTeams : MenaTaxHubWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.AppTeamsTabEnvironment;
                        break;
                    default:
                        environmentMessage = MenaTaxHubWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.UnknownEnvironment;
                }
                return environmentMessage;
            });
        }
        return Promise.resolve(this.context.isServedFromLocalhost ? MenaTaxHubWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.AppLocalEnvironmentSharePoint : MenaTaxHubWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.AppSharePointEnvironment);
    };
    MenaTaxHubWebPart.prototype.onThemeChanged = function (currentTheme) {
        if (!currentTheme) {
            return;
        }
        this._isDarkTheme = !!currentTheme.isInverted;
        var semanticColors = currentTheme.semanticColors;
        if (semanticColors) {
            this.domElement.style.setProperty('--bodyText', semanticColors.bodyText || null);
            this.domElement.style.setProperty('--link', semanticColors.link || null);
            this.domElement.style.setProperty('--linkHovered', semanticColors.linkHovered || null);
        }
    };
    MenaTaxHubWebPart.prototype.onDispose = function () {
        react_dom__WEBPACK_IMPORTED_MODULE_1__.unmountComponentAtNode(this.domElement);
    };
    Object.defineProperty(MenaTaxHubWebPart.prototype, "dataVersion", {
        get: function () {
            return _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_2__.Version.parse('1.0');
        },
        enumerable: false,
        configurable: true
    });
    MenaTaxHubWebPart.prototype.getPropertyPaneConfiguration = function () {
        return {
            pages: [
                {
                    header: {
                        description: MenaTaxHubWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.PropertyPaneDescription
                    },
                    groups: [
                        {
                            groupName: MenaTaxHubWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.BasicGroupName,
                            groupFields: [
                                (0,_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_3__.PropertyPaneTextField)('description', {
                                    label: MenaTaxHubWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.DescriptionFieldLabel
                                })
                            ]
                        }
                    ]
                }
            ]
        };
    };
    return MenaTaxHubWebPart;
}(_microsoft_sp_webpart_base__WEBPACK_IMPORTED_MODULE_4__.BaseClientSideWebPart));
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MenaTaxHubWebPart);

})();

/******/ 	return __webpack_exports__;
/******/ })()
;
});;
//# sourceMappingURL=mena-tax-hub-web-part.js.map