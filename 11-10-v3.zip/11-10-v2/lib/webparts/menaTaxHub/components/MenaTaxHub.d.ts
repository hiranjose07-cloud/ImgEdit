import * as React from 'react';
import type { IMenaTaxHubProps } from './IMenaTaxHubProps';
declare global {
    interface Window {
        loadMenaTaxPage?: (pageName: string) => void;
    }
}
interface IMenaTaxHubState {
    activeView: 'home' | 'ssl' | 'cst' | 'quality' | 'leadership' | 'mydocs' | 'eyi' | 'faqs' | 'resourcing' | 'onshore' | 'nongcc' | 'gds' | 'talent' | 'webcast' | 'communications' | 'markets' | 'engagement' | 'policies' | 'training' | 'training-pack' | 'training-recorded' | 'virtual-clinics';
    menuOpen: boolean;
    routeLoading: boolean;
}
export default class MenaTaxHub extends React.Component<IMenaTaxHubProps, IMenaTaxHubState> {
    state: IMenaTaxHubState;
    private routeLoadingTimer?;
    private skipRouteLoading;
    private scrollToTop;
    private handleHashChange;
    componentDidMount(): void;
    componentWillUnmount(): void;
    componentDidUpdate(_previousProps: IMenaTaxHubProps, previousState: IMenaTaxHubState): void;
    private showSSL;
    private showCST;
    private showQuality;
    private showLeadership;
    private showMyDocs;
    private showEYI;
    private showFAQs;
    private showResourcing;
    private showOnshore;
    private showNonGcc;
    private showGDS;
    private showTalent;
    private showWebcast;
    private showCommunications;
    private showMarkets;
    private showEngagement;
    private showPolicies;
    private showTraining;
    private showTrainingPack;
    private showRecordedSession;
    private showVirtualClinics;
    private showHome;
    private toggleMenu;
    private openExternalLink;
    private navigateFromMenu;
    render(): React.ReactElement<IMenaTaxHubProps>;
}
export {};
//# sourceMappingURL=MenaTaxHub.d.ts.map