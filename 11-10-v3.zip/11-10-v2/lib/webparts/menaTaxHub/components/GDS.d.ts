import * as React from 'react';
interface IGDSProps {
    onShowHome?: () => void;
}
declare const GDS: React.FC<IGDSProps>;
export default GDS;
//# sourceMappingURL=GDS.d.ts.map