import * as React from 'react';
interface ITrainingRecordedSessionProps {
    onShowHome: () => void;
}
declare const TrainingRecordedSession: React.FC<ITrainingRecordedSessionProps>;
export default TrainingRecordedSession;
//# sourceMappingURL=TrainingRecordedSession.d.ts.map