declare const _default: string;
export default _default;
//# sourceMappingURL=MenaTaxTalentPocsHtml.d.ts.map