import * as React from 'react';
interface IPoliciesAndProceduresProps {
    onShowHome: () => void;
}
declare const PoliciesAndProcedures: React.FC<IPoliciesAndProceduresProps>;
export default PoliciesAndProcedures;
//# sourceMappingURL=PoliciesAndProcedures.d.ts.map