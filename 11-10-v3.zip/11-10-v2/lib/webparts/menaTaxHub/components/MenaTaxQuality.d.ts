import * as React from 'react';
interface IMenaTaxQualityProps {
    onShowHome: () => void;
    onShowFAQs: () => void;
}
declare const MenaTaxQuality: React.FC<IMenaTaxQualityProps>;
export default MenaTaxQuality;
//# sourceMappingURL=MenaTaxQuality.d.ts.map