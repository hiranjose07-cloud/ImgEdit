import * as React from 'react';
interface IOnshoreResourcingProps {
    onShowResourcing: () => void;
    onShowHome: () => void;
}
declare const OnshoreResourcing: React.FC<IOnshoreResourcingProps>;
export default OnshoreResourcing;
//# sourceMappingURL=OnshoreResourcing.d.ts.map