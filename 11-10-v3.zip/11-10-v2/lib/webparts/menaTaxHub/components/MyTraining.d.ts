import * as React from 'react';
interface IMyTrainingProps {
    onShowHome: () => void;
    onShowTrainingPack?: () => void;
    onShowRecordedSession?: () => void;
    onShowVirtualClinics?: () => void;
}
declare const MyTraining: React.FC<IMyTrainingProps>;
export default MyTraining;
//# sourceMappingURL=MyTraining.d.ts.map