import * as React from 'react';
interface INonGccResourcingProps {
    onShowResourcing: () => void;
    onShowHome: () => void;
}
declare const NonGccResourcing: React.FC<INonGccResourcingProps>;
export default NonGccResourcing;
//# sourceMappingURL=NonGccResourcing.d.ts.map