import * as React from 'react';
interface ICommunicationsProps {
    onShowHome: () => void;
}
declare const Communications: React.FC<ICommunicationsProps>;
export default Communications;
//# sourceMappingURL=Communications.d.ts.map