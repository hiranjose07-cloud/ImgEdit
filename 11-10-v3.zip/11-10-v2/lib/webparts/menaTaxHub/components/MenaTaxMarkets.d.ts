import * as React from 'react';
interface IMarketsProps {
    onShowHome: () => void;
}
declare const MenaTaxMarkets: React.FC<IMarketsProps>;
export default MenaTaxMarkets;
//# sourceMappingURL=MenaTaxMarkets.d.ts.map