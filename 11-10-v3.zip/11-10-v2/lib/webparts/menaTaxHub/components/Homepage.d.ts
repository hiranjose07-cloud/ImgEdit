import * as React from 'react';
interface IHomepageProps {
    onShowSSL: () => void;
    onShowCST: () => void;
    onShowQuality: () => void;
    onShowFAQs: () => void;
    onShowLeadership: () => void;
    onShowMyDocs: () => void;
    onShowEYI: () => void;
    onShowResourcing: () => void;
    onShowOnshore: () => void;
    onShowNonGcc: () => void;
    onShowGDS: () => void;
    onShowTalent: () => void;
    onShowWebcast: () => void;
    onShowCommunications: () => void;
    onShowMarkets: () => void;
    onShowEngagement: () => void;
    onShowPolicies: () => void;
    userDisplayName: string;
    userEmail: string;
}
declare const Homepage: React.FC<IHomepageProps>;
export default Homepage;
//# sourceMappingURL=Homepage.d.ts.map