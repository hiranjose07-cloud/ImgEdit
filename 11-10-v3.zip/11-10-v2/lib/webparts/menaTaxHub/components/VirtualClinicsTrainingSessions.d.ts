import * as React from 'react';
interface IVirtualClinicsTrainingSessionsProps {
    onShowHome: () => void;
}
declare const VirtualClinicsTrainingSessions: React.FC<IVirtualClinicsTrainingSessionsProps>;
export default VirtualClinicsTrainingSessions;
//# sourceMappingURL=VirtualClinicsTrainingSessions.d.ts.map