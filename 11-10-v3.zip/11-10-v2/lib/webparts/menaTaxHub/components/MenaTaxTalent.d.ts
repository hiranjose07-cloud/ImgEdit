import * as React from 'react';
interface IMenaTaxTalentProps {
    onShowHome: () => void;
}
declare const MenaTaxTalent: React.FC<IMenaTaxTalentProps>;
export default MenaTaxTalent;
//# sourceMappingURL=MenaTaxTalent.d.ts.map