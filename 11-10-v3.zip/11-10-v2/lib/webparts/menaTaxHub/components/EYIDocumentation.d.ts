import * as React from 'react';
interface IEYIDocumentationProps {
    onShowHome: () => void;
}
declare const EYIDocumentation: React.FC<IEYIDocumentationProps>;
export default EYIDocumentation;
//# sourceMappingURL=EYIDocumentation.d.ts.map