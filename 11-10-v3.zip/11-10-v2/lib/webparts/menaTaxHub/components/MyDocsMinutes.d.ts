import * as React from 'react';
interface IMyDocsMinutesProps {
    onShowHome: () => void;
}
declare const MyDocsMinutes: React.FC<IMyDocsMinutesProps>;
export default MyDocsMinutes;
//# sourceMappingURL=MyDocsMinutes.d.ts.map