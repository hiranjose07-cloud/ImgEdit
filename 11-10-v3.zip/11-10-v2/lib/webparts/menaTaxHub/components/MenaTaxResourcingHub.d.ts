import * as React from 'react';
interface IMenaTaxResourcingHubProps {
    onShowHome: () => void;
    onShowOnshore: () => void;
    onShowNonGcc: () => void;
}
declare const MenaTaxResourcingHub: React.FC<IMenaTaxResourcingHubProps>;
export default MenaTaxResourcingHub;
//# sourceMappingURL=MenaTaxResourcingHub.d.ts.map