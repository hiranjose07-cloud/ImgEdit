import * as React from 'react';
interface IMenaTaxLeadershipProps {
    onShowHome: () => void;
}
declare const MenaTaxLeadership: React.FC<IMenaTaxLeadershipProps>;
export default MenaTaxLeadership;
//# sourceMappingURL=MenaTaxLeadership.d.ts.map