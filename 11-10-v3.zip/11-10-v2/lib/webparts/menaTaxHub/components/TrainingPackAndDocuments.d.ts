import * as React from 'react';
interface ITrainingPackAndDocumentsProps {
    onShowHome: () => void;
}
declare const TrainingPackAndDocuments: React.FC<ITrainingPackAndDocumentsProps>;
export default TrainingPackAndDocuments;
//# sourceMappingURL=TrainingPackAndDocuments.d.ts.map