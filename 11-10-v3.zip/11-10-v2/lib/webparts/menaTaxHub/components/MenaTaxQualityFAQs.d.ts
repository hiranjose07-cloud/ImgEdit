import * as React from 'react';
interface IMenaTaxQualityFAQsProps {
    onShowHome: () => void;
}
declare const MenaTaxQualityFAQs: React.FC<IMenaTaxQualityFAQsProps>;
export default MenaTaxQualityFAQs;
//# sourceMappingURL=MenaTaxQualityFAQs.d.ts.map