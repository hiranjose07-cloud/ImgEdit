export interface IMenaTaxHubProps {
    description: string;
    isDarkTheme: boolean;
    environmentMessage: string;
    hasTeamsContext: boolean;
    userDisplayName: string;
    userEmail: string;
}
//# sourceMappingURL=IMenaTaxHubProps.d.ts.map