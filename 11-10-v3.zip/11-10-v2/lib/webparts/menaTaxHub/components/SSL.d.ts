import * as React from 'react';
interface ISSLProps {
    onShowHome: () => void;
}
declare const SSL: React.FC<ISSLProps>;
export default SSL;
//# sourceMappingURL=SSL.d.ts.map