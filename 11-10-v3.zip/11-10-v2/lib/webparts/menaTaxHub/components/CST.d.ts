import * as React from 'react';
interface ICSTProps {
    onShowHome: () => void;
}
declare const CST: React.FC<ICSTProps>;
export default CST;
//# sourceMappingURL=CST.d.ts.map