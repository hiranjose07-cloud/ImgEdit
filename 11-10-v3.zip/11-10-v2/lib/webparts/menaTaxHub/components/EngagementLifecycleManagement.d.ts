import * as React from 'react';
interface IEngagementProps {
    onShowHome: () => void;
    onShowPolicies?: () => void;
    onShowTraining?: () => void;
}
declare const EngagementLifecycleManagement: React.FC<IEngagementProps>;
export default EngagementLifecycleManagement;
//# sourceMappingURL=EngagementLifecycleManagement.d.ts.map