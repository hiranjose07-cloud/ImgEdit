import * as React from 'react';
interface IWebcastProps {
    onShowHome: () => void;
}
declare const Webcast: React.FC<IWebcastProps>;
export default Webcast;
//# sourceMappingURL=Webcast.d.ts.map