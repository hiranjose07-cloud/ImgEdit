declare const styles: {
    menaTaxHub: string;
    teams: string;
    menuButton: string;
    menuOverlay: string;
    menuOverlayOpen: string;
    routeLoading: string;
    loadingRing: string;
    routeSpin: string;
    menuPanel: string;
    menuLink: string;
    menuPanelOpen: string;
    menuHeader: string;
    menuClose: string;
    menuItemActive: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=MenaTaxHub.module.scss.d.ts.map