import * as React from 'react';
import type { IHomePageProps } from './IHomePageProps';
interface ILearningCourse {
    id: string;
    title: string;
    description: string;
    thumbnail: string;
    link: string;
}
interface ICareerStage {
    name: string;
    courses: ILearningCourse[];
}
interface IFeaturedLearning {
    id: string;
    name: string;
    link: string;
    date?: Date;
    category: string;
    location: string;
}
interface IHomePageState {
    activeStage: number;
    activeFeaturedPage: number;
    careerStages: ICareerStage[];
    featuredItems: IFeaturedLearning[];
    careerLoading: boolean;
    featuredLoading: boolean;
    careerError: boolean;
    featuredError: boolean;
}
export default class HomePage extends React.Component<IHomePageProps, IHomePageState> {
    constructor(props: IHomePageProps);
    componentDidMount(): void;
    private loadList;
    private loadCareerStages;
    private loadFeaturedLearning;
    private selectStage;
    private selectFeaturedPage;
    render(): React.ReactElement<IHomePageProps>;
}
export {};
//# sourceMappingURL=HomePage.d.ts.map