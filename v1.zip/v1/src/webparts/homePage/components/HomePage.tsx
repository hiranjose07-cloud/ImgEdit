import * as React from 'react';
import { SPHttpClient } from '@microsoft/sp-http';
import styles from './HomePage.module.scss';
import type { IHomePageProps } from './IHomePageProps';
const css = styles as unknown as Record<string, string>;

const learningSiteUrl = 'https://sites.ey.com/sites/ENATaxHub';
const careerStageApi = `${learningSiteUrl}/_api/web/lists/getByTitle('CareerStageLearning')/items?$select=*&$orderby=LSlNo asc`;
const featuredLearningApi = `${learningSiteUrl}/_api/web/lists/getByTitle('FeaturedLearning')/items?$select=*&$orderby=FSlNo asc`;

interface ISharePointLinkField { Url?: string; url?: string; Description?: string; }
interface ISharePointChoiceField { Value?: string; value?: string; }
interface ISharePointRow { Id?: number; Rank?: string | ISharePointChoiceField; LearningThumbnail?: string | ISharePointLinkField; LearningTitle?: string; LearningDescription?: string; LearningLink?: string | ISharePointLinkField; LSlNo?: string; FeaturedLearningName?: string; FeaturedLearningLink?: string | ISharePointLinkField; FeaturedLearningDate?: string; FeaturedLearningCategory?: string; FeaturedLearningLocation?: string; FSlNo?: string; }
interface ILearningCourse { id: string; title: string; description: string; thumbnail: string; link: string; }
interface ICareerStage { name: string; courses: ILearningCourse[]; }
interface IFeaturedLearning { id: string; name: string; link: string; date?: Date; category: string; location: string; }
interface IListResponse<T> { value?: T[]; d?: { results?: T[] }; }

function readListItems<T>(payload: IListResponse<T>): T[] {
  return payload.value || (payload.d && payload.d.results) || [];
}

function readText(value: string | ISharePointChoiceField | undefined): string {
  if (typeof value === 'string') return value;
  return value ? value.Value || value.value || '' : '';
}

function readLink(value: string | ISharePointLinkField | undefined): string {
  if (typeof value === 'string') return value;
  return value ? value.Url || value.url || '' : '';
}

function readSortNumber(value: string | undefined): number {
  const parsed = Number(value);
  return isNaN(parsed) ? 999999999 : parsed;
}

function formatFeaturedDate(date?: Date): { month: string; day: string } {
  if (!date || isNaN(date.getTime())) return { month: 'TBC', day: '' };
  return {
    month: new Intl.DateTimeFormat('en', { month: 'short' }).format(date),
    day: new Intl.DateTimeFormat('en', { day: '2-digit' }).format(date)
  };
}

type IconName = 'calendar' | 'compass' | 'bulb' | 'sparkles' | 'award' | 'graduation' | 'arrowUpRight' | 'arrowDown' | 'chevronLeft' | 'chevronRight' | 'pin' | 'file' | 'mail' | 'help' | 'support' | 'arrowRight';
const iconPaths: Record<IconName, React.ReactNode> = {
  calendar: <><path d="M8 2v3M16 2v3" /><rect x="3" y="3" width="18" height="18" rx="2" /><path d="M3 9h18M8 13h.01M12 13h.01M16 13h.01M8 17h.01M12 17h.01M16 17h.01" /></>,
  compass: <><circle cx="12" cy="12" r="10" /><path d="m16.24 7.76-1.8 5.41a2 2 0 0 1-1.27 1.27l-5.41 1.8 1.8-5.41a2 2 0 0 1 1.27-1.27z" /></>,
  bulb: <><path d="M15 14c.2-1 .7-1.7 1.5-2.5A6 6 0 1 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5M9 18h6M10 22h4" /></>,
  sparkles: <><path d="M11 3a1 1 0 0 1 2 0l1 5.4a2 2 0 0 0 1.6 1.6l5.4 1a1 1 0 0 1 0 2l-5.4 1a2 2 0 0 0-1.6 1.6L13 21a1 1 0 0 1-2 0l-1-5.4a2 2 0 0 0-1.6-1.6L3 13a1 1 0 0 1 0-2l5.4-1A2 2 0 0 0 10 8.4z" /><path d="M20 2v4M22 4h-4" /><circle cx="4" cy="20" r="2" /></>,
  award: <><path d="m15.5 13 1.5 8.5a.5.5 0 0 1-.8.5l-3.6-2.7a1 1 0 0 0-1.2 0l-3.6 2.7a.5.5 0 0 1-.8-.5l1.5-8.5" /><circle cx="12" cy="8" r="6" /></>,
  graduation: <><path d="m21.4 10.9-8.6 3.9a2 2 0 0 1-1.7 0l-8.5-3.9a1 1 0 0 1 0-1.8l8.5-3.9a2 2 0 0 1 1.7 0l8.6 3.9a1 1 0 0 1 0 1.8ZM22 10v6M6 12.5V16a6 3 0 0 0 12 0v-3.5" /></>,
  arrowUpRight: <><path d="M7 7h10v10M7 17 17 7" /></>,
  arrowDown: <><path d="M12 5v14m7-7-7 7-7-7" /></>,
  chevronLeft: <path d="m15 18-6-6 6-6" />,
  chevronRight: <path d="m9 18 6-6-6-6" />,
  pin: <><path d="M20 10c0 5-5.5 10.2-7.4 11.8a1 1 0 0 1-1.2 0C9.5 20.2 4 15 4 10a8 8 0 1 1 16 0Z" /><circle cx="12" cy="10" r="3" /></>,
  file: <><path d="M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.7.7l3.6 3.6A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2zM14 2v5a1 1 0 0 0 1 1h5M8 13h8M8 17h8M8 9h2" /></>,
  mail: <><path d="m22 7-9 5.7a2 2 0 0 1-2 0L2 7" /><rect x="2" y="4" width="20" height="16" rx="2" /></>,
  help: <><circle cx="12" cy="12" r="10" /><path d="M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3M12 17h.01" /></>,
  support: <><circle cx="12" cy="12" r="10" /><path d="m4.9 4.9 4.3 4.3m5.6-.1 4.3-4.3m-4.3 9.9 4.3 4.3m-9.9-4.3-4.3 4.3" /><circle cx="12" cy="12" r="4" /></>,
  arrowRight: <><path d="M5 12h14m-7-7 7 7-7 7" /></>
};

const portalItems = [
  { eyebrow: 'Learning', title: 'Calendar', icon: 'calendar' as IconName },
  { eyebrow: 'Browse', title: 'Opportunities', icon: 'compass' as IconName },
  { eyebrow: 'SuccessFactors', title: 'Learning', icon: 'bulb' as IconName },
  { eyebrow: 'Viva', title: 'Learning', icon: 'sparkles' as IconName },
  { eyebrow: 'EY', title: 'Badges', icon: 'award' as IconName },
  { eyebrow: 'EY', title: 'Degrees', icon: 'graduation' as IconName }
];

const contactItems = [
  { title: 'Mailbox', description: 'Email the learning team', icon: 'mail' as IconName },
  { title: 'FAQ', description: 'Quick answers to common questions', icon: 'help' as IconName },
  { title: 'Support Request', description: 'Raise a ticket for help', icon: 'support' as IconName }
];

function Icon(props: { name: IconName; className?: string }): React.ReactElement {
  return <svg className={props.className} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{iconPaths[props.name]}</svg>;
}

function Brand(): React.ReactElement {
  return <div className={css.brand}><div className={css.brandMark}><span>EY</span></div><span className={css.brandTagline}>Shape the future<br />with confidence</span></div>;
}

interface IHomePageState {
  activeStage: number;
  activeFeaturedPage: number;
  careerStages: ICareerStage[];
  featuredItems: IFeaturedLearning[];
  careerLoading: boolean;
  featuredLoading: boolean;
  careerError: boolean;
  featuredError: boolean;
}

export default class HomePage extends React.Component<IHomePageProps, IHomePageState> {
  public constructor(props: IHomePageProps) {
    super(props);
    this.state = {
      activeStage: 0,
      activeFeaturedPage: 0,
      careerStages: [],
      featuredItems: [],
      careerLoading: true,
      featuredLoading: true,
      careerError: false,
      featuredError: false
    };
  }

  public componentDidMount(): void {
    this.loadCareerStages();
    this.loadFeaturedLearning();
  }

  private loadList = <T extends ISharePointRow>(url: string): Promise<T[]> => {
    return this.props.spHttpClient.get(url, SPHttpClient.configurations.v1, {
      headers: { Accept: 'application/json;odata=nometadata' }
    }).then((response) => {
      if (!response.ok) throw new Error(`SharePoint request failed: ${response.status}`);
      return response.json() as Promise<IListResponse<T>>;
    }).then(readListItems);
  };

  private loadCareerStages = (): void => {
    this.loadList<ISharePointRow>(careerStageApi).then((rows) => {
      const sortedRows = rows.slice().sort((left, right) => readSortNumber(left.LSlNo) - readSortNumber(right.LSlNo));
      const stageMap: { [rank: string]: ICareerStage } = {};
      sortedRows.forEach((row) => {
        const rank = readText(row.Rank).trim();
        const title = row.LearningTitle || '';
        if (!rank || !title) return;
        if (!stageMap[rank]) stageMap[rank] = { name: rank, courses: [] };
        stageMap[rank].courses.push({
          id: String(row.Id || row.LSlNo || `${rank}-${title}`),
          title,
          description: row.LearningDescription || '',
          thumbnail: readLink(row.LearningThumbnail),
          link: readLink(row.LearningLink)
        });
      });
      this.setState({ careerStages: Object.keys(stageMap).map((rank) => stageMap[rank]), careerLoading: false });
    }).catch(() => this.setState({ careerLoading: false, careerError: true }));
  };

  private loadFeaturedLearning = (): void => {
    this.loadList<ISharePointRow>(featuredLearningApi).then((rows) => {
      const featuredItems = rows.slice().sort((left, right) => readSortNumber(left.FSlNo) - readSortNumber(right.FSlNo)).map((row, index) => {
        const parsedDate = row.FeaturedLearningDate ? new Date(row.FeaturedLearningDate) : null;
        return {
          id: String(row.Id || row.FSlNo || index),
          name: row.FeaturedLearningName || '',
          link: readLink(row.FeaturedLearningLink),
          date: parsedDate && !isNaN(parsedDate.getTime()) ? parsedDate : undefined,
          category: row.FeaturedLearningCategory || '',
          location: row.FeaturedLearningLocation || ''
        };
      }).filter((item) => item.name);
      this.setState({ featuredItems, featuredLoading: false });
    }).catch(() => this.setState({ featuredLoading: false, featuredError: true }));
  };

  private selectStage = (activeStage: number): void => this.setState({ activeStage });
  private selectFeaturedPage = (activeFeaturedPage: number): void => this.setState({ activeFeaturedPage });

  public render(): React.ReactElement<IHomePageProps> {
    const activeStage = this.state.careerStages[this.state.activeStage];
    const pageSize = 4;
    const pageCount = Math.ceil(this.state.featuredItems.length / pageSize);
    const featuredItems = this.state.featuredItems.slice(this.state.activeFeaturedPage * pageSize, (this.state.activeFeaturedPage + 1) * pageSize);
    const pageIndexes: number[] = [];
    for (let pageIndex = 0; pageIndex < pageCount; pageIndex++) pageIndexes.push(pageIndex);

    return (
      <main className={css.homePage}>
        <section className={css.hero} id="top">
          <div className={css.heroImage} aria-hidden="true" /><div className={css.heroShade} aria-hidden="true" /><div className={css.heroGrid} aria-hidden="true" />
          <div className={css.heroInner}>
            <header className={css.header}><a className={css.brandLink} href="#top" aria-label="MENA Learning Hub home"><Brand /></a><nav className={css.navigation} aria-label="Main navigation"><a href="#featured">Featured</a><a href="#stages">Career stages</a><a href="#contact">Contact</a></nav></header>
            <div className={css.heroCopy}><h1>MENA<br /><span>Learning Hub</span></h1><p>Everything you need to grow your career, in one place. Discover programs, earn credentials, and learn with colleagues across the region.</p></div>
            <div className={css.portalArea} id="portals"><div className={css.portalGrid}>{portalItems.map((item) => <div className={css.portalCard} key={`${item.eyebrow}-${item.title}`}><span className={css.portalGlow} aria-hidden="true" /><span className={css.portalContent}><span className={css.portalTop}><span className={css.portalIcon}><Icon name={item.icon} /></span><Icon name="arrowUpRight" className={css.portalArrow} /></span><span><span className={css.portalEyebrow}>{item.eyebrow}</span><span className={css.portalTitle}>{item.title}</span></span></span><span className={css.colorBar} aria-hidden="true" /></div>)}</div><a className={css.exploreLink} href="#featured">Explore <Icon name="arrowDown" /></a></div>
          </div>
        </section>

        <section id="featured" className={css.featuredSection}><div className={css.sectionInner}>
          <div className={css.sectionHeader}><div className={css.sectionTitleBlock}><p className={css.eyebrow}>Don&apos;t miss out</p><h2>Featured Learning</h2><span className={css.colorBar} aria-hidden="true" /></div>{pageCount > 1 && <div className={css.carouselControls}><div className={css.pageDots} aria-label="Featured learning pages">{pageIndexes.map((index) => <button key={index} className={index === this.state.activeFeaturedPage ? css.activeDot : ''} aria-label={`Page ${index + 1}`} aria-current={index === this.state.activeFeaturedPage ? 'page' : undefined} onClick={() => this.selectFeaturedPage(index)} />)}</div><button className={css.carouselArrow} aria-label="Previous" onClick={() => this.selectFeaturedPage((this.state.activeFeaturedPage + pageCount - 1) % pageCount)}><Icon name="chevronLeft" /></button><button className={css.carouselArrow} aria-label="Next" onClick={() => this.selectFeaturedPage((this.state.activeFeaturedPage + 1) % pageCount)}><Icon name="chevronRight" /></button></div>}</div>
          {this.state.featuredLoading ? <p className={css.dataMessage}>Loading featured learning...</p> : this.state.featuredError ? <p className={css.dataMessage}>Featured learning could not be loaded.</p> : featuredItems.length ? <div className={css.featuredGrid}>{featuredItems.map((item) => { const dateParts = formatFeaturedDate(item.date); return <article className={css.featuredCard} key={item.id}><div className={css.featuredMeta}><span className={css.dateBadge}><span>{dateParts.month}</span><strong>{dateParts.day}</strong></span>{item.category && <span className={css.category}>{item.category}</span>}</div><h3>{item.name}</h3>{item.location && <p className={css.location}><Icon name="pin" />{item.location}</p>}<div className={css.registerLine}>{item.link ? <a href={item.link} target="_blank" rel="noreferrer">View learning</a> : <span>Learning details</span>}<span className={css.registerArrow}><Icon name="arrowRight" /></span></div></article>; })}</div> : <p className={css.dataMessage}>No featured learning is available right now.</p>}
        </div></section>

        <section id="stages" className={css.stagesSection}><div className={css.stagePattern} aria-hidden="true" /><div className={css.sectionInner}>
          <div className={css.sectionTitleBlock}><p className={css.eyebrow}>Grow at every level</p><h2>Learning by Career Stage</h2><span className={css.colorBar} aria-hidden="true" /></div>
          {this.state.careerLoading ? <p className={css.stageDescription}>Loading career-stage learning...</p> : this.state.careerError ? <p className={css.stageDescription}>Career-stage learning could not be loaded.</p> : activeStage ? <><div className={css.stageTabs} role="group" aria-label="Career stage">{this.state.careerStages.map((stage, index) => <button type="button" key={stage.name} aria-pressed={this.state.activeStage === index} onClick={() => this.selectStage(index)}><span className={css.stageNumber}>{index + 1}</span>{stage.name}</button>)}</div><div className={css.courseGrid}>{activeStage.courses.map((course) => <article className={css.courseCard} key={course.id}><a className={css.courseLink} href={course.link || undefined} target={course.link ? '_blank' : undefined} rel={course.link ? 'noreferrer' : undefined}><div className={css.courseImageWrap}>{course.thumbnail ? <img src={course.thumbnail} alt={course.title} loading="lazy" /> : <span className={css.courseImageFallback} aria-hidden="true"><Icon name="file" /></span>}<span className={css.courseIcon}><Icon name="file" /></span></div><div className={css.courseContent}><h3>{course.title}</h3>{course.description && <p>{course.description}</p>}</div></a></article>)}</div></> : <p className={css.stageDescription}>No career-stage learning is available right now.</p>}
        </div></section>

        <footer id="contact" className={css.footer}><span className={css.footerColorBar} aria-hidden="true" /><div className={css.sectionInner}>
          <div className={css.contactGrid}><div className={css.contactIntro}><p className={css.eyebrow}>We&apos;re here to help</p><h2>Contact the Learning Team</h2><p>Questions about a program, registration, or your learning record? Reach out any time.</p></div><div className={css.contactCards}>{contactItems.map((item) => <div className={css.contactCard} key={item.title}><Icon name={item.icon} className={css.contactIcon} /><span><strong>{item.title}<Icon name="arrowRight" className={css.contactArrow} /></strong><small>{item.description}</small></span></div>)}</div></div>
          <div className={css.footerBottom}><Brand /><p>© 2026 EY MENA Learning. All rights reserved.</p></div>
        </div></footer>
      </main>
    );
  }
}
