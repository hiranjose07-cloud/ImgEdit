import type { SPHttpClient } from '@microsoft/sp-http';

export interface IHomePageProps {
  description: string;
  isDarkTheme: boolean;
  environmentMessage: string;
  hasTeamsContext: boolean;
  userDisplayName: string;
  spHttpClient: SPHttpClient;
}
