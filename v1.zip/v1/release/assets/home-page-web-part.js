define("ebc404b0-c2df-41b6-ac41-fd90a265f239_0.0.1", ["react","react-dom","@microsoft/sp-core-library","@microsoft/sp-property-pane","@microsoft/sp-webpart-base","HomePageWebPartStrings","@microsoft/sp-http"], (__WEBPACK_EXTERNAL_MODULE__959__, __WEBPACK_EXTERNAL_MODULE__398__, __WEBPACK_EXTERNAL_MODULE__676__, __WEBPACK_EXTERNAL_MODULE__877__, __WEBPACK_EXTERNAL_MODULE__642__, __WEBPACK_EXTERNAL_MODULE__299__, __WEBPACK_EXTERNAL_MODULE__909__) => { return /******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 591:
/*!**************************************************************!*\
  !*** ./lib/webparts/homePage/components/HomePage.module.css ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_microsoft_sp_css_loader_node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/@microsoft/sp-css-loader/node_modules/@microsoft/load-themed-styles/lib-es6/index.js */ 323);
// Imports


_node_modules_microsoft_sp_css_loader_node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__.loadStyles(".homePage_c565b63f{--hub-bg:#17171d;--hub-panel:#202027;--hub-text:#f7f7f5;--hub-muted:#b7b7bd;--hub-yellow:#ffe600;--hub-pink:#e8288f;--hub-cyan:#29c3e0;background:var(--hub-bg);color:var(--hub-text);height:100vh;left:0;line-height:1.5;overflow:hidden;overflow:auto;position:fixed;scroll-behavior:smooth;top:0;width:100%;z-index:999999}.homePage_c565b63f,.homePage_c565b63f button{font-family:Arial,sans-serif}.hero_c565b63f{isolation:isolate;min-height:100svh;overflow:hidden;position:relative}.heroGrid_c565b63f,.heroImage_c565b63f,.heroShade_c565b63f{inset:0;pointer-events:none;position:absolute}.heroImage_c565b63f{background:url(https://images.unsplash.com/photo-1541746972996-4e0b0f43e02a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=2000) center 42%/cover no-repeat;transform:scale(1.06);z-index:-3}.heroShade_c565b63f{background:linear-gradient(180deg,rgba(23,23,29,.76),rgba(23,23,29,.82) 52%,#17171d),linear-gradient(90deg,rgba(23,23,29,.94),rgba(23,23,29,.44) 64%,transparent);z-index:-2}.heroGrid_c565b63f{background-image:linear-gradient(90deg,#fff 1px,transparent 0),linear-gradient(#fff 1px,transparent 0);background-size:64px 64px;mask-image:radial-gradient(at 30% 40%,#000 20%,transparent 70%);opacity:.06;z-index:-1}.heroInner_c565b63f,.sectionInner_c565b63f{margin-inline:auto;width:min(100% - 40px,1280px)}.heroInner_c565b63f{display:flex;flex-direction:column;min-height:100svh}.header_c565b63f{align-items:center;display:flex;gap:24px;justify-content:space-between;padding-block:24px}.brandLink_c565b63f{color:inherit;text-decoration:none}.brand_c565b63f{align-items:flex-end;display:flex;gap:10px}.brandMark_c565b63f{font-size:30px;font-weight:750;letter-spacing:0;line-height:.95;position:relative}.brandMark_c565b63f:before{background:var(--hub-yellow);content:\"\";height:7px;left:0;position:absolute;top:-9px;transform:skewY(-12deg);transform-origin:left;width:36px}.brandTagline_c565b63f{color:hsla(0,0%,100%,.82);font-size:11px;font-weight:550;line-height:1.15}.navigation_c565b63f{align-items:center;backdrop-filter:blur(12px);background:hsla(0,0%,100%,.05);border:1px solid hsla(0,0%,100%,.12);border-radius:999px;display:flex;gap:3px;padding:4px}.navigation_c565b63f a{border-radius:999px;color:hsla(0,0%,100%,.82);font-size:14px;padding:9px 16px;text-decoration:none;transition:background-color .18s,color .18s}.navigation_c565b63f a:focus-visible,.navigation_c565b63f a:hover{background:var(--hub-yellow);color:#17171d;outline:0}.heroCopy_c565b63f{animation:riseIn_c565b63f .7s ease-out both;display:flex;flex:1;flex-direction:column;justify-content:center;max-width:700px;padding:36px 0 0}.heroCopy_c565b63f h1{font-size:clamp(48px,7vw,88px);font-weight:650;line-height:.98;margin:0}.heroCopy_c565b63f h1 span{background:linear-gradient(90deg,var(--hub-yellow),#ffb800);background-clip:text;color:transparent}.heroCopy_c565b63f>p{color:hsla(0,0%,100%,.78);font-size:18px;margin:20px 0 0;max-width:590px}.portalArea_c565b63f{padding-bottom:24px}.portalGrid_c565b63f{display:grid;gap:16px;grid-template-columns:repeat(6,minmax(0,1fr))}.portalCard_c565b63f{animation:riseIn_c565b63f .65s ease-out both;backdrop-filter:blur(20px);background:hsla(0,0%,100%,.055);border:1px solid hsla(0,0%,100%,.12);border-radius:12px;color:inherit;display:flex;flex-direction:column;min-width:0;overflow:hidden;position:relative;text-align:left;text-decoration:none;transition:border-color .2s,background-color .2s,transform .2s}.portalCard_c565b63f:nth-child(2){animation-delay:60ms}.portalCard_c565b63f:nth-child(3){animation-delay:.12s}.portalCard_c565b63f:nth-child(4){animation-delay:.18s}.portalCard_c565b63f:nth-child(5){animation-delay:.24s}.portalCard_c565b63f:nth-child(6){animation-delay:.3s}.portalCard_c565b63f:focus-visible,.portalCard_c565b63f:hover{background:hsla(0,0%,100%,.11);border-color:rgba(255,230,0,.65);outline:0;transform:translateY(-3px)}.portalGlow_c565b63f{background:0 0;border-radius:50%;filter:blur(35px);height:128px;position:absolute;right:-40px;top:-40px;transition:background-color .3s;width:128px}.portalCard_c565b63f:hover .portalGlow_c565b63f{background:rgba(255,230,0,.24)}.portalContent_c565b63f{display:flex;flex:1;flex-direction:column;gap:8px;padding:16px;position:relative}.portalTop_c565b63f{align-items:flex-start;display:flex;justify-content:space-between}.portalIcon_c565b63f{background:hsla(0,0%,100%,.1);border-radius:9px;display:grid;height:40px;place-items:center;transition:transform .2s,background-color .2s,color .2s;width:40px}.portalIcon_c565b63f svg{height:20px;width:20px}.portalCard_c565b63f:hover .portalIcon_c565b63f{background:var(--hub-yellow);color:#17171d;transform:rotate(-8deg)}.portalArrow_c565b63f{color:var(--hub-muted);height:20px;opacity:0;transform:translate(-4px,4px);transition:opacity .2s,transform .2s,color .2s;width:20px}.portalCard_c565b63f:hover .portalArrow_c565b63f{color:var(--hub-yellow);opacity:1;transform:none}.portalEyebrow_c565b63f,.portalTitle_c565b63f{display:block}.portalEyebrow_c565b63f{color:var(--hub-yellow);font-size:12px;font-weight:650}.portalTitle_c565b63f{font-size:18px;font-weight:650;margin-top:2px}.colorBar_c565b63f,.footerColorBar_c565b63f{background:linear-gradient(90deg,var(--hub-yellow),var(--hub-pink),var(--hub-cyan));display:block;height:4px;width:100%}.portalCard_c565b63f .colorBar_c565b63f{transform:scaleX(.5);transform-origin:left;transition:transform .35s}.portalCard_c565b63f:hover .colorBar_c565b63f{transform:scaleX(1)}.exploreLink_c565b63f{align-items:center;color:var(--hub-muted);display:flex;font-size:11px;gap:8px;justify-content:center;letter-spacing:.14em;margin:16px auto 0;text-decoration:none;text-transform:uppercase;width:fit-content}.exploreLink_c565b63f:hover{color:var(--hub-yellow)}.exploreLink_c565b63f svg{height:16px;width:16px}.featuredSection_c565b63f{background:var(--hub-bg);padding-block:104px}.sectionHeader_c565b63f{align-items:flex-end;display:flex;gap:24px;justify-content:space-between}.sectionTitleBlock_c565b63f{align-items:flex-start;display:flex;flex-direction:column;gap:12px}.eyebrow_c565b63f{color:var(--hub-yellow);font-size:12px;font-weight:700;letter-spacing:.2em;margin:0;text-transform:uppercase}.contactIntro_c565b63f h2,.sectionTitleBlock_c565b63f h2{font-size:clamp(30px,4vw,50px);font-weight:650;line-height:1.08;margin:0}.sectionTitleBlock_c565b63f>.colorBar_c565b63f{width:96px}.carouselControls_c565b63f{align-items:center;display:flex;gap:12px}.pageDots_c565b63f{align-items:center;display:flex;gap:6px}.pageDots_c565b63f button{background:hsla(0,0%,100%,.24);border:0;border-radius:999px;cursor:pointer;height:6px;padding:0;transition:width .2s,background-color .2s;width:12px}.pageDots_c565b63f button:hover{background:hsla(0,0%,100%,.48)}.pageDots_c565b63f button.activeDot_c565b63f{background:var(--hub-yellow);width:32px}.carouselArrow_c565b63f{background:0 0;border:1px solid hsla(0,0%,100%,.2);border-radius:50%;color:var(--hub-text);cursor:pointer;display:grid;height:44px;place-items:center;transition:.2s;width:44px}.carouselArrow_c565b63f svg{height:20px;width:20px}.carouselArrow_c565b63f:focus-visible,.carouselArrow_c565b63f:hover{background:var(--hub-yellow);border-color:var(--hub-yellow);color:#17171d;outline:0}.featuredGrid_c565b63f{display:grid;gap:16px;grid-template-columns:repeat(4,minmax(0,1fr));margin-top:48px}.featuredCard_c565b63f{animation:riseIn_c565b63f .4s ease-out both;background:var(--hub-panel);border:1px solid hsla(0,0%,100%,.12);border-radius:14px;display:flex;flex-direction:column;min-height:250px;overflow:hidden;padding:18px;position:relative}.featuredCard_c565b63f:before{background:linear-gradient(135deg,rgba(255,230,0,0),rgba(232,40,143,0));content:\"\";inset:0;pointer-events:none;position:absolute;transition:background .3s}.featuredCard_c565b63f:hover:before{background:linear-gradient(135deg,rgba(255,230,0,.08),rgba(232,40,143,.08))}.featuredCard_c565b63f h3,.featuredMeta_c565b63f,.location_c565b63f,.registerLine_c565b63f{position:relative}.featuredMeta_c565b63f{align-items:flex-start;display:flex;gap:8px;justify-content:space-between}.dateBadge_c565b63f{align-items:center;background:hsla(0,0%,100%,.07);border-radius:9px;display:flex;flex-direction:column;min-width:54px;padding:7px 10px;transition:.2s}.featuredCard_c565b63f:hover .dateBadge_c565b63f{background:var(--hub-yellow);color:#17171d}.dateBadge_c565b63f span{font-size:10px;font-weight:700;letter-spacing:.1em;text-transform:uppercase}.dateBadge_c565b63f strong{font-size:24px;line-height:1.15}.category_c565b63f{border:1px solid hsla(0,0%,100%,.12);border-radius:999px;color:var(--hub-muted);font-size:11px;padding:5px 10px}.featuredCard_c565b63f h3{font-size:20px;font-weight:650;line-height:1.25;margin:20px 0 0}.location_c565b63f{align-items:center;color:var(--hub-muted);display:flex;font-size:12px;gap:6px;margin:9px 0 0}.location_c565b63f svg{height:14px;width:14px}.registerLine_c565b63f{align-items:center;border-top:1px solid hsla(0,0%,100%,.12);color:var(--hub-yellow);display:flex;font-size:14px;justify-content:space-between;margin-top:auto;padding-top:14px}.registerLine_c565b63f a{color:inherit;text-decoration:none}.registerLine_c565b63f a:hover{text-decoration:underline}.registerArrow_c565b63f{background:rgba(255,230,0,.1);border-radius:50%;display:grid;height:36px;place-items:center;transition:.2s;width:36px}.registerArrow_c565b63f svg{height:16px;width:16px}.featuredCard_c565b63f:hover .registerArrow_c565b63f{background:var(--hub-yellow);color:#17171d;transform:rotate(-45deg)}.dataMessage_c565b63f{color:var(--hub-muted);margin:28px 0 0}.stagesSection_c565b63f{background:#f4f4f6;color:#1f1f28;overflow:hidden;padding-block:104px;position:relative}.stagePattern_c565b63f{background-image:radial-gradient(#c9c9d4 1px,transparent 0);background-size:22px 22px;inset:0;mask-image:linear-gradient(270deg,#000,transparent 70%);opacity:.5;pointer-events:none;position:absolute}.stagesSection_c565b63f .sectionInner_c565b63f{position:relative}.stagesSection_c565b63f .eyebrow_c565b63f{color:#806f00}.stageTabs_c565b63f{background:#fff;border-radius:999px;box-shadow:0 1px 3px rgba(0,0,0,.1);display:flex;gap:4px;margin-top:42px;max-width:100%;overflow-x:auto;padding:6px;width:max-content}.stageTabs_c565b63f button{align-items:center;background:0 0;border:0;border-radius:999px;color:rgba(31,31,40,.68);cursor:pointer;display:flex;flex:0 0 auto;font-size:14px;font-weight:600;gap:8px;padding:9px 16px;transition:color .2s,background-color .2s}.stageTabs_c565b63f button[aria-pressed=true]{background:#1f1f28;color:#fff}.stageTabs_c565b63f button:focus-visible{outline:2px solid #806f00;outline-offset:2px}.stageNumber_c565b63f{background:rgba(0,0,0,.08);border-radius:50%;color:#1f1f28;display:grid;font-size:10px;font-weight:750;height:21px;place-items:center;width:21px}.stageTabs_c565b63f button[aria-pressed=true] .stageNumber_c565b63f{background:var(--hub-yellow)}.stageDescription_c565b63f{color:rgba(31,31,40,.74);font-size:18px;margin:30px 0 0}.courseGrid_c565b63f{display:grid;gap:24px;grid-template-columns:repeat(3,minmax(0,1fr));margin-top:28px}.courseCard_c565b63f{background:#fff;border-radius:14px;box-shadow:0 1px 4px rgba(0,0,0,.1);overflow:hidden;transition:box-shadow .25s,transform .25s}.courseCard_c565b63f:hover{box-shadow:0 16px 35px rgba(0,0,0,.16);transform:translateY(-3px)}.courseLink_c565b63f{color:inherit;display:block;text-decoration:none}.courseImageWrap_c565b63f{height:208px;overflow:hidden;position:relative}.courseImageWrap_c565b63f:after{background:linear-gradient(0deg,rgba(0,0,0,.5),transparent 55%);content:\"\";inset:0;pointer-events:none;position:absolute}.courseImageWrap_c565b63f img{height:100%;object-fit:cover;transition:transform .5s;width:100%}.courseCard_c565b63f:hover img{transform:scale(1.06)}.courseImageFallback_c565b63f{background:linear-gradient(135deg,#2a2a31,#45454d);color:var(--hub-yellow);display:grid;height:100%;place-items:center;width:100%}.courseImageFallback_c565b63f svg{height:40px;width:40px}.courseIcon_c565b63f{background:var(--hub-yellow);border-radius:50%;bottom:12px;box-shadow:0 6px 15px rgba(0,0,0,.18);color:#1f1f28;display:grid;height:44px;place-items:center;position:absolute;right:18px;transition:transform .2s;width:44px;z-index:1}.courseIcon_c565b63f svg{height:20px;width:20px}.courseCard_c565b63f:hover .courseIcon_c565b63f{transform:rotate(12deg) scale(1.06)}.courseContent_c565b63f{padding:24px}.courseContent_c565b63f h3{font-size:18px;font-weight:650;margin:0}.courseContent_c565b63f p{color:rgba(31,31,40,.68);font-size:14px;line-height:1.55;margin:6px 0 0}.footer_c565b63f{background:var(--hub-bg);overflow:hidden;position:relative}.footerColorBar_c565b63f{height:4px}.footer_c565b63f .sectionInner_c565b63f{padding-block:80px 28px}.contactGrid_c565b63f{align-items:center;display:grid;gap:48px;grid-template-columns:1fr 1.3fr}.contactIntro_c565b63f h2{margin-top:12px}.contactIntro_c565b63f>p:last-child{color:var(--hub-muted);margin:16px 0 0;max-width:400px}.contactCards_c565b63f{display:grid;gap:12px;grid-template-columns:repeat(3,minmax(0,1fr))}.contactCard_c565b63f{background:var(--hub-panel);border:1px solid hsla(0,0%,100%,.12);border-radius:14px;color:inherit;display:flex;flex-direction:column;gap:16px;justify-content:space-between;min-height:130px;padding:16px;text-decoration:none;transition:border-color .2s}.contactCard_c565b63f:focus-visible,.contactCard_c565b63f:hover{border-color:rgba(255,230,0,.65);outline:0}.contactIcon_c565b63f{color:var(--hub-yellow);height:24px;width:24px}.contactCard_c565b63f strong{align-items:center;display:flex;font-size:14px;gap:8px}.contactCard_c565b63f small{color:var(--hub-muted);display:block;font-size:11px;margin-top:5px}.contactArrow_c565b63f{height:16px;opacity:0;transform:translateX(-6px);transition:.2s;width:16px}.contactCard_c565b63f:hover .contactArrow_c565b63f{opacity:1;transform:none}.footerBottom_c565b63f{align-items:center;border-top:1px solid hsla(0,0%,100%,.12);display:flex;gap:24px;justify-content:space-between;margin-top:64px;padding-top:28px}.footerBottom_c565b63f>p{color:var(--hub-muted);font-size:12px;margin:0}@keyframes riseIn_c565b63f{0%{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}@media (min-width:1024px) and (max-width:1599px){.heroCopy_c565b63f h1{font-size:65px}}@media (min-width:768px){.heroInner_c565b63f,.sectionInner_c565b63f{width:min(100% - 64px,1280px)}.heroCopy_c565b63f{padding-top:32px}}@media (max-width:1023px){.portalGrid_c565b63f{grid-template-columns:repeat(3,minmax(0,1fr))}.featuredGrid_c565b63f{grid-template-columns:repeat(2,minmax(0,1fr))}.contactGrid_c565b63f{grid-template-columns:1fr}}@media (max-width:767px){.heroInner_c565b63f,.hero_c565b63f{min-height:auto}.heroInner_c565b63f,.sectionInner_c565b63f{width:min(100% - 36px,1280px)}.header_c565b63f{padding-block:20px}.navigation_c565b63f{display:none}.heroCopy_c565b63f{min-height:340px;padding:34px 0 0}.heroCopy_c565b63f h1{font-size:clamp(46px,13vw,66px)}.heroCopy_c565b63f>p{font-size:16px}.portalGrid_c565b63f{gap:10px;grid-template-columns:repeat(2,minmax(0,1fr))}.portalContent_c565b63f{gap:10px;padding:12px}.portalIcon_c565b63f{height:34px;width:34px}.portalIcon_c565b63f svg{height:18px;width:18px}.portalTitle_c565b63f{font-size:15px}.portalArrow_c565b63f{opacity:.75;transform:none}.exploreLink_c565b63f{display:none}.featuredSection_c565b63f,.stagesSection_c565b63f{padding-block:72px}.sectionHeader_c565b63f{align-items:flex-start;flex-direction:column}.carouselControls_c565b63f{align-self:flex-end}.featuredGrid_c565b63f{gap:12px;margin-top:28px}.featuredCard_c565b63f{min-height:220px;padding:14px}.category_c565b63f{font-size:10px}.featuredCard_c565b63f h3{font-size:17px;margin-top:16px}.stageTabs_c565b63f{border-radius:14px;width:100%}.courseGrid_c565b63f{gap:16px;grid-template-columns:1fr}.courseImageWrap_c565b63f{height:220px}.footer_c565b63f .sectionInner_c565b63f{padding-top:64px}.contactCards_c565b63f{grid-template-columns:1fr}.contactCard_c565b63f{min-height:108px;padding:14px}.footerBottom_c565b63f{align-items:flex-start;flex-direction:column;margin-top:44px}}@media (prefers-reduced-motion:reduce){*,:after,:before{animation-duration:0s!important;animation-iteration-count:1!important;scroll-behavior:auto!important;transition-duration:0s!important}}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovTUVOQUxlYXJuaW5nL3NyYy93ZWJwYXJ0cy9ob21lUGFnZS9jb21wb25lbnRzL0hvbWVQYWdlLm1vZHVsZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVBLG1CQUNFLGdCQUFBLENBQ0EsbUJBQUEsQ0FDQSxrQkFBQSxDQUNBLG1CQUFBLENBQ0Esb0JBQUEsQ0FDQSxrQkFBQSxDQUNBLGtCQUFBLENBR0Esd0JBQUEsQ0FDQSxxQkFBQSxDQUlFLFlBQUEsQ0FFQSxNQUFBLENBSkYsZUFBQSxDQUxBLGVBQUEsQ0FRRSxhQUFBLENBSG1CLGNBQUEsQ0FKckIsc0JBQUEsQ0FTRSxLQUFBLENBSkEsVUFBQSxDQUtBLGNBQUEsQ0FHSiw2Q0FWRSw0QkFVaUIsQ0FFbkIsZUFBNEIsaUJBQUEsQ0FBc0MsaUJBQUEsQ0FBbEIsZUFBQSxDQUF4QyxpQkFBMEQsQ0FDbEUsMkRBQXdELE9BQUEsQ0FBVSxtQkFBQSxDQUE5QixpQkFBOEIsQ0FDbEUsb0JBQTBCLDJKQUFBLENBQWtLLHFCQUFBLENBQS9LLFVBQStLLENBQzVMLG9CQUEwQixpS0FBQSxDQUFiLFVBQWEsQ0FDMUIsbUJBQXVDLHNHQUFBLENBQW9ILHlCQUFBLENBQTRCLCtEQUFBLENBQTlKLFdBQUEsQ0FBYixVQUEySyxDQUN2TCwyQ0FBNkQsa0JBQUEsQ0FBakMsNkJBQWlDLENBQzdELG9CQUFpQyxZQUFBLENBQWUscUJBQUEsQ0FBbkMsaUJBQW1DLENBQ2hELGlCQUF5QixrQkFBQSxDQUFmLFlBQUEsQ0FBb0UsUUFBQSxDQUFoQyw2QkFBQSxDQUEyQyxrQkFBQSxDQUN6RixvQkFBYSxhQUFBLENBQWdCLG9CQUFBLENBQzdCLGdCQUF3QixvQkFBQSxDQUFmLFlBQUEsQ0FBc0MsUUFBQSxDQUMvQyxvQkFBaUMsY0FBQSxDQUFpQixlQUFBLENBQW9DLGdCQUFBLENBQWxCLGVBQUEsQ0FBdkQsaUJBQXlFLENBQ3RGLDJCQUFvRyw0QkFBQSxDQUEvRSxVQUFBLENBQWtFLFVBQUEsQ0FBakMsTUFBQSxDQUFwQixpQkFBQSxDQUE2QixRQUFBLENBQW9FLHVCQUFBLENBQTBCLHFCQUFBLENBQW5GLFVBQW1GLENBQzdKLHVCQUFnQix5QkFBQSxDQUE4QixjQUFBLENBQWlCLGVBQUEsQ0FBa0IsZ0JBQUEsQ0FDakYscUJBQTZCLGtCQUFBLENBQStJLDBCQUFBLENBQW5DLDhCQUFBLENBQS9ELG9DQUFBLENBQXlDLG1CQUFBLENBQXJHLFlBQUEsQ0FBb0MsT0FBQSxDQUFVLFdBQWdILENBQzVLLHVCQUFtQyxtQkFBQSxDQUFzQix5QkFBQSxDQUE4QixjQUFBLENBQXZFLGdCQUFBLENBQXdGLG9CQUFBLENBQXVCLDJDQUFBLENBQy9ILGtFQUFtRCw0QkFBQSxDQUErQixhQUFBLENBQWdCLFNBQUEsQ0FDbEcsbUJBQTBILDJDQUFBLENBQW5GLFlBQUEsQ0FBVCxNQUFBLENBQXdCLHFCQUFBLENBQXdCLHNCQUFBLENBQWxFLGVBQUEsQ0FBMkYsZ0JBQW1CLENBQzFILHNCQUEwQiw4QkFBQSxDQUFtQyxlQUFBLENBQWtCLGVBQUEsQ0FBaEUsUUFBZ0UsQ0FDL0UsMkJBQW9CLDJEQUFBLENBQWdFLG9CQUFBLENBQXVCLGlCQUFBLENBQzNHLHFCQUFvRCx5QkFBQSxDQUE4QixjQUFBLENBQWhELGVBQUEsQ0FBbEIsZUFBa0UsQ0FDbEYscUJBQWMsbUJBQUEsQ0FDZCxxQkFBYyxZQUFBLENBQWlFLFFBQUEsQ0FBbEQsNkNBQWtELENBQy9FLHFCQUFvVyw0Q0FBQSxDQUFoRywwQkFBQSxDQUE3RiwrQkFBQSxDQUE5RCxvQ0FBQSxDQUF5QyxrQkFBQSxDQUF5RCxhQUFBLENBQXpLLFlBQUEsQ0FBZSxxQkFBQSxDQUF3QixXQUFBLENBQWMsZUFBQSxDQUF6RSxpQkFBQSxDQUE2TSxlQUFBLENBQWtCLG9CQUFBLENBQW9ELDhEQUFtRSxDQUNwVyxrQ0FBMkIsb0JBQUEsQ0FBd0Isa0NBQTJCLG9CQUFBLENBQXdCLGtDQUEyQixvQkFBQSxDQUF3QixrQ0FBMkIsb0JBQUEsQ0FBd0Isa0NBQTJCLG1CQUFBLENBQ3ZPLDhEQUFrRiw4QkFBQSxDQUFuQyxnQ0FBQSxDQUFtRyxTQUFBLENBQTdCLDBCQUE2QixDQUNsSixxQkFBNkcsY0FBQSxDQUFwQixpQkFBQSxDQUE2QyxpQkFBQSxDQUE1RCxZQUFBLENBQTVELGlCQUFBLENBQWdDLFdBQUEsQ0FBWixTQUFBLENBQXdILCtCQUFBLENBQTlGLFdBQThGLENBQzFKLGdEQUFnQyw4QkFBQSxDQUNoQyx3QkFBcUMsWUFBQSxDQUFlLE1BQUEsQ0FBUyxxQkFBQSxDQUF3QixPQUFBLENBQVUsWUFBQSxDQUE5RSxpQkFBOEUsQ0FDL0Ysb0JBQTRCLHNCQUFBLENBQWYsWUFBQSxDQUF3Qyw2QkFBQSxDQUNyRCxxQkFBaUcsNkJBQUEsQ0FBcEIsaUJBQUEsQ0FBL0QsWUFBQSxDQUE0QixXQUFBLENBQWMsa0JBQUEsQ0FBMkUsdURBQUEsQ0FBdEcsVUFBc0csQ0FDbkkseUJBQStCLFdBQUEsQ0FBYixVQUFhLENBQy9CLGdEQUEwRCw0QkFBQSxDQUErQixhQUFBLENBQXpELHVCQUF5RCxDQUN6RixzQkFBMEMsc0JBQUEsQ0FBZCxXQUFBLENBQXVDLFNBQUEsQ0FBWSw2QkFBQSxDQUFpQyw4Q0FBQSxDQUFqRyxVQUFpRyxDQUNoSCxpREFBNkMsdUJBQUEsQ0FBWixTQUFBLENBQXNDLGNBQUEsQ0FDdkUsOENBQStCLGFBQUEsQ0FDL0Isd0JBQWlCLHVCQUFBLENBQTBCLGNBQUEsQ0FBaUIsZUFBQSxDQUM1RCxzQkFBZ0MsY0FBQSxDQUFpQixlQUFBLENBQWxDLGNBQWtDLENBQ2pELDRDQUF1RSxtRkFBQSxDQUExQyxhQUFBLENBQWdCLFVBQUEsQ0FBYSxVQUFhLENBQ3ZFLHdDQUF3QixvQkFBQSxDQUF1QixxQkFBQSxDQUF3Qix5QkFBQSxDQUN2RSw4Q0FBOEIsbUJBQUEsQ0FDOUIsc0JBQThCLGtCQUFBLENBQWlHLHNCQUFBLENBQWhILFlBQUEsQ0FBeUksY0FBQSxDQUE1RSxPQUFBLENBQXpCLHNCQUFBLENBQXNILG9CQUFBLENBQS9ELGtCQUFBLENBQWlILG9CQUFBLENBQTNCLHdCQUFBLENBQTFHLGlCQUFxSSxDQUMzTiw0QkFBcUIsdUJBQUEsQ0FBMkIsMEJBQWdDLFdBQUEsQ0FBYixVQUFhLENBRWhGLDBCQUF5Qyx3QkFBQSxDQUF0QixtQkFBc0IsQ0FDekMsd0JBQWdDLG9CQUFBLENBQWYsWUFBQSxDQUFzRSxRQUFBLENBQWhDLDZCQUFnQyxDQUN2Riw0QkFBNEQsc0JBQUEsQ0FBdkMsWUFBQSxDQUFlLHFCQUFBLENBQWlELFFBQUEsQ0FDckYsa0JBQXNCLHVCQUFBLENBQTBCLGNBQUEsQ0FBaUIsZUFBQSxDQUFrQixtQkFBQSxDQUF4RSxRQUFBLENBQThGLHdCQUFBLENBQ3pHLHlEQUFxRCw4QkFBQSxDQUFtQyxlQUFBLENBQWtCLGdCQUFBLENBQWhFLFFBQWdFLENBQzFHLCtDQUFpQyxVQUFBLENBQ2pDLDJCQUFtQyxrQkFBQSxDQUFmLFlBQUEsQ0FBb0MsUUFBQSxDQUN4RCxtQkFBMkIsa0JBQUEsQ0FBZixZQUFBLENBQW9DLE9BQUEsQ0FDaEQsMEJBQTBGLDhCQUFBLENBQWpDLFFBQUEsQ0FBVyxtQkFBQSxDQUF5RCxjQUFBLENBQTdGLFVBQUEsQ0FBYSxTQUFBLENBQWlHLHlDQUFBLENBQTNILFVBQTJILENBQzlJLGdDQUF5Qiw4QkFBQSxDQUFvQyw2Q0FBMEMsNEJBQUEsQ0FBYixVQUFhLENBQ3ZHLHdCQUE0SSxjQUFBLENBQTVELG1DQUFBLENBQXdDLGlCQUFBLENBQTZDLHFCQUFBLENBQXdCLGNBQUEsQ0FBNUssWUFBQSxDQUE0QixXQUFBLENBQWMsa0JBQUEsQ0FBbUosY0FBQSxDQUE5SyxVQUE4SyxDQUM5TSw0QkFBa0MsV0FBQSxDQUFiLFVBQWEsQ0FBZSxvRUFBc0YsNEJBQUEsQ0FBakMsOEJBQUEsQ0FBZ0UsYUFBQSxDQUFnQixTQUFBLENBQ3RMLHVCQUFnQixZQUFBLENBQWlFLFFBQUEsQ0FBbEQsNkNBQUEsQ0FBNkQsZUFBQSxDQUM1Rix1QkFBMk4sMkNBQUEsQ0FBOUIsMkJBQUEsQ0FBOUQsb0NBQUEsQ0FBeUMsa0JBQUEsQ0FBcEksWUFBQSxDQUFrQyxxQkFBQSxDQUFuQixnQkFBQSxDQUEyQyxlQUFBLENBQWtCLFlBQUEsQ0FBaEcsaUJBQTJNLENBQzNOLDhCQUFtRSx1RUFBQSxDQUEzQyxVQUFBLENBQWlDLE9BQUEsQ0FBa0gsbUJBQUEsQ0FBdEksaUJBQUEsQ0FBMEcseUJBQTRCLENBQXVCLG9DQUE4QiwyRUFBQSxDQUNoTywyRkFBNEQsaUJBQUEsQ0FBcUIsdUJBQStCLHNCQUFBLENBQWYsWUFBQSxDQUF3RSxPQUFBLENBQWhDLDZCQUFnQyxDQUN6SyxvQkFBcUUsa0JBQUEsQ0FBNEQsOEJBQUEsQ0FBcEIsaUJBQUEsQ0FBaEcsWUFBQSxDQUFnQyxxQkFBQSxDQUFqQixjQUFBLENBQThELGdCQUFBLENBQTBFLGNBQUEsQ0FBa0IsaURBQWlDLDRCQUFBLENBQStCLGFBQUEsQ0FDdFAseUJBQWtCLGNBQUEsQ0FBaUIsZUFBQSxDQUFrQixtQkFBQSxDQUFzQix3QkFBQSxDQUE0QiwyQkFBb0IsY0FBQSxDQUFpQixnQkFBQSxDQUM1SSxtQkFBK0Isb0NBQUEsQ0FBeUMsbUJBQUEsQ0FBc0Isc0JBQUEsQ0FBeUIsY0FBQSxDQUEzRyxnQkFBMkcsQ0FDdkgsMEJBQXFDLGNBQUEsQ0FBaUIsZUFBQSxDQUFrQixnQkFBQSxDQUFyRCxlQUFxRCxDQUFvQixtQkFBMkIsa0JBQUEsQ0FBZ0Qsc0JBQUEsQ0FBL0QsWUFBQSxDQUF3RixjQUFBLENBQXBELE9BQUEsQ0FBVSxjQUEwQyxDQUFrQix1QkFBNkIsV0FBQSxDQUFiLFVBQWEsQ0FDL08sdUJBQStCLGtCQUFBLENBQTBGLHdDQUFBLENBQTZDLHVCQUFBLENBQXRKLFlBQUEsQ0FBZ0wsY0FBQSxDQUE1SSw2QkFBQSxDQUFnQyxlQUFBLENBQWtCLGdCQUEwRixDQUNoTSx5QkFBa0IsYUFBQSxDQUFnQixvQkFBQSxDQUF3QiwrQkFBd0IseUJBQUEsQ0FDbEYsd0JBQW9HLDZCQUFBLENBQXBCLGlCQUFBLENBQS9ELFlBQUEsQ0FBNEIsV0FBQSxDQUFjLGtCQUFBLENBQXlFLGNBQUEsQ0FBcEcsVUFBb0csQ0FBa0IsNEJBQWtDLFdBQUEsQ0FBYixVQUFhLENBQWUscURBQWdFLDRCQUFBLENBQStCLGFBQUEsQ0FBMUQsd0JBQTBELENBQ3RTLHNCQUFpQyxzQkFBQSxDQUFsQixlQUFrQixDQUVqQyx3QkFBNkUsa0JBQUEsQ0FBcUIsYUFBQSxDQUE3RCxlQUFBLENBQWtCLG1CQUFBLENBQXRDLGlCQUFpRixDQUNsRyx1QkFBMkQsMkRBQUEsQ0FBaUUseUJBQUEsQ0FBeEYsT0FBQSxDQUFvSCx1REFBQSxDQUExRyxVQUFBLENBQXVLLG1CQUFBLENBQXJNLGlCQUFxTSxDQUF1QiwrQ0FBK0IsaUJBQUEsQ0FBcUIsMENBQTBCLGFBQUEsQ0FDMVQsb0JBQW1KLGVBQUEsQ0FBdEIsbUJBQUEsQ0FBd0MsbUNBQUEsQ0FBeEosWUFBQSxDQUFvRCxPQUFBLENBQTRCLGVBQUEsQ0FBN0MsY0FBQSxDQUEyQixlQUFBLENBQW9DLFdBQUEsQ0FBbkYsaUJBQXlJLENBQ3JLLDJCQUFtRCxrQkFBQSxDQUFtRixjQUFBLENBQWpDLFFBQUEsQ0FBVyxtQkFBQSxDQUErQyx3QkFBQSxDQUE4RCxjQUFBLENBQXpNLFlBQUEsQ0FBZSxhQUFBLENBQXVKLGNBQUEsQ0FBaUIsZUFBQSxDQUFuSSxPQUFBLENBQVUsZ0JBQUEsQ0FBNEoseUNBQUEsQ0FDOU8sOENBQXlDLGtCQUFBLENBQXFCLFVBQUEsQ0FBYyx5Q0FBa0MseUJBQUEsQ0FBNEIsa0JBQUEsQ0FDMUksc0JBQWtHLDBCQUFBLENBQXBCLGlCQUFBLENBQWlELGFBQUEsQ0FBaEgsWUFBQSxDQUFnSSxjQUFBLENBQWlCLGVBQUEsQ0FBckgsV0FBQSxDQUFjLGtCQUFBLENBQTNCLFVBQWtJLENBQW1CLG9FQUFzRCw0QkFBQSxDQUN6TywyQkFBc0Msd0JBQUEsQ0FBMkIsY0FBQSxDQUE3QyxlQUE2QyxDQUNqRSxxQkFBYyxZQUFBLENBQWlFLFFBQUEsQ0FBbEQsNkNBQUEsQ0FBNkQsZUFBQSxDQUFtQixxQkFBcUQsZUFBQSxDQUFyQixrQkFBQSxDQUF1QyxtQ0FBQSxDQUF6RCxlQUFBLENBQStGLHlDQUFBLENBQThDLDJCQUFpRCxzQ0FBQSxDQUE3QiwwQkFBNkIsQ0FBMEMscUJBQThCLGFBQUEsQ0FBaEIsYUFBQSxDQUFnQyxvQkFBQSxDQUNqWiwwQkFBdUMsWUFBQSxDQUFlLGVBQUEsQ0FBbkMsaUJBQW1DLENBQW1CLGdDQUFxRSwrREFBQSxDQUEzQyxVQUFBLENBQWlDLE9BQUEsQ0FBZ0YsbUJBQUEsQ0FBcEcsaUJBQW9HLENBQXVCLDhCQUFvQyxXQUFBLENBQWMsZ0JBQUEsQ0FBbUIsd0JBQUEsQ0FBOUMsVUFBOEMsQ0FBNEIsK0JBQXdCLHFCQUFBLENBQ3BXLDhCQUFzRixrREFBQSxDQUF1RCx1QkFBQSxDQUF0SCxZQUFBLENBQTRCLFdBQUEsQ0FBYyxrQkFBQSxDQUEzQixVQUF1RyxDQUEyQixrQ0FBd0MsV0FBQSxDQUFiLFVBQWEsQ0FDaE4scUJBQTRKLDRCQUFBLENBQXBCLGlCQUFBLENBQTdFLFdBQUEsQ0FBZ0oscUNBQUEsQ0FBaEIsYUFBQSxDQUFsSCxZQUFBLENBQTRCLFdBQUEsQ0FBYyxrQkFBQSxDQUFyRyxpQkFBQSxDQUFnQyxVQUFBLENBQXFNLHdCQUFBLENBQTNKLFVBQUEsQ0FBdEQsU0FBaU4sQ0FBNEIseUJBQStCLFdBQUEsQ0FBYixVQUFhLENBQWUsZ0RBQWdDLG1DQUFBLENBQzdWLHdCQUFpQixZQUFBLENBQWdCLDJCQUErQixjQUFBLENBQWlCLGVBQUEsQ0FBNUIsUUFBNEIsQ0FBbUIsMEJBQW9DLHdCQUFBLENBQTJCLGNBQUEsQ0FBaUIsZ0JBQUEsQ0FBN0QsY0FBNkQsQ0FFcEwsaUJBQWdELHdCQUFBLENBQWxCLGVBQUEsQ0FBcEIsaUJBQXNDLENBQTRCLHlCQUFrQixVQUFBLENBQWMsd0NBQXdCLHVCQUFBLENBQ3BJLHNCQUFnRSxrQkFBQSxDQUFqRCxZQUFBLENBQXNFLFFBQUEsQ0FBdkQsK0JBQXVELENBQVksMEJBQW1CLGVBQUEsQ0FBbUIsb0NBQW1FLHNCQUFBLENBQWxCLGVBQUEsQ0FBbEIsZUFBb0MsQ0FDMU0sdUJBQWdCLFlBQUEsQ0FBaUUsUUFBQSxDQUFsRCw2Q0FBa0QsQ0FBWSxzQkFBaU0sMkJBQUEsQ0FBOUQsb0NBQUEsQ0FBeUMsa0JBQUEsQ0FBbUQsYUFBQSxDQUFoTixZQUFBLENBQWtDLHFCQUFBLENBQXdELFFBQUEsQ0FBaEMsNkJBQUEsQ0FBM0MsZ0JBQUEsQ0FBc0YsWUFBQSxDQUEySCxvQkFBQSxDQUF1QiwyQkFBQSxDQUErQixnRUFBaUQsZ0NBQUEsQ0FBbUMsU0FBQSxDQUN0ZCxzQkFBMEMsdUJBQUEsQ0FBZCxXQUFBLENBQWIsVUFBMkIsQ0FBMkIsNkJBQXFDLGtCQUFBLENBQWYsWUFBQSxDQUE4QyxjQUFBLENBQVYsT0FBVSxDQUFrQiw0QkFBc0Qsc0JBQUEsQ0FBakMsYUFBQSxDQUEwRCxjQUFBLENBQTFDLGNBQTBDLENBQWtCLHVCQUE2QixXQUFBLENBQWMsU0FBQSxDQUFZLDBCQUFBLENBQTZCLGNBQUEsQ0FBcEUsVUFBb0UsQ0FBa0IsbURBQW1DLFNBQUEsQ0FBWSxjQUFBLENBQ2paLHVCQUErQixrQkFBQSxDQUFxRyx3Q0FBQSxDQUFwSCxZQUFBLENBQW9FLFFBQUEsQ0FBaEMsNkJBQUEsQ0FBMkMsZUFBQSxDQUFrQixnQkFBbUIsQ0FBOEMseUJBQStCLHNCQUFBLENBQXlCLGNBQUEsQ0FBcEMsUUFBb0MsQ0FFMU8sMkJBQW9CLEdBQU8sU0FBQSxDQUFZLDBCQUFBLENBQStCLEdBQUssU0FBQSxDQUFZLHVCQUFBLENBQUEsQ0FDdkYsaURBQXFELHNCQUFlLGNBQUEsQ0FBQSxDQUNwRSx5QkFBNEIsMkNBQTRCLDZCQUFBLENBQW1DLG1CQUFZLGdCQUFBLENBQUEsQ0FDdkcsMEJBQTZCLHFCQUFjLDZDQUFBLENBQW9ELHVCQUFnQiw2Q0FBQSxDQUFvRCxzQkFBZSx5QkFBQSxDQUFBLENBQ2xMLHlCQUE0QixtQ0FBb0IsZUFBQSxDQUFvQiwyQ0FBNEIsNkJBQUEsQ0FBbUMsaUJBQVUsa0JBQUEsQ0FBdUIscUJBQWMsWUFBQSxDQUFpQixtQkFBWSxnQkFBQSxDQUFtQixnQkFBQSxDQUFxQixzQkFBZSwrQkFBQSxDQUFzQyxxQkFBZ0IsY0FBQSxDQUFtQixxQkFBZ0UsUUFBQSxDQUFsRCw2Q0FBa0QsQ0FBYSx3QkFBaUIsUUFBQSxDQUFXLFlBQUEsQ0FBaUIscUJBQTJCLFdBQUEsQ0FBYixVQUFhLENBQWdCLHlCQUErQixXQUFBLENBQWIsVUFBYSxDQUFnQixzQkFBZSxjQUFBLENBQW1CLHNCQUFlLFdBQUEsQ0FBYyxjQUFBLENBQW1CLHNCQUFlLFlBQUEsQ0FBaUIsa0RBQW1DLGtCQUFBLENBQXVCLHdCQUFpQixzQkFBQSxDQUF5QixxQkFBQSxDQUEwQiwyQkFBb0IsbUJBQUEsQ0FBd0IsdUJBQWdCLFFBQUEsQ0FBVyxlQUFBLENBQW9CLHVCQUFnQixnQkFBQSxDQUFtQixZQUFBLENBQWlCLG1CQUFZLGNBQUEsQ0FBbUIsMEJBQXFDLGNBQUEsQ0FBbEIsZUFBa0IsQ0FBbUIsb0JBQTBCLGtCQUFBLENBQWIsVUFBYSxDQUF1QixxQkFBMEMsUUFBQSxDQUE1Qix5QkFBNEIsQ0FBYSwwQkFBbUIsWUFBQSxDQUFpQix3Q0FBd0IsZ0JBQUEsQ0FBcUIsdUJBQWdCLHlCQUFBLENBQThCLHNCQUFlLGdCQUFBLENBQW1CLFlBQUEsQ0FBaUIsdUJBQWdCLHNCQUFBLENBQXlCLHFCQUFBLENBQXdCLGVBQUEsQ0FBQSxDQUNwMUMsdUNBQTBDLGlCQUEyRCwrQkFBQSxDQUFzQyxxQ0FBQSxDQUF4RSw4QkFBQSxDQUFpSCxnQ0FBQSxDQUFBIiwiZmlsZSI6IkhvbWVQYWdlLm1vZHVsZS5jc3MifQ== */", true);

// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  homePage_c565b63f: "homePage_c565b63f",
  hero_c565b63f: "hero_c565b63f",
  heroGrid_c565b63f: "heroGrid_c565b63f",
  heroImage_c565b63f: "heroImage_c565b63f",
  heroShade_c565b63f: "heroShade_c565b63f",
  heroInner_c565b63f: "heroInner_c565b63f",
  sectionInner_c565b63f: "sectionInner_c565b63f",
  header_c565b63f: "header_c565b63f",
  brandLink_c565b63f: "brandLink_c565b63f",
  brand_c565b63f: "brand_c565b63f",
  brandMark_c565b63f: "brandMark_c565b63f",
  brandTagline_c565b63f: "brandTagline_c565b63f",
  navigation_c565b63f: "navigation_c565b63f",
  heroCopy_c565b63f: "heroCopy_c565b63f",
  riseIn_c565b63f: "riseIn_c565b63f",
  portalArea_c565b63f: "portalArea_c565b63f",
  portalGrid_c565b63f: "portalGrid_c565b63f",
  portalCard_c565b63f: "portalCard_c565b63f",
  portalGlow_c565b63f: "portalGlow_c565b63f",
  portalContent_c565b63f: "portalContent_c565b63f",
  portalTop_c565b63f: "portalTop_c565b63f",
  portalIcon_c565b63f: "portalIcon_c565b63f",
  portalArrow_c565b63f: "portalArrow_c565b63f",
  portalEyebrow_c565b63f: "portalEyebrow_c565b63f",
  portalTitle_c565b63f: "portalTitle_c565b63f",
  colorBar_c565b63f: "colorBar_c565b63f",
  footerColorBar_c565b63f: "footerColorBar_c565b63f",
  exploreLink_c565b63f: "exploreLink_c565b63f",
  featuredSection_c565b63f: "featuredSection_c565b63f",
  sectionHeader_c565b63f: "sectionHeader_c565b63f",
  sectionTitleBlock_c565b63f: "sectionTitleBlock_c565b63f",
  eyebrow_c565b63f: "eyebrow_c565b63f",
  contactIntro_c565b63f: "contactIntro_c565b63f",
  carouselControls_c565b63f: "carouselControls_c565b63f",
  pageDots_c565b63f: "pageDots_c565b63f",
  activeDot_c565b63f: "activeDot_c565b63f",
  carouselArrow_c565b63f: "carouselArrow_c565b63f",
  featuredGrid_c565b63f: "featuredGrid_c565b63f",
  featuredCard_c565b63f: "featuredCard_c565b63f",
  featuredMeta_c565b63f: "featuredMeta_c565b63f",
  location_c565b63f: "location_c565b63f",
  registerLine_c565b63f: "registerLine_c565b63f",
  dateBadge_c565b63f: "dateBadge_c565b63f",
  category_c565b63f: "category_c565b63f",
  registerArrow_c565b63f: "registerArrow_c565b63f",
  dataMessage_c565b63f: "dataMessage_c565b63f",
  stagesSection_c565b63f: "stagesSection_c565b63f",
  stagePattern_c565b63f: "stagePattern_c565b63f",
  stageTabs_c565b63f: "stageTabs_c565b63f",
  stageNumber_c565b63f: "stageNumber_c565b63f",
  stageDescription_c565b63f: "stageDescription_c565b63f",
  courseGrid_c565b63f: "courseGrid_c565b63f",
  courseCard_c565b63f: "courseCard_c565b63f",
  courseLink_c565b63f: "courseLink_c565b63f",
  courseImageWrap_c565b63f: "courseImageWrap_c565b63f",
  courseImageFallback_c565b63f: "courseImageFallback_c565b63f",
  courseIcon_c565b63f: "courseIcon_c565b63f",
  courseContent_c565b63f: "courseContent_c565b63f",
  footer_c565b63f: "footer_c565b63f",
  contactGrid_c565b63f: "contactGrid_c565b63f",
  contactCards_c565b63f: "contactCards_c565b63f",
  contactCard_c565b63f: "contactCard_c565b63f",
  contactIcon_c565b63f: "contactIcon_c565b63f",
  contactArrow_c565b63f: "contactArrow_c565b63f",
  footerBottom_c565b63f: "footerBottom_c565b63f"
});


/***/ }),

/***/ 807:
/*!******************************************************!*\
  !*** ./lib/webparts/homePage/components/HomePage.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _microsoft_sp_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @microsoft/sp-http */ 909);
/* harmony import */ var _microsoft_sp_http__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_http__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _HomePage_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./HomePage.module.scss */ 315);
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();



var css = _HomePage_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"];
var learningSiteUrl = 'https://sites.ey.com/sites/ENATaxHub';
var careerStageApi = "".concat(learningSiteUrl, "/_api/web/lists/getByTitle('CareerStageLearning')/items?$select=*&$orderby=LSlNo asc");
var featuredLearningApi = "".concat(learningSiteUrl, "/_api/web/lists/getByTitle('FeaturedLearning')/items?$select=*&$orderby=FSlNo asc");
function readListItems(payload) {
    return payload.value || (payload.d && payload.d.results) || [];
}
function readText(value) {
    if (typeof value === 'string')
        return value;
    return value ? value.Value || value.value || '' : '';
}
function readLink(value) {
    if (typeof value === 'string')
        return value;
    return value ? value.Url || value.url || '' : '';
}
function readSortNumber(value) {
    var parsed = Number(value);
    return isNaN(parsed) ? 999999999 : parsed;
}
function formatFeaturedDate(date) {
    if (!date || isNaN(date.getTime()))
        return { month: 'TBC', day: '' };
    return {
        month: new Intl.DateTimeFormat('en', { month: 'short' }).format(date),
        day: new Intl.DateTimeFormat('en', { day: '2-digit' }).format(date)
    };
}
var iconPaths = {
    calendar: react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { d: "M8 2v3M16 2v3" }),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", { x: "3", y: "3", width: "18", height: "18", rx: "2" }),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { d: "M3 9h18M8 13h.01M12 13h.01M16 13h.01M8 17h.01M12 17h.01M16 17h.01" })),
    compass: react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", { cx: "12", cy: "12", r: "10" }),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { d: "m16.24 7.76-1.8 5.41a2 2 0 0 1-1.27 1.27l-5.41 1.8 1.8-5.41a2 2 0 0 1 1.27-1.27z" })),
    bulb: react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { d: "M15 14c.2-1 .7-1.7 1.5-2.5A6 6 0 1 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5M9 18h6M10 22h4" })),
    sparkles: react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { d: "M11 3a1 1 0 0 1 2 0l1 5.4a2 2 0 0 0 1.6 1.6l5.4 1a1 1 0 0 1 0 2l-5.4 1a2 2 0 0 0-1.6 1.6L13 21a1 1 0 0 1-2 0l-1-5.4a2 2 0 0 0-1.6-1.6L3 13a1 1 0 0 1 0-2l5.4-1A2 2 0 0 0 10 8.4z" }),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { d: "M20 2v4M22 4h-4" }),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", { cx: "4", cy: "20", r: "2" })),
    award: react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { d: "m15.5 13 1.5 8.5a.5.5 0 0 1-.8.5l-3.6-2.7a1 1 0 0 0-1.2 0l-3.6 2.7a.5.5 0 0 1-.8-.5l1.5-8.5" }),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", { cx: "12", cy: "8", r: "6" })),
    graduation: react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { d: "m21.4 10.9-8.6 3.9a2 2 0 0 1-1.7 0l-8.5-3.9a1 1 0 0 1 0-1.8l8.5-3.9a2 2 0 0 1 1.7 0l8.6 3.9a1 1 0 0 1 0 1.8ZM22 10v6M6 12.5V16a6 3 0 0 0 12 0v-3.5" })),
    arrowUpRight: react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { d: "M7 7h10v10M7 17 17 7" })),
    arrowDown: react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { d: "M12 5v14m7-7-7 7-7-7" })),
    chevronLeft: react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { d: "m15 18-6-6 6-6" }),
    chevronRight: react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { d: "m9 18 6-6-6-6" }),
    pin: react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { d: "M20 10c0 5-5.5 10.2-7.4 11.8a1 1 0 0 1-1.2 0C9.5 20.2 4 15 4 10a8 8 0 1 1 16 0Z" }),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", { cx: "12", cy: "10", r: "3" })),
    file: react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.7.7l3.6 3.6A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2zM14 2v5a1 1 0 0 0 1 1h5M8 13h8M8 17h8M8 9h2" })),
    mail: react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { d: "m22 7-9 5.7a2 2 0 0 1-2 0L2 7" }),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", { x: "2", y: "4", width: "20", height: "16", rx: "2" })),
    help: react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", { cx: "12", cy: "12", r: "10" }),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { d: "M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3M12 17h.01" })),
    support: react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", { cx: "12", cy: "12", r: "10" }),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { d: "m4.9 4.9 4.3 4.3m5.6-.1 4.3-4.3m-4.3 9.9 4.3 4.3m-9.9-4.3-4.3 4.3" }),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", { cx: "12", cy: "12", r: "4" })),
    arrowRight: react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { d: "M5 12h14m-7-7 7 7-7 7" }))
};
var portalItems = [
    { eyebrow: 'Learning', title: 'Calendar', icon: 'calendar' },
    { eyebrow: 'Browse', title: 'Opportunities', icon: 'compass' },
    { eyebrow: 'SuccessFactors', title: 'Learning', icon: 'bulb' },
    { eyebrow: 'Viva', title: 'Learning', icon: 'sparkles' },
    { eyebrow: 'EY', title: 'Badges', icon: 'award' },
    { eyebrow: 'EY', title: 'Degrees', icon: 'graduation' }
];
var contactItems = [
    { title: 'Mailbox', description: 'Email the learning team', icon: 'mail' },
    { title: 'FAQ', description: 'Quick answers to common questions', icon: 'help' },
    { title: 'Support Request', description: 'Raise a ticket for help', icon: 'support' }
];
function Icon(props) {
    return react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", { className: props.className, xmlns: "http://www.w3.org/2000/svg", width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", "aria-hidden": "true" }, iconPaths[props.name]);
}
function Brand() {
    return react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.brand },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.brandMark },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "EY")),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: css.brandTagline },
            "Shape the future",
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
            "with confidence"));
}
var HomePage = /** @class */ (function (_super) {
    __extends(HomePage, _super);
    function HomePage(props) {
        var _this = _super.call(this, props) || this;
        _this.loadList = function (url) {
            return _this.props.spHttpClient.get(url, _microsoft_sp_http__WEBPACK_IMPORTED_MODULE_1__.SPHttpClient.configurations.v1, {
                headers: { Accept: 'application/json;odata=nometadata' }
            }).then(function (response) {
                if (!response.ok)
                    throw new Error("SharePoint request failed: ".concat(response.status));
                return response.json();
            }).then(readListItems);
        };
        _this.loadCareerStages = function () {
            _this.loadList(careerStageApi).then(function (rows) {
                var sortedRows = rows.slice().sort(function (left, right) { return readSortNumber(left.LSlNo) - readSortNumber(right.LSlNo); });
                var stageMap = {};
                sortedRows.forEach(function (row) {
                    var rank = readText(row.Rank).trim();
                    var title = row.LearningTitle || '';
                    if (!rank || !title)
                        return;
                    if (!stageMap[rank])
                        stageMap[rank] = { name: rank, courses: [] };
                    stageMap[rank].courses.push({
                        id: String(row.Id || row.LSlNo || "".concat(rank, "-").concat(title)),
                        title: title,
                        description: row.LearningDescription || '',
                        thumbnail: readLink(row.LearningThumbnail),
                        link: readLink(row.LearningLink)
                    });
                });
                _this.setState({ careerStages: Object.keys(stageMap).map(function (rank) { return stageMap[rank]; }), careerLoading: false });
            }).catch(function () { return _this.setState({ careerLoading: false, careerError: true }); });
        };
        _this.loadFeaturedLearning = function () {
            _this.loadList(featuredLearningApi).then(function (rows) {
                var featuredItems = rows.slice().sort(function (left, right) { return readSortNumber(left.FSlNo) - readSortNumber(right.FSlNo); }).map(function (row, index) {
                    var parsedDate = row.FeaturedLearningDate ? new Date(row.FeaturedLearningDate) : null;
                    return {
                        id: String(row.Id || row.FSlNo || index),
                        name: row.FeaturedLearningName || '',
                        link: readLink(row.FeaturedLearningLink),
                        date: parsedDate && !isNaN(parsedDate.getTime()) ? parsedDate : undefined,
                        category: row.FeaturedLearningCategory || '',
                        location: row.FeaturedLearningLocation || ''
                    };
                }).filter(function (item) { return item.name; });
                _this.setState({ featuredItems: featuredItems, featuredLoading: false });
            }).catch(function () { return _this.setState({ featuredLoading: false, featuredError: true }); });
        };
        _this.selectStage = function (activeStage) { return _this.setState({ activeStage: activeStage }); };
        _this.selectFeaturedPage = function (activeFeaturedPage) { return _this.setState({ activeFeaturedPage: activeFeaturedPage }); };
        _this.state = {
            activeStage: 0,
            activeFeaturedPage: 0,
            careerStages: [],
            featuredItems: [],
            careerLoading: true,
            featuredLoading: true,
            careerError: false,
            featuredError: false
        };
        return _this;
    }
    HomePage.prototype.componentDidMount = function () {
        this.loadCareerStages();
        this.loadFeaturedLearning();
    };
    HomePage.prototype.render = function () {
        var _this = this;
        var activeStage = this.state.careerStages[this.state.activeStage];
        var pageSize = 4;
        var pageCount = Math.ceil(this.state.featuredItems.length / pageSize);
        var featuredItems = this.state.featuredItems.slice(this.state.activeFeaturedPage * pageSize, (this.state.activeFeaturedPage + 1) * pageSize);
        var pageIndexes = [];
        for (var pageIndex = 0; pageIndex < pageCount; pageIndex++)
            pageIndexes.push(pageIndex);
        return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("main", { className: css.homePage },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("section", { className: css.hero, id: "top" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.heroImage, "aria-hidden": "true" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.heroShade, "aria-hidden": "true" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.heroGrid, "aria-hidden": "true" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.heroInner },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("header", { className: css.header },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { className: css.brandLink, href: "#top", "aria-label": "MENA Learning Hub home" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement(Brand, null)),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("nav", { className: css.navigation, "aria-label": "Main navigation" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { href: "#featured" }, "Featured"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { href: "#stages" }, "Career stages"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { href: "#contact" }, "Contact"))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.heroCopy },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("h1", null,
                            "MENA",
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "Learning Hub")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "Everything you need to grow your career, in one place. Discover programs, earn credentials, and learn with colleagues across the region.")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.portalArea, id: "portals" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.portalGrid }, portalItems.map(function (item) { return react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.portalCard, key: "".concat(item.eyebrow, "-").concat(item.title) },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: css.portalGlow, "aria-hidden": "true" }),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: css.portalContent },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: css.portalTop },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: css.portalIcon },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement(Icon, { name: item.icon })),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(Icon, { name: "arrowUpRight", className: css.portalArrow })),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null,
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: css.portalEyebrow }, item.eyebrow),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: css.portalTitle }, item.title))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: css.colorBar, "aria-hidden": "true" })); })),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { className: css.exploreLink, href: "#featured" },
                            "Explore ",
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement(Icon, { name: "arrowDown" }))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("section", { id: "featured", className: css.featuredSection },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.sectionInner },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.sectionHeader },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.sectionTitleBlock },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: css.eyebrow }, "Don't miss out"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("h2", null, "Featured Learning"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: css.colorBar, "aria-hidden": "true" })),
                        pageCount > 1 && react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.carouselControls },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.pageDots, "aria-label": "Featured learning pages" }, pageIndexes.map(function (index) { return react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { key: index, className: index === _this.state.activeFeaturedPage ? css.activeDot : '', "aria-label": "Page ".concat(index + 1), "aria-current": index === _this.state.activeFeaturedPage ? 'page' : undefined, onClick: function () { return _this.selectFeaturedPage(index); } }); })),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { className: css.carouselArrow, "aria-label": "Previous", onClick: function () { return _this.selectFeaturedPage((_this.state.activeFeaturedPage + pageCount - 1) % pageCount); } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement(Icon, { name: "chevronLeft" })),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { className: css.carouselArrow, "aria-label": "Next", onClick: function () { return _this.selectFeaturedPage((_this.state.activeFeaturedPage + 1) % pageCount); } },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement(Icon, { name: "chevronRight" })))),
                    this.state.featuredLoading ? react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: css.dataMessage }, "Loading featured learning...") : this.state.featuredError ? react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: css.dataMessage }, "Featured learning could not be loaded.") : featuredItems.length ? react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.featuredGrid }, featuredItems.map(function (item) { var dateParts = formatFeaturedDate(item.date); return react__WEBPACK_IMPORTED_MODULE_0__.createElement("article", { className: css.featuredCard, key: item.id },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.featuredMeta },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: css.dateBadge },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, dateParts.month),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", null, dateParts.day)),
                            item.category && react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: css.category }, item.category)),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("h3", null, item.name),
                        item.location && react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: css.location },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement(Icon, { name: "pin" }),
                            item.location),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.registerLine },
                            item.link ? react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { href: item.link, target: "_blank", rel: "noreferrer" }, "View learning") : react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "Learning details"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: css.registerArrow },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement(Icon, { name: "arrowRight" })))); })) : react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: css.dataMessage }, "No featured learning is available right now."))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("section", { id: "stages", className: css.stagesSection },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.stagePattern, "aria-hidden": "true" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.sectionInner },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.sectionTitleBlock },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: css.eyebrow }, "Grow at every level"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("h2", null, "Learning by Career Stage"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: css.colorBar, "aria-hidden": "true" })),
                    this.state.careerLoading ? react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: css.stageDescription }, "Loading career-stage learning...") : this.state.careerError ? react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: css.stageDescription }, "Career-stage learning could not be loaded.") : activeStage ? react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.stageTabs, role: "group", "aria-label": "Career stage" }, this.state.careerStages.map(function (stage, index) { return react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { type: "button", key: stage.name, "aria-pressed": _this.state.activeStage === index, onClick: function () { return _this.selectStage(index); } },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: css.stageNumber }, index + 1),
                            stage.name); })),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.courseGrid }, activeStage.courses.map(function (course) { return react__WEBPACK_IMPORTED_MODULE_0__.createElement("article", { className: css.courseCard, key: course.id },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { className: css.courseLink, href: course.link || undefined, target: course.link ? '_blank' : undefined, rel: course.link ? 'noreferrer' : undefined },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.courseImageWrap },
                                    course.thumbnail ? react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: course.thumbnail, alt: course.title, loading: "lazy" }) : react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: css.courseImageFallback, "aria-hidden": "true" },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement(Icon, { name: "file" })),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: css.courseIcon },
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement(Icon, { name: "file" }))),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.courseContent },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("h3", null, course.title),
                                    course.description && react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, course.description)))); }))) : react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: css.stageDescription }, "No career-stage learning is available right now."))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("footer", { id: "contact", className: css.footer },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: css.footerColorBar, "aria-hidden": "true" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.sectionInner },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.contactGrid },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.contactIntro },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: css.eyebrow }, "We're here to help"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("h2", null, "Contact the Learning Team"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "Questions about a program, registration, or your learning record? Reach out any time.")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.contactCards }, contactItems.map(function (item) { return react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.contactCard, key: item.title },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement(Icon, { name: item.icon, className: css.contactIcon }),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", null,
                                    item.title,
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(Icon, { name: "arrowRight", className: css.contactArrow })),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("small", null, item.description))); }))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: css.footerBottom },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement(Brand, null),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null, "\u00A9 2026 EY MENA Learning. All rights reserved."))))));
    };
    return HomePage;
}(react__WEBPACK_IMPORTED_MODULE_0__.Component));
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomePage);


/***/ }),

/***/ 315:
/*!******************************************************************!*\
  !*** ./lib/webparts/homePage/components/HomePage.module.scss.js ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
__webpack_require__(/*! ./HomePage.module.css */ 591);
var styles = {
    homePage: 'homePage_c565b63f',
    hero: 'hero_c565b63f',
    heroImage: 'heroImage_c565b63f',
    heroShade: 'heroShade_c565b63f',
    heroGrid: 'heroGrid_c565b63f',
    heroInner: 'heroInner_c565b63f',
    sectionInner: 'sectionInner_c565b63f',
    header: 'header_c565b63f',
    brandLink: 'brandLink_c565b63f',
    brand: 'brand_c565b63f',
    brandMark: 'brandMark_c565b63f',
    brandTagline: 'brandTagline_c565b63f',
    navigation: 'navigation_c565b63f',
    heroCopy: 'heroCopy_c565b63f',
    riseIn: 'riseIn_c565b63f',
    portalArea: 'portalArea_c565b63f',
    portalGrid: 'portalGrid_c565b63f',
    portalCard: 'portalCard_c565b63f',
    portalGlow: 'portalGlow_c565b63f',
    portalContent: 'portalContent_c565b63f',
    portalTop: 'portalTop_c565b63f',
    portalIcon: 'portalIcon_c565b63f',
    portalArrow: 'portalArrow_c565b63f',
    portalEyebrow: 'portalEyebrow_c565b63f',
    portalTitle: 'portalTitle_c565b63f',
    colorBar: 'colorBar_c565b63f',
    footerColorBar: 'footerColorBar_c565b63f',
    exploreLink: 'exploreLink_c565b63f',
    featuredSection: 'featuredSection_c565b63f',
    sectionHeader: 'sectionHeader_c565b63f',
    sectionTitleBlock: 'sectionTitleBlock_c565b63f',
    eyebrow: 'eyebrow_c565b63f',
    contactIntro: 'contactIntro_c565b63f',
    carouselControls: 'carouselControls_c565b63f',
    pageDots: 'pageDots_c565b63f',
    activeDot: 'activeDot_c565b63f',
    carouselArrow: 'carouselArrow_c565b63f',
    featuredGrid: 'featuredGrid_c565b63f',
    featuredCard: 'featuredCard_c565b63f',
    featuredMeta: 'featuredMeta_c565b63f',
    location: 'location_c565b63f',
    registerLine: 'registerLine_c565b63f',
    dateBadge: 'dateBadge_c565b63f',
    category: 'category_c565b63f',
    registerArrow: 'registerArrow_c565b63f',
    dataMessage: 'dataMessage_c565b63f',
    stagesSection: 'stagesSection_c565b63f',
    stagePattern: 'stagePattern_c565b63f',
    stageTabs: 'stageTabs_c565b63f',
    stageNumber: 'stageNumber_c565b63f',
    stageDescription: 'stageDescription_c565b63f',
    courseGrid: 'courseGrid_c565b63f',
    courseCard: 'courseCard_c565b63f',
    courseLink: 'courseLink_c565b63f',
    courseImageWrap: 'courseImageWrap_c565b63f',
    courseImageFallback: 'courseImageFallback_c565b63f',
    courseIcon: 'courseIcon_c565b63f',
    courseContent: 'courseContent_c565b63f',
    footer: 'footer_c565b63f',
    contactGrid: 'contactGrid_c565b63f',
    contactCards: 'contactCards_c565b63f',
    contactCard: 'contactCard_c565b63f',
    contactIcon: 'contactIcon_c565b63f',
    contactArrow: 'contactArrow_c565b63f',
    footerBottom: 'footerBottom_c565b63f'
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (styles);


/***/ }),

/***/ 323:
/*!***********************************************************************************************************!*\
  !*** ./node_modules/@microsoft/sp-css-loader/node_modules/@microsoft/load-themed-styles/lib-es6/index.js ***!
  \***********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ClearStyleOptions: () => (/* binding */ ClearStyleOptions),
/* harmony export */   Mode: () => (/* binding */ Mode),
/* harmony export */   clearStyles: () => (/* binding */ clearStyles),
/* harmony export */   configureLoadStyles: () => (/* binding */ configureLoadStyles),
/* harmony export */   configureRunMode: () => (/* binding */ configureRunMode),
/* harmony export */   detokenize: () => (/* binding */ detokenize),
/* harmony export */   flush: () => (/* binding */ flush),
/* harmony export */   loadStyles: () => (/* binding */ loadStyles),
/* harmony export */   loadTheme: () => (/* binding */ loadTheme),
/* harmony export */   splitStyles: () => (/* binding */ splitStyles)
/* harmony export */ });
// Copyright (c) Microsoft Corporation. All rights reserved. Licensed under the MIT license.
// See LICENSE in the project root for license information.
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
/**
 * In sync mode, styles are registered as style elements synchronously with loadStyles() call.
 * In async mode, styles are buffered and registered as batch in async timer for performance purpose.
 */
var Mode;
(function (Mode) {
    Mode[Mode["sync"] = 0] = "sync";
    Mode[Mode["async"] = 1] = "async";
})(Mode || (Mode = {}));
/**
 * Themable styles and non-themable styles are tracked separately
 * Specify ClearStyleOptions when calling clearStyles API to specify which group of registered styles should be cleared.
 */
var ClearStyleOptions;
(function (ClearStyleOptions) {
    /** only themable styles will be cleared */
    ClearStyleOptions[ClearStyleOptions["onlyThemable"] = 1] = "onlyThemable";
    /** only non-themable styles will be cleared */
    ClearStyleOptions[ClearStyleOptions["onlyNonThemable"] = 2] = "onlyNonThemable";
    /** both themable and non-themable styles will be cleared */
    ClearStyleOptions[ClearStyleOptions["all"] = 3] = "all";
})(ClearStyleOptions || (ClearStyleOptions = {}));
// Store the theming state in __themeState__ global scope for reuse in the case of duplicate
// load-themed-styles hosted on the page.
var _root = typeof window === 'undefined' ? __webpack_require__.g : window; // eslint-disable-line @typescript-eslint/no-explicit-any
// Nonce string to inject into script tag if one provided. This is used in CSP (Content Security Policy).
var _styleNonce = _root && _root.CSPSettings && _root.CSPSettings.nonce;
var _themeState = initializeThemeState();
/**
 * Matches theming tokens. For example, "[theme: themeSlotName, default: #FFF]" (including the quotes).
 */
var _themeTokenRegex = /[\'\"]\[theme:\s*(\w+)\s*(?:\,\s*default:\s*([\\"\']?[\.\,\(\)\#\-\s\w]*[\.\,\(\)\#\-\w][\"\']?))?\s*\][\'\"]/g;
var now = function () {
    return typeof performance !== 'undefined' && !!performance.now ? performance.now() : Date.now();
};
function measure(func) {
    var start = now();
    func();
    var end = now();
    _themeState.perf.duration += end - start;
}
/**
 * initialize global state object
 */
function initializeThemeState() {
    var state = _root.__themeState__ || {
        theme: undefined,
        lastStyleElement: undefined,
        registeredStyles: []
    };
    if (!state.runState) {
        state = __assign(__assign({}, state), { perf: {
                count: 0,
                duration: 0
            }, runState: {
                flushTimer: 0,
                mode: Mode.sync,
                buffer: []
            } });
    }
    if (!state.registeredThemableStyles) {
        state = __assign(__assign({}, state), { registeredThemableStyles: [] });
    }
    _root.__themeState__ = state;
    return state;
}
/**
 * Loads a set of style text. If it is registered too early, we will register it when the window.load
 * event is fired.
 * @param {string | ThemableArray} styles Themable style text to register.
 * @param {boolean} loadAsync When true, always load styles in async mode, irrespective of current sync mode.
 */
function loadStyles(styles, loadAsync) {
    if (loadAsync === void 0) { loadAsync = false; }
    measure(function () {
        var styleParts = Array.isArray(styles) ? styles : splitStyles(styles);
        var _a = _themeState.runState, mode = _a.mode, buffer = _a.buffer, flushTimer = _a.flushTimer;
        if (loadAsync || mode === Mode.async) {
            buffer.push(styleParts);
            if (!flushTimer) {
                _themeState.runState.flushTimer = asyncLoadStyles();
            }
        }
        else {
            applyThemableStyles(styleParts);
        }
    });
}
/**
 * Allows for customizable loadStyles logic. e.g. for server side rendering application
 * @param {(processedStyles: string, rawStyles?: string | ThemableArray) => void}
 * a loadStyles callback that gets called when styles are loaded or reloaded
 */
function configureLoadStyles(loadStylesFn) {
    _themeState.loadStyles = loadStylesFn;
}
/**
 * Configure run mode of load-themable-styles
 * @param mode load-themable-styles run mode, async or sync
 */
function configureRunMode(mode) {
    _themeState.runState.mode = mode;
}
/**
 * external code can call flush to synchronously force processing of currently buffered styles
 */
function flush() {
    measure(function () {
        var styleArrays = _themeState.runState.buffer.slice();
        _themeState.runState.buffer = [];
        var mergedStyleArray = [].concat.apply([], styleArrays);
        if (mergedStyleArray.length > 0) {
            applyThemableStyles(mergedStyleArray);
        }
    });
}
/**
 * register async loadStyles
 */
function asyncLoadStyles() {
    // Use "self" to distinguish conflicting global typings for setTimeout() from lib.dom.d.ts vs Jest's @types/node
    // https://github.com/jestjs/jest/issues/14418
    return self.setTimeout(function () {
        _themeState.runState.flushTimer = 0;
        flush();
    }, 0);
}
/**
 * Loads a set of style text. If it is registered too early, we will register it when the window.load event
 * is fired.
 * @param {string} styleText Style to register.
 * @param {IStyleRecord} styleRecord Existing style record to re-apply.
 */
function applyThemableStyles(stylesArray, styleRecord) {
    if (_themeState.loadStyles) {
        _themeState.loadStyles(resolveThemableArray(stylesArray).styleString, stylesArray);
    }
    else {
        registerStyles(stylesArray);
    }
}
/**
 * Registers a set theme tokens to find and replace. If styles were already registered, they will be
 * replaced.
 * @param {theme} theme JSON object of theme tokens to values.
 */
function loadTheme(theme) {
    _themeState.theme = theme;
    // reload styles.
    reloadStyles();
}
/**
 * Clear already registered style elements and style records in theme_State object
 * @param option - specify which group of registered styles should be cleared.
 * Default to be both themable and non-themable styles will be cleared
 */
function clearStyles(option) {
    if (option === void 0) { option = ClearStyleOptions.all; }
    if (option === ClearStyleOptions.all || option === ClearStyleOptions.onlyNonThemable) {
        clearStylesInternal(_themeState.registeredStyles);
        _themeState.registeredStyles = [];
    }
    if (option === ClearStyleOptions.all || option === ClearStyleOptions.onlyThemable) {
        clearStylesInternal(_themeState.registeredThemableStyles);
        _themeState.registeredThemableStyles = [];
    }
}
function clearStylesInternal(records) {
    records.forEach(function (styleRecord) {
        var styleElement = styleRecord && styleRecord.styleElement;
        if (styleElement && styleElement.parentElement) {
            styleElement.parentElement.removeChild(styleElement);
        }
    });
}
/**
 * Reloads styles.
 */
function reloadStyles() {
    if (_themeState.theme) {
        var themableStyles = [];
        for (var _i = 0, _a = _themeState.registeredThemableStyles; _i < _a.length; _i++) {
            var styleRecord = _a[_i];
            themableStyles.push(styleRecord.themableStyle);
        }
        if (themableStyles.length > 0) {
            clearStyles(ClearStyleOptions.onlyThemable);
            applyThemableStyles([].concat.apply([], themableStyles));
        }
    }
}
/**
 * Find theme tokens and replaces them with provided theme values.
 * @param {string} styles Tokenized styles to fix.
 */
function detokenize(styles) {
    if (styles) {
        styles = resolveThemableArray(splitStyles(styles)).styleString;
    }
    return styles;
}
/**
 * Resolves ThemingInstruction objects in an array and joins the result into a string.
 * @param {ThemableArray} splitStyleArray ThemableArray to resolve and join.
 */
function resolveThemableArray(splitStyleArray) {
    var theme = _themeState.theme;
    var themable = false;
    // Resolve the array of theming instructions to an array of strings.
    // Then join the array to produce the final CSS string.
    var resolvedArray = (splitStyleArray || []).map(function (currentValue) {
        var themeSlot = currentValue.theme;
        if (themeSlot) {
            themable = true;
            // A theming annotation. Resolve it.
            var themedValue = theme ? theme[themeSlot] : undefined;
            var defaultValue = currentValue.defaultValue || 'inherit';
            // Warn to console if we hit an unthemed value even when themes are provided, but only if "DEBUG" is true.
            // Allow the themedValue to be undefined to explicitly request the default value.
            if (theme &&
                !themedValue &&
                console &&
                !(themeSlot in theme) &&
                "boolean" !== 'undefined' &&
                true) {
                // eslint-disable-next-line no-console
                console.warn("Theming value not provided for \"".concat(themeSlot, "\". Falling back to \"").concat(defaultValue, "\"."));
            }
            return themedValue || defaultValue;
        }
        else {
            // A non-themable string. Preserve it.
            return currentValue.rawString;
        }
    });
    return {
        styleString: resolvedArray.join(''),
        themable: themable
    };
}
/**
 * Split tokenized CSS into an array of strings and theme specification objects
 * @param {string} styles Tokenized styles to split.
 */
function splitStyles(styles) {
    var result = [];
    if (styles) {
        var pos = 0; // Current position in styles.
        var tokenMatch = void 0;
        while ((tokenMatch = _themeTokenRegex.exec(styles))) {
            var matchIndex = tokenMatch.index;
            if (matchIndex > pos) {
                result.push({
                    rawString: styles.substring(pos, matchIndex)
                });
            }
            result.push({
                theme: tokenMatch[1],
                defaultValue: tokenMatch[2] // May be undefined
            });
            // index of the first character after the current match
            pos = _themeTokenRegex.lastIndex;
        }
        // Push the rest of the string after the last match.
        result.push({
            rawString: styles.substring(pos)
        });
    }
    return result;
}
/**
 * Registers a set of style text. If it is registered too early, we will register it when the
 * window.load event is fired.
 * @param {ThemableArray} styleArray Array of IThemingInstruction objects to register.
 * @param {IStyleRecord} styleRecord May specify a style Element to update.
 */
function registerStyles(styleArray) {
    if (typeof document === 'undefined') {
        return;
    }
    var head = document.getElementsByTagName('head')[0];
    var styleElement = document.createElement('style');
    var _a = resolveThemableArray(styleArray), styleString = _a.styleString, themable = _a.themable;
    styleElement.setAttribute('data-load-themed-styles', 'true');
    if (_styleNonce) {
        styleElement.setAttribute('nonce', _styleNonce);
    }
    styleElement.appendChild(document.createTextNode(styleString));
    _themeState.perf.count++;
    head.appendChild(styleElement);
    var ev = document.createEvent('HTMLEvents');
    ev.initEvent('styleinsert', true /* bubbleEvent */, false /* cancelable */);
    ev.args = {
        newStyle: styleElement
    };
    document.dispatchEvent(ev);
    var record = {
        styleElement: styleElement,
        themableStyle: styleArray
    };
    if (themable) {
        _themeState.registeredThemableStyles.push(record);
    }
    else {
        _themeState.registeredStyles.push(record);
    }
}


/***/ }),

/***/ 676:
/*!*********************************************!*\
  !*** external "@microsoft/sp-core-library" ***!
  \*********************************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__676__;

/***/ }),

/***/ 909:
/*!*************************************!*\
  !*** external "@microsoft/sp-http" ***!
  \*************************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__909__;

/***/ }),

/***/ 877:
/*!**********************************************!*\
  !*** external "@microsoft/sp-property-pane" ***!
  \**********************************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__877__;

/***/ }),

/***/ 642:
/*!*********************************************!*\
  !*** external "@microsoft/sp-webpart-base" ***!
  \*********************************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__642__;

/***/ }),

/***/ 299:
/*!*****************************************!*\
  !*** external "HomePageWebPartStrings" ***!
  \*****************************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__299__;

/***/ }),

/***/ 959:
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__959__;

/***/ }),

/***/ 398:
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__398__;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/*!**************************************************!*\
  !*** ./lib/webparts/homePage/HomePageWebPart.js ***!
  \**************************************************/
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom */ 398);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @microsoft/sp-core-library */ 676);
/* harmony import */ var _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @microsoft/sp-property-pane */ 877);
/* harmony import */ var _microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _microsoft_sp_webpart_base__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @microsoft/sp-webpart-base */ 642);
/* harmony import */ var _microsoft_sp_webpart_base__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_webpart_base__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var HomePageWebPartStrings__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! HomePageWebPartStrings */ 299);
/* harmony import */ var HomePageWebPartStrings__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(HomePageWebPartStrings__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components_HomePage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./components/HomePage */ 807);
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();







var HomePageWebPart = /** @class */ (function (_super) {
    __extends(HomePageWebPart, _super);
    function HomePageWebPart() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._isDarkTheme = false;
        _this._environmentMessage = '';
        return _this;
    }
    HomePageWebPart.prototype.render = function () {
        var element = react__WEBPACK_IMPORTED_MODULE_0__.createElement(_components_HomePage__WEBPACK_IMPORTED_MODULE_6__["default"], {
            description: this.properties.description,
            isDarkTheme: this._isDarkTheme,
            environmentMessage: this._environmentMessage,
            hasTeamsContext: !!this.context.sdks.microsoftTeams,
            userDisplayName: this.context.pageContext.user.displayName,
            spHttpClient: this.context.spHttpClient
        });
        react_dom__WEBPACK_IMPORTED_MODULE_1__.render(element, this.domElement);
    };
    HomePageWebPart.prototype.onInit = function () {
        var _this = this;
        return this._getEnvironmentMessage().then(function (message) {
            _this._environmentMessage = message;
        });
    };
    HomePageWebPart.prototype._getEnvironmentMessage = function () {
        var _this = this;
        if (!!this.context.sdks.microsoftTeams) { // running in Teams, office.com or Outlook
            return this.context.sdks.microsoftTeams.teamsJs.app.getContext()
                .then(function (context) {
                var environmentMessage = '';
                switch (context.app.host.name) {
                    case 'Office': // running in Office
                        environmentMessage = _this.context.isServedFromLocalhost ? HomePageWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.AppLocalEnvironmentOffice : HomePageWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.AppOfficeEnvironment;
                        break;
                    case 'Outlook': // running in Outlook
                        environmentMessage = _this.context.isServedFromLocalhost ? HomePageWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.AppLocalEnvironmentOutlook : HomePageWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.AppOutlookEnvironment;
                        break;
                    case 'Teams': // running in Teams
                    case 'TeamsModern':
                        environmentMessage = _this.context.isServedFromLocalhost ? HomePageWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.AppLocalEnvironmentTeams : HomePageWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.AppTeamsTabEnvironment;
                        break;
                    default:
                        environmentMessage = HomePageWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.UnknownEnvironment;
                }
                return environmentMessage;
            });
        }
        return Promise.resolve(this.context.isServedFromLocalhost ? HomePageWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.AppLocalEnvironmentSharePoint : HomePageWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.AppSharePointEnvironment);
    };
    HomePageWebPart.prototype.onThemeChanged = function (currentTheme) {
        if (!currentTheme) {
            return;
        }
        this._isDarkTheme = !!currentTheme.isInverted;
        var semanticColors = currentTheme.semanticColors;
        if (semanticColors) {
            this.domElement.style.setProperty('--bodyText', semanticColors.bodyText || null);
            this.domElement.style.setProperty('--link', semanticColors.link || null);
            this.domElement.style.setProperty('--linkHovered', semanticColors.linkHovered || null);
        }
    };
    HomePageWebPart.prototype.onDispose = function () {
        react_dom__WEBPACK_IMPORTED_MODULE_1__.unmountComponentAtNode(this.domElement);
    };
    Object.defineProperty(HomePageWebPart.prototype, "dataVersion", {
        get: function () {
            return _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_2__.Version.parse('1.0');
        },
        enumerable: false,
        configurable: true
    });
    HomePageWebPart.prototype.getPropertyPaneConfiguration = function () {
        return {
            pages: [
                {
                    header: {
                        description: HomePageWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.PropertyPaneDescription
                    },
                    groups: [
                        {
                            groupName: HomePageWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.BasicGroupName,
                            groupFields: [
                                (0,_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_3__.PropertyPaneTextField)('description', {
                                    label: HomePageWebPartStrings__WEBPACK_IMPORTED_MODULE_5__.DescriptionFieldLabel
                                })
                            ]
                        }
                    ]
                }
            ]
        };
    };
    return HomePageWebPart;
}(_microsoft_sp_webpart_base__WEBPACK_IMPORTED_MODULE_4__.BaseClientSideWebPart));
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomePageWebPart);

})();

/******/ 	return __webpack_exports__;
/******/ })()
;
});;
//# sourceMappingURL=home-page-web-part.js.map