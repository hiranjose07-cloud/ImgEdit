import * as React from 'react';
import { SPHttpClient } from '@microsoft/sp-http';
import styles from './HomePage.module.scss';
import teamPhoto from '../assets/img.png';
import type { IHomePageProps } from './IHomePageProps';

const css = styles as unknown as Record<string, string>;
const postcardsApiUrl = "https://sites.ey.com/sites/MENATaxHub/_api/web/lists/getByTitle('PostcardsAndVideos')/items?$select=*,File/Name,File/ServerRelativeUrl&$expand=File";

interface IPostcardListItem {
  ID?: number;
  Id?: number;
  FileRef?: string;
  FileDirRef?: string;
  FileLeafRef?: string;
  EncodedAbsUrl?: string;
  File?: {
    Name?: string;
    ServerRelativeUrl?: string;
  };
}

interface IPostcardApiResponse {
  value?: IPostcardListItem[];
  d?: {
    results?: IPostcardListItem[];
  };
}

interface IPostcard {
  id: number | string;
  name: string;
  url: string;
}

interface ITeamMember {
  name: string;
  role: string;
}

const team: ITeamMember[] = [
  { name: 'Corey Porter', role: 'Audit Transformation Lead' },
  { name: 'Sammi Cassin', role: 'Program Manager' },
  { name: 'Kishore Menon', role: 'Solution Architect' },
  { name: 'Noha Ali', role: 'Communications Lead' },
  { name: 'Rahul L C', role: 'Project Manager' }
];

function MailIcon(): React.ReactElement {
  return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 5h20v14H2V5zm2 2v.5l8 5.5 8-5.5V7H4zm16 3.2-8 5.5-8-5.5V17h16v-6.8z" /></svg>;
}

function PhoneIcon(): React.ReactElement {
  return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6.6 10.8c1.4 2.8 3.8 5.1 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.2.4 2.4.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1C10.6 21 3 13.4 3 4c0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.2.2 2.4.6 3.6.1.3 0 .7-.2 1l-2.3 2.2z" /></svg>;
}

function PersonIcon(): React.ReactElement {
  return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 12a4.5 4.5 0 1 0 0-9 4.5 4.5 0 0 0 0 9zm0 2c-4 0-8 2-8 5v2h16v-2c0-3-4-5-8-5z" /></svg>;
}

function Skyline(): React.ReactElement {
  return (
    <svg className={css.auditSkyline} viewBox="0 0 1400 200" preserveAspectRatio="none" aria-hidden="true">
      <g fill="#1a1a24" opacity=".92">
        <rect x="30" y="90" width="70" height="110" /><rect x="110" y="60" width="55" height="140" />
        <rect x="180" y="100" width="80" height="100" /><rect x="280" y="40" width="60" height="160" />
        <rect x="355" y="80" width="45" height="120" /><rect x="415" y="110" width="90" height="90" />
        <rect x="530" y="55" width="65" height="145" /><rect x="620" y="95" width="50" height="105" />
        <rect x="690" y="30" width="75" height="170" /><rect x="790" y="85" width="55" height="115" />
        <rect x="865" y="65" width="60" height="135" /><rect x="950" y="105" width="85" height="95" />
        <rect x="1060" y="50" width="55" height="150" /><rect x="1135" y="90" width="70" height="110" />
        <rect x="1225" y="70" width="60" height="130" /><rect x="1305" y="100" width="70" height="100" />
      </g>
      <g fill="#ffe600" opacity=".55">
        <rect x="295" y="55" width="6" height="6" /><rect x="310" y="75" width="6" height="6" />
        <rect x="545" y="70" width="6" height="6" /><rect x="705" y="45" width="6" height="6" />
        <rect x="720" y="70" width="6" height="6" /><rect x="880" y="80" width="6" height="6" />
        <rect x="1075" y="65" width="6" height="6" /><rect x="1240" y="85" width="6" height="6" />
      </g>
    </svg>
  );
}

function PostcardArtwork(props: { postcard: IPostcard; large?: boolean }): React.ReactElement {
  return <img
    className={`${css.postcardImage} ${props.large ? css.postcardImageLarge : ''}`}
    src={props.postcard.url}
    alt={props.postcard.name}
  />;
}

function readPostcards(data: IPostcardApiResponse): IPostcard[] {
  const items = Array.isArray(data.value) ? data.value : data.d && data.d.results;
  if (!Array.isArray(items)) {
    throw new Error('The PostcardsAndVideos response did not contain a list of items.');
  }

  const imageExtensions = /\.(avif|bmp|gif|jpe?g|png|svg|tiff?|webp)$/i;
  return items.reduce((postcardItems: IPostcard[], item: IPostcardListItem) => {
    const filePath = item.FileRef || (item.File && item.File.ServerRelativeUrl) || item.EncodedAbsUrl;
    const name = (item.File && item.File.Name) || item.FileLeafRef;
    if (!filePath || !name || !imageExtensions.test(name)) return postcardItems;

    const fileUrl = new URL(filePath, postcardsApiUrl);
    const folderPath = item.FileDirRef || fileUrl.pathname.substring(0, fileUrl.pathname.lastIndexOf('/'));
    const isInPostcardsFolder = folderPath.split('/').some(segment => /^postcards?$/i.test(segment));
    if (!isInPostcardsFolder) return postcardItems;

    postcardItems.push({
      id: item.ID !== undefined ? item.ID : (item.Id !== undefined ? item.Id : filePath),
      name,
      url: fileUrl.href
    });
    return postcardItems;
  }, []);
}

export default function HomePage(props: IHomePageProps): React.ReactElement {
  const [postcards, setPostcards] = React.useState<IPostcard[]>([]);
  const [isLoadingPostcards, setIsLoadingPostcards] = React.useState(true);
  const [postcardsError, setPostcardsError] = React.useState<string | undefined>(undefined);
  const [activePostcard, setActivePostcard] = React.useState<number | undefined>(undefined);
  const [galleryTransition, setGalleryTransition] = React.useState('');
  const modalCloseButton = React.useRef<HTMLButtonElement>(null);
  const activeCardButton = React.useRef<HTMLButtonElement | null>(null);
  const touchStartX = React.useRef<number | undefined>(undefined);
  const activePostcardRef = React.useRef<number | undefined>(undefined);
  const navigationInProgress = React.useRef(false);
  const navigationTimer = React.useRef<number | undefined>(undefined);
  const isGalleryOpen = activePostcard !== undefined;

  React.useEffect(() => {
    let isCancelled = false;
    props.spHttpClient.get(postcardsApiUrl, SPHttpClient.configurations.v1)
      .then(response => {
        if (!response.ok) {
          throw new Error(`SharePoint returned ${response.status} ${response.statusText}.`);
        }
        return response.json() as Promise<IPostcardApiResponse>;
      })
      .then(data => {
        if (isCancelled) return;
        setPostcards(readPostcards(data));
        setIsLoadingPostcards(false);
      })
      .catch(error => {
        if (isCancelled) return;
        setPostcardsError(error instanceof Error ? error.message : 'An unexpected error occurred.');
        setIsLoadingPostcards(false);
      });

    return () => {
      isCancelled = true;
    };
  }, [props.spHttpClient]);

  const closeModal = React.useCallback((): void => {
    if (navigationTimer.current !== undefined) window.clearTimeout(navigationTimer.current);
    navigationTimer.current = undefined;
    navigationInProgress.current = false;
    activePostcardRef.current = undefined;
    setGalleryTransition('');
    setActivePostcard(undefined);
  }, []);
  const showPostcard = React.useCallback((index: number): void => {
    if (postcards.length === 0) return;
    const nextIndex = ((index % postcards.length) + postcards.length) % postcards.length;
    if (activePostcardRef.current === undefined) {
      activePostcardRef.current = nextIndex;
      setActivePostcard(nextIndex);
      return;
    }

    if (nextIndex === activePostcardRef.current || navigationInProgress.current) return;
    const currentIndex = activePostcardRef.current;
    const direction = (nextIndex - currentIndex + postcards.length) % postcards.length <= postcards.length / 2 ? 1 : -1;
    navigationInProgress.current = true;
    setGalleryTransition(direction > 0 ? css.galleryFadeOutNext : css.galleryFadeOutPrevious);
    navigationTimer.current = window.setTimeout(() => {
      activePostcardRef.current = nextIndex;
      setActivePostcard(nextIndex);
      setGalleryTransition(direction > 0 ? css.galleryFadeInNext : css.galleryFadeInPrevious);
      navigationTimer.current = window.setTimeout(() => {
        setGalleryTransition('');
        navigationInProgress.current = false;
        navigationTimer.current = undefined;
      }, 240);
    }, 180);
  }, [postcards.length]);
  const movePostcard = React.useCallback((direction: number): void => {
    const currentIndex = activePostcardRef.current;
    if (currentIndex === undefined) return;
    showPostcard(currentIndex + direction);
  }, [showPostcard]);

  React.useEffect(() => {
    if (activePostcard === undefined) {
      if (activeCardButton.current) activeCardButton.current.focus();
      return;
    }
  }, [activePostcard]);

  React.useEffect(() => {
    if (!isGalleryOpen) return;

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    window.setTimeout(() => {
      if (modalCloseButton.current) modalCloseButton.current.focus();
    }, 0);

    const handleKeyDown = (event: KeyboardEvent): void => {
      if (event.key === 'Escape') {
        event.preventDefault();
        event.stopPropagation();
        closeModal();
      }
      else if (event.key === 'ArrowRight') movePostcard(1);
      else if (event.key === 'ArrowLeft') movePostcard(-1);
    };

    window.addEventListener('keydown', handleKeyDown, true);
    return () => {
      window.removeEventListener('keydown', handleKeyDown, true);
      document.body.style.overflow = previousOverflow;
    };
  }, [isGalleryOpen, closeModal, movePostcard]);

  React.useEffect(() => () => {
    if (navigationTimer.current !== undefined) window.clearTimeout(navigationTimer.current);
  }, []);

  const handleTouchStart = (event: React.TouchEvent<HTMLDivElement>): void => {
    touchStartX.current = event.touches[0].clientX;
  };

  const handleTouchEnd = (event: React.TouchEvent<HTMLDivElement>): void => {
    if (touchStartX.current === undefined) return;
    const distance = event.changedTouches[0].clientX - touchStartX.current;
    if (Math.abs(distance) > 50 && activePostcard !== undefined) movePostcard(distance < 0 ? 1 : -1);
    touchStartX.current = undefined;
  };

  return (
    <main className={css.auditPage}>
      <header className={css.auditHero}>
        <div className={css.auditGlow} />
        <Skyline />
        <span className={css.auditCorner} aria-hidden="true" />
        <span className={css.auditCornerSecondary} aria-hidden="true" />
        <div className={css.auditHeroContent}>
          <h1>Audit Transformation<br />Toolkit</h1>
          <span className={css.auditUnderline} />
        </div>
      </header>

      <section className={css.auditIntro} aria-labelledby="audit-intro-title">
        <div className={css.auditSectionHead}>
          <span className={css.auditSectionBar} />
          <h2 id="audit-intro-title">Future of Audit. Now.</h2>
        </div>
        <p className={css.auditLead}>EY isn&apos;t waiting for the future – we&apos;re shaping it with confidence.</p>
        <p>By combining top talent with innovative technology, a continuous improvement mindset, and a streamlined methodology, we are redefining what it means to bring assurance to the capital markets. With quality as our foundation, we are elevating the experience for our people and our clients.</p>
        <p>The contents of this toolkit will help leaders around the globe and their GBC teams convey a consistent, high-level audit transformation narrative. Further tailoring for local markets and audiences may be necessary. In addition to the global assets, we will continue to curate and share best practice from across the regions for the benefit of all.</p>
        <p>For questions about this toolkit and the resources in it, please reach out to <a href="mailto:corey.porter@ey.com">Corey Porter</a> and <a href="mailto:sammi.cassin@ey.com">Sammi Cassin</a>.</p>
      </section>

      <section className={css.auditSection} id="team" aria-labelledby="team-title">
        <div className={css.auditSectionHead}>
          <span className={css.auditSectionBar} />
          <h2 id="team-title">Our Team</h2>
        </div>
        <p className={css.auditSubhead}>Connect with the team for any questions, support, or collaboration.</p>
        <div className={css.teamGrid}>
          {team.map((member, index) => (
            <article className={css.teamCard} key={member.name} style={{ animationDelay: `${index * 0.08}s` }}>
              <div className={css.teamPhoto}>
                <img className={css.teamPhotoImage} src={teamPhoto} alt={member.name} />
              </div>
              <div className={css.teamBody}>
                <h3>{member.name}</h3>
                <p>{member.role}</p>
                <div className={css.teamIcons}>
                  <a className={css.teamIconButton} href="mailto:auditsupport@ey.com" aria-label={`Email ${member.name}`}><MailIcon /></a>
                  <button className={css.teamIconButton} type="button" disabled aria-label={`Phone number unavailable for ${member.name}`}><PhoneIcon /></button>
                  <button className={css.teamIconButton} type="button" disabled aria-label={`Profile information unavailable for ${member.name}`}><PersonIcon /></button>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className={css.auditSection} id="postcards" aria-labelledby="postcards-title">
        <div className={css.auditSectionHead}>
          <span className={css.auditSectionBar} />
          <h2 id="postcards-title">Postcards</h2>
        </div>
        <p className={css.auditSubhead}>Explore the postcards to support your audit transformation journey.</p>
        {isLoadingPostcards && <p className={css.auditSubhead} role="status">Loading postcards...</p>}
        {postcardsError && <p className={css.auditSubhead} role="alert">Unable to load postcards: {postcardsError}</p>}
        {!isLoadingPostcards && !postcardsError && postcards.length === 0 && (
          <p className={css.auditSubhead}>No postcards are currently available.</p>
        )}
        {postcards.length > 0 && <div className={css.postcardGrid}>
          {postcards.map((postcard, index) => (
            <button
              className={css.postcardButton}
              key={postcard.id}
              type="button"
              aria-label={`Open postcard ${index + 1} of ${postcards.length}`}
              style={{ animationDelay: `${index * 0.06}s` }}
              onClick={(event) => {
                activeCardButton.current = event.currentTarget;
                showPostcard(index);
              }}
            >
              <PostcardArtwork postcard={postcard} />
            </button>
          ))}
        </div>}
      </section>

      <footer className={css.auditFooter}><span>© All Rights Reserved.</span></footer>

      {activePostcard !== undefined && (
        <div
          className={css.galleryModal}
          role="presentation"
          onMouseDown={(event) => { if (event.target === event.currentTarget) closeModal(); }}
        >
          <div className={css.galleryInner}>
            <button className={css.galleryClose} type="button" ref={modalCloseButton} onClick={closeModal} aria-label="Close postcard viewer">×</button>
            <div className={`${css.galleryCard} ${galleryTransition}`} onTouchStart={handleTouchStart} onTouchEnd={handleTouchEnd}>
              <PostcardArtwork postcard={postcards[activePostcard]} large />
            </div>
            <button className={`${css.galleryNav} ${css.galleryPrevious}`} type="button" onClick={() => movePostcard(-1)} aria-label="Previous postcard">‹</button>
            <button className={`${css.galleryNav} ${css.galleryNext}`} type="button" onClick={() => movePostcard(1)} aria-label="Next postcard">›</button>
            <p className={css.galleryPosition} aria-live="polite">{postcards[activePostcard].name} ({activePostcard + 1} of {postcards.length})</p>
            <div className={css.galleryDots} aria-label="Choose postcard">
              {postcards.map((postcard, index) => (
                <button
                  type="button"
                  key={postcard.id}
                  className={`${css.galleryDot} ${index === activePostcard ? css.galleryDotActive : ''}`}
                  aria-label={`Go to postcard ${index + 1}`}
                  aria-current={index === activePostcard ? 'true' : undefined}
                  onClick={() => showPostcard(index)}
                />
              ))}
            </div>
            <p className={css.galleryHint}><kbd>←</kbd><kbd>→</kbd> navigate&nbsp; · &nbsp;<kbd>Esc</kbd> close</p>
          </div>
        </div>
      )}
    </main>
  );
}
