import * as React from 'react';
import type { IHomePageProps } from './IHomePageProps';
export default function HomePage(props: IHomePageProps): React.ReactElement;
//# sourceMappingURL=HomePage.d.ts.map